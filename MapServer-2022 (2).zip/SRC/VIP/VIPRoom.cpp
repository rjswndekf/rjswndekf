#include <RHVIP.h>
#include <MapFunctions.h>

using namespace std;

// Gratt's Treasure Warehouse Max Room 48 (0x0 - 0x2F)
extern int ROOM_PLAYER_NUM_INDEX0_ADDR;
// Gratt's Underground Waterway Upper Max Room 48 (0x0 - 0x2F)
extern int ROOM_PLAYER_NUM_INDEX1_ADDR;
// Gratt's Underground Waterway Lower Max Room 48 (0x0 - 0x2F)
extern int ROOM_PLAYER_NUM_INDEX2_ADDR;
// Gratt's Underground Waterway Max Room 13 (0x0 - 0xC)
extern int ROOM_PLAYER_NUM_INDEX3_ADDR;
// Corrupt Hero's Halls Max Room 58 (0x0 - 0x39)
extern int ROOM_PLAYER_NUM_INDEX4_ADDR;

unsigned char VIP_ROOMS[181];
int VIP_ROOMS_ADDR = (DWORD)VIP_ROOMS;

void VIPRoomEnter(int pDynamic, int pSendPacket)
{
	int addrs;
	int CurPlayerNum = 0;
	int MAP_Index;
	int RoomNum;
	int pData;
	
	pData = (DWORD)pSendPacket + 4;
	addrs = (DWORD)pData;
	MAP_Index = *(reinterpret_cast<short*>(addrs));
	addrs = (DWORD)pData + 2;
	RoomNum = *(reinterpret_cast<short*>(addrs));
	
	MAP_Index &= 0xFFFF;
	RoomNum &= 0xFFFF;

	switch(MAP_Index)
	{
		//Gratt's Treasure Warehouse Max Room 48 (0x0 - 0x2F)
		case 0:
		{
			addrs = ROOM_PLAYER_NUM_INDEX0_ADDR + ((RoomNum * 3) + 2);
			CurPlayerNum = *(reinterpret_cast<char*>(addrs));
			CurPlayerNum &= 0xFF;
			CurPlayerNum += 1;
			if (CurPlayerNum > 255) CurPlayerNum = 255;
			addrs = ROOM_PLAYER_NUM_INDEX0_ADDR + ((RoomNum * 3) + 2);
			*(reinterpret_cast<char*>(addrs)) = (char)CurPlayerNum;
		}
		break;
		
		// Gratt's Underground Waterway Upper Max Room 48 (0x0 - 0x2F)
		case 1:
		{
			addrs = ROOM_PLAYER_NUM_INDEX1_ADDR + ((RoomNum * 3) + 2);
			CurPlayerNum = *(reinterpret_cast<char*>(addrs));
			CurPlayerNum &= 0xFF;
			CurPlayerNum += 1;
			if (CurPlayerNum > 255) CurPlayerNum = 255;
			addrs = ROOM_PLAYER_NUM_INDEX1_ADDR + ((RoomNum * 3) + 2);
			*(reinterpret_cast<char*>(addrs)) = (char)CurPlayerNum;
		}
		break;

		// Gratt's Underground Waterway Lower Max Room 48 (0x0 - 0x2F)
		case 2:
		{
			addrs = ROOM_PLAYER_NUM_INDEX2_ADDR + ((RoomNum * 3) + 2);
			CurPlayerNum = *(reinterpret_cast<char*>(addrs));
			CurPlayerNum &= 0xFF;
			CurPlayerNum += 1;
			if (CurPlayerNum > 255) CurPlayerNum = 255;
			addrs = ROOM_PLAYER_NUM_INDEX2_ADDR + ((RoomNum * 3) + 2);
			*(reinterpret_cast<char*>(addrs)) = (char)CurPlayerNum;
		}
		break;

		// Gratt's Underground Waterway Max Room 13 (0x0 - 0xC)
		case 3:
		{
			addrs = ROOM_PLAYER_NUM_INDEX3_ADDR + ((RoomNum * 3) + 2);
			CurPlayerNum = *(reinterpret_cast<char*>(addrs));
			CurPlayerNum &= 0xFF;
			CurPlayerNum += 1;
			if (CurPlayerNum > 255) CurPlayerNum = 255;
			addrs = ROOM_PLAYER_NUM_INDEX3_ADDR + ((RoomNum * 3) + 2);
			*(reinterpret_cast<char*>(addrs)) = (char)CurPlayerNum;
		}
		break;

		// Corrupt Hero's Halls Max Room 58 (0x0 - 0x39)
		case 4:
		{
			addrs = ROOM_PLAYER_NUM_INDEX4_ADDR + ((RoomNum * 3) + 2);
			CurPlayerNum = *(reinterpret_cast<char*>(addrs));
			CurPlayerNum &= 0xFF;
			CurPlayerNum += 1;
			if (CurPlayerNum > 255) CurPlayerNum = 255;
			addrs = ROOM_PLAYER_NUM_INDEX4_ADDR + ((RoomNum * 3) + 2);
			*(reinterpret_cast<char*>(addrs)) = (char)CurPlayerNum;
		}
		break;
	}
}

void VIPRoomLeave(int pDynamic, int pSendPacket)
{
	int addrs;
	int CurPlayerNum = 0;
	int MAP_Index;
	int RoomNum;
	int pData;

	pData = (DWORD)pSendPacket + 4;
	addrs = (DWORD)pData;
	MAP_Index = *(reinterpret_cast<short*>(addrs));
	addrs = (DWORD)pData + 2;
	RoomNum = *(reinterpret_cast<short*>(addrs));

	MAP_Index &= 0xFFFF;
	RoomNum &= 0xFFFF;

	switch(MAP_Index)
	{
		//Gratt's Treasure Warehouse Max Room 48 (0x0 - 0x2F)
		case 0:
		{
			addrs = ROOM_PLAYER_NUM_INDEX0_ADDR + ((RoomNum * 3) + 2);
			CurPlayerNum = *(reinterpret_cast<char*>(addrs));
			CurPlayerNum &= 0xFF;
			CurPlayerNum -= 1;
			if (CurPlayerNum < 0) CurPlayerNum = 0;
			addrs = ROOM_PLAYER_NUM_INDEX0_ADDR + ((RoomNum * 3) + 2);
			*(reinterpret_cast<char*>(addrs)) = (char)CurPlayerNum;
		}
		break;
		
		// Gratt's Underground Waterway Upper Max Room 48 (0x0 - 0x2F)
		case 1:
		{
			addrs = ROOM_PLAYER_NUM_INDEX1_ADDR + ((RoomNum * 3) + 2);
			CurPlayerNum = *(reinterpret_cast<char*>(addrs));
			CurPlayerNum &= 0xFF;
			CurPlayerNum -= 1;
			if (CurPlayerNum < 0) CurPlayerNum = 0;
			addrs = ROOM_PLAYER_NUM_INDEX1_ADDR + ((RoomNum * 3) + 2);
			*(reinterpret_cast<char*>(addrs)) = (char)CurPlayerNum;
		}
		break;

		// Gratt's Underground Waterway Lower Max Room 48 (0x0 - 0x2F)
		case 2:
		{
			addrs = ROOM_PLAYER_NUM_INDEX2_ADDR + ((RoomNum * 3) + 2);
			CurPlayerNum = *(reinterpret_cast<char*>(addrs));
			CurPlayerNum &= 0xFF;
			CurPlayerNum -= 1;
			if (CurPlayerNum < 0) CurPlayerNum = 0;
			addrs = ROOM_PLAYER_NUM_INDEX2_ADDR + ((RoomNum * 3) + 2);
			*(reinterpret_cast<char*>(addrs)) = (char)CurPlayerNum;
		}
		break;

		// Gratt's Underground Waterway Max Room 13 (0x0 - 0xC)
		case 3:
		{
			addrs = ROOM_PLAYER_NUM_INDEX3_ADDR + ((RoomNum * 3) + 2);
			CurPlayerNum = *(reinterpret_cast<char*>(addrs));
			CurPlayerNum &= 0xFF;
			CurPlayerNum -= 1;
			if (CurPlayerNum < 0) CurPlayerNum = 0;
			addrs = ROOM_PLAYER_NUM_INDEX3_ADDR + ((RoomNum * 3) + 2);
			*(reinterpret_cast<char*>(addrs)) = (char)CurPlayerNum;
		}
		break;

		// Corrupt Hero's Halls Max Room 58 (0x0 - 0x39)
		case 4:
		{
			addrs = ROOM_PLAYER_NUM_INDEX4_ADDR + ((RoomNum * 3) + 2);
			CurPlayerNum = *(reinterpret_cast<char*>(addrs));
			CurPlayerNum &= 0xFF;
			CurPlayerNum -= 1;
			if (CurPlayerNum < 0) CurPlayerNum = 0;
			addrs = ROOM_PLAYER_NUM_INDEX4_ADDR + ((RoomNum * 3) + 2);
			*(reinterpret_cast<char*>(addrs)) = (char)CurPlayerNum;
		}
		break;
	}	
}

/************* RCM_MAP_VIPROOMS 0x252F ***************/
void VIPRooms(int pDynamic, int pSendPacket)
{
	int result;
	int addrs;
	int pData;
	
	memset(VIP_ROOMS,0,sizeof(char)*181);

	pData = (DWORD)pSendPacket + 4;

	result = GetVIPRooms(pDynamic, pData);
	if (result != 0)
	{
		addrs = (DWORD)VIP_ROOMS_ADDR;
		*(reinterpret_cast<char*>(addrs)) = result;
		SendPacket(pDynamic, 0x252F, VIP_ROOMS_ADDR, 0x1);
	}
}

int GetVIPRooms(int pDynamic, int pData)
{
	int addrs;
	int i;
	int SRC;
	int DST;
	int pPlayer;
	int pThis;
	int VIPLevel = 0;
	int Activate = 0;
	int MAP_Index;
	int RoomNum = 0;
	int RoomCount = 0;
	int RoomNumCount = 0;
	int PlayerNum = 0;
	int pSize = 0;

	addrs = pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 2;

	pThis = pPlayer;
	VIPLevel = BioticBaseGetAbility(pThis, 0x90);
	if (VIPLevel == 0) return 2;

	pThis = pPlayer;
	Activate = BioticBaseGetAbility(pThis, 0x91);
	if (Activate == 0) return 2;

	addrs = pData;
	MAP_Index = *(reinterpret_cast<short*>(addrs));
	MAP_Index &= 0xFF;
	
	// Result
	addrs = VIP_ROOMS_ADDR;
	*(reinterpret_cast<char*>(addrs)) = 0;
	// MAP Index
	addrs = VIP_ROOMS_ADDR + 1;
	*(reinterpret_cast<short*>(addrs)) = MAP_Index;

	if (MAP_Index == 0)
	{
		SRC = ROOM_PLAYER_NUM_INDEX0_ADDR;
		RoomCount = 48;
	}
	else if (MAP_Index == 1)
	{
		SRC = ROOM_PLAYER_NUM_INDEX1_ADDR;
		RoomCount = 48;
	}
	else if (MAP_Index == 2)
	{
		SRC = ROOM_PLAYER_NUM_INDEX2_ADDR;
		RoomCount = 48;
	}
	else if (MAP_Index == 3)
	{
		SRC = ROOM_PLAYER_NUM_INDEX3_ADDR;
		RoomCount = 13;
	}
	else if (MAP_Index == 4)
	{
		SRC = ROOM_PLAYER_NUM_INDEX4_ADDR;
		RoomCount = 58;
	}
	else
	{
		SRC = ROOM_PLAYER_NUM_INDEX0_ADDR;
		RoomCount = 48;
	}

	RoomNumCount = RoomCount - 1;
	addrs = VIP_ROOMS_ADDR + 3;
	*(reinterpret_cast<int*>(addrs)) = RoomNumCount;

	DST = VIP_ROOMS_ADDR + 7;
	for(i=0; i < RoomCount; i++)
	{
		addrs = SRC;
		RoomNum = *(reinterpret_cast<short*>(addrs));
		addrs = SRC + 2;
		PlayerNum = *(reinterpret_cast<char*>(addrs));

		addrs = DST;
		*(reinterpret_cast<short*>(addrs)) = (short)RoomNum;
		addrs = DST + 2;
		*(reinterpret_cast<char*>(addrs)) = (char)PlayerNum;

		DST += 3;
		SRC += 3;
	}

	pSize = 7 + (RoomCount * 3);
	pThis = pDynamic;
	SendPacket(pThis, 0x252F, VIP_ROOMS_ADDR, pSize);

	return 0;
}