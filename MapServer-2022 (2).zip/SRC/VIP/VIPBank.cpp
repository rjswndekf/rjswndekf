#include <RHVIP.h>
#include <MapFunctions.h>

using namespace std;

int BANK_EXIT = 0x0044F125;
int BANK_VIP_RET = 0x0044F225;
int VIPBANK_PLAYER;

int VIPBANK2BAG_EXIT = 0x0042FE6A;
int VIPBANK2BAG_VIP_RET = 0x0042FF35;
int VIPBANK2BAG_PLAYER;

int BAG2VIPBANK_EXIT = 0x0042FD54;
int BAG2VIPBANK_VIP_RET = 0x0042F552;
int BAG2VIPBANK_PLAYER;

int VIPBANKMOVE_EXIT = 0x004397FF;
int VIPBANKMOVE_VIP_RET = 0x004398A3;
int VIPBANKMOVE_PLAYER;

int VIPDEPOSIT_EXIT = 0x0043052C;
int VIPDEPOSIT_VIP_RET = 0x004305E2;
int VIPDEPOSIT_PLAYER;

int VIPWITHDRAW_EXIT = 0x00430F2A;
int VIPWITHDRAW_VIP_RET = 0x00430AFA;
int VIPWITHDRAW_PLAYER;

// Call VIP Bank
void VIPBank()
{
	__asm mov ecx,dword ptr ss:[ebp-0x19DC]
	__asm mov VIPBANK_PLAYER,ecx

	CheckVIPBank(VIPBANK_PLAYER);

	__asm test eax,eax
	__asm je RET_EXIT
	__asm jmp BANK_VIP_RET

RET_EXIT:
	__asm jmp BANK_EXIT
}

// VIP Bank to Bag
void VIPBankToBag()
{
	__asm mov ecx,dword ptr ss:[ebp-0x10]
	__asm mov VIPBANK2BAG_PLAYER,ecx

	CheckVIPBank(VIPBANK2BAG_PLAYER);

	__asm test eax,eax
	__asm je RET_EXIT
	__asm jmp VIPBANK2BAG_VIP_RET

RET_EXIT:
	__asm jmp VIPBANK2BAG_EXIT
}

// Bag to VIP Bank
void BagToVIPBank()
{
	__asm mov ecx,dword ptr ss:[ebp-0x24]
	__asm mov BAG2VIPBANK_PLAYER,ecx

	CheckVIPBank(BAG2VIPBANK_PLAYER);

	__asm test eax,eax
	__asm je RET_EXIT
	__asm jmp BAG2VIPBANK_VIP_RET

RET_EXIT:
	__asm mov eax,0x12
	__asm jmp BAG2VIPBANK_EXIT
}

// VIP Bank Item Move
void VIPBankItemMove()
{
	__asm mov edx,dword ptr ss:[ebp-0x10]
	__asm mov VIPBANKMOVE_PLAYER,edx

	CheckVIPBank(VIPBANKMOVE_PLAYER);

	__asm test eax,eax
	__asm je RET_EXIT
	__asm jmp VIPBANKMOVE_VIP_RET

RET_EXIT:
	__asm jmp VIPBANKMOVE_EXIT
}

// VIP Bank Deposit
void VIPBankDeposit()
{
	__asm mov ecx,dword ptr ss:[ebp-0x18]
	__asm mov VIPDEPOSIT_PLAYER,ecx

	CheckVIPBank(VIPDEPOSIT_PLAYER);

	__asm test eax,eax
	__asm je RET_EXIT
	__asm jmp VIPDEPOSIT_VIP_RET

RET_EXIT:
	__asm jmp VIPDEPOSIT_EXIT
}

// VIP Bank Withdraw
void VIPBankWithdraw()
{
	__asm mov ecx,dword ptr ss:[ebp-0x18]
	__asm mov VIPWITHDRAW_PLAYER,ecx

	CheckVIPBank(VIPWITHDRAW_PLAYER);

	__asm test eax,eax
	__asm je RET_EXIT
	__asm jmp VIPWITHDRAW_VIP_RET

RET_EXIT:
	__asm jmp VIPWITHDRAW_EXIT

}

int CheckVIPBank(int pPlayer)
{
	int pThis;
	int VIPLevel;
	int Activate;
	
	pThis = pPlayer;
	VIPLevel = BioticBaseGetAbility(pThis, 0x90);
	if (VIPLevel < 3) return 0;

	pThis = pPlayer;
	Activate = BioticBaseGetAbility(pThis, 0x91);
	if (Activate == 0) return 0;
	
	return 1;
}
