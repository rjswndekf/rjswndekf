#include <RHVIP.h>
#include <MapFunctions.h>

using namespace std;

void VIPReward(int pPlayer)
{
	int addrs;
	int pThis;
	int VIPLevel;
	int Activate;
	int Value;
	
	int VIPAllStats = 0;
	int VIPDefense = 0;
	int VIPAttack = 0;
	int VIPHPAdd = 0;
	int VIPEXPBonusRate = 0;

	int VIPSmeltRate = 0;
	int VIPReinforceRate = 0;
	int VIPCombineRate = 0;
	int VIPCronDropRate = 0;

	pThis = pPlayer;
	VIPLevel = BioticBaseGetAbility(pThis, 0x90);

	pThis = pPlayer;
	Activate = BioticBaseGetAbility(pThis, 0x91);

	if (Activate == 1)
	{
		switch(VIPLevel)
		{
			case 1:
			{
				VIPEXPBonusRate = 300;
				VIPCronDropRate = 10;
			}
			break;
			case 2:
			{
				VIPEXPBonusRate = 310;
				VIPAttack = 300;
				VIPDefense = 300;
				VIPHPAdd = 5000;
				VIPCronDropRate = 20;
			}
			break;
			case 3:
			{
				VIPEXPBonusRate = 330;
				VIPAttack = 700;
				VIPDefense = 700;
				VIPHPAdd = 10000;
				VIPCronDropRate = 30;
			}
			break;
			case 4:
			{
				VIPEXPBonusRate = 350;
				VIPAttack = 1500;
				VIPDefense = 1500;
				VIPHPAdd = 20000;
				VIPCronDropRate = 50;
			}
			break;
		}
		// VIP EXP Bonus Rate
		addrs = pPlayer + 0x1AA4;
		Value = *(reinterpret_cast<int*>(addrs));
		Value += VIPEXPBonusRate;
		*(reinterpret_cast<int*>(addrs)) = Value;

		// VIP All Stats
		if (VIPAllStats != 0)
		{
			pThis = pPlayer + 0x1140;
			Value = EntityBaseStatusGetAbility(pThis, 0x70);
			Value += VIPAllStats;
			pThis = pPlayer + 0x1140;
			EntityBaseStatusSetAbility(pThis, 0x70, Value);

			for(int i = 0; i < 6; i++ )
			{
				pThis = pPlayer + 0x1140;
				Value = EntityBaseStatusGetAbility(pThis, i);

				Value += VIPAllStats;

				pThis = pPlayer + 0x1140;
				EntityBaseStatusSetAbility(pThis, i, Value);
			}
		}

		// VIP Attack
		pThis = pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0x72, VIPAttack);

		// VIP Defense
		pThis = pPlayer + 0x1140;
		Value = EntityBaseStatusGetAbility(pThis, 0x74);
		Value += VIPDefense;
		pThis = pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0x74, Value);

		// VIP HP Add
		pThis = pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0x75, VIPHPAdd);

		// VIP Smelt Rate
		pThis = pPlayer;
		BioticBaseSetAbility(pThis, 0x92, VIPSmeltRate);

		// VIP Reinforce Rate
		pThis = pPlayer;
		BioticBaseSetAbility(pThis, 0x93, VIPReinforceRate);

		// VIP Combine Rate
		pThis = pPlayer;
		BioticBaseSetAbility(pThis, 0x94, VIPCombineRate);

		// VIP Cron Drop Rate
		pThis = pPlayer;
		BioticBaseSetAbility(pThis, 0x95, VIPCronDropRate);
	}

}