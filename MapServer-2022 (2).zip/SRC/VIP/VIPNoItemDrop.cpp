#include <RHVIP.h>
#include <MapFunctions.h>

using namespace std;

int VIPNODROP_ORIG_RET = 0x0053C407;
int VIPNODROP_VIP_RET = 0x0053C42B;
int VIPNODROP_PLAYER;

/******* ASM Funs *******/
extern int CHECKASENABLE;
//int CHECKASSTATE = (DWORD)CheckAffectStatus;

// mov dword ptr ss:[ebp-0x44],0x1   NoDropItem
// mov dword ptr ss:[ebp-0x48],0x1   NoDropEXP

void VIPNoItemDrop()
{
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov VIPNODROP_PLAYER,ecx

	CheckVIPDorp(VIPNODROP_PLAYER);

	__asm test eax,eax
	__asm je RET_CHECK_ORG
	__asm jmp VIPNODROP_VIP_RET

RET_CHECK_ORG:

	__asm push 0xA023
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm add ecx,0x100
	__asm call CHECKASENABLE
	__asm jmp VIPNODROP_ORIG_RET

}

int CheckVIPDorp(int pPlayer)
{
	int pThis;
	int VIPLevel;
	int Activate;
	
	pThis = pPlayer;
	VIPLevel = BioticBaseGetAbility(pThis, 0x90);
	if (VIPLevel < 4) return 0;

	pThis = pPlayer;
	Activate = BioticBaseGetAbility(pThis, 0x91);
	if (Activate == 0) return 0;

	return 1;
}
