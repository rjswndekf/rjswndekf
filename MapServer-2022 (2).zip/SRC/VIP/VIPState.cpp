#include <RHVIP.h>
#include <MapFunctions.h>
#include <RHDB.h>
#include <sqlext.h>
#include <ctime>

using namespace std; 

// 2018 RCM_GATE_VIPSTATE 0xE00A
void VIPState(int pDynamic, int pSendPacket)
{
	// VIPLevel 1-4
	int addrs;
	int VIPLevel = 0;
	int ExpireTime = 0;
	int CurSeconds = 0;

	unsigned char VIPSTATE[12] = {0};
	int VIPSTATE_ADDRS = (DWORD)VIPSTATE;

	GetVIPStatus(pDynamic);

	addrs = (DWORD)pDynamic + 0x2640;
	VIPLevel = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pDynamic + 0x2644;
	ExpireTime = *(reinterpret_cast<int*>(addrs));

	time_t Seconds = time(NULL);
	CurSeconds = (int)Seconds;

	if (CurSeconds > ExpireTime)
	{
		addrs = (DWORD)pDynamic + 0x2648;
		*(reinterpret_cast<int*>(addrs)) = 0;
	}
	else
	{
		addrs = (DWORD)pDynamic + 0x2648;
		*(reinterpret_cast<int*>(addrs)) = 1;
	}

	addrs = VIPSTATE_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = VIPSTATE_ADDRS + 4;
	*(reinterpret_cast<int*>(addrs)) = VIPLevel;
	addrs = VIPSTATE_ADDRS + 8;
	*(reinterpret_cast<int*>(addrs)) = ExpireTime - (8 * 60 * 60);

	SendCryptPacket(pDynamic, 0xE00A, VIPSTATE_ADDRS, 0xC);
}

void GetVIPStatus(int pDynamic)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);
	int addrs;
	int UserID;
	int VIPLevel = 0;
	int ExpireTime = 0;

	addrs = (DWORD)pDynamic + 0x4F0;
	UserID = *(reinterpret_cast<int*>(addrs));

	unsigned char cmdstr[] = "SELECT VIPLevel, ExpireTime FROM RohanUser.dbo.TVIPState WHERE UserID = ?";

	// VIP Status
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UserID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			// VIP Level
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &VIPLevel, 0, NULL);
			// Expire Time
			SQLGetData(SHSTMT, 2, SQL_C_ULONG, &ExpireTime, 0, NULL);
		}
	}

	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);

	addrs = (DWORD)pDynamic + 0x2640;
	*(reinterpret_cast<int*>(addrs)) = VIPLevel;
	addrs = (DWORD)pDynamic + 0x2644;
	*(reinterpret_cast<int*>(addrs)) = ExpireTime;

}

void SetVIPStatus(int pPlayer)
{
	int addrs;
	int pThis = 0;
	int pDynamic;
	int VIPLevel;
	int Activate;
	
	if (pPlayer == 0) return;
	addrs = pPlayer + 0x1098;
	pDynamic = *(reinterpret_cast<int*>(addrs));

	addrs = pDynamic + 0x2640;
	VIPLevel = *(reinterpret_cast<int*>(addrs));
	addrs = pDynamic + 0x2648;
	Activate = *(reinterpret_cast<int*>(addrs));

	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x90, VIPLevel);
	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x91, Activate);

	/***
	addrs = pDynamic + 0x2640;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = pDynamic + 0x2644;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = pDynamic + 0x2648;
	*(reinterpret_cast<int*>(addrs)) = 0;
	***/

}