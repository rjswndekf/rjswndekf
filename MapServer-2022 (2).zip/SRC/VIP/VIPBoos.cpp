#include <RHVIP.h>
#include <MapFunctions.h>

using namespace std;

unsigned char VIP_BOOS[158];
int VIP_BOOS_ADDR = (DWORD)VIP_BOOS;

extern int VIPBOSSBIN_ADDRS;
extern int VIPBOSSBINSIZE;

/************* RCM_MAP_VIPBOOS 0x2530 ***************/
void VIPBoos(int pDynamic, int pSendPacket)
{
	int result;
	int addrs;
	int pData;

	pData = (DWORD)pSendPacket + 4;

	result = GetVIPBoos(pDynamic, pData);
	if (result != 0)
	{
		addrs = (DWORD)VIP_BOOS_ADDR;
		*(reinterpret_cast<char*>(addrs)) = result;
		SendPacket(pDynamic, 0x2530, VIP_BOOS_ADDR, 0x1);
	}
}

int GetVIPBoos(int pDynamic, int pData)
{
	int addrs;
	int pPlayer;
	int pThis;
	int VIPLevel = 0;
	int Activate = 0;
	int MaxCount;
	int SRC;
	int DST;
	int pSize;
	int MonsterID;
	int TeleportalID;
	int pMon;
	int Summon;

	addrs = pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 2;

	pThis = pPlayer;
	VIPLevel = BioticBaseGetAbility(pThis, 0x90);
	if (VIPLevel < 3) return 2;

	pThis = pPlayer;
	Activate = BioticBaseGetAbility(pThis, 0x91);
	if (Activate == 0) return 2;

	// Result
	addrs = VIP_BOOS_ADDR;
	*(reinterpret_cast<char*>(addrs)) = 0;

	// VIP Boss Count;
	MaxCount = VIPBOSSBINSIZE / 0x10;

	addrs = VIP_BOOS_ADDR + 1;
	*(reinterpret_cast<int*>(addrs)) = MaxCount;

	SRC = VIPBOSSBIN_ADDRS;
	DST = VIP_BOOS_ADDR + 5;

	for(int i = 0; i < MaxCount; i++)
	{
		// Monster Type
		addrs = SRC + (i * 0x10);
		MonsterID = *(reinterpret_cast<int*>(addrs));

		// Teleportal ID
		addrs = SRC + (i * 0x10) + 0xC;
		TeleportalID = *(reinterpret_cast<int*>(addrs));

		// Monster Type
		addrs = DST + (i * 9);
		*(reinterpret_cast<int*>(addrs)) = MonsterID;

		// Summon
		pMon = CheckNpc(MonsterID);
		if (pMon == 0) Summon = 0;
		else Summon = 1;

		addrs = DST + (i * 9) + 0x4;
		*(reinterpret_cast<char*>(addrs)) = (char)Summon;

		// Teleportal ID
		addrs = DST + (i * 9) + 0x5;
		*(reinterpret_cast<int*>(addrs)) = TeleportalID;
	}

	pSize = 5 + (MaxCount * 9);
	pThis = pDynamic;
	SendPacket(pThis, 0x2530, VIP_BOOS_ADDR, pSize);

	return 0;
}
