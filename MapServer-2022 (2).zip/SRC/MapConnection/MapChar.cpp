#include <MapConnection.h>
#include <MapFunctions.h>

using namespace std;

unsigned char CHANGEJOB_BUFFER[205] = {0};
unsigned char USETRANSJOB_BUFFER[216] = {0};

int INCABI_TYPE;
int INCABI_PLAYER;
int INCABIDBSK_RET = 0x00428659;

int INCABIMORE_VALUE;
int INCABIMORE_TYPE;
int INCABIMORE_PLAYER;
int INCABIMOREDBSK_RET = 0x00467951;

int CHANGEJOB_ADDRS = (DWORD)CHANGEJOB_BUFFER;
int USETRANSJOB_ADDRS = (DWORD)USETRANSJOB_BUFFER;

int CHANGEJOB_RET = 0x004FBAC4;
int USETRANSJOB_RET = 0x0044AB35;

extern int CHARSTATUS_SIZE;
int CHJOB_PKSIZE = 0x9 + CHARSTATUS_SIZE;
int USETRANSJOB_PKSIZE = 0x14 + CHARSTATUS_SIZE;

/******* ASM Funs *******/
extern int GETSTATUS;
extern int GETABILITY;
extern int SENDPACKET_FUN;

// **** 2018 RCM_MAP_GETSTATUS 0x1801 ************************************************
void GetStatus()
{
	int PlayerPTR;

	__asm mov PlayerPTR, ecx

	PlayerSendStatus(PlayerPTR);

}

// **** 2018 RCM_MAP_INCABILITY_BROADCAST 0x1808 *************************************
void IncabilityBroadcast()
{
	int PlayerPTR;
	
	__asm mov PlayerPTR, ecx

	PlayerBroadcastIncAbility(PlayerPTR);

}

void IncabilityDBTask()
{
	// AbilityType
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm mov edx,dword ptr ds:[ecx]
	__asm mov INCABI_TYPE, edx
	// pPlayer
	__asm mov ecx,dword ptr ss:[ebp-0xC]
	__asm mov INCABI_PLAYER, ecx

	PlayerDBTaskIncAbility(INCABI_PLAYER, INCABI_TYPE, 1);

	__asm jmp INCABIDBSK_RET
}

void IncabilityDBTaskMore()
{
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm movsx edx,word ptr ds:[ecx+0x4]
	__asm mov INCABIMORE_VALUE, edx
	__asm mov eax,dword ptr ds:[ecx]
	__asm mov INCABIMORE_TYPE, eax
	__asm mov ecx,dword ptr ss:[ebp-0xC]
	__asm mov INCABIMORE_PLAYER, ecx

	PlayerDBTaskIncAbility(INCABIMORE_PLAYER, INCABIMORE_TYPE, INCABIMORE_VALUE);

	__asm jmp INCABIMOREDBSK_RET
}

// **** 2018 RCM_MAP_CHANGEJOB 0x180B ************************************************
void ChangeJob()
{
	__asm mov edi, CHANGEJOB_ADDRS
	// +0
	__asm mov byte ptr ss:[edi],0x0
	// PlayerPTR
	__asm mov edx,dword ptr ss:[ebp-0x78]
	__asm mov eax,dword ptr ds:[edx+0x30]
	__asm mov dword ptr ss:[ebp-0x5C],eax
	__asm mov ecx,dword ptr ss:[ebp-0x5C]
	// +5 CharID
	__asm mov dword ptr ss:[edi+0x5],ecx
	// PlayerPTR
	__asm mov edx,dword ptr ss:[ebp-0x78]
	__asm mov eax,dword ptr ds:[edx+0x2C]
	__asm mov dword ptr ss:[ebp-0x60],eax
	__asm mov ecx,dword ptr ss:[ebp-0x60]
	// +1 CType
	__asm mov dword ptr ss:[edi+0x1],ecx
	// +9 CharStatus
	__asm add edi, 0x9
	__asm push edi
	__asm mov ecx,dword ptr ss:[ebp-0x78]
	__asm push ecx
	__asm call GETSTATUS

	// PlayerPTR
	__asm mov eax,dword ptr ss:[ebp-0x78]
	// DynamicPTR
	__asm mov ecx,dword ptr ds:[eax+0x1098]
	__asm mov dword ptr ss:[ebp-0x64],ecx
	// Check DynamicPTR
	__asm cmp dword ptr ss:[ebp-0x64],0x0
	__asm je RET_TARGET

	// Send Packet
	// 2021 PacketSize 0xB9; 2018 PacketSize 0x85;
	__asm mov edi, CHANGEJOB_ADDRS
	__asm mov eax, CHJOB_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x180B
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp CHANGEJOB_RET

}

// **** 2018 RCM_MAP_USETRANSJOB 0x141C **********************************************
void UseTransJob(int SendPacketPTR)
{
	__asm mov edi, USETRANSJOB_ADDRS
	// +0
	__asm mov byte ptr ss:[edi],0x0
	// SendPacket
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov ecx,dword ptr ds:[eax]
	__asm mov edx,dword ptr ds:[eax+0x4]
	// +1
	__asm mov dword ptr ss:[edi+0x1],ecx
	// +5
	__asm mov dword ptr ss:[edi+0x5],edx
	// +9
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov cl,byte ptr ds:[eax+0x8]
	__asm mov byte ptr ss:[edi+0x9],cl
	// +A
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov al,byte ptr ds:[edx+0x9]
	__asm mov byte ptr ss:[edi+0x0A],al
	// +B
	__asm mov cl,byte ptr ss:[ebp-0x68]
	__asm mov byte ptr ss:[edi+0x0B],cl
	// +C CharStatus
	__asm add edi, 0x0C
	__asm push edi
	// PlayerPTR
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm push ecx
	__asm call GETSTATUS
	__asm mov eax,CHARSTATUS_SIZE
	__asm add edi, eax
	// SkillPoint
	__asm push 0x16
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm call GETABILITY
	__asm mov dword ptr ss:[edi],eax
	__asm add edi, 0x4
	//PlayerPTR
	__asm mov eax,dword ptr ss:[ebp-0x64]
	__asm mov ecx,dword ptr ds:[eax+0x2C]
	__asm mov dword ptr ss:[ebp-0xCC],ecx
	__asm mov edx,dword ptr ss:[ebp-0xCC]
	// CType
	__asm mov dword ptr ss:[edi],edx
	__asm add edi, 0x4
	// PlayerPTR
	__asm mov eax,dword ptr ss:[ebp-0x64]
	// DynamicPTR
	__asm mov ecx,dword ptr ds:[eax+0x1098]
	__asm mov dword ptr ss:[ebp-0xD0],ecx
	// Check DynamicPTR
	__asm cmp dword ptr ss:[ebp-0xD0],0x0
	__asm je RET_TARGET
	
	// Send Packet
	// 2021 PacketSize 0xC4; 2018 PacketSize 0x90;
	__asm mov edi, USETRANSJOB_ADDRS
	__asm mov eax, USETRANSJOB_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x141C
	__asm mov ecx,dword ptr ss:[ebp-0xD0]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp USETRANSJOB_RET

}
