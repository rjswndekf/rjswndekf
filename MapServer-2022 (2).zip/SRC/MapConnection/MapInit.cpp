#include <MapConnection.h>
#include <MapFunctions.h>

using namespace std;

unsigned char USEINITSKILL_BUFFER[214] = {0};
int USEINITSKILL_ADDRS = (DWORD)USEINITSKILL_BUFFER;
int USEINITSKILL_RET = 0x00509636;

unsigned char INITSKILL_BUFFER[202] = {0};
int INITSKILL_ADDRS = (DWORD)INITSKILL_BUFFER;
int INITSKILL_RET = 0x0050B8FD;

unsigned char USEINITSTATUS_BUFFER[225] = {0};
int USEINITSTATUS_ADDRS = (DWORD)USEINITSTATUS_BUFFER;
int USEINITSTATUS_RET = 0x00441726;

unsigned char INITSTATUS_BUFFER[224] = {0};
int INITSTATUS_ADDRS = (DWORD)INITSTATUS_BUFFER;
int INITSTATUS_RET = 0x004582A2;

unsigned char RESETABILITY_BUFFER[218] = {0};
int RESETABILITY_ADDRS = (DWORD)RESETABILITY_BUFFER;
int RESETABILITY_RET = 0x0044396B;

unsigned char QUESTINITSTATUS_BUFFER[213] = {0};
int QUESTINITSTATUS_ADDRS = (DWORD)QUESTINITSTATUS_BUFFER;
int QUESTINITSTATUS_RET = 0x0059C24A;

extern int CHARSTATUS_SIZE;
int USEINITSKILL_PKSIZE = 0x12 + CHARSTATUS_SIZE;
int INITSKILL_PKSIZE = 0x6 + CHARSTATUS_SIZE;
int USEINITSTATUS_PKSIZE = 0x1D + CHARSTATUS_SIZE;
int INITSTATUS_PKSIZE = 0x1C + CHARSTATUS_SIZE;
int RESETABILITY_PKSIZE = 0x16 + CHARSTATUS_SIZE;
int QUESTINITSTATUS_PKSIZE = 0x11 + CHARSTATUS_SIZE;

int CHARBASEINIT = 0x004D5390;

/******* ASM Funs *******/
extern int GETSTATUS;
extern int GETABILITY;
extern int SENDPACKET_FUN;
extern int SENDLIFIMANABROADCAST;
extern int GETENTITYSTATUS;


// **** 2018 RCM_MAP_USEINITSKILL 0x1418 *********************************************
void UseInitSkill(int SendPacketPTR)
{
	__asm mov edi, USEINITSKILL_ADDRS
	// +0
	__asm mov byte ptr ds:[edi],0x0
	// SendPacket
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov eax,dword ptr ds:[edx]
	__asm mov ecx,dword ptr ds:[edx+0x4]
	// +1
	__asm mov dword ptr ds:[edi+0x1],eax
	// +5
	__asm mov dword ptr ds:[edi+0x5],ecx
	// SendPacket
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov al,byte ptr ds:[edx+0x8]
	// +9
	__asm mov byte ptr ds:[edi+0x9],al
	// SendPacket
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm mov dl,byte ptr ds:[ecx+0x9]
	// +A
	__asm mov byte ptr ds:[edi+0x0A],dl
	// +B
	__asm mov al,byte ptr ss:[ebp-0x64]
	__asm mov byte ptr ds:[edi+0x0B],al
	// +C CharStatus
	__asm add edi, 0x0C
	__asm push edi
	// PlayerPTR
	__asm mov ecx,dword ptr ss:[ebp-0xD4]
	__asm push ecx
	__asm call GETSTATUS
	__asm mov eax,CHARSTATUS_SIZE
	__asm add edi, eax
	// SkillPoint
	__asm push 0x16
	__asm mov ecx,dword ptr ss:[ebp-0xD4]
	__asm call GETABILITY
	__asm mov dword ptr ds:[edi],eax
	__asm add edi, 0x4

	__asm mov dl,byte ptr ss:[ebp-0x5C]
	__asm mov byte ptr ds:[edi],dl
	__asm add edi, 0x1
	
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov cl,byte ptr ds:[eax+0xA]
	__asm mov byte ptr ds:[edi],cl
	__asm add edi, 0x1
	// PlayerPTR
	__asm mov edx,dword ptr ss:[ebp-0xD4]
	__asm mov eax,dword ptr ds:[edx+0x1098]
	__asm mov dword ptr ss:[ebp-0xCC],eax
	__asm cmp dword ptr ss:[ebp-0xCC],0x0
	__asm je RET_TARGET
	
	// Send Packet
	// 2021 PacketSize 0xC2; 2018 PacketSize 0x7E;
	__asm mov edi, USEINITSKILL_ADDRS
	__asm mov eax, USEINITSKILL_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x1418
	__asm mov ecx,dword ptr ss:[ebp-0xCC]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp USEINITSKILL_RET

}

// **** 2018 RCM_SKILL_INITSKILL 0x1610 **********************************************
void MapInitSkill()
{
	__asm mov edi, INITSKILL_ADDRS
	// +0
	__asm mov byte ptr ds:[edi],cl
	__asm add edi, 0x1
	// +1
	__asm mov dl,byte ptr ss:[ebp+0x8]
	__asm mov byte ptr ds:[edi],dl
	__asm add edi, 0x1
	// CharStatus
	__asm push edi
	__asm mov ecx,dword ptr ss:[ebp-0x298]
	__asm push ecx
	__asm call GETSTATUS
	__asm mov eax,CHARSTATUS_SIZE
	__asm add edi, eax

	__asm mov ecx,dword ptr ss:[ebp-0x1C]
	__asm mov dword ptr ds:[edi],ecx
	__asm add edi, 0x4

	// SendLifeManaBroadcast
	__asm push 0x0
	__asm mov ecx,dword ptr ss:[ebp-0x298]
	__asm call SENDLIFIMANABROADCAST

	__asm mov edx,dword ptr ss:[ebp-0x298]
	__asm mov eax,dword ptr ds:[edx+0x1098]
	__asm mov dword ptr ss:[ebp-0x284],eax
	__asm cmp dword ptr ss:[ebp-0x284],0x0
	__asm je RET_TARGET

	// Send Packet
	// 2021 PacketSize 0xB6; 2018 PacketSize 0x72;
	__asm mov edi, INITSKILL_ADDRS
	__asm mov eax, INITSKILL_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x1610
	__asm mov ecx,dword ptr ss:[ebp-0x284]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp INITSKILL_RET

}

// **** 2018 RCM_MAP_USEINITSTATUS 0x1417 ********************************************
void UseInitStatus()
{
	__asm mov edi, USEINITSTATUS_ADDRS

	__asm mov byte ptr ds:[edi],0x0
	__asm add edi, 0x1

	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm mov edx,dword ptr ds:[ecx]
	__asm mov eax,dword ptr ds:[ecx+0x4]
	__asm mov dword ptr ds:[edi],edx
	__asm add edi, 0x4
	__asm mov dword ptr ds:[edi],eax
	__asm add edi, 0x4

	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm mov dl,byte ptr ds:[ecx+0x8]
	__asm mov byte ptr ds:[edi],dl
	__asm add edi, 0x1

	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov cl,byte ptr ds:[eax+0x9]
	__asm mov byte ptr ds:[edi],cl
	__asm add edi, 0x1

	__asm mov dl,byte ptr ss:[ebp-0x78]
	__asm mov byte ptr ds:[edi],dl
	__asm add edi, 0x1
	
	__asm push edi
	__asm mov ecx,dword ptr ss:[ebp-0x74]
	__asm push ecx
	__asm call GETSTATUS
	__asm mov eax,CHARSTATUS_SIZE
	__asm add edi, eax

	__asm push 0x17
	__asm mov ecx,dword ptr ss:[ebp-0x74]
	__asm call GETABILITY
	__asm mov dword ptr ds:[edi],eax
	__asm add edi, 0x4
	
	__asm mov cl,byte ptr ss:[ebp-0x6C]
	__asm mov byte ptr ds:[edi],cl
	__asm add edi, 0x1

	//2018: 0 3 1 2 4 5
	__asm push 0x0
	__asm mov ecx,dword ptr ss:[ebp-0x74]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x3
	__asm mov ecx,dword ptr ss:[ebp-0x74]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x1
	__asm mov ecx,dword ptr ss:[ebp-0x74]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x2
	__asm mov ecx,dword ptr ss:[ebp-0x74]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x4
	__asm mov ecx,dword ptr ss:[ebp-0x74]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x5
	__asm mov ecx,dword ptr ss:[ebp-0x74]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm mov edx,dword ptr ss:[ebp-0x74]
	__asm mov eax,dword ptr ds:[edx+0x1098]
	__asm mov dword ptr ss:[ebp-0xE4],eax
	__asm cmp dword ptr ss:[ebp-0xE4],0x0
	__asm je RET_TARGET

	// Send Packet
	// 2021 PacketSize 0xCD; 2018 PacketSize 0x89;
	__asm mov edi, USEINITSTATUS_ADDRS
	__asm mov eax, USEINITSTATUS_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x1417
	__asm mov ecx,dword ptr ss:[ebp-0xE4]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp USEINITSTATUS_RET

}


// **** 2018 RCM_MAP_MALL_USE_INITSTATUS 0x1433 **************************************
void MallUseInitStatus()
{
	__asm mov edi, INITSTATUS_ADDRS

	__asm mov byte ptr ds:[edi],0x0

	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov eax,dword ptr ds:[edx]
	__asm mov ecx,dword ptr ds:[edx+0x4]
	__asm mov dword ptr ds:[edi+0x1],eax
	__asm mov dword ptr ds:[edi+0x5],ecx

	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov al,byte ptr ds:[edx+0x8]
	__asm mov byte ptr ds:[edi+0x9],al

	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm mov dl,byte ptr ds:[ecx+0x9]
	__asm mov byte ptr ds:[edi+0xA],dl

	__asm add edi, 0x0B
	__asm push edi
	__asm mov ecx,dword ptr ss:[ebp-0x6C]
	__asm push ecx
	__asm call GETSTATUS
	__asm mov eax,CHARSTATUS_SIZE
	__asm add edi, eax

	__asm push 0x17
	__asm mov ecx,dword ptr ss:[ebp-0x6C]
	__asm call GETABILITY
	__asm mov dword ptr ds:[edi],eax
	__asm add edi, 0x4

	__asm mov cl,byte ptr ss:[ebp-0x64]
	__asm mov byte ptr ds:[edi],cl
	__asm add edi, 0x1

	__asm push 0x0
	__asm mov ecx,dword ptr ss:[ebp-0x6C]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x3
	__asm mov ecx,dword ptr ss:[ebp-0x6C]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x1
	__asm mov ecx,dword ptr ss:[ebp-0x6C]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x2
	__asm mov ecx,dword ptr ss:[ebp-0x6C]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x4
	__asm mov ecx,dword ptr ss:[ebp-0x6C]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x5
	__asm mov ecx,dword ptr ss:[ebp-0x6C]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm mov edx,dword ptr ss:[ebp-0x6C]
	__asm mov eax,dword ptr ds:[edx+0x1098]
	__asm mov dword ptr ss:[ebp-0xE4],eax
	__asm cmp dword ptr ss:[ebp-0xE4],0x0
	__asm je RET_TARGET

	// Send Packet
	// 2021 PacketSize 0xCC; 2018 PacketSize 0x88;
	__asm mov edi, INITSTATUS_ADDRS
	__asm mov eax, INITSTATUS_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x1433
	__asm mov ecx,dword ptr ss:[ebp-0xE4]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp INITSTATUS_RET

}

// **** 2018 RCM_MAP_INIT_STATUS 0x181C **********************************************
void InitStatus()
{
	__asm mov edi, RESETABILITY_ADDRS
	// +0
	__asm mov byte ptr ds:[edi],0x0
	// +1
	__asm mov edx, dword ptr ss:[ebp-0x5F]
	__asm mov dword ptr ds:[edi+0x1],edx
	// +5
	__asm mov dl, byte ptr ss:[ebp-0x5B]
	__asm mov byte ptr ds:[edi+0x5],dl

	// +6 Char Status
	__asm add edi, 0x6
	__asm push edi
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm push ecx
	__asm call GETSTATUS
	__asm mov eax,CHARSTATUS_SIZE
	__asm add edi, eax

	__asm push 0x17
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm call GETABILITY
	__asm mov dword ptr ds:[edi],eax
	__asm add edi, 0x4

	__asm push 0x0
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x3
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x1
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x2
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x4
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x5
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	// Send Packet
	// 2021 PacketSize 0xC6; 2018 PacketSize 0x82;
	__asm mov edi, RESETABILITY_ADDRS
	__asm mov eax, RESETABILITY_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x181C
	__asm mov ecx,dword ptr ss:[ebp-0x118]
	__asm call SENDPACKET_FUN

	__asm jmp RESETABILITY_RET

}

// **** 2018 RCM_MAP_QUEST_INITSTATUS 0x1A0B *****************************************
void QuestInitStatus()
{
	__asm mov edi, QUESTINITSTATUS_ADDRS
	// +0
	__asm mov byte ptr ds:[edi],0x0
	// +1
	__asm add edi, 0x1
	__asm push edi
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm push ecx
	__asm call GETSTATUS
	__asm mov eax,CHARSTATUS_SIZE
	__asm add edi, eax
	
	__asm push 0x17
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov dword ptr ds:[edi],eax
	__asm add edi, 0x4

	//2018: 0 3 1 2 4 5
	__asm push 0x0
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x3
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x1
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x2
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x4
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm push 0x5
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm add ecx,0x1140
	__asm call GETENTITYSTATUS
	__asm mov word ptr ds:[edi],ax
	__asm add edi, 0x2

	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov ecx,dword ptr ds:[eax+0x1098]
	__asm mov dword ptr ss:[ebp-0x120],ecx
	__asm cmp dword ptr ss:[ebp-0x120],0x0
	__asm je RET_TARGET

	// Send Packet
	// 2021 PacketSize 0xC1; 2018 PacketSize 0x7D;
	__asm mov edi, QUESTINITSTATUS_ADDRS
	__asm mov eax, QUESTINITSTATUS_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x1A0B
	__asm mov ecx,dword ptr ss:[ebp-0x120]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp QUESTINITSTATUS_RET

}

// CharBaseStatus Add Aesir
void CharBaseStatus()
{
	__asm push 0x0F
	__asm push 0x19
	__asm push 0x19
	__asm push 0x1E
	__asm push 0x12
	__asm push 0x21
	__asm push 0x9000
	__asm mov ecx,dword ptr ss:[ebp-0x40]
	__asm call CHARBASEINIT

	__asm mov eax,dword ptr ss:[ebp-0x40]
	__asm mov esp,ebp
	__asm pop ebp
	__asm retn
}
