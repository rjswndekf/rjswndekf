#include <MapConnection.h>
#include <MapFunctions.h>
#include <ctime>
#include <RHDB.h>
#include <sqlext.h>

using namespace std;

extern int ATTENDANCE_ADDRS;
int ATTENDANCE_LINE_ZISE = 0x74;

unsigned char DAILYLOGIN_BUFFER[5] = {0};
int DAILYLOGIN_ADDRS = (DWORD)DAILYLOGIN_BUFFER;

extern int LUCKYNUM_WAIT_TIME;
extern int PCMALL_WAIT_TIME;

/******* ASM Funs *******/
//extern int SENDPACKET_FUN;

void DailyLoginRewards(int DynamicPTR, int SendPacketPTR)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	int addrs;
	int PlayerPTR;
	int UserID;
	int DLThis;
	int callen;
	int result;
	int DaysLoggedIn = 0;
	int BadRequest = 0;
	int NotAquired;
	int LastDay = 0;
	unsigned int DLItemID;
	int NextSedTime;
	int PMallTimer;

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);
	
	DLThis = DynamicPTR;
	addrs = (DWORD)DLThis + 0x534;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)PlayerPTR + 0x1A0C;
	UserID = *(reinterpret_cast<int*>(addrs));

	// Get LastDay & DaysLoggedIn
	unsigned char cmdstr1[] = "SELECT DaysLoggedIn, LastDay From RohanMall.dbo.TDailyLogin Where userid = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UserID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS))
	{
		//printf( "Error querying SQL Server\n");
		ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &DaysLoggedIn, 0, NULL);
			SQLGetData(SHSTMT, 2, SQL_C_ULONG, &LastDay, 0, NULL);
		}
	}

	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// Get CurDate
	time_t now = time(0);
	tm *ltm = localtime(&now);
	int CurMonth = ltm->tm_mon;
	int CurDay = ltm->tm_mday;

	// Lucky Number Time
	NextSedTime = (int)now;
	NextSedTime += LUCKYNUM_WAIT_TIME;
	addrs = (DWORD)DynamicPTR + 0x2630;
	*(reinterpret_cast<int*>(addrs)) = NextSedTime;

	// PC-Mall Time
	PMallTimer = (int)now;
	PMallTimer += PCMALL_WAIT_TIME;
	// PC-ROOM Link
	addrs = (DWORD)DynamicPTR + 0x2600;
	*(reinterpret_cast<int*>(addrs)) = 1;
	// PC-Mall Time
	addrs = (DWORD)DynamicPTR + 0x2604;
	*(reinterpret_cast<int*>(addrs)) = PMallTimer;

	if (LastDay == CurDay)
	{
		result = 3;
		NotAquired = 0;
	}
	else
	{
		DLThis = DynamicPTR;
		addrs = (DWORD)DLThis + 0x534;
		PlayerPTR = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)PlayerPTR + 0x1A0C;
		UserID = *(reinterpret_cast<int*>(addrs));

		result = 0;
		NotAquired = 1;
		DaysLoggedIn += 1;
		if (DaysLoggedIn > 28) DaysLoggedIn -= 28;

		//Get Rewards ItemID
		callen = (CurMonth * ATTENDANCE_LINE_ZISE) + (DaysLoggedIn * 4);
		addrs = ATTENDANCE_ADDRS + callen;
		DLItemID = *(reinterpret_cast<unsigned int*>(addrs));

		// Update DB
		unsigned char cmdstr2[] = "UPDATE RohanMall.dbo.TDailyLogin SET DaysLoggedIn = ?, LastDay = ? WHERE userid = ?";
		SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &DaysLoggedIn, 0, 0);
		SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CurDay, 0, 0);
		SQLBindParameter(SHSTMT, 3, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UserID, 0, 0);
		SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr2, SQL_NTS);
		// GO
		SQLFreeStmt(SHSTMT, SQL_CLOSE);

		// Send MailItem
		unsigned char cmdstr3[] = "INSERT INTO RohanMall.dbo.TItem (type, attr, stack, rank, equip_level, equip_dexterity, equip_intelligence, equip_strength, user_id, date) VALUES (?, 0, 1, 0, 0, 0, 0, 0, ?, GETDATE())";
		SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &DLItemID, 0, 0);
		SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UserID, 0, 0);
		SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr3, SQL_NTS);
		// GO
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}

	// Send Packet
	CurMonth += 1;
	addrs = DAILYLOGIN_ADDRS;
	*(reinterpret_cast<char*>(addrs)) = (char)result;
	addrs = DAILYLOGIN_ADDRS + 1;
	*(reinterpret_cast<char*>(addrs)) = (char)DaysLoggedIn;
	addrs = DAILYLOGIN_ADDRS + 2;
	*(reinterpret_cast<char*>(addrs)) = (char)CurMonth;
	addrs = DAILYLOGIN_ADDRS + 3;
	*(reinterpret_cast<char*>(addrs)) = (char)BadRequest;
	addrs = DAILYLOGIN_ADDRS + 4;
	*(reinterpret_cast<char*>(addrs)) = (char)NotAquired;
	DLThis = DynamicPTR;
	SendPacketEX(DLThis, 0x1849, DAILYLOGIN_ADDRS, 0x5);
	
	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
}
