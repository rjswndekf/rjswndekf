#include <MapConnection.h>
#include <MapFunctions.h>
#include <RHDB.h>
#include <sqlext.h>

using namespace std;

int QUESTCHECK_PLAYER;
int QUESTCHECK_ID;
int QUESTCHECK_RETORIG = 0x00429A85;
int QUESTCHECK_RETEXIT = 0x00429AE2;

int QUESTITEM_PLAYRTPTR;
int QUESTITEM_ITEMID;
int QUESTITEM_NID;
int QUESTITEM_RET = 0x004FABCC;


void QuestStateCheckProc()
{
	// pDynamic
	__asm mov dword ptr ss:[ebp-0x20],ecx
	__asm mov eax,dword ptr ss:[ebp-0x20]
	// pPlayer
	__asm mov ecx,dword ptr ds:[eax+0x534]
	__asm mov dword ptr ss:[ebp-0x10],ecx
	__asm mov QUESTCHECK_PLAYER,ecx
	// pData
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov eax,dword ptr ds:[edx]
	__asm mov QUESTCHECK_ID,eax

	QuestCheck(QUESTCHECK_PLAYER, QUESTCHECK_ID);

	__asm test eax,eax
	__asm je ORIG
	//__asm mov eax,0x2
	__asm jmp QUESTCHECK_RETEXIT

ORIG:
	__asm jmp QUESTCHECK_RETORIG

}

int QuestCheck(int pPlayer, int QuestID)
{
	int Result = 0;
	int QuestStateCheck = 0;

	if (QuestID == 2219)
	{
		QuestStateCheck = Quest2219StateCheck(pPlayer);
		if (QuestStateCheck == 0) Result = 1;
	}

	return Result;
}

int Quest2219StateCheck(int pPlayer)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	//int Result;
	int addrs;
	int pThis;
	int CharID;
	//int Reward1;
	int Reward2 = 0;

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);
	
	pThis = pPlayer;
	addrs = (DWORD)pThis + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));
/***
	// Reward1
	unsigned char cmdstr1[] = "SELECT bReward1 FROM RohanGame.dbo.TQuest WHERE nCharID = ? and nQuestID = 2219";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &Reward1, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);
***/
	// Reward2
	unsigned char cmdstr2[] = "SELECT bReward2 FROM RohanGame.dbo.TQuest WHERE nCharID = ? and nQuestID = 2219";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr2, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &Reward2, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
	
	//Result = Reward2;

	return Reward2;
}

void ArrendalQuestItemCheck()
{
	__asm mov ecx,dword ptr ss:[ebp-0x98]
	__asm mov QUESTITEM_PLAYRTPTR,ecx
	__asm mov eax,dword ptr ds:[ecx+0x2C]
	__asm cmp eax, 0x34036
	__asm je CHECKITEM
	__asm cmp eax, 0x34037
	__asm jne RETORIG

CHECKITEM:
	__asm mov eax,dword ptr ss:[ebp-0x90]
	__asm mov QUESTITEM_ITEMID,eax
	__asm mov edx,dword ptr ss:[ebp-0x8C]
	__asm mov QUESTITEM_NID,edx
	__asm cmp eax, 0x284E34
	__asm je INSDBT
	__asm cmp eax, 0x28521C
	__asm jne RETORIG

INSDBT:
	DelWeaponBindData(QUESTITEM_PLAYRTPTR);
	InsWeaponBindData(QUESTITEM_PLAYRTPTR, QUESTITEM_ITEMID, QUESTITEM_NID);
	ArrendalInitBroadcast(QUESTITEM_PLAYRTPTR, QUESTITEM_ITEMID, QUESTITEM_NID);

RETORIG:
	// Original Code
	__asm mov eax,dword ptr ss:[ebp-0x4]
	__asm pop edi
	__asm pop esi
	__asm jmp QUESTITEM_RET
}
