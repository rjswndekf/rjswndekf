#include <MapConnection.h>
#include <MapFunctions.h>
#include <fstream>

using namespace std;

// ServerDir
extern char ServerDirPath[100];
unsigned char PORTALINFO[28];

int pPortalData;
int PortalDataSize;

// 2021 Teleport
int MAPTELE_RET = 0x0043EA4D;
int TELEPLAYER;
unsigned int TELEPRICE;
int GERTTELEPRICE = (DWORD)GetTeleportPrice;
/******* ASM Funs *******/
extern int GETABILITY;
extern int SENDPACKET_FUN;

/***************** Load Xls *****************/
void LoadPortal()
{
	int addrs;
	int MaxCount = 0;
	char * PORTALDATA;

	string XlsFile = "\\Fairy\\MapID\\portal.xls";
	string DirPath;
	string XlsPath;

	DirPath = ServerDirPath;
	XlsPath = DirPath + XlsFile;

	string StrLine;
	string PID;
	string Text;
	int PortalID;

	ifstream CalFile(XlsPath.c_str());
	if (!CalFile) return;
	while(getline (CalFile, StrLine , '\n'))
	{
		MaxCount++;
	}
	CalFile.close();

	PortalDataSize = MaxCount * 0x30;

	PORTALDATA = (char*) malloc(PortalDataSize * sizeof(char));
	memset(PORTALDATA, 0, PortalDataSize);

	pPortalData = (int)PORTALDATA;

	ifstream LoadFile(XlsPath.c_str());

	for (int i = 0; i < MaxCount; i++)
	{
		// Portal ID
		getline (LoadFile, PID , '\t');
		PortalID = atoi(PID.c_str());

		// Portal String
		getline (LoadFile, Text , '\t');
		
		addrs = pPortalData + (i * 0x30);
		*(reinterpret_cast<int*>(addrs)) = PortalID;

		addrs = pPortalData + (i * 0x30) + 4;
		strncpy((char*)addrs, Text.c_str(), Text.size());

		getline (LoadFile, StrLine , '\n');
	}

	LoadFile.close();
}

/***************** Portal *****************/
void Portal()
{
	int pProtal;

	__asm mov pProtal,ecx

	int addrs;
	int pThis;
	int Result;
	int CheckLock;
	int MaxCount = 0;
	int PortalID;
	int pPortalStr;
	int PortalSize;
	string PortalStr;
	

	LoadPortal();

	MaxCount = PortalDataSize / 0x30;
	
	for (int i = 0; i < MaxCount; i++)
	{
		memset(PORTALINFO, 0, 28);

		addrs = pPortalData + (i * 0x30);
		PortalID = *(reinterpret_cast<int*>(addrs));

		pPortalStr = pPortalData + (i * 0x30) + 4;
		PortalStr = (char*)pPortalStr;
		PortalSize = PortalStr.size();

		SetPortalInfo((int)PORTALINFO, 0, 0);
		GetPortalInfo((int)PORTALINFO, pPortalStr, PortalSize);
		SetPortal(pProtal, (int)PORTALINFO, PortalID);
		SetPortalInfo((int)PORTALINFO, 1, 0);
	}

	memset(PORTALINFO, 0, 28);

	addrs = pProtal + 0x90;
	CheckLock = *(reinterpret_cast<int*>(addrs));
	if (CheckLock != 0)
	{
		addrs = (int)PORTALINFO;
		*(reinterpret_cast<int*>(addrs)) = 0x1D0000;
		addrs = pProtal + 0x90;
		CheckLock = *(reinterpret_cast<int*>(addrs));
		pThis = CheckLock + 4;
		Result = GetPortalLock(pThis, (int)PORTALINFO);

		if (Result != 0)
		{
			addrs = (int)PORTALINFO;
			*(reinterpret_cast<int*>(addrs)) = 0x1D0000;
			addrs = pProtal + 0x90;
			CheckLock = *(reinterpret_cast<int*>(addrs));
			pThis = CheckLock + 4;
			Result = SetPortalLock(pThis, (int)PORTALINFO);

			GeoBaseIsLocked(Result);
			GeoBaseIsLocked(0x4BEEB58);
		}
	}
}

// 2021 Map Teleport
void MapTeleport(int SendPacketPTR)
{
	// Check Teleport Type
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm movzx ecx, byte ptr ss:[eax+0xC]
	__asm cmp ecx,0x44
	__asm jnz SEND_PACKET

	__asm mov ecx,dword ptr ss:[ebp-0x14]
	__asm mov TELEPLAYER, ecx

	//Get Player Level
	__asm push 0x15
	__asm mov ecx,TELEPLAYER
	__asm call GETABILITY

	//Get Teleport Price
	__asm push eax
	__asm call GERTTELEPRICE
	__asm mov TELEPRICE,eax

	//Sub Money
	PlayerSubMoney(TELEPLAYER, TELEPRICE, 0x0, 0x4F, 1);

SEND_PACKET:
	// Send Teleport Packet
	__asm push 0xE
	__asm lea ecx,dword ptr ss:[ebp-0x10]
	__asm push ecx
	__asm push 0x8002
	__asm mov ecx,dword ptr ss:[ebp-0x940]
	__asm call SENDPACKET_FUN

	__asm jmp MAPTELE_RET

}

unsigned int GetTeleportPrice(int level)
{
	unsigned int price;

	if (level == 1) price = 27000;
	if (level == 2) price = 27900;
	if (level == 3) price = 28700;
	if (level == 4) price = 29600;
	if (level == 5) price = 30500;
	if (level == 6) price = 31500;
	if (level == 7) price = 32500;
	if (level == 8) price = 33500;
	if (level == 9) price = 34500;
	if (level == 10) price = 35600;
	if (level == 11) price = 36700;
	if (level == 12) price = 37800;
	if (level == 13) price = 39000;
	if (level == 14) price = 40200;
	if (level == 15) price = 41400;
	if (level == 16) price = 42700;
	if (level == 17) price = 44000;
	if (level == 18) price = 45400;
	if (level == 19) price = 46800;
	if (level == 20) price = 48300;
	if (level == 21) price = 49700;
	if (level == 22) price = 51300;
	if (level == 23) price = 52900;
	if (level == 24) price = 54500;
	if (level == 25) price = 56200;
	if (level == 26) price = 57900;
	if (level == 27) price = 59700;
	if (level == 28) price = 61600;
	if (level == 29) price = 63500;
	if (level == 30) price = 65500;
	if (level == 31) price = 67500;
	if (level == 32) price = 69600;
	if (level == 33) price = 71700;
	if (level == 34) price = 73900;
	if (level == 35) price = 76200;
	if (level == 36) price = 78600;
	if (level == 37) price = 81000;
	if (level == 38) price = 83500;
	if (level == 39) price = 86100;
	if (level == 40) price = 88800;
	if (level == 41) price = 91500;
	if (level == 42) price = 94400;
	if (level == 43) price = 97300;
	if (level == 44) price = 100300;
	if (level == 45) price = 103400;
	if (level == 46) price = 106600;
	if (level == 47) price = 109900;
	if (level == 48) price = 113300;
	if (level == 49) price = 116800;
	if (level == 50) price = 120400;
	if (level == 51) price = 124100;
	if (level == 52) price = 128000;
	if (level == 53) price = 131900;
	if (level == 54) price = 136000;
	if (level == 55) price = 140200;
	if (level == 56) price = 144600;
	if (level == 57) price = 149000;
	if (level == 58) price = 153600;
	if (level == 59) price = 158400;
	if (level == 60) price = 163300;
	if (level == 61) price = 168300;
	if (level == 62) price = 173500;
	if (level == 63) price = 178900;
	if (level == 64) price = 184500;
	if (level == 65) price = 190200;
	if (level == 66) price = 196000;
	if (level == 67) price = 202100;
	if (level == 68) price = 208400;
	if (level == 69) price = 214800;
	if (level == 70) price = 221500;
	if (level == 71) price = 228300;
	if (level == 72) price = 235400;
	if (level == 73) price = 242600;
	if (level == 74) price = 250200;
	if (level == 75) price = 257900;
	if (level == 76) price = 265900;
	if (level == 77) price = 274100;
	if (level == 78) price = 282600;
	if (level == 79) price = 291300;
	if (level == 80) price = 300300;
	if (level == 81) price = 309600;
	if (level == 82) price = 319200;
	if (level == 83) price = 329100;
	if (level == 84) price = 339200;
	if (level == 85) price = 349700;
	if (level == 86) price = 360600;
	if (level == 87) price = 371700;
	if (level == 88) price = 383200;
	if (level == 89) price = 395100;
	if (level == 90) price = 407300;
	if (level == 91) price = 419900;
	if (level == 92) price = 432900;
	if (level == 93) price = 446200;
	if (level == 94) price = 460100;
	if (level == 95) price = 474300;
	if (level == 96) price = 489000;
	if (level == 97) price = 504100;
	if (level == 98) price = 519700;
	if (level == 99) price = 535700;
	if (level == 100) price = 552300;
	if (level == 101) price = 569400;
	if (level == 102) price = 587000;
	if (level == 103) price = 605200;
	if (level == 104) price = 623900;
	if (level == 105) price = 643200;
	if (level == 106) price = 663100;
	if (level == 107) price = 683600;
	if (level == 108) price = 704700;
	if (level == 109) price = 726500;
	if (level == 110) price = 749000;
	if (level == 111) price = 772200;
	if (level == 112) price = 796000;
	if (level == 113) price = 820700;
	if (level == 114) price = 846000;
	if (level == 115) price = 872200;
	if (level == 116) price = 899200;
	if (level == 117) price = 927000;
	if (level == 118) price = 955700;
	if (level == 119) price = 985200;
	if (level == 120) price = 1015700;
	if (level == 121) price = 1047100;
	if (level == 122) price = 1079500;
	if (level == 123) price = 1112900;
	if (level == 124) price = 1147300;
	if (level == 125) price = 1182800;
	if (level == 126) price = 1219400;
	if (level == 127) price = 1257100;
	if (level == 128) price = 1296000;
	if (level == 129) price = 1336100;
	if (level == 130) price = 1377400;
	if (level == 131) price = 1420000;
	if (level == 132) price = 1463900;
	if (level == 133) price = 1509200;
	if (level == 134) price = 1555900;
	if (level == 135) price = 1604000;
	if (level == 136) price = 1653600;
	if (level == 137) price = 1704700;
	if (level == 138) price = 1757500;
	if (level == 139) price = 1811800;
	if (level == 140) price = 1867800;
	if (level == 141) price = 1925600;
	if (level == 142) price = 1985200;
	if (level == 143) price = 2046600;
	if (level == 144) price = 2109900;
	if (level == 145) price = 2175100;
	if (level == 146) price = 2242400;
	if (level == 147) price = 2311800;
	if (level == 148) price = 2383300;
	if (level == 149) price = 2457000;
	if (level == 150) price = 2533000;
	if (level == 151) price = 2611300;
	if (level == 152) price = 2692100;
	if (level == 153) price = 2775300;
	if (level == 154) price = 2861200;
	if (level == 155) price = 2949600;
	if (level == 156) price = 3040900;
	if (level == 157) price = 3134900;
	if (level == 158) price = 3231900;
	if (level == 159) price = 3331800;
	if (level == 160) price = 3434900;
	if (level == 161) price = 3541100;
	if (level == 162) price = 3650600;
	if (level == 163) price = 3763600;
	if (level == 164) price = 3880000;
	if (level == 165) price = 4000000;
	if (level > 165) price = 4000000;

	return price;
}
