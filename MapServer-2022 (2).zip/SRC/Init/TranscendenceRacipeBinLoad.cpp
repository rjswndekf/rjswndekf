#include <MapServer.h>

using namespace std;

// ServerDir & attendance Path
extern char ServerDirPath[100];

// TranscendenceRacipe.bin
int TRANSRACIPE_ADDRS;
int TRANSRACIPE_SIZE;

/***************** Load Bin *****************/
void TranscendenceRacipeBin()
{
	int FileSize;
	char * BINBUFFER;

	string BinFile = "\\Data\\transcendenceracipe.bin";
	string DirPath;
	string BinPath;

	DirPath = ServerDirPath;
	BinPath = DirPath + BinFile;

	// Read bin File
	FILE *fp;
	fp = fopen(BinPath.c_str(), "rb");
	if(!fp) return;

	// Cal File Size
	fseek(fp,0L,SEEK_END);
	FileSize = ftell(fp);
	fclose(fp);

	fp = fopen(BinPath.c_str(), "rb");

	BINBUFFER = (char*) malloc(FileSize * sizeof(char));
	memset(BINBUFFER, 0, FileSize);
	fread(BINBUFFER, FileSize, 1, fp);
	fclose(fp);
	
	TRANSRACIPE_ADDRS = (int)BINBUFFER;
	TRANSRACIPE_SIZE = FileSize;
}
