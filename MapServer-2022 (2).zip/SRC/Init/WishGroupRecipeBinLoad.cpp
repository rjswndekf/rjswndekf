#include <MapServer.h>

using namespace std;

// ServerDir & attendance Path
extern char ServerDirPath[100];

// wishgrouprecipe.bin
int WISHGROUPRECIPEBIN_ADDRS;
int WISHGROUPRECIPEBIN_SIZE;

/***************** Load Bin *****************/
void WishGroupRecipeBin()
{
	int FileSize;
	char * BINBUFFER;

	string BinFile = "\\Data\\wishgrouprecipe.bin";
	string DirPath;
	string BinPath;

	DirPath = ServerDirPath;
	BinPath = DirPath + BinFile;

	// Read bin File
	FILE *fp;
	fp = fopen(BinPath.c_str(), "rb");
	if(!fp) return;

	// Cal File Size
	fseek(fp,0L,SEEK_END);
	FileSize = ftell(fp);
	fclose(fp);

	fp = fopen(BinPath.c_str(), "rb");

	BINBUFFER = (char*) malloc(FileSize * sizeof(char));
	memset(BINBUFFER, 0, FileSize);
	fread(BINBUFFER, FileSize, 1, fp);
	fclose(fp);
	
	WISHGROUPRECIPEBIN_ADDRS = (int)BINBUFFER;
	WISHGROUPRECIPEBIN_SIZE = FileSize;
}

int GetWishGroupIDScript(int ID)
{
	int pScript = 0;
	//int addrs;
	int BinID;
	int MaxCount = 0;
	int Offset = 0;

	MaxCount = WISHGROUPRECIPEBIN_SIZE / 0x80;
	Offset = (DWORD)WISHGROUPRECIPEBIN_ADDRS;
	for( int i = 0; i < MaxCount; i++ )
	{
		BinID = *(reinterpret_cast<int*>(Offset));
		if (BinID == ID)
		{
			pScript = Offset;
			break;
		}
		else
		{
			Offset += 0x80;
		}
	}

	return pScript;
}

int CheckGroupID(int pScript, int ItemID)
{
	int Result = 0;
	int addrs;
	int BinItemID;
	int Offset = 0;
	Offset = (DWORD)pScript + 0x38;
	for( int i = 0; i < 18; i++ )
	{
		addrs = Offset + (i * 4);
		BinItemID = *(reinterpret_cast<int*>(addrs));
		if (BinItemID == ItemID)
		{
			Result = 1;
			break;
		}
	}
	return Result;
}
