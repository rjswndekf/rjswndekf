#include <MapServer.h>

using namespace std;

// ServerDir & attendance Path
extern char ServerDirPath[100];

// wishticketgetitem.bin
int WISHGETITEMBIN_ADDRS;
int WISHGETITEMBIN_SIZE;

/***************** Load Bin *****************/
void WishTicketGetItemBin()
{
	int FileSize;
	char * BINBUFFER;

	string BinFile = "\\Data\\wishticketgetitem.bin";
	string DirPath;
	string BinPath;

	DirPath = ServerDirPath;
	BinPath = DirPath + BinFile;

	// Read bin File
	FILE *fp;
	fp = fopen(BinPath.c_str(), "rb");
	if(!fp) return;

	// Cal File Size
	fseek(fp,0L,SEEK_END);
	FileSize = ftell(fp);
	fclose(fp);

	fp = fopen(BinPath.c_str(), "rb");

	BINBUFFER = (char*) malloc(FileSize * sizeof(char));
	memset(BINBUFFER, 0, FileSize);
	fread(BINBUFFER, FileSize, 1, fp);
	fclose(fp);
	
	WISHGETITEMBIN_ADDRS = (int)BINBUFFER;
	WISHGETITEMBIN_SIZE = FileSize;
}
