#include <MapServer.h>

using namespace std;

// ServerDir & attendance Path
extern char ServerDirPath[100];

// luckynumber.bin
int LUCKYNUMLIST_ADDRS;
int LUCKYNUMLIST_SIZE;

/***************** Load Bin *****************/
void LuckynumberBin()
{
	int FileSize;
	char * BINBUFFER;

	string BinFile = "\\Data\\luckynumber.bin";
	string DirPath;
	string BinPath;

	DirPath = ServerDirPath;
	BinPath = DirPath + BinFile;

	// Read bin File
	FILE *fp;
	fp = fopen(BinPath.c_str(), "rb");
	if(!fp) return;

	// Cal File Size
	fseek(fp,0L,SEEK_END);
	FileSize = ftell(fp);
	fclose(fp);

	fp = fopen(BinPath.c_str(), "rb");

	BINBUFFER = (char*) malloc(FileSize * sizeof(char));
	memset(BINBUFFER, 0, FileSize);
	fread(BINBUFFER, FileSize, 1, fp);
	fclose(fp);
	
	LUCKYNUMLIST_ADDRS = (int)BINBUFFER;
	LUCKYNUMLIST_SIZE = FileSize;
}
