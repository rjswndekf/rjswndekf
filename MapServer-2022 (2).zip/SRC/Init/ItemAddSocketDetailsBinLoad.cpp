#include <MapServer.h>

using namespace std;

// ServerDir & attendance Path
extern char ServerDirPath [100];

// itemaddsocketdetails.bin
char ItemAddSocketDetailsPath [100] = {0};
unsigned char ITEMADDSOCKETDS[3420] = {0};
int ITEMADDSOCKETDS_ADDRS = (DWORD)ITEMADDSOCKETDS;
int ITEMADDSOCKETDSSIZE;

/***************** Load Bin *****************/
void ItemAddSocketDetailsBin()
{
	int addrs;
	int n;
	unsigned int IntVar;
	int FileSize;
	int MaxCount;
	char FilePath[] = "\\Data\\itemaddsocketdetails.bin";
	
	strncpy(ItemAddSocketDetailsPath, ServerDirPath, 100);

	/**** Strings merge ****/
	n = 100 - strlen(ItemAddSocketDetailsPath);
    if (n > 0)
	{
		strncat(ItemAddSocketDetailsPath, FilePath, n);
		ItemAddSocketDetailsPath[100] = 0;
    }

	// Read Attendance bin File
	std::string strBin = string(ItemAddSocketDetailsPath);
	FILE *fp;
	fp = fopen(strBin.c_str(), "rb");
	if(!fp) return; 
	
	//Cal File Size
	fseek(fp,0L,SEEK_END); 
	FileSize = ftell(fp);
	fclose(fp);

	ITEMADDSOCKETDSSIZE = FileSize;

	MaxCount = FileSize / 4;
	fp = fopen(strBin.c_str(), "rb");

	addrs = ITEMADDSOCKETDS_ADDRS;

	for( int i=0; i < MaxCount; i++ )
	{
		fread(&IntVar, 4, 1, fp );
		*(reinterpret_cast<unsigned int*>(addrs)) = IntVar;
		addrs += 4;
	}

	fclose(fp);
}
