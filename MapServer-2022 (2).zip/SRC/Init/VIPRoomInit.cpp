#include <MapServer.h>

using namespace std;

// VIP Room
// Gratt's Treasure Warehouse Max Room 48 (0x0 - 0x2F)
unsigned char ROOM_PLAYER_NUM_INDEX0[144] = {0};
int ROOM_PLAYER_NUM_INDEX0_ADDR = (DWORD)ROOM_PLAYER_NUM_INDEX0;
// Gratt's Underground Waterway Upper Max Room 48 (0x0 - 0x2F)
unsigned char ROOM_PLAYER_NUM_INDEX1[144] = {0};
int ROOM_PLAYER_NUM_INDEX1_ADDR = (DWORD)ROOM_PLAYER_NUM_INDEX1;
// Gratt's Underground Waterway Lower Max Room 48 (0x0 - 0x2F)
unsigned char ROOM_PLAYER_NUM_INDEX2[144] = {0};
int ROOM_PLAYER_NUM_INDEX2_ADDR = (DWORD)ROOM_PLAYER_NUM_INDEX2;
// Gratt's Underground Waterway Max Room 13 (0x0 - 0xC)
unsigned char ROOM_PLAYER_NUM_INDEX3[39] = {0};
int ROOM_PLAYER_NUM_INDEX3_ADDR = (DWORD)ROOM_PLAYER_NUM_INDEX3;
// Corrupt Hero's Halls Max Room 58 (0x0 - 0x39)
unsigned char ROOM_PLAYER_NUM_INDEX4[174] = {0};
int ROOM_PLAYER_NUM_INDEX4_ADDR = (DWORD)ROOM_PLAYER_NUM_INDEX4;

void VIPRoomInit()
{
	int addrs;
	int i;

	// Gratt's Treasure Warehouse Max Room 48 (0x0 - 0x2F)
	addrs = ROOM_PLAYER_NUM_INDEX0_ADDR;
	for( i=0; i < 48; i++ )
	{
		*(reinterpret_cast<char*>(addrs)) = (char)i;
		addrs += 3;
	}

	// Gratt's Underground Waterway Upper Max Room 48 (0x0 - 0x2F)
	addrs = ROOM_PLAYER_NUM_INDEX1_ADDR;
	for( i=0; i < 48; i++ )
	{
		*(reinterpret_cast<char*>(addrs)) = (char)i;
		addrs += 3;
	}

	// Gratt's Underground Waterway Lower Max Room 48 (0x0 - 0x2F)
	addrs = ROOM_PLAYER_NUM_INDEX2_ADDR;
	for( i=0; i < 48; i++ )
	{
		*(reinterpret_cast<char*>(addrs)) = (char)i;
		addrs += 3;
	}

	// Gratt's Underground Waterway Max Room 13 (0x0 - 0xC)
	addrs = ROOM_PLAYER_NUM_INDEX3_ADDR;
	for( i=0; i < 13; i++ )
	{
		*(reinterpret_cast<char*>(addrs)) = (char)i;
		addrs += 3;
	}

	// Corrupt Hero's Halls Max Room 58 (0x0 - 0x39)
	addrs = ROOM_PLAYER_NUM_INDEX4_ADDR;
	for( i=0; i < 58; i++ )
	{
		*(reinterpret_cast<char*>(addrs)) = (char)i;
		addrs += 3;
	}

}
