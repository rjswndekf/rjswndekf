#include <MapServer.h>

using namespace std;

// ServerDir & attendance Path
extern char ServerDirPath [100];

// vipboss.bin
char VipBossPath [100] = {0};
unsigned char VIPBOSSBIN[272] = {0};
int VIPBOSSBIN_ADDRS = (DWORD)VIPBOSSBIN;
int VIPBOSSBINSIZE;

/***************** Load Bin *****************/
void VipBossBin()
{
	int addrs;
	int n;
	unsigned int IntVar;
	int FileSize;
	int MaxCount;
	char FilePath[] = "\\Data\\vipboss.bin";
	
	strncpy(VipBossPath, ServerDirPath, 100);

	/**** Strings merge ****/
	n = 100 - strlen(VipBossPath);
    if (n > 0)
	{
		strncat(VipBossPath, FilePath, n);
		VipBossPath[100] = 0;
    }

	// Read Bin File
	std::string strBin = string(VipBossPath);
	FILE *fp;
	fp = fopen(strBin.c_str(), "rb");
	if(!fp) return; 

	//Cal File Size
	fseek(fp,0L,SEEK_END); 
	FileSize = ftell(fp);
	fclose(fp);

	VIPBOSSBINSIZE = FileSize;

	MaxCount = FileSize / 4;
	fp = fopen(strBin.c_str(), "rb");

	addrs = VIPBOSSBIN_ADDRS;

	for( int i=0; i < MaxCount; i++ )
	{
		fread(&IntVar, 4, 1, fp );
		*(reinterpret_cast<unsigned int*>(addrs)) = IntVar;
		addrs += 4;
	}

	fclose(fp);
}
