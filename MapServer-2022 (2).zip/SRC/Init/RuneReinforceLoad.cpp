#include <MapServer.h>

using namespace std;

// ServerDir & attendance Path
extern char ServerDirPath[100];

// runereinforce.bin
int RUNEREINFORCE_ADDRS;
int RUNEREINFORCE_SIZE;

/***************** Load Bin *****************/
void RuneReinforceBin()
{
	int FileSize;
	char * BINBUFFER;

	string BinFile = "\\Data\\runereinforce.bin";
	string DirPath;
	string BinPath;

	DirPath = ServerDirPath;
	BinPath = DirPath + BinFile;

	// Read bin File
	FILE *fp;
	fp = fopen(BinPath.c_str(), "rb");
	if(!fp) return;

	// Cal File Size
	fseek(fp,0L,SEEK_END);
	FileSize = ftell(fp);
	fclose(fp);

	fp = fopen(BinPath.c_str(), "rb");

	BINBUFFER = (char*) malloc(FileSize * sizeof(char));
	memset(BINBUFFER, 0, FileSize);
	fread(BINBUFFER, FileSize, 1, fp);
	fclose(fp);
	
	RUNEREINFORCE_ADDRS = (int)BINBUFFER;
	RUNEREINFORCE_SIZE = FileSize;
}
