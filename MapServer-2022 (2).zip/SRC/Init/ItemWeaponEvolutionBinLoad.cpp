#include <MapServer.h>

using namespace std;

// ServerDir & attendance Path
extern char ServerDirPath[100];

// itemweaponevolution.bin
int WEAPONEVOLUTION_ADDRS;
int WEAPONEVOLUTION_SIZE;

/***************** Load Bin *****************/
void ItemWeaponEvolutionBin()
{
	int FileSize;
	char * BINBUFFER;

	string BinFile = "\\Data\\itemweaponevolution.bin";
	string DirPath;
	string BinPath;

	DirPath = ServerDirPath;
	BinPath = DirPath + BinFile;

	// Read bin File
	FILE *fp;
	fp = fopen(BinPath.c_str(), "rb");
	if(!fp) return;

	// Cal File Size
	fseek(fp,0L,SEEK_END);
	FileSize = ftell(fp);
	fclose(fp);

	fp = fopen(BinPath.c_str(), "rb");

	BINBUFFER = (char*) malloc(FileSize * sizeof(char));
	memset(BINBUFFER, 0, FileSize);
	fread(BINBUFFER, FileSize, 1, fp);
	fclose(fp);
	
	WEAPONEVOLUTION_ADDRS = (int)BINBUFFER;
	WEAPONEVOLUTION_SIZE = FileSize;
}
