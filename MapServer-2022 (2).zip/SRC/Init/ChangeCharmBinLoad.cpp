#include <MapServer.h>

using namespace std;

// ServerDir & attendance Path
extern char ServerDirPath [100];

// changecharm.bin
char ChangeCharmPath [100] = {0};
unsigned char CHCHARMS[170624] = {0};
int CHCHARMS_ADDRS = (DWORD)CHCHARMS;
int CHCHARMSSIZE;

/***************** Load Bin *****************/
void ChangeCharmBin()
{
	int addrs;
	int n;
	unsigned int IntVar;
	int FileSize;
	int MaxCount;
	char FilePath[] = "\\Data\\changecharm.bin";

	strncpy(ChangeCharmPath, ServerDirPath, 100);

	/**** Strings merge ****/
	n = 100 - strlen(ChangeCharmPath);
    if (n > 0)
	{
		strncat(ChangeCharmPath, FilePath, n);
		ChangeCharmPath[100] = 0;
    }

	// Read Bin File
	std::string strBin = string(ChangeCharmPath);
	FILE *fp;
	fp = fopen(strBin.c_str(), "rb");
	if(!fp) return; 

	//Cal File Size
	fseek(fp,0L,SEEK_END); 
	FileSize = ftell(fp);
	fclose(fp);

	CHCHARMSSIZE = FileSize;

	MaxCount = FileSize / 4;
	fp = fopen(strBin.c_str(), "rb");

	addrs = CHCHARMS_ADDRS;

	for( int i=0; i < MaxCount; i++ )
	{
		fread(&IntVar, 4, 1, fp );
		*(reinterpret_cast<unsigned int*>(addrs)) = IntVar;
		addrs += 4;
	}

	fclose(fp);
}
