#include <MapServer.h>
#include <MapHooks.h>

using namespace std; 

// =====================================================================
INT APIENTRY DllMain(HMODULE hDLL, DWORD Reason, LPVOID Reserved)  
{
	switch(Reason){
		case DLL_PROCESS_ATTACH:
			HookMain();
			break;
		case DLL_PROCESS_DETACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
			break;
	}
	return TRUE;  
}

void HookMain()
{
	//MapServer Initialization
	SrvInit();

	// GenHook
	GenHooks();
	// DB Hook
	//DBHooks();
	// MainHooks
	MainHooks();
	// GateCharHooks
	GateCharHooks();
	// ItemHooks
	ItemHooks();
	EquipHooks();
	TalismanHooks();
	EnchantItemHooks();
	BankInventoryHooks();
	UseDCItemHooks();
	ItemBuffScrollHooks();
	MallItemHooks();
	MailHooks();
	// ItemTypeHooks
	ItemTypeHooks();
	// MapConnectionHooks
	MapConnectionHooks();
	CharInitHooks();
	PortalHooks();
	// SkillHooks
	SkillHooks();
	// PacketHooks
	PacketHooks();
	// BattleHooks
	BattleHooks();
	// ScenegraphHooks
	ScenegraphHooks();
	// PartyHooks
	PartyHooks();
	// TradeHooks
	TradeHooks();
	// PlayerHooks
	PlayerHooks();
	ConquerorHooks();
	ExpRecoveryHooks();
	ExpRateHooks();
	CalNewAbilityHooks();
	PlayerLevelHooks();
	// PetHooks
	PetCheckHooks();
	PetHooks();
	// VIP Hook
	VIPHooks();
}

/**********************************************************************************/


