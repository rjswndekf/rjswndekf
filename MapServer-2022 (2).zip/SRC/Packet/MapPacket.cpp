#include <MapPacket.h>
#include <MapConnection.h>
#include <RHVIP.h>
#include <RHMain.h>
#include <RHItem.h>
#include <Player.h>
#include <Party.h>
#include <SkillManager.h>
#include <BattleManager.h>

using namespace std;

int CRYPT_THIS;
int NOCRYPT_THIS;

int CRYPT_RET_ORG = 0x00418DF1;
int CRYPT_RET_END = 0x004191EA;

int NOCRYPT_RET_ORG = 0x00419265;
int NOCRYPT_RET_END = 0x0041DEB9;

// **** Crypt Packet *******************************************************************
void CryptPacketProc(int SendPacketPTR)
{
	// Original Code
	__asm movzx eax,word ptr ds:[edx]
	__asm mov dword ptr ss:[ebp-0x68],eax

	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm mov CRYPT_THIS, ecx

	__asm mov eax, dword ptr ss:[ebp-0x68]
	__asm cmp eax,0xE00A
	__asm je PKE00A

	__asm cmp eax,0xD10F
	__asm je PKD10F

	// Bank Passwd
	__asm cmp eax,0x8006
	__asm je RET_END

	// Skill 16554 0x40AA AxeCall
	__asm cmp eax,0x8003
	__asm je RET_END

	// RET ORIG
	__asm jmp CRYPT_RET_ORG

PKE00A:
	VIPState(CRYPT_THIS, SendPacketPTR);
	__asm jmp RET_END

PKD10F:
	UserDataInit(CRYPT_THIS, SendPacketPTR);
	__asm jmp CRYPT_RET_ORG

RET_END:
	__asm jmp CRYPT_RET_END

}

// **** No Crypt Packet ****************************************************************
void NoCryptPacketProc(int pSendPacket)
{
	// Original Code
	// PacketType
	__asm mov dword ptr ss:[ebp+0xFFFF8464],ecx

	// Dynamic Pointer
	__asm mov edx,dword ptr ss:[ebp+0xFFFF8468]
	__asm mov NOCRYPT_THIS, edx

	NoCryptPacketType(NOCRYPT_THIS, pSendPacket);

	__asm jmp eax
}

int NoCryptPacketType(int pDynamic, int pSendPacket)
{
	int Result = NOCRYPT_RET_ORG;
	int addrs;
	int PacketType;

	addrs = (DWORD)pSendPacket;
	PacketType = *(reinterpret_cast<unsigned short*>(addrs));
	PacketType &= 0xFFFF;

	switch(PacketType)
	{
		// RCM_MAP_USE_DC_ITEM 0x1459 / 0x1477
		/***
		case 0x1459:
		{
			OpenUseItem(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		***/
		// RandomBox Reward
		case 0x1479:
		{
			RandomBoxReward(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Bank Expansion Ticket
		case 0x145B:
		{
			BankExpansionTicket(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Enhancement Ticket
		case 0x1472:
		{
			EnhancementTicket(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// NPC Equip Dismantle
		case 0x1476:
		{
			EquipDismantle(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// RCM_MAP_USE_DC_ITEM 0x1459 / 0x1477
		case 0x1477:
		{
			OpenUseItem(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Enchant Rune
		case 0x147A:
		{
			EnchantRune(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// WishTicket Item Exchange
		case 0x147B:
		{
			WishItemExchange(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		case 0x147C:
		{
			WishItemExchange(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		case 0x147D:
		{
			WishItemExchange(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Wish Level Enchant
		case 0x147E:
		{
			WishLevelEnchant(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Wish Weapon OptionChange
		case 0x147F:
		{
			WishEquipOptionChange(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Wish Armor OptionChange
		case 0x1480:
		{
			WishEquipOptionChange(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Wish Reinforce
		case 0x1481:
		{
			WishReinforce(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// WishTicket Transition
		case 0x1482:
		{
			WishTransition(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// WishTicket GetItem
		case 0x1483:
		{
			WishGetItem(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// ItemCombination EX 2022
		case 0x1484:
		{
			ItemCombinationEX(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Transcendence Exhange NPC Obel
		case 0x151B:
		{
			TranscendenceExhange(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// items Sort
		case 0x151C:
		{
			ItemsSort(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Party Message
		case 0x171E:
		{
			PartyRuneInfo(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// KR Guild Slill 0x1828
		case 0x1828:
		{
			SkillChangeAttitude(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// UseLoudSpeaker
		/***
		case 0x183B:
		{
			UseLoudSpeaker(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		***/
		// DailyLogin
		case 0x1849:
		{
			DailyLoginRewards(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Lucky Number
		case 0x184A:
		{
			LuckyNumber(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		case 0x184B:
		{
			NumberSelect(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		case 0x184C:
		{
			LuckyNumberLast(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		case 0x184D:
		{
			GetLuckyNumberReward(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Transcendence Stat
		case 0x1850:
		{
			TranscendenceStat(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Hunting Bonus
		case 0x1851:
		{
			HuntingBonus(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Talisman List
		case 0x1853:
		{
			TalismanList(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// RCM_MAP_BUY_PC_MALL_ITEM 0x1A22
		case 0x1A22:
		{
			BuyPCMallItem(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// RCM_MAP_BANK_SECRETINFO
		case 0x1D18:
		{
			BankSecretInfo(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Bank Info
		case 0x1D2A:
		{
			BankGetInfo(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		case 0x1D2E:
		{
			ExtendBanktabInfo(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Item Socket Reinforce
		case 0x2310:
		{
			ItemSocketReinforce(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// New ItemRecipe
		case 0x231C:
		{
			ItemRecipe(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Transcendence Racipe
		case 0x231F:
		{
			TranscendenceEquipRacipe(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Transcended Item Socket Reinforce
		case 0x2320:
		{
			TransItemSocketReinforce(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Accessory Socket Reinforce
		case 0x2328:
		{
			AccessorySocketReinforce(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Character Transcendence
		case 0x2322:
		{
			CharacterTranscendence(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Transcendence Exhange Ticket
		case 0x2323:
		{
			TranscendenceWeaponsRacipe(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Transcended Stone Change
		case 0x2324:
		{
			TranscendenceAccessoryRacipe(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Exhange Rune
		case 0x2325:
		{
			ExhangeRune(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Enchant Talisman
		case 0x2326:
		{
			EnchantTalisman(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Igniel's Conversion Stone
		case 0x2327:
		{
			IgnielSkyItemRacipe(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Smelt Hammer
		case 0x2329:
		{
			ChakraSmelt(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Transcendence Sky Add Special Option
		case 0x232A:
		{
			SkyItemAddSpecialOption(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Transcendence Sky Special Option Grant Confirm
		case 0x232B:
		{
			SkyItemSpecialOptionGrantConfirm(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Transcendence Sky Special Option Count Reset
		case 0x232C:
		{
			SkyItemSpecialOptionReset(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Transcendence Sky Special Option Reassignment
		case 0x232D:
		{
			SkyItemSpecialOptionReassignment(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Coliseum Gatekeeper
		case 0x2402:
		{
			Result = NOCRYPT_RET_END;
		}
		break;
		case 0x2403:
		{
			Result = NOCRYPT_RET_END;
		}
		break;
		case 0x2404:
		{
			Result = NOCRYPT_RET_END;
		}
		break;
		// VIP Room
		case 0x252D:
		{
			VIPRoomEnter(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		case 0x252E:
		{
			VIPRoomLeave(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		case 0x252F:
		{
			VIPRooms(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// VIP Boos
		case 0x2530:
		{
			VIPBoos(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Hunting Bonus
		case 0x2806:
		{
			HuntingBonusInit(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_ORG;
		}
		break;
		// Other
		case 0x280C:
		{
			Packet280C(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Trinity Arrendal Evolution
		case 0x3003:
		{
			ArrendalEvolution(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Trinity Arrendal Transmutation
		case 0x3004:
		{
			ArrendalTransmutation(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
		// Trinity Arrendal Growth
		case 0x3007:
		{
			ArrendalGrowthManual(pDynamic, pSendPacket);
			Result = NOCRYPT_RET_END;
		}
		break;
	}

	return Result;
}
