#include <MapPacket.h>

using namespace std;

int UNCRYPTPK_RUN;
int UNNOCRYPTPK_RUN;
int UNCRYPTPKPTR;
int UNCRYPTPKSIZE;
// For VS Net
int UNCRYPTPK_RET = 0x00401020;

int UNNOCRYPTPKPTR;
int UNNOCRYPTPKSIZE;
int UNNOCRYPTPK_RET = 0x0041DEC4;

// **** Unknown Crypt Packet ******************************************************************
void UnknownCryptPacketProc()
{
	// Check Unknown Packet
	__asm cmp eax, 0x80004005
	__asm jnz RET_RESTORE

	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov UNCRYPTPKPTR, edx

	__asm movzx ecx,word ptr ds:[edx+0x2]
	__asm add ecx,0x4
	__asm mov UNCRYPTPKSIZE, ecx

	UNCRYPTPK_RUN = CaptureUnknownPacket(UNCRYPTPKPTR, UNCRYPTPKSIZE, 1);

	__asm xor eax, eax

RET_RESTORE:
	// For VS Net
	__asm jmp UNCRYPTPK_RET

	// For VC++6.0
	//__asm mov esp,ebp
	//__asm pop ebp
	//__asm retn 0x4

}

// **** Unknown NoCrypt Packet ****************************************************************
void UnknownNoCryptPacketProc()
{
	// Backup Register
	__asm push edi
	__asm push esi
	//__asm push ebp
	
	// Check Unknown Packet
	__asm cmp eax, 0x80004005
	__asm jnz RET_RESTORE
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm mov UNNOCRYPTPKPTR, ecx

	__asm movzx esi,word ptr ds:[ecx+0x2]
	__asm add esi,0x4
	__asm mov UNNOCRYPTPKSIZE, esi
	
	UNNOCRYPTPK_RUN = CaptureUnknownPacket(UNNOCRYPTPKPTR, UNNOCRYPTPKSIZE, 0);

	__asm xor eax, eax

RET_RESTORE:
	// Restore Register
	//__asm pop ebp
	__asm pop esi
	__asm pop edi
	// Original Code
	__asm mov ecx,dword ptr ss:[ebp-0x124]
	
	__asm jmp UNNOCRYPTPK_RET
}

int CaptureUnknownPacket(int PacketPTR, int PacketSize, int Crypt)
{
	// Crypt 0=NoCrypt 1=Crypt 
	int i;
	
	string CryptPacket = "Crypt Client Packet";
	string NoCryptPacket = "NoCrypt Client Packet";

	string Text = "";
	string hexstr = "";
	unsigned int bytep;

	// Write files in binary format
	for ( i = 0; i < PacketSize; i++ )
	{
		int Addrs = PacketPTR;
		Addrs += i;

		bytep = *(reinterpret_cast<unsigned char*>(Addrs));

		switch(bytep) {
			case 0: hexstr="00 "; break;
			case 1: hexstr="01 "; break;
			case 2: hexstr="02 "; break;
			case 3: hexstr="03 "; break;
			case 4: hexstr="04 "; break;
			case 5: hexstr="05 "; break;
			case 6: hexstr="06 "; break;
			case 7: hexstr="07 "; break;
			case 8: hexstr="08 "; break;
			case 9: hexstr="09 "; break;
			case 10: hexstr="0A "; break;
			case 11: hexstr="0B "; break;
			case 12: hexstr="0C "; break;
			case 13: hexstr="0D "; break;
			case 14: hexstr="0E "; break;
			case 15: hexstr="0F "; break;
			case 16: hexstr="10 "; break;
			case 17: hexstr="11 "; break;
			case 18: hexstr="12 "; break;
			case 19: hexstr="13 "; break;
			case 20: hexstr="14 "; break;
			case 21: hexstr="15 "; break;
			case 22: hexstr="16 "; break;
			case 23: hexstr="17 "; break;
			case 24: hexstr="18 "; break;
			case 25: hexstr="19 "; break;
			case 26: hexstr="1A "; break;
			case 27: hexstr="1B "; break;
			case 28: hexstr="1C "; break;
			case 29: hexstr="1D "; break;
			case 30: hexstr="1E "; break;
			case 31: hexstr="1F "; break;
			case 32: hexstr="20 "; break;
			case 33: hexstr="21 "; break;
			case 34: hexstr="22 "; break;
			case 35: hexstr="23 "; break;
			case 36: hexstr="24 "; break;
			case 37: hexstr="25 "; break;
			case 38: hexstr="26 "; break;
			case 39: hexstr="27 "; break;
			case 40: hexstr="28 "; break;
			case 41: hexstr="29 "; break;
			case 42: hexstr="2A "; break;
			case 43: hexstr="2B "; break;
			case 44: hexstr="2C "; break;
			case 45: hexstr="2D "; break;
			case 46: hexstr="2E "; break;
			case 47: hexstr="2F "; break;
			case 48: hexstr="30 "; break;
			case 49: hexstr="31 "; break;
			case 50: hexstr="32 "; break;
			case 51: hexstr="33 "; break;
			case 52: hexstr="34 "; break;
			case 53: hexstr="35 "; break;
			case 54: hexstr="36 "; break;
			case 55: hexstr="37 "; break;
			case 56: hexstr="38 "; break;
			case 57: hexstr="39 "; break;
			case 58: hexstr="3A "; break;
			case 59: hexstr="3B "; break;
			case 60: hexstr="3C "; break;
			case 61: hexstr="3D "; break;
			case 62: hexstr="3E "; break;
			case 63: hexstr="3F "; break;
			case 64: hexstr="40 "; break;
			case 65: hexstr="41 "; break;
			case 66: hexstr="42 "; break;
			case 67: hexstr="43 "; break;
			case 68: hexstr="44 "; break;
			case 69: hexstr="45 "; break;
			case 70: hexstr="46 "; break;
			case 71: hexstr="47 "; break;
			case 72: hexstr="48 "; break;
			case 73: hexstr="49 "; break;
			case 74: hexstr="4A "; break;
			case 75: hexstr="4B "; break;
			case 76: hexstr="4C "; break;
			case 77: hexstr="4D "; break;
			case 78: hexstr="4E "; break;
			case 79: hexstr="4F "; break;
			case 80: hexstr="50 "; break;
			case 81: hexstr="51 "; break;
			case 82: hexstr="52 "; break;
			case 83: hexstr="53 "; break;
			case 84: hexstr="54 "; break;
			case 85: hexstr="55 "; break;
			case 86: hexstr="56 "; break;
			case 87: hexstr="57 "; break;
			case 88: hexstr="58 "; break;
			case 89: hexstr="59 "; break;
			case 90: hexstr="5A "; break;
			case 91: hexstr="5B "; break;
			case 92: hexstr="5C "; break;
			case 93: hexstr="5D "; break;
			case 94: hexstr="5E "; break;
			case 95: hexstr="5F "; break;
			case 96: hexstr="60 "; break;
			case 97: hexstr="61 "; break;
			case 98: hexstr="62 "; break;
			case 99: hexstr="63 "; break;
			case 100: hexstr="64 "; break;
			case 101: hexstr="65 "; break;
			case 102: hexstr="66 "; break;
			case 103: hexstr="67 "; break;
			case 104: hexstr="68 "; break;
			case 105: hexstr="69 "; break;
			case 106: hexstr="6A "; break;
			case 107: hexstr="6B "; break;
			case 108: hexstr="6C "; break;
			case 109: hexstr="6D "; break;
			case 110: hexstr="6E "; break;
			case 111: hexstr="6F "; break;
			case 112: hexstr="70 "; break;
			case 113: hexstr="71 "; break;
			case 114: hexstr="72 "; break;
			case 115: hexstr="73 "; break;
			case 116: hexstr="74 "; break;
			case 117: hexstr="75 "; break;
			case 118: hexstr="76 "; break;
			case 119: hexstr="77 "; break;
			case 120: hexstr="78 "; break;
			case 121: hexstr="79 "; break;
			case 122: hexstr="7A "; break;
			case 123: hexstr="7B "; break;
			case 124: hexstr="7C "; break;
			case 125: hexstr="7D "; break;
			case 126: hexstr="7E "; break;
			case 127: hexstr="7F "; break;
			case 128: hexstr="80 "; break;
			case 129: hexstr="81 "; break;
			case 130: hexstr="82 "; break;
			case 131: hexstr="83 "; break;
			case 132: hexstr="84 "; break;
			case 133: hexstr="85 "; break;
			case 134: hexstr="86 "; break;
			case 135: hexstr="87 "; break;
			case 136: hexstr="88 "; break;
			case 137: hexstr="89 "; break;
			case 138: hexstr="8A "; break;
			case 139: hexstr="8B "; break;
			case 140: hexstr="8C "; break;
			case 141: hexstr="8D "; break;
			case 142: hexstr="8E "; break;
			case 143: hexstr="8F "; break;
			case 144: hexstr="90 "; break;
			case 145: hexstr="91 "; break;
			case 146: hexstr="92 "; break;
			case 147: hexstr="93 "; break;
			case 148: hexstr="94 "; break;
			case 149: hexstr="95 "; break;
			case 150: hexstr="96 "; break;
			case 151: hexstr="97 "; break;
			case 152: hexstr="98 "; break;
			case 153: hexstr="99 "; break;
			case 154: hexstr="9A "; break;
			case 155: hexstr="9B "; break;
			case 156: hexstr="9C "; break;
			case 157: hexstr="9D "; break;
			case 158: hexstr="9E "; break;
			case 159: hexstr="9F "; break;
			case 160: hexstr="A0 "; break;
			case 161: hexstr="A1 "; break;
			case 162: hexstr="A2 "; break;
			case 163: hexstr="A3 "; break;
			case 164: hexstr="A4 "; break;
			case 165: hexstr="A5 "; break;
			case 166: hexstr="A6 "; break;
			case 167: hexstr="A7 "; break;
			case 168: hexstr="A8 "; break;
			case 169: hexstr="A9 "; break;
			case 170: hexstr="AA "; break;
			case 171: hexstr="AB "; break;
			case 172: hexstr="AC "; break;
			case 173: hexstr="AD "; break;
			case 174: hexstr="AE "; break;
			case 175: hexstr="AF "; break;
			case 176: hexstr="B0 "; break;
			case 177: hexstr="B1 "; break;
			case 178: hexstr="B2 "; break;
			case 179: hexstr="B3 "; break;
			case 180: hexstr="B4 "; break;
			case 181: hexstr="B5 "; break;
			case 182: hexstr="B6 "; break;
			case 183: hexstr="B7 "; break;
			case 184: hexstr="B8 "; break;
			case 185: hexstr="B9 "; break;
			case 186: hexstr="BA "; break;
			case 187: hexstr="BB "; break;
			case 188: hexstr="BC "; break;
			case 189: hexstr="BD "; break;
			case 190: hexstr="BE "; break;
			case 191: hexstr="BF "; break;
			case 192: hexstr="C0 "; break;
			case 193: hexstr="C1 "; break;
			case 194: hexstr="C2 "; break;
			case 195: hexstr="C3 "; break;
			case 196: hexstr="C4 "; break;
			case 197: hexstr="C5 "; break;
			case 198: hexstr="C6 "; break;
			case 199: hexstr="C7 "; break;
			case 200: hexstr="C8 "; break;
			case 201: hexstr="C9 "; break;
			case 202: hexstr="CA "; break;
			case 203: hexstr="CB "; break;
			case 204: hexstr="CC "; break;
			case 205: hexstr="CD "; break;
			case 206: hexstr="CE "; break;
			case 207: hexstr="CF "; break;
			case 208: hexstr="D0 "; break;
			case 209: hexstr="D1 "; break;
			case 210: hexstr="D2 "; break;
			case 211: hexstr="D3 "; break;
			case 212: hexstr="D4 "; break;
			case 213: hexstr="D5 "; break;
			case 214: hexstr="D6 "; break;
			case 215: hexstr="D7 "; break;
			case 216: hexstr="D8 "; break;
			case 217: hexstr="D9 "; break;
			case 218: hexstr="DA "; break;
			case 219: hexstr="DB "; break;
			case 220: hexstr="DC "; break;
			case 221: hexstr="DD "; break;
			case 222: hexstr="DE "; break;
			case 223: hexstr="DF "; break;
			case 224: hexstr="E0 "; break;
			case 225: hexstr="E1 "; break;
			case 226: hexstr="E2 "; break;
			case 227: hexstr="E3 "; break;
			case 228: hexstr="E4 "; break;
			case 229: hexstr="E5 "; break;
			case 230: hexstr="E6 "; break;
			case 231: hexstr="E7 "; break;
			case 232: hexstr="E8 "; break;
			case 233: hexstr="E9 "; break;
			case 234: hexstr="EA "; break;
			case 235: hexstr="EB "; break;
			case 236: hexstr="EC "; break;
			case 237: hexstr="ED "; break;
			case 238: hexstr="EE "; break;
			case 239: hexstr="EF "; break;
			case 240: hexstr="F0 "; break;
			case 241: hexstr="F1 "; break;
			case 242: hexstr="F2 "; break;
			case 243: hexstr="F3 "; break;
			case 244: hexstr="F4 "; break;
			case 245: hexstr="F5 "; break;
			case 246: hexstr="F6 "; break;
			case 247: hexstr="F7 "; break;
			case 248: hexstr="F8 "; break;
			case 249: hexstr="F9 "; break;
			case 250: hexstr="FA "; break;
			case 251: hexstr="FB "; break;
			case 252: hexstr="FC "; break;
			case 253: hexstr="FD "; break;
			case 254: hexstr="FE "; break;
			case 255: hexstr="FF "; break;
		}

		Text += hexstr;

	}

	FILE * pFile;

	pFile = fopen ("UnknownPacket.txt", "at+"); // "wb" Write files only in binary append mode.

	if (Crypt) fwrite(CryptPacket.c_str(), 1, CryptPacket.size(), pFile);
	else fwrite(NoCryptPacket.c_str(), 1, NoCryptPacket.size(), pFile);

	fwrite("\n", 1, 1, pFile);
	fwrite(Text.c_str(), 1, Text.size(), pFile);
	fwrite("\n", 1, 1, pFile);
	fwrite("\n", 1, 1, pFile);

	fclose (pFile);

	return 0;
}

// DeBug
int CheckPacket(int PacketPTR, int PacketSize, int Crypt)
{
	// Crypt 0=NoCrypt 1=Crypt 
	int i;
	
	string CryptPacket = "Crypt Client Packet";
	string NoCryptPacket = "NoCrypt Client Packet";

	string Text = "";
	string hexstr = "";
	unsigned int bytep;

	// Write files in binary format
	for ( i = 0; i < PacketSize; i++ )
	{
		int Addrs = PacketPTR;
		Addrs += i;

		bytep = *(reinterpret_cast<unsigned char*>(Addrs));

		switch(bytep) {
			case 0: hexstr="00 "; break;
			case 1: hexstr="01 "; break;
			case 2: hexstr="02 "; break;
			case 3: hexstr="03 "; break;
			case 4: hexstr="04 "; break;
			case 5: hexstr="05 "; break;
			case 6: hexstr="06 "; break;
			case 7: hexstr="07 "; break;
			case 8: hexstr="08 "; break;
			case 9: hexstr="09 "; break;
			case 10: hexstr="0A "; break;
			case 11: hexstr="0B "; break;
			case 12: hexstr="0C "; break;
			case 13: hexstr="0D "; break;
			case 14: hexstr="0E "; break;
			case 15: hexstr="0F "; break;
			case 16: hexstr="10 "; break;
			case 17: hexstr="11 "; break;
			case 18: hexstr="12 "; break;
			case 19: hexstr="13 "; break;
			case 20: hexstr="14 "; break;
			case 21: hexstr="15 "; break;
			case 22: hexstr="16 "; break;
			case 23: hexstr="17 "; break;
			case 24: hexstr="18 "; break;
			case 25: hexstr="19 "; break;
			case 26: hexstr="1A "; break;
			case 27: hexstr="1B "; break;
			case 28: hexstr="1C "; break;
			case 29: hexstr="1D "; break;
			case 30: hexstr="1E "; break;
			case 31: hexstr="1F "; break;
			case 32: hexstr="20 "; break;
			case 33: hexstr="21 "; break;
			case 34: hexstr="22 "; break;
			case 35: hexstr="23 "; break;
			case 36: hexstr="24 "; break;
			case 37: hexstr="25 "; break;
			case 38: hexstr="26 "; break;
			case 39: hexstr="27 "; break;
			case 40: hexstr="28 "; break;
			case 41: hexstr="29 "; break;
			case 42: hexstr="2A "; break;
			case 43: hexstr="2B "; break;
			case 44: hexstr="2C "; break;
			case 45: hexstr="2D "; break;
			case 46: hexstr="2E "; break;
			case 47: hexstr="2F "; break;
			case 48: hexstr="30 "; break;
			case 49: hexstr="31 "; break;
			case 50: hexstr="32 "; break;
			case 51: hexstr="33 "; break;
			case 52: hexstr="34 "; break;
			case 53: hexstr="35 "; break;
			case 54: hexstr="36 "; break;
			case 55: hexstr="37 "; break;
			case 56: hexstr="38 "; break;
			case 57: hexstr="39 "; break;
			case 58: hexstr="3A "; break;
			case 59: hexstr="3B "; break;
			case 60: hexstr="3C "; break;
			case 61: hexstr="3D "; break;
			case 62: hexstr="3E "; break;
			case 63: hexstr="3F "; break;
			case 64: hexstr="40 "; break;
			case 65: hexstr="41 "; break;
			case 66: hexstr="42 "; break;
			case 67: hexstr="43 "; break;
			case 68: hexstr="44 "; break;
			case 69: hexstr="45 "; break;
			case 70: hexstr="46 "; break;
			case 71: hexstr="47 "; break;
			case 72: hexstr="48 "; break;
			case 73: hexstr="49 "; break;
			case 74: hexstr="4A "; break;
			case 75: hexstr="4B "; break;
			case 76: hexstr="4C "; break;
			case 77: hexstr="4D "; break;
			case 78: hexstr="4E "; break;
			case 79: hexstr="4F "; break;
			case 80: hexstr="50 "; break;
			case 81: hexstr="51 "; break;
			case 82: hexstr="52 "; break;
			case 83: hexstr="53 "; break;
			case 84: hexstr="54 "; break;
			case 85: hexstr="55 "; break;
			case 86: hexstr="56 "; break;
			case 87: hexstr="57 "; break;
			case 88: hexstr="58 "; break;
			case 89: hexstr="59 "; break;
			case 90: hexstr="5A "; break;
			case 91: hexstr="5B "; break;
			case 92: hexstr="5C "; break;
			case 93: hexstr="5D "; break;
			case 94: hexstr="5E "; break;
			case 95: hexstr="5F "; break;
			case 96: hexstr="60 "; break;
			case 97: hexstr="61 "; break;
			case 98: hexstr="62 "; break;
			case 99: hexstr="63 "; break;
			case 100: hexstr="64 "; break;
			case 101: hexstr="65 "; break;
			case 102: hexstr="66 "; break;
			case 103: hexstr="67 "; break;
			case 104: hexstr="68 "; break;
			case 105: hexstr="69 "; break;
			case 106: hexstr="6A "; break;
			case 107: hexstr="6B "; break;
			case 108: hexstr="6C "; break;
			case 109: hexstr="6D "; break;
			case 110: hexstr="6E "; break;
			case 111: hexstr="6F "; break;
			case 112: hexstr="70 "; break;
			case 113: hexstr="71 "; break;
			case 114: hexstr="72 "; break;
			case 115: hexstr="73 "; break;
			case 116: hexstr="74 "; break;
			case 117: hexstr="75 "; break;
			case 118: hexstr="76 "; break;
			case 119: hexstr="77 "; break;
			case 120: hexstr="78 "; break;
			case 121: hexstr="79 "; break;
			case 122: hexstr="7A "; break;
			case 123: hexstr="7B "; break;
			case 124: hexstr="7C "; break;
			case 125: hexstr="7D "; break;
			case 126: hexstr="7E "; break;
			case 127: hexstr="7F "; break;
			case 128: hexstr="80 "; break;
			case 129: hexstr="81 "; break;
			case 130: hexstr="82 "; break;
			case 131: hexstr="83 "; break;
			case 132: hexstr="84 "; break;
			case 133: hexstr="85 "; break;
			case 134: hexstr="86 "; break;
			case 135: hexstr="87 "; break;
			case 136: hexstr="88 "; break;
			case 137: hexstr="89 "; break;
			case 138: hexstr="8A "; break;
			case 139: hexstr="8B "; break;
			case 140: hexstr="8C "; break;
			case 141: hexstr="8D "; break;
			case 142: hexstr="8E "; break;
			case 143: hexstr="8F "; break;
			case 144: hexstr="90 "; break;
			case 145: hexstr="91 "; break;
			case 146: hexstr="92 "; break;
			case 147: hexstr="93 "; break;
			case 148: hexstr="94 "; break;
			case 149: hexstr="95 "; break;
			case 150: hexstr="96 "; break;
			case 151: hexstr="97 "; break;
			case 152: hexstr="98 "; break;
			case 153: hexstr="99 "; break;
			case 154: hexstr="9A "; break;
			case 155: hexstr="9B "; break;
			case 156: hexstr="9C "; break;
			case 157: hexstr="9D "; break;
			case 158: hexstr="9E "; break;
			case 159: hexstr="9F "; break;
			case 160: hexstr="A0 "; break;
			case 161: hexstr="A1 "; break;
			case 162: hexstr="A2 "; break;
			case 163: hexstr="A3 "; break;
			case 164: hexstr="A4 "; break;
			case 165: hexstr="A5 "; break;
			case 166: hexstr="A6 "; break;
			case 167: hexstr="A7 "; break;
			case 168: hexstr="A8 "; break;
			case 169: hexstr="A9 "; break;
			case 170: hexstr="AA "; break;
			case 171: hexstr="AB "; break;
			case 172: hexstr="AC "; break;
			case 173: hexstr="AD "; break;
			case 174: hexstr="AE "; break;
			case 175: hexstr="AF "; break;
			case 176: hexstr="B0 "; break;
			case 177: hexstr="B1 "; break;
			case 178: hexstr="B2 "; break;
			case 179: hexstr="B3 "; break;
			case 180: hexstr="B4 "; break;
			case 181: hexstr="B5 "; break;
			case 182: hexstr="B6 "; break;
			case 183: hexstr="B7 "; break;
			case 184: hexstr="B8 "; break;
			case 185: hexstr="B9 "; break;
			case 186: hexstr="BA "; break;
			case 187: hexstr="BB "; break;
			case 188: hexstr="BC "; break;
			case 189: hexstr="BD "; break;
			case 190: hexstr="BE "; break;
			case 191: hexstr="BF "; break;
			case 192: hexstr="C0 "; break;
			case 193: hexstr="C1 "; break;
			case 194: hexstr="C2 "; break;
			case 195: hexstr="C3 "; break;
			case 196: hexstr="C4 "; break;
			case 197: hexstr="C5 "; break;
			case 198: hexstr="C6 "; break;
			case 199: hexstr="C7 "; break;
			case 200: hexstr="C8 "; break;
			case 201: hexstr="C9 "; break;
			case 202: hexstr="CA "; break;
			case 203: hexstr="CB "; break;
			case 204: hexstr="CC "; break;
			case 205: hexstr="CD "; break;
			case 206: hexstr="CE "; break;
			case 207: hexstr="CF "; break;
			case 208: hexstr="D0 "; break;
			case 209: hexstr="D1 "; break;
			case 210: hexstr="D2 "; break;
			case 211: hexstr="D3 "; break;
			case 212: hexstr="D4 "; break;
			case 213: hexstr="D5 "; break;
			case 214: hexstr="D6 "; break;
			case 215: hexstr="D7 "; break;
			case 216: hexstr="D8 "; break;
			case 217: hexstr="D9 "; break;
			case 218: hexstr="DA "; break;
			case 219: hexstr="DB "; break;
			case 220: hexstr="DC "; break;
			case 221: hexstr="DD "; break;
			case 222: hexstr="DE "; break;
			case 223: hexstr="DF "; break;
			case 224: hexstr="E0 "; break;
			case 225: hexstr="E1 "; break;
			case 226: hexstr="E2 "; break;
			case 227: hexstr="E3 "; break;
			case 228: hexstr="E4 "; break;
			case 229: hexstr="E5 "; break;
			case 230: hexstr="E6 "; break;
			case 231: hexstr="E7 "; break;
			case 232: hexstr="E8 "; break;
			case 233: hexstr="E9 "; break;
			case 234: hexstr="EA "; break;
			case 235: hexstr="EB "; break;
			case 236: hexstr="EC "; break;
			case 237: hexstr="ED "; break;
			case 238: hexstr="EE "; break;
			case 239: hexstr="EF "; break;
			case 240: hexstr="F0 "; break;
			case 241: hexstr="F1 "; break;
			case 242: hexstr="F2 "; break;
			case 243: hexstr="F3 "; break;
			case 244: hexstr="F4 "; break;
			case 245: hexstr="F5 "; break;
			case 246: hexstr="F6 "; break;
			case 247: hexstr="F7 "; break;
			case 248: hexstr="F8 "; break;
			case 249: hexstr="F9 "; break;
			case 250: hexstr="FA "; break;
			case 251: hexstr="FB "; break;
			case 252: hexstr="FC "; break;
			case 253: hexstr="FD "; break;
			case 254: hexstr="FE "; break;
			case 255: hexstr="FF "; break;
		}

		Text += hexstr;

	}

	FILE * pFile;

	pFile = fopen ("CheckPacket.txt", "at+"); // "wb" Write files only in binary append mode.

	if (Crypt) fwrite(CryptPacket.c_str(), 1, CryptPacket.size(), pFile);
	else fwrite(NoCryptPacket.c_str(), 1, NoCryptPacket.size(), pFile);

	fwrite("\n", 1, 1, pFile);
	fwrite(Text.c_str(), 1, Text.size(), pFile);
	fwrite("\n", 1, 1, pFile);
	fwrite("\n", 1, 1, pFile);

	fclose (pFile);

	return 0;
}
