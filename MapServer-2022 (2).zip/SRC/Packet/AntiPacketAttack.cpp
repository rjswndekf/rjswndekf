#include <MapPacket.h>

using namespace std;

int ANTI_RET_ORIG = 0x00418D5F;
//int ANTI_RET_END = 0x00418D68;
int ANTI_RET_END = 0x00418D6A;

int SEND_PACKET_RET = 0x0066A2CA;
int SKIP_PACKET_RET = 0x0066A30E;

int RETORIG_RET = 0x0066E029;
int EMPTY_POINTER_RET = 0x0066E09A;

int EMPTY_NOCRYPT_ORIG = 0x0066185E;
int EMPTY_NOCRYPT_EXIT = 0x00661883;

// **** Anti-PacketAttack *******************************************************************
void AntiPacketAttack(int SendPacketPTR)
{
	//int DynamicPTR; //dword ptr ss:[ebp+0xFFFFBFBC]
	__asm mov ecx, SendPacketPTR
	// EDI PacketType
	__asm movzx eax,word ptr ds:[ecx]
	__asm mov edi,eax
	// ESI PacketSize
	__asm movzx eax,word ptr ds:[ecx+0x2]
	__asm mov esi,eax

	// Extreme Injecto Packet
	// RCM_MAP_PRODUCTION_ACTION_RESULT
	__asm cmp edi, 0x230D
	__asm je CPK230D

	// Check PK Packet
	__asm cmp edi, 0x0122
	__asm je PNULL
	__asm cmp edi, 0x1A1A
	__asm je PNULL
	__asm cmp edi, 0x1B33
	__asm je PNULL
	__asm cmp edi, 0x1462
	__asm je PNULL
	__asm cmp edi, 0x1463
	__asm je PNULL
	__asm cmp edi, 0x1466
	__asm je PNULL
	__asm cmp edi, 0x1468
	__asm je PNULL
	__asm cmp edi, 0x1469
	__asm je PNULL
	__asm cmp edi, 0x146A
	__asm je PNULL
	__asm cmp edi, 0x210F
	__asm je PNULL
	__asm cmp edi, 0x2110
	__asm je PNULL
	__asm cmp edi, 0x2111
	__asm je PNULL

	__asm jmp RET_ORIG

// Extreme Injecto Packet
CPK230D:
	__asm cmp esi, 0x6F
	__asm jnz RET_END
	__asm jmp RET_ORIG

// Check pPlayer Null
PNULL:
	__asm mov ecx,dword ptr ss:[ebp+0xFFFFBFBC]
	__asm mov eax,dword ptr ds:[ecx+0x534]
	__asm cmp eax, 0x0
	__asm je RET_NULLEND

RET_ORIG:
	__asm mov ecx,dword ptr ss:[ebp+0xFFFFBFBC]
	__asm jmp ANTI_RET_ORIG

RET_END:
	__asm mov eax,0x80004005
	__asm jmp ANTI_RET_END

RET_NULLEND:
	__asm jmp ANTI_RET_END

}

// Send Packet Empty Pointer Check
void PacketPTRCheck()
{
	__asm cmp ecx,0x0
	__asm je RET_END
	__asm cmp ecx,0x1098
	__asm je RET_END

	__asm mov dword ptr ss:[ebp-0x4],ecx
	__asm mov eax,dword ptr ss:[ebp-0x4]
	__asm jmp SEND_PACKET_RET

RET_END:
	__asm jmp SKIP_PACKET_RET

}

// Qualities Empty Pointer Check
void QualitiesEmptyCheck()
{
	__asm cmp eax,0x0
	__asm je RET_END
	
	__asm mov ecx,dword ptr ds:[eax+0xC]
	__asm mov dword ptr ss:[ebp-0x10],ecx
	__asm jmp RETORIG_RET

RET_END:
	__asm jmp EMPTY_POINTER_RET

}

// DBSK Empty Pointer Check
void DBSKEmptyCheck()
{
	__asm mov dword ptr ss:[ebp-0x10],ecx
	__asm mov eax,dword ptr ss:[ebp-0x10]
	__asm cmp ecx,0x0
	__asm je EXIT
	__asm cmp ecx,0x1098
	__asm je EXIT
	__asm jmp EMPTY_NOCRYPT_ORIG

EXIT:
	__asm jmp EMPTY_NOCRYPT_EXIT

}
