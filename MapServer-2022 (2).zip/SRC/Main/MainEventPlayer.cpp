#include <SkillManager.h>
#include <BattleManager.h>
#include <RHMain.h>
#include <MapFunctions.h>

using namespace std;

int MAINEVENT_RETORG = 0x004F2B1F;
int MAINEVENT_RETEND = 0x004F2BF2;
int MAINEVENT_PLAYER;
int MAINEVENT_CALAFFECT;

/******* ASM Funs *******/
extern int CHECKASENABLE;

void MainTimeEventPlayerProc()
{
	__asm mov dword ptr ss:[ebp-0xC],0x0
	
	__asm mov ecx,dword ptr ss:[ebp-0x3C]
	__asm mov MAINEVENT_PLAYER,ecx

	// Check Battle Status
	StopBattleStatus(MAINEVENT_PLAYER);

	// Check PC-Bang Point
	//IncPCBangPoint(MAINEVENT_PLAYER);

	// Skill 8229 0x2025 Distortion Claw - Reverse
	__asm mov ecx,dword ptr ss:[ebp-0x3C]
	__asm add ecx,0x100
	__asm mov MAINEVENT_CALAFFECT,ecx

	CheckAffectStatus(MAINEVENT_CALAFFECT, 0x2025);

	__asm test eax,eax
	__asm je CHECKLIFEMANA
	__asm jmp MAINEVENT_RETEND

CHECKLIFEMANA:
	__asm jmp MAINEVENT_RETORG

}