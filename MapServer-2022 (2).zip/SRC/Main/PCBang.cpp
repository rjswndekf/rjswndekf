#include <RHMain.h>
#include <MapFunctions.h>
#include <ctime>
#include <RHDB.h>
#include <sqlext.h>

using namespace std;

unsigned char PC_BANG_POINT[9] = {0};
int PC_BANG_POINT_ADDRS = (DWORD)PC_BANG_POINT;

unsigned char BUY_PC_MALL_ITEM[66] = {0};

extern int PCMALL_WAIT_TIME;

// RCM_MAP_PC_BANG_MILEAGE_INFO 0x1A20
void GetPCBangPoint(int pDynamic)
{
	int addrs;
	int pThis;
	int PPoint = 0;

	pThis = pDynamic;
	GetDBSKPPoint(pThis);

	// P-Point
	addrs = (DWORD)pDynamic + 0x2608;
	PPoint = *(reinterpret_cast<int*>(addrs));

	// Client Packet
	addrs = (DWORD)PC_BANG_POINT_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = PPoint;

	addrs = (DWORD)PC_BANG_POINT_ADDRS + 4;
	*(reinterpret_cast<int*>(addrs)) = 0;

	addrs = (DWORD)PC_BANG_POINT_ADDRS + 8;
	*(reinterpret_cast<char*>(addrs)) = 0;

	pThis = pDynamic;
	SendPacketEX(pDynamic, 0x1A20, PC_BANG_POINT_ADDRS, 0x9);
}

void GetDBSKPPoint(int pDynamic)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle
	
	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	int addrs;
	int UserID;
	int PPoint = 0;

	addrs = (DWORD)pDynamic + 0x4F0;
	UserID = *(reinterpret_cast<int*>(addrs));

	unsigned char cmdstr[] = "SELECT Point_2 From RohanUser.dbo.TUser Where user_id = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UserID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			// P-Point
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &PPoint, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);

	// P-Point
	addrs = (DWORD)pDynamic + 0x2608;
	*(reinterpret_cast<int*>(addrs)) = PPoint;
}

// RCM_MAP_BUY_PC_MALL_ITEM 0x1A22
void BuyPCMallItem(int pDynamic, int pSendPacket)
{
	int addrs;
	int Result;
	int pData;

	memset(BUY_PC_MALL_ITEM, 0, 66);
	
	pData = pSendPacket + 4;
	Result = GetPCMallItem(pDynamic, pData);
	if (Result != 0)
	{
		addrs = (int)BUY_PC_MALL_ITEM;
		*(char*)addrs = (char)Result;
		SendPacket(pDynamic, 0x1A22, (int)BUY_PC_MALL_ITEM, 0x1);
	}
}

int GetPCMallItem(int pDynamic, int pData)
{
	//int addrs;
	int pPlayer;
	int pThis;
	int Result;
	int ItemID;
	int nID;
	int pItem;
	int Inventory = 0xFF;
	int Slot = 0xFF;
	int pScript;
	int Price;
	int PPoint;

	unsigned char NEWNID[8] = {0};

	pPlayer = *(int*)(pDynamic + 0x534);
	if (pPlayer == 0) return 2;

	// Send Packet
	ItemID = *(unsigned int*)(pData + 0x8);

	// P-Point
	PPoint =  *(unsigned int*)(pDynamic + 0x2608);

	//Price = GetPMallPrice(ItemID);
	pScript = GetItemMallScriptInfo(ItemID);
	if (pScript == 0) return 0x19;
	Price = GetItemScriptAttrbute(pScript, 186);

	if (Price < 1) return 196;
	if (PPoint < Price) return 222;
	
	PPoint -= Price;
	*(unsigned int*)(pDynamic + 0x2608) = PPoint;

	// Cerate Item
	AllocItem((int)NEWNID, ItemID);
	nID = *(int*)((int)NEWNID + 4);
	if (nID < 1) return 142;
	pItem = CreateItem((int)NEWNID, 1);

	pThis = pPlayer + 0xCC8;
	Result = GetFreeInventorySlot(pThis, (int)&Inventory, (int)&Slot);
	if (Result == 0) return 0x37;

	pThis = pPlayer + 0xCC8;
	Result = AddItem(pThis, pItem, Inventory, Slot, 0);
	if (Result == 0) return 0x37;

	// Clinet Packet
	// ItemGR
	tagItemInit((int)BUY_PC_MALL_ITEM + 1);
	EpochItemBaseGetItemGR(pItem, (int)BUY_PC_MALL_ITEM + 1);
	// CurPoint
	*(unsigned int*)((int)BUY_PC_MALL_ITEM + 0x3E) = PPoint;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x1A22, (int)BUY_PC_MALL_ITEM, 0x42);

	// Sub PPoint
	pThis = pDynamic;
	UpdateDBSKPPoint(pThis);

	return 0;
}
void UpdateDBSKPPoint(int pDynamic)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	int addrs;
	int UserID;
	int PPoint = 0;

	addrs = (DWORD)pDynamic + 0x4F0;
	UserID = *(reinterpret_cast<int*>(addrs));

	// P-Point
	addrs = (DWORD)pDynamic + 0x2608;
	PPoint = *(reinterpret_cast<int*>(addrs));

	unsigned char cmdstr[] = "UPDATE RohanUser.dbo.TUser SET Point_2 = ? WHERE user_id = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &PPoint, 0, 0);
	SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UserID, 0, 0);
	SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr, SQL_NTS);
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
}

int GetPMallPrice(int ItemID)
{
	int Price = 0;

	switch(ItemID)
	{
		case 2625640: Price = 100; break;
		case 2625641: Price = 100; break;
		case 2625642: Price = 100; break;
		case 2625644: Price = 100; break;
		case 2625645: Price = 100; break;
		case 2625646: Price = 100; break;
		case 2625647: Price = 100; break;
		case 2625648: Price = 100; break;
		case 2625649: Price = 100; break;
		case 2625650: Price = 100; break;
		case 2625651: Price = 100; break;
		case 2625652: Price = 100; break;
		case 2643441: Price = 100; break;
		case 2644441: Price = 100; break;
		case 2690496: Price = 20; break;
		case 2690497: Price = 20; break;
		case 2690498: Price = 20; break;
		case 2690499: Price = 20; break;
		case 2690500: Price = 20; break;
		case 2690501: Price = 20; break;
		case 2690502: Price = 20; break;
		case 2690503: Price = 20; break;
		case 2690504: Price = 20; break;
		case 2690505: Price = 20; break;
		case 2885640: Price = 2; break;
		case 2885641: Price = 4; break;
		case 2885642: Price = 8; break;
		case 2885643: Price = 16; break;
		case 2885644: Price = 3; break;
		case 2885645: Price = 6; break;
		case 2885646: Price = 12; break;
		case 2885647: Price = 24; break;
		case 4719412: Price = 9; break;
		case 4719413: Price = 6; break;
		case 4719414: Price = 6; break;
		case 4719415: Price = 9; break;
		case 4719416: Price = 9; break;
		case 4719417: Price = 9; break;
		case 4719418: Price = 3; break;
		case 4719419: Price = 13; break;
		case 4719420: Price = 9; break;
		case 4719421: Price = 9; break;
		case 4719422: Price = 13; break;
		case 4719423: Price = 13; break;
		case 4719424: Price = 13; break;
		case 4719425: Price = 5; break;
		case 2884936: Price = 20; break;
		case 2886254: Price = 20; break;
		case 2886255: Price = 20; break;
		case 2886256: Price = 20; break;
		case 2886257: Price = 20; break;
		case 2818556: Price = 1; break;
		case 2884718: Price = 5; break;
		case 2884887: Price = 5; break;
		case 2884889: Price = 10; break;
		case 2885581: Price = 25; break;
		case 2886034: Price = 30; break;
		case 2886088: Price = 15; break;
		case 2886134: Price = 15; break;
		case 2886160: Price = 25; break;
		case 2886206: Price = 25; break;
		case 2903590: Price = 2; break;
		case 4328415: Price = 96; break;
		case 4719400: Price = 1; break;
		case 4719404: Price = 3; break;
	}

	return Price;
}

void IncPCBangPoint(int pPlayerr)
{
	int addrs;
	int pDynamic;
	int pThis;
	int PCRoomLink;
	int PMallTimer;
	int PPoint = 0;
	int CutTimer;
	
	if (pPlayerr != 0)
	{
		addrs = (DWORD)pPlayerr + 0x1098;
		pDynamic = *(reinterpret_cast<int*>(addrs));
		if (pDynamic != 0)
		{
			addrs = (DWORD)pDynamic + 0x2600;
			PCRoomLink = *(reinterpret_cast<int*>(addrs));
			addrs = (DWORD)pDynamic + 0x2604;
			PMallTimer = *(reinterpret_cast<int*>(addrs));
			addrs = (DWORD)pDynamic + 0x2608;
			PPoint = *(reinterpret_cast<int*>(addrs));

			if (PCRoomLink == 1)
			{
				// Get CurDate
				time_t now = time(0);
				CutTimer = (int)now;
				if (CutTimer >= PMallTimer)
				{
					// Set NextTimer
					CutTimer += PCMALL_WAIT_TIME;
					addrs = (DWORD)pDynamic + 0x2604;
					*(reinterpret_cast<int*>(addrs)) = CutTimer;
					// AddPPoint
					PPoint += 2;
					if (PPoint >= 2147483647) PPoint = 2147483647;

					addrs = (DWORD)pDynamic + 0x2608;
					*(reinterpret_cast<int*>(addrs)) = PPoint;
					pThis = (DWORD)pDynamic;
					UpdateDBSKPPoint(pThis);

					// Client Packet
					addrs = (DWORD)PC_BANG_POINT_ADDRS;
					*(reinterpret_cast<int*>(addrs)) = PPoint;

					addrs = (DWORD)PC_BANG_POINT_ADDRS + 4;
					*(reinterpret_cast<int*>(addrs)) = 0;

					addrs = (DWORD)PC_BANG_POINT_ADDRS + 8;
					*(reinterpret_cast<char*>(addrs)) = 0;

					pThis = (DWORD)pDynamic;
					SendPacketEX(pDynamic, 0x1A20, PC_BANG_POINT_ADDRS, 0x9);
				}
			}
		}
	}
}
