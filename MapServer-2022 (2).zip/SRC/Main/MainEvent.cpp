#include <RHMain.h>
#include <MapFunctions.h>
#include <ctime>
//#include <RHDB.h>
//#include <sqlext.h>

using namespace std;

extern int LUCKY_NUMBER_EXPIRE_TIME;

void MainTimeEventProc()
{
	MainTimeEvent();

	// Orig Code
	__asm mov esp,ebp
	__asm pop ebp
	__asm retn
}

void MainTimeEvent()
{
	int CurTimestamp;
	time_t seconds = time(NULL);
	CurTimestamp = (int)seconds;

	// Lucky Number
	if (LUCKY_NUMBER_EXPIRE_TIME != 0)
	{
		if (CurTimestamp >= LUCKY_NUMBER_EXPIRE_TIME)
		{
			LuckyNumberReset();
		}
	}
 
}