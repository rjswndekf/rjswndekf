#include <RHMain.h>
#include <MapFunctions.h>

using namespace std; 

/************************************
 2016 Size 0xAD
 0x17 + 0x3C(CharData) + 0x5A+
 <-      0x53      ->
 
 2018 Size 0xDD
 0x17 + 0x6C(CharData) + 0x5A
 <-      0x83      ->
 
 2021 Size 0x121
 0x17 + 0xB0(CharData) + 0x5A
 <-      0xC7      ->
 
 2021kr Size 0x125
 0x17 + 0xB4(CharData) + 0x5A
 <-      0xCB      ->

 TargetPTR: dword ptr ss:[ebp-0xC4]
 GMPlayerPTR: dword ptr ss:[ebp+0x8]
 DynamicPTR: dword ptr ds:[GMPlayerPTR+0x1098]
 PacketSRCPTR: dword ptr ss:[ebp-0xB8]
************************************/
unsigned char GWHOP_BUFFER[293] = {0};
int GWHOP_ADDRS = (DWORD)GWHOP_BUFFER;
int GWHOP_RET = 0x004C7B8B;

extern int CHARSTATUS_SIZE;
int CHAR_LEN = 0x17 + CHARSTATUS_SIZE;
int GMWP_PKSIZE = 0x17 + CHARSTATUS_SIZE + 0x5A;

/******* ASM Funs *******/
extern int GETSTATUS;
extern int SENDPACKET_FUN;

// 2018 RCM_MAP_GM_WHO_PLAYER 0x1B19 Patch
void GMWhoPlayer()
{
	__asm lea esi, dword ptr ss:[ebp-0xB8]
	__asm mov edi, GWHOP_ADDRS
	__asm mov ecx, 0x17
	__asm rep movs byte ptr es:[edi],byte ptr ds:[esi]
	
	// CharStatus
	__asm push edi
	// TargetPTR
	__asm mov ecx,dword ptr ss:[ebp-0xC4]
	__asm push ecx
	__asm call GETSTATUS

	__asm lea esi, dword ptr ss:[ebp-0xB8]
	__asm add esi, 0x53
	__asm mov edi, GWHOP_ADDRS
	__asm mov eax, CHAR_LEN
	__asm add edi, eax
	__asm mov ecx, 0x5A
	__asm rep movs byte ptr es:[edi],byte ptr ds:[esi]

	// Send Packet
	__asm mov edi, GWHOP_ADDRS
	__asm mov eax, GMWP_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x1B19
	// DynamicPTR
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov ecx,dword ptr ds:[edx+0x1098]
	__asm call SENDPACKET_FUN

	__asm jmp GWHOP_RET

}
