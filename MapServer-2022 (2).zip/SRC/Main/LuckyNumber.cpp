#include <RHMain.h>
#include <MapFunctions.h>
#include <ctime>
#include <RHDB.h>
#include <sqlext.h>

using namespace std;

// LuckyNumber
unsigned char CUR_LUCKYNUM[22] = {0};
int CUR_LUCKYNUM_ADDRS = (DWORD)CUR_LUCKYNUM;

unsigned char SELECT_LUCKYNUM[3] = {0};
int SELECT_LUCKYNUM_ADDRS = (DWORD)SELECT_LUCKYNUM;

unsigned char LAST_LUCKYNUM[19] = {0};
int LAST_LUCKYNUM_ADDRS = (DWORD)LAST_LUCKYNUM;

unsigned char REWARD_LUCKYNUM[2] = {0};
int REWARD_LUCKYNUM_ADDRS = (DWORD)REWARD_LUCKYNUM;

// 2022
int LuckyID = 9;
int LuckyType = 2;
extern int LUCKYNUMLIST_ADDRS;
extern int LUCKYNUMLIST_SIZE;
extern int LUCKYNUM_WAIT_TIME;
extern int LUCKY_NUMBER_EXPIRE_TIME;
extern int LUCKY_NUMBER_USER_EXPIRE_TIME;

// **** RCM_LUCKY_NUMBER_CURRENT 0x184A *******************************
void LuckyNumber(int pDynamic, int pSendPacket)
{
	int addrs;
	int pThis;

	int Num1 = 0;
	int Num2 = 0;
	int Num3 = 0;
	int Num4 = 0;
	int Num5 = 0;
	int Num6 = 0;
	int Num7 = 0;
	int SedNum1 = 0;
	int SedNum2 = 0;
	int SedNum3 = 0;
	int SedNum4 = 0;
	int SedNum5 = 0;
	int SedNum6 = 0;
	int SedNum7 = 0;
	
	int pLucky;
	int SedNum = 0;
	int SedDate;
	int NextSedTime;
	int CurWeek;
	int CurTimestamp;
	int CurSed = 0;
	int RemainingTime;

	// Check LuckyNumber User Reset
	pThis = pDynamic;
	LuckyNumberUserReset(pThis);

	pLucky = pDynamic + 0x2610;

	if (pLucky != 0)
	{
		addrs = pLucky;
		Num1 = *(reinterpret_cast<char*>(addrs));
		Num1 &= 0xFF;

		addrs = pLucky + 0x1;
		Num2 = *(reinterpret_cast<char*>(addrs));
		Num2 &= 0xFF;

		addrs = pLucky + 0x2;
		Num3 = *(reinterpret_cast<char*>(addrs));
		Num3 &= 0xFF;

		addrs = pLucky + 0x3;
		Num4 = *(reinterpret_cast<char*>(addrs));
		Num4 &= 0xFF;

		addrs = pLucky + 0x4;
		Num5 = *(reinterpret_cast<char*>(addrs));
		Num5 &= 0xFF;

		addrs = pLucky + 0x5;
		Num6 = *(reinterpret_cast<char*>(addrs));
		Num6 &= 0xFF;

		addrs = pLucky + 0x6;
		Num7 = *(reinterpret_cast<char*>(addrs));
		Num7 &= 0xFF;

		addrs = pLucky + 0x10;
		SedNum1 = *(reinterpret_cast<char*>(addrs));
		SedNum1 &= 0xFF;

		addrs = pLucky + 0x11;
		SedNum2 = *(reinterpret_cast<char*>(addrs));
		SedNum2 &= 0xFF;

		addrs = pLucky + 0x12;
		SedNum3 = *(reinterpret_cast<char*>(addrs));
		SedNum3 &= 0xFF;

		addrs = pLucky + 0x13;
		SedNum4 = *(reinterpret_cast<char*>(addrs));
		SedNum4 &= 0xFF;

		addrs = pLucky + 0x14;
		SedNum5 = *(reinterpret_cast<char*>(addrs));
		SedNum5 &= 0xFF;

		addrs = pLucky + 0x15;
		SedNum6 = *(reinterpret_cast<char*>(addrs));
		SedNum6 &= 0xFF;

		addrs = pLucky + 0x16;
		SedNum7 = *(reinterpret_cast<char*>(addrs));
		SedNum7 &= 0xFF;

		addrs = pLucky + 0x17;
		SedDate = *(reinterpret_cast<char*>(addrs));
		SedDate &= 0xFF;

		for(int i = 0; i < 7; i++)
		{
			addrs = pLucky + 0x10 + i;
			SedNum = *(reinterpret_cast<char*>(addrs));
			if (SedNum != 0) CurSed ++;
		}

		addrs =  (DWORD)pLucky + 0x20;
		NextSedTime = *(reinterpret_cast<int*>(addrs));
	}

	if (CurSed > 6)
	{
		RemainingTime = 0xFFFFFFFF;
	}
	else
	{
		time_t now = time(0);
		tm *ltm = localtime(&now);
		CurWeek = ltm->tm_wday;
		if (CurWeek == 0) CurWeek = 7;
		if (SedDate == CurWeek)
		{
			RemainingTime = 0xFFFFFFFF;
		}
		else
		{
			time_t seconds = time(NULL);
			CurTimestamp = (int)seconds;
			if (NextSedTime > CurTimestamp)
			{
				RemainingTime = NextSedTime - CurTimestamp;
			}
			else
			{
				NextSedTime = CurTimestamp + LUCKYNUM_WAIT_TIME;
				addrs = (DWORD)pLucky + 0x20;
				*(reinterpret_cast<int*>(addrs)) = NextSedTime;
				RemainingTime = LUCKYNUM_WAIT_TIME;
			}
		}
	}

	// Res
	addrs = CUR_LUCKYNUM_ADDRS;
	*(reinterpret_cast<char*>(addrs)) = 0;

	// Lucky Number
	addrs = CUR_LUCKYNUM_ADDRS + 1;
	*(reinterpret_cast<char*>(addrs)) = (char)Num1;
	addrs = CUR_LUCKYNUM_ADDRS + 2;
	*(reinterpret_cast<char*>(addrs)) = (char)Num2;
	addrs = CUR_LUCKYNUM_ADDRS + 3;
	*(reinterpret_cast<char*>(addrs)) = (char)Num3;
	addrs = CUR_LUCKYNUM_ADDRS + 4;
	*(reinterpret_cast<char*>(addrs)) = (char)Num4;
	addrs = CUR_LUCKYNUM_ADDRS + 5;
	*(reinterpret_cast<char*>(addrs)) = (char)Num5;
	addrs = CUR_LUCKYNUM_ADDRS + 6;
	*(reinterpret_cast<char*>(addrs)) = (char)Num6;
	addrs = CUR_LUCKYNUM_ADDRS + 7;
	*(reinterpret_cast<char*>(addrs)) = (char)Num7;

	// Select Number
	addrs = CUR_LUCKYNUM_ADDRS + 8;
	*(reinterpret_cast<char*>(addrs)) = (char)SedNum1;
	addrs = CUR_LUCKYNUM_ADDRS + 9;
	*(reinterpret_cast<char*>(addrs)) = (char)SedNum2;
	addrs = CUR_LUCKYNUM_ADDRS + 10;
	*(reinterpret_cast<char*>(addrs)) = (char)SedNum3;
	addrs = CUR_LUCKYNUM_ADDRS + 11;
	*(reinterpret_cast<char*>(addrs)) = (char)SedNum4;
	addrs = CUR_LUCKYNUM_ADDRS + 12;
	*(reinterpret_cast<char*>(addrs)) = (char)SedNum5;
	addrs = CUR_LUCKYNUM_ADDRS + 13;
	*(reinterpret_cast<char*>(addrs)) = (char)SedNum6;
	addrs = CUR_LUCKYNUM_ADDRS + 14;
	*(reinterpret_cast<char*>(addrs)) = (char)SedNum7;

	// Selected Number Count
	addrs = CUR_LUCKYNUM_ADDRS + 15;
	*(reinterpret_cast<char*>(addrs)) = (char)CurSed;
	// ID 1
	addrs = CUR_LUCKYNUM_ADDRS + 16;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyID;
	// LuckyType 0 - 2
	addrs = CUR_LUCKYNUM_ADDRS + 17;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyType;

	// Remaining Time
	addrs = CUR_LUCKYNUM_ADDRS + 18;
	*(reinterpret_cast<int*>(addrs)) = RemainingTime;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x184A, CUR_LUCKYNUM_ADDRS, 0x16);
}

// **** RCM_LUCKY_NUMBER_SELECT 0x184B *******************************
void NumberSelect(int pDynamic, int pSendPacket)
{
	int addrs;
	int pThis;
	int pData;
	int No;
	int Number;
	int Res;
	int pCurNum;
	int ChkNum;
	int MaxNo;
	int i;

	pData = (DWORD)pSendPacket + 4;
	addrs = pData;
	No = *(reinterpret_cast<char*>(addrs));
	No &= 0xFF;

	Res = 0;
	pCurNum = pDynamic + 0x2620;

	srand(time(NULL));
	Number = rand()%50;  // 0-49
	Number &= 0xFF;
	Number += 1;

	MaxNo = No + 1;

    for(i = 0; i < MaxNo; i++)
    {
		addrs = pCurNum + i;
		ChkNum = *(reinterpret_cast<char*>(addrs));
		ChkNum &= 0xFF;
		if (ChkNum != 0)
		{
			if (Number == ChkNum)
			{
				Number += 3;
				if (Number > 50) Number -= 50;
			}
		}
    }

	addrs = pCurNum + No;
	*(reinterpret_cast<char*>(addrs)) = (char)Number;

	addrs = SELECT_LUCKYNUM_ADDRS;
	*(reinterpret_cast<char*>(addrs)) = Res;
	addrs = SELECT_LUCKYNUM_ADDRS + 1;
	*(reinterpret_cast<char*>(addrs)) = (char)Number;
	addrs = SELECT_LUCKYNUM_ADDRS + 2;
	*(reinterpret_cast<char*>(addrs)) = (char)No;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x184B, SELECT_LUCKYNUM_ADDRS, 0x3);

	// Update DB
	pThis = pDynamic;
	SetSelectNumber(pThis, No, Number);
}

// **** RCM_LUCKY_NUMBER_LAST 0x184C *******************************
void LuckyNumberLast(int pDynamic, int pSendPacket)
{
	int addrs;
	int pThis;

	int Num1 = 0;
	int Num2 = 0;
	int Num3 = 0;
	int Num4 = 0;
	int Num5 = 0;
	int Num6 = 0;
	int Num7 = 0;
	int SedNum1 = 0;
	int SedNum2 = 0;
	int SedNum3 = 0;
	int SedNum4 = 0;
	int SedNum5 = 0;
	int SedNum6 = 0;
	int SedNum7 = 0;
	
	int Num = 0;
	int SedNum = 0;
	int pLucky;
	int Reward = 1;
	int Result = 0;

	int Won = 0;
	int Grade = 0;

	pLucky = pDynamic + 0x2610;

	addrs = pLucky + 0x8;
	Num1 = *(reinterpret_cast<char*>(addrs));
	Num1 &= 0xFF;

	addrs = pLucky + 0x9;
	Num2 = *(reinterpret_cast<char*>(addrs));
	Num2 &= 0xFF;

	addrs = pLucky + 0xA;
	Num3 = *(reinterpret_cast<char*>(addrs));
	Num3 &= 0xFF;

	addrs = pLucky + 0xB;
	Num4 = *(reinterpret_cast<char*>(addrs));
	Num4 &= 0xFF;

	addrs = pLucky + 0xC;
	Num5 = *(reinterpret_cast<char*>(addrs));
	Num5 &= 0xFF;

	addrs = pLucky + 0xD;
	Num6 = *(reinterpret_cast<char*>(addrs));
	Num6 &= 0xFF;

	addrs = pLucky + 0xE;
	Num7 = *(reinterpret_cast<char*>(addrs));
	Num7 &= 0xFF;

	addrs = pLucky + 0x18;
	SedNum1 = *(reinterpret_cast<char*>(addrs));
	SedNum1 &= 0xFF;

	addrs = pLucky + 0x19;
	SedNum2 = *(reinterpret_cast<char*>(addrs));
	SedNum2 &= 0xFF;

	addrs = pLucky + 0x1A;
	SedNum3 = *(reinterpret_cast<char*>(addrs));
	SedNum3 &= 0xFF;

	addrs = pLucky + 0x1B;
	SedNum4 = *(reinterpret_cast<char*>(addrs));
	SedNum4 &= 0xFF;

	addrs = pLucky + 0x1C;
	SedNum5 = *(reinterpret_cast<char*>(addrs));
	SedNum5 &= 0xFF;

	addrs = pLucky + 0x1D;
	SedNum6 = *(reinterpret_cast<char*>(addrs));
	SedNum6 &= 0xFF;

	addrs = pLucky + 0x1E;
	SedNum7 = *(reinterpret_cast<char*>(addrs));
	SedNum7 &= 0xFF;

	for(int i = 0; i < 7; i++)
	{
		addrs = pLucky + 0x18 + i;
		SedNum = *(reinterpret_cast<char*>(addrs));
		SedNum &= 0xFF;
		for(int j = 0; j < 7; j++)
		{
		addrs = pLucky + 0x8 + j;
		Num = *(reinterpret_cast<char*>(addrs));
		if (SedNum == Num) Won ++;
		}
	}
	
	Grade = 8 - Won;

	addrs = LAST_LUCKYNUM_ADDRS;
	*(reinterpret_cast<char*>(addrs)) = 0;

	addrs = pLucky + 0x1F;
	Result = *(reinterpret_cast<char*>(addrs));
	Result &= 0xFF;
	if (Result == 1) Reward = 0;

	// 1: GetReward / 0:Can Not Get Reward
	addrs = LAST_LUCKYNUM_ADDRS + 1;
	*(reinterpret_cast<char*>(addrs)) = Reward;

	// Grade
	addrs = LAST_LUCKYNUM_ADDRS + 2;
	*(reinterpret_cast<char*>(addrs)) = Grade;

	// Lucky Number
	addrs = LAST_LUCKYNUM_ADDRS + 3;
	*(reinterpret_cast<char*>(addrs)) = (char)Num1;
	addrs = LAST_LUCKYNUM_ADDRS + 4;
	*(reinterpret_cast<char*>(addrs)) = (char)Num2;
	addrs = LAST_LUCKYNUM_ADDRS + 5;
	*(reinterpret_cast<char*>(addrs)) = (char)Num3;
	addrs = LAST_LUCKYNUM_ADDRS + 6;
	*(reinterpret_cast<char*>(addrs)) = (char)Num4;
	addrs = LAST_LUCKYNUM_ADDRS + 7;
	*(reinterpret_cast<char*>(addrs)) = (char)Num5;
	addrs = LAST_LUCKYNUM_ADDRS + 8;
	*(reinterpret_cast<char*>(addrs)) = (char)Num6;
	addrs = LAST_LUCKYNUM_ADDRS + 9;
	*(reinterpret_cast<char*>(addrs)) = (char)Num7;

	// Select Number
	addrs = LAST_LUCKYNUM_ADDRS + 10;
	*(reinterpret_cast<char*>(addrs)) = (char)SedNum1;
	addrs = LAST_LUCKYNUM_ADDRS + 11;
	*(reinterpret_cast<char*>(addrs)) = (char)SedNum2;
	addrs = LAST_LUCKYNUM_ADDRS + 12;
	*(reinterpret_cast<char*>(addrs)) = (char)SedNum3;
	addrs = LAST_LUCKYNUM_ADDRS + 13;
	*(reinterpret_cast<char*>(addrs)) = (char)SedNum4;
	addrs = LAST_LUCKYNUM_ADDRS + 14;
	*(reinterpret_cast<char*>(addrs)) = (char)SedNum5;
	addrs = LAST_LUCKYNUM_ADDRS + 15;
	*(reinterpret_cast<char*>(addrs)) = (char)SedNum6;
	addrs = LAST_LUCKYNUM_ADDRS + 16;
	*(reinterpret_cast<char*>(addrs)) = (char)SedNum7;

	// ID 1
	addrs = LAST_LUCKYNUM_ADDRS + 17;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyID;
	// LuckyType
	addrs = LAST_LUCKYNUM_ADDRS + 18;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyType;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x184C, LAST_LUCKYNUM_ADDRS, 0x13);
}

// **** RCM_LUCKY_NUMBER_REWARD 0x184D *******************************
void GetLuckyNumberReward(int pDynamic, int pSendPacket)
{
	int addrs;
	int pThis;
	int pLucky;
	int Num;
	int SedNum;
	int Won = 0;
	int Grade = 0;
	int ItemID;
	int Result;

	pLucky = pDynamic + 0x2610;

	for(int i = 0; i < 7; i++)
	{
		addrs = pLucky + 0x18 + i;
		SedNum = *(reinterpret_cast<char*>(addrs));
		SedNum &= 0xFF;
		for(int j = 0; j < 7; j++)
		{
			addrs = pLucky + 0x8 + j;
			Num = *(reinterpret_cast<char*>(addrs));
			if (SedNum == Num) Won ++;
		}
	}

	Grade = 8 - Won;

	ItemID = GetLuckyNumberItem(Grade);

	addrs = pLucky + 0x1F;
	Result = *(reinterpret_cast<char*>(addrs));
	Result &= 0xFF;

	// Result
	addrs = REWARD_LUCKYNUM_ADDRS;
	*(reinterpret_cast<char*>(addrs)) = (char)Result;
	// Grade
	addrs = REWARD_LUCKYNUM_ADDRS + 1;
	*(reinterpret_cast<char*>(addrs)) = (char)Grade;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x184D, REWARD_LUCKYNUM_ADDRS, 0x2);

	// Send MallItem;
	if (Result == 0)
	{
		pThis = pDynamic;
		LuckyNumberSendReward(pThis, ItemID);
	}
}

int GetLuckyNumberItem(int Grade)
{
	int addrs;
	int Itemaddrs;
	int ItemID = 0;
	int BinID = 0;
	int MaxCount = 0;
	int Offset = 0;

	MaxCount = LUCKYNUMLIST_SIZE / 0xBC;

	Offset = (DWORD)LUCKYNUMLIST_ADDRS;
	
	//LuckyType -= 1;
	Grade -= 1;

	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset;
		BinID = *(reinterpret_cast<int*>(addrs));
		if (BinID == LuckyID)
		{
			Itemaddrs = Offset + 0x68;
			addrs = Itemaddrs + (LuckyType * 0x1C) + (Grade * 4);
			ItemID = *(reinterpret_cast<int*>(addrs));
			break;
		}
		else
		{
			Offset += 0xBC;
		}
	}

	return ItemID;
}

void LuckyNumberSendReward(int pDynamic, int ItemID)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	int addrs;
	int UserID;

	addrs = (DWORD)pDynamic + 0x4F0;
	UserID = *(reinterpret_cast<int*>(addrs));

	addrs = pDynamic + 0x262F;
	*(reinterpret_cast<char*>(addrs)) = 1;

	// Send MailItem
	unsigned char cmdstr1[] = "INSERT INTO RohanMall.dbo.TItem (type, attr, stack, rank, equip_level, equip_dexterity, equip_intelligence, equip_strength, user_id, date) VALUES (?, 0, 1, 0, 0, 0, 0, 0, ?, GETDATE())";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &ItemID, 0, 0);
	SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UserID, 0, 0);
	SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS);

	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	unsigned char cmdstr2[] = "UPDATE RohanGame.dbo.TLuckyNumLast SET SelectDate = 1 WHERE UserID = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UserID, 0, 0);
	SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr2, SQL_NTS);

	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);

}

void LuckyNumberInit(int pDynamic)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	int addrs;
	int pLucky;
	int UserID;
	int LuckyNum1 = 0;
	int LuckyNum2 = 0;
	int LuckyNum3 = 0;
	int LuckyNum4 = 0;
	int LuckyNum5 = 0;
	int LuckyNum6 = 0;
	int LuckyNum7 = 0;
	int SelectDate = 0;
	int NxetTime = 0;

	pLucky = pDynamic + 0x2610;

	// LuckyNum Current
	unsigned char cmdstr1[] = "SELECT LuckyNum1, LuckyNum2, LuckyNum3, LuckyNum4, LuckyNum5, LuckyNum6, LuckyNum7, SelectDate, NxetTime From RohanGame.dbo.TLuckyNumCurrent Where UserID = 0";

	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			// LuckyNum1
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &LuckyNum1, 0, NULL);
			// LuckyNum2
			SQLGetData(SHSTMT, 2, SQL_C_ULONG, &LuckyNum2, 0, NULL);
			// LuckyNum3
			SQLGetData(SHSTMT, 3, SQL_C_ULONG, &LuckyNum3, 0, NULL);
			// LuckyNum4
			SQLGetData(SHSTMT, 4, SQL_C_ULONG, &LuckyNum4, 0, NULL);
			// LuckyNum5
			SQLGetData(SHSTMT, 5, SQL_C_ULONG, &LuckyNum5, 0, NULL);
			// LuckyNum6
			SQLGetData(SHSTMT, 6, SQL_C_ULONG, &LuckyNum6, 0, NULL);
			// LuckyNum7
			SQLGetData(SHSTMT, 7, SQL_C_ULONG, &LuckyNum7, 0, NULL);
			// SelectDate
			SQLGetData(SHSTMT, 8, SQL_C_ULONG, &SelectDate, 0, NULL);
			// NxetTime
			SQLGetData(SHSTMT, 9, SQL_C_ULONG, &NxetTime, 0, NULL);
		}
	}

	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	addrs = pLucky;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum1;
	addrs = pLucky + 0x1;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum2;
	addrs = pLucky + 0x2;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum3;
	addrs = pLucky + 0x3;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum4;
	addrs = pLucky + 0x4;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum5;
	addrs = pLucky + 0x5;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum6;
	addrs = pLucky + 0x6;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum7;

	addrs = (DWORD)pDynamic + 0x4F0;
	UserID = *(reinterpret_cast<int*>(addrs));

	LuckyNum1 = 0;
	LuckyNum2 = 0;
	LuckyNum3 = 0;
	LuckyNum4 = 0;
	LuckyNum5 = 0;
	LuckyNum6 = 0;
	LuckyNum7 = 0;
	SelectDate = 0;
	NxetTime = 0;

	// LuckyNum Current Select
	unsigned char cmdstr2[] = "SELECT LuckyNum1, LuckyNum2, LuckyNum3, LuckyNum4, LuckyNum5, LuckyNum6, LuckyNum7, SelectDate, NxetTime From RohanGame.dbo.TLuckyNumCurrent Where UserID = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UserID, 0, 0);

	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr2, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			// LuckyNum1
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &LuckyNum1, 0, NULL);
			// LuckyNum2
			SQLGetData(SHSTMT, 2, SQL_C_ULONG, &LuckyNum2, 0, NULL);
			// LuckyNum3
			SQLGetData(SHSTMT, 3, SQL_C_ULONG, &LuckyNum3, 0, NULL);
			// LuckyNum4
			SQLGetData(SHSTMT, 4, SQL_C_ULONG, &LuckyNum4, 0, NULL);
			// LuckyNum5
			SQLGetData(SHSTMT, 5, SQL_C_ULONG, &LuckyNum5, 0, NULL);
			// LuckyNum6
			SQLGetData(SHSTMT, 6, SQL_C_ULONG, &LuckyNum6, 0, NULL);
			// LuckyNum7
			SQLGetData(SHSTMT, 7, SQL_C_ULONG, &LuckyNum7, 0, NULL);
			// SelectDate
			SQLGetData(SHSTMT, 8, SQL_C_ULONG, &SelectDate, 0, NULL);
			// NxetTime
			SQLGetData(SHSTMT, 9, SQL_C_ULONG, &NxetTime, 0, NULL);
		}
	}

	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	addrs = pLucky + 0x10;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum1;
	addrs = pLucky + 0x11;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum2;
	addrs = pLucky + 0x12;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum3;
	addrs = pLucky + 0x13;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum4;
	addrs = pLucky + 0x14;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum5;
	addrs = pLucky + 0x15;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum6;
	addrs = pLucky + 0x16;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum7;
	addrs = pLucky + 0x17;
	*(reinterpret_cast<char*>(addrs)) = (char)SelectDate;

	LuckyNum1 = 0;
	LuckyNum2 = 0;
	LuckyNum3 = 0;
	LuckyNum4 = 0;
	LuckyNum5 = 0;
	LuckyNum6 = 0;
	LuckyNum7 = 0;
	SelectDate = 0;
	NxetTime = 0;

	// LuckyNum Last
	unsigned char cmdstr3[] = "SELECT LuckyNum1, LuckyNum2, LuckyNum3, LuckyNum4, LuckyNum5, LuckyNum6, LuckyNum7, SelectDate, NxetTime From RohanGame.dbo.TLuckyNumLast Where UserID = 0";

	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr3, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			// LuckyNum1
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &LuckyNum1, 0, NULL);
			// LuckyNum2
			SQLGetData(SHSTMT, 2, SQL_C_ULONG, &LuckyNum2, 0, NULL);
			// LuckyNum3
			SQLGetData(SHSTMT, 3, SQL_C_ULONG, &LuckyNum3, 0, NULL);
			// LuckyNum4
			SQLGetData(SHSTMT, 4, SQL_C_ULONG, &LuckyNum4, 0, NULL);
			// LuckyNum5
			SQLGetData(SHSTMT, 5, SQL_C_ULONG, &LuckyNum5, 0, NULL);
			// LuckyNum6
			SQLGetData(SHSTMT, 6, SQL_C_ULONG, &LuckyNum6, 0, NULL);
			// LuckyNum7
			SQLGetData(SHSTMT, 7, SQL_C_ULONG, &LuckyNum7, 0, NULL);
			// SelectDate
			SQLGetData(SHSTMT, 8, SQL_C_ULONG, &SelectDate, 0, NULL);
			// NxetTime
			SQLGetData(SHSTMT, 9, SQL_C_ULONG, &NxetTime, 0, NULL);
		}
	}

	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	addrs = pLucky + 0x8;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum1;
	addrs = pLucky + 0x9;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum2;
	addrs = pLucky + 0xA;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum3;
	addrs = pLucky + 0xB;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum4;
	addrs = pLucky + 0xC;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum5;
	addrs = pLucky + 0xD;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum6;
	addrs = pLucky + 0xE;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum7;

	LUCKY_NUMBER_EXPIRE_TIME = NxetTime;

	addrs = (DWORD)pDynamic + 0x4F0;
	UserID = *(reinterpret_cast<int*>(addrs));

	LuckyNum1 = 0;
	LuckyNum2 = 0;
	LuckyNum3 = 0;
	LuckyNum4 = 0;
	LuckyNum5 = 0;
	LuckyNum6 = 0;
	LuckyNum7 = 0;
	SelectDate = 0;
	NxetTime = 0;

	// LuckyNum Last Select
	unsigned char cmdstr4[] = "SELECT LuckyNum1, LuckyNum2, LuckyNum3, LuckyNum4, LuckyNum5, LuckyNum6, LuckyNum7, SelectDate, NxetTime From RohanGame.dbo.TLuckyNumLast Where UserID = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UserID, 0, 0);

	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr4, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS)
		{
			// LuckyNum1
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &LuckyNum1, 0, NULL);
			// LuckyNum2
			SQLGetData(SHSTMT, 2, SQL_C_ULONG, &LuckyNum2, 0, NULL);
			// LuckyNum3
			SQLGetData(SHSTMT, 3, SQL_C_ULONG, &LuckyNum3, 0, NULL);
			// LuckyNum4
			SQLGetData(SHSTMT, 4, SQL_C_ULONG, &LuckyNum4, 0, NULL);
			// LuckyNum5
			SQLGetData(SHSTMT, 5, SQL_C_ULONG, &LuckyNum5, 0, NULL);
			// LuckyNum6
			SQLGetData(SHSTMT, 6, SQL_C_ULONG, &LuckyNum6, 0, NULL);
			// LuckyNum7
			SQLGetData(SHSTMT, 7, SQL_C_ULONG, &LuckyNum7, 0, NULL);
			// SelectDate
			SQLGetData(SHSTMT, 8, SQL_C_ULONG, &SelectDate, 0, NULL);
			// NxetTime
			SQLGetData(SHSTMT, 9, SQL_C_ULONG, &NxetTime, 0, NULL);
		}
	}

	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	addrs = pLucky + 0x18;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum1;
	addrs = pLucky + 0x19;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum2;
	addrs = pLucky + 0x1A;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum3;
	addrs = pLucky + 0x1B;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum4;
	addrs = pLucky + 0x1C;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum5;
	addrs = pLucky + 0x1D;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum6;
	addrs = pLucky + 0x1E;
	*(reinterpret_cast<char*>(addrs)) = (char)LuckyNum7;
	addrs = pLucky + 0x1F;
	*(reinterpret_cast<char*>(addrs)) = (char)SelectDate;

	LUCKY_NUMBER_USER_EXPIRE_TIME = NxetTime;

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
}

void SetSelectNumber(int pDynamic, int No, int Number)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	int addrs;
	int UserID;
	int SelectDate = 0;
	int NxetTime = 0;

	time_t now = time(0);
	tm *ltm = localtime(&now);
	SelectDate = ltm->tm_wday;
	if (SelectDate == 0) SelectDate = 7;

	addrs = (DWORD)pDynamic + 0x2627;
	*(reinterpret_cast<char*>(addrs)) = (char)SelectDate;

	addrs = (DWORD)pDynamic + 0x4F0;
	UserID = *(reinterpret_cast<int*>(addrs));

	unsigned char cmdstr1[] = "UPDATE RohanGame.dbo.TLuckyNumCurrent SET LuckyNum1 = ?, SelectDate = ?, NxetTime = ? WHERE UserID = ?";
	unsigned char cmdstr2[] = "UPDATE RohanGame.dbo.TLuckyNumCurrent SET LuckyNum2 = ?, SelectDate = ?, NxetTime = ? WHERE UserID = ?";
	unsigned char cmdstr3[] = "UPDATE RohanGame.dbo.TLuckyNumCurrent SET LuckyNum3 = ?, SelectDate = ?, NxetTime = ? WHERE UserID = ?";
	unsigned char cmdstr4[] = "UPDATE RohanGame.dbo.TLuckyNumCurrent SET LuckyNum4 = ?, SelectDate = ?, NxetTime = ? WHERE UserID = ?";
	unsigned char cmdstr5[] = "UPDATE RohanGame.dbo.TLuckyNumCurrent SET LuckyNum5 = ?, SelectDate = ?, NxetTime = ? WHERE UserID = ?";
	unsigned char cmdstr6[] = "UPDATE RohanGame.dbo.TLuckyNumCurrent SET LuckyNum6 = ?, SelectDate = ?, NxetTime = ? WHERE UserID = ?";
	unsigned char cmdstr7[] = "UPDATE RohanGame.dbo.TLuckyNumCurrent SET LuckyNum7 = ?, SelectDate = ?, NxetTime = ? WHERE UserID = ?";

	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &Number, 0, 0);
	SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &SelectDate, 0, 0);
	SQLBindParameter(SHSTMT, 3, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &NxetTime, 0, 0);
	SQLBindParameter(SHSTMT, 4, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UserID, 0, 0);

	switch(No)
	{
		case 0:
		{
			SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS);
		}
		break;
		case 1:
		{
			SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr2, SQL_NTS);
		}
		break;
		case 2:
		{
			SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr3, SQL_NTS);
		}
		break;
		case 3:
		{
			SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr4, SQL_NTS);
		}
		break;
		case 4:
		{
			SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr5, SQL_NTS);
		}
		break;
		case 5:
		{
			SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr6, SQL_NTS);
		}
		break;
		case 6:
		{
			SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr7, SQL_NTS);
		}
		break;
	}

	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
}

void LuckyNumberReset()
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	int i, j;
    int num[6];
	int n;
	int Number1, Number2, Number3, Number4, Number5, Number6, Number7;
	int NxetTime;

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	srand(time(NULL));
	for(i = 0; i < 7; i++)
	{
		n = rand()%50;  // 0-49
		n += 1;
		num[i] = n;
		for(j = 0; j < i; j++)
		{
			if(num[i] == num[j])
			{
				i--;
				break;
			}
		}
	}

	Number1 = num[0];
	Number2 = num[1];
	Number3 = num[2];
	Number4 = num[3];
	Number5 = num[4];
	Number6 = num[5];
	Number7 = num[6];
	// LuckyNum Current
	unsigned char cmdstr1[] = "{CALL [ROHAN_LuckyNumberReset](?,?,?,?,?,?,?)}";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &Number1, 0, 0);
	SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &Number2, 0, 0);
	SQLBindParameter(SHSTMT, 3, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &Number3, 0, 0);
	SQLBindParameter(SHSTMT, 4, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &Number4, 0, 0);
	SQLBindParameter(SHSTMT, 5, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &Number5, 0, 0);
	SQLBindParameter(SHSTMT, 6, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &Number6, 0, 0);
	SQLBindParameter(SHSTMT, 7, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &Number7, 0, 0);

	SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS);
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);
	
	// Reset Next Timestamp
	unsigned char cmdstr2[] = "SELECT NxetTime From RohanGame.dbo.TLuckyNumLast Where UserID = 0";

	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr2, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			// NxetTime
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &NxetTime, 0, NULL);
		}
	}

	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);

	LUCKY_NUMBER_EXPIRE_TIME = NxetTime;

}

void LuckyNumberUserReset(int pDynamic)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	int addrs;
	int pThis;
	int CurTimestamp;
	int UserID;
	int NxetTime;

	time_t seconds = time(NULL);
	CurTimestamp = (int)seconds;
	
	if (LUCKY_NUMBER_USER_EXPIRE_TIME != 0)
	{
		if (CurTimestamp >= LUCKY_NUMBER_USER_EXPIRE_TIME)
		{
			ODBCConnectDB(SHENV, SHDBC, SHSTMT);

			addrs = (DWORD)pDynamic + 0x4F0;
			UserID = *(reinterpret_cast<int*>(addrs));

			unsigned char cmdstr1[] = "{CALL [ROHAN_LuckyNumberUserReset](?)}";
			SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UserID, 0, 0);

			SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS);

			// GO
			SQLFreeStmt(SHSTMT, SQL_CLOSE);

			// Reset Next Timestamp
			unsigned char cmdstr2[] = "SELECT NxetTime From RohanGame.dbo.TLuckyNumLast Where UserID = ?";
			SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UserID, 0, 0);

			if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr2, SQL_NTS))
			{
				SQLFreeStmt(SHSTMT, SQL_CLOSE);
			}
			else
			{
				while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
					// NxetTime
					SQLGetData(SHSTMT, 1, SQL_C_ULONG, &NxetTime, 0, NULL);
				}
			}

			// GO
			SQLFreeStmt(SHSTMT, SQL_CLOSE);

			ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);

			LUCKY_NUMBER_USER_EXPIRE_TIME = NxetTime;

			pThis = pDynamic;
			LuckyNumberInit(pThis);
		}
	}
}
