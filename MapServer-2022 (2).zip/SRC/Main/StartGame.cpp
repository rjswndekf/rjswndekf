#include <RHMain.h>
#include <MapFunctions.h>
#include <SkillManager.h>
#include <Player.h>
#include <RHVIP.h>

using namespace std;

// Initialization Acquire RewardCron
//unsigned char Packet_146B[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

// Initialization VIP
unsigned char VIPINIT[88] = {0};
int VIPINIT_ADDRS = (DWORD)VIPINIT;

int START_PLAYER;
unsigned char STARTGAME_BUFFER[201] = {0};
int STARTGAME_ADDRS = (DWORD)STARTGAME_BUFFER;
int STARTGAME_RET = 0x004CE49C;

int ENTERWORD_THIS;
int ENTERWORLD_RET = 0x0048E214;

int RESPAWN_THIS;
int RESPAWN_RET = 0x00436FDB;

extern int CHARSTATUS_SIZE;
int START_PKSIZE = 0x15 + CHARSTATUS_SIZE;

/******* ASM Funs *******/
extern int GETSTATUS;
extern int GETABILITY;
extern int SENDPACKET_FUN;

/********************* Enc Packet *********************/
void UserDataInit(int pDynamic, int pSendPacket)
{
	int addrs;
	int pThis;

	/***
	// Check & Free User Data
	int CheckUserData;
	char * UserMData;
	addrs = pDynamic + 0x2650;
	CheckUserData = *(reinterpret_cast<int*>(addrs));
	if (CheckUserData != 0)
	{
		memset((char*)CheckUserData, 0xFD, 128);
		free((char*)CheckUserData);
	}
	// Create User Data
	UserMData = (char*) malloc(128 * sizeof(char));
	memset(UserMData, 0, 128);

	addrs = pDynamic + 0x2650;
	*(reinterpret_cast<int*>(addrs)) = (int)UserMData;
	***/

	// User Data Ext Init (pDynamic + 0x2600 Size 0x100)
	// pPCBang pDynamic + 0x2600 Size 0xC
	addrs = pDynamic + 0x2600;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = pDynamic + 0x2604;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = pDynamic + 0x2608;
	*(reinterpret_cast<int*>(addrs)) = 0;
	// pLucky pDynamic + 0x2610 Size 0x24
	// pVIP pDynamic + 0x2640 Size 0xC

	// Lucky Number Init
	pThis = pDynamic;
	LuckyNumberInit(pDynamic);
}

/******************** UnEnc Packet ********************/
void Packet280C(int pDynamic, int pSendPacket)
{
	unsigned char Packet_280C[] = {0x00, 0x00, 0x00};
	SendPacketEX(pDynamic, 0x280C, (int)Packet_280C, 0x3);
}

void HuntingBonusInit(int pDynamic, int pSendPacket)
{
	int addrs;
	int pPlayer;
	int CType;
	int Mode;
	int pThis;
	int StateCount;

	unsigned char HUNTINGINIT[4] = {0};
	unsigned char STATECOUNT_BUFFER[9] = {0};

	/*** VIP Initialization ***/
	addrs = (DWORD)VIPINIT_ADDRS + 0x13;
	*(reinterpret_cast<int*>(addrs)) = 5;
	addrs = (DWORD)VIPINIT_ADDRS + 0x23;
	*(reinterpret_cast<int*>(addrs)) = 5;
	addrs = (DWORD)VIPINIT_ADDRS + 0x33;
	*(reinterpret_cast<int*>(addrs)) = 5;
	addrs = (DWORD)VIPINIT_ADDRS + 0x43;
	*(reinterpret_cast<int*>(addrs)) = 5;
	addrs = (DWORD)VIPINIT_ADDRS + 0x53;
	*(reinterpret_cast<int*>(addrs)) = 5;

	pThis = pDynamic;
	SendPacket(pThis, 0x146E, VIPINIT_ADDRS, 0x58);

	/*** HuntingBonusInit ***/
	pThis = pDynamic;
	SendPacket(pThis, 0x1A4C, (int)HUNTINGINIT, 0x4);

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));

	pThis = (DWORD)pPlayer + 0x1140;
	EntityBaseStatusSetAbility(pThis, 0xF2, 0);
	pThis = (DWORD)pPlayer + 0x1140;
	EntityBaseStatusSetAbility(pThis, 0xF3, 0);
	pThis = (DWORD)pPlayer + 0x1140;
	EntityBaseStatusSetAbility(pThis, 0xF4, 0);
	pThis = (DWORD)pPlayer + 0x1140;
	EntityBaseStatusSetAbility(pThis, 0xF5, 0);

	pThis = pPlayer;
	PlayerSendStatus(pThis);

	/*** pPlayer Ext Data Init ***/
	// Trinity Arrendal EXP Init pPlayer + 0x2060 Size 0x8
	addrs = (DWORD)pPlayer + 0x2060;
	*(reinterpret_cast<__int64*>(addrs)) = 0;
	// Transcendence Stats Temp pPlayer + 0x2070 Size 0x6
	addrs = (DWORD)pPlayer + 0x2070;
	*(reinterpret_cast<__int64*>(addrs)) = 0;
	// AssassinInfo pPlayer + 0x2080 Size 0x20
	addrs = (DWORD)pPlayer + 0x2080;
	memset((char*)addrs, 0, 32);
	// Sky Equip Special Option Reassignment (pPlayer + 0x20A0 Size 0x10)
	addrs = (DWORD)pPlayer + 0x20A0;
	memset((char*)addrs, 0, 16);
	
	// Transcendence StateCount
	pThis = pPlayer;
	StateCount = BioticBaseGetAbility(pThis, 0x77);
	addrs = (int)STATECOUNT_BUFFER;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = (int)STATECOUNT_BUFFER + 0x1;
	*(reinterpret_cast<int*>(addrs)) = StateCount;
	addrs = (int)STATECOUNT_BUFFER + 0x5;
	*(reinterpret_cast<int*>(addrs)) = 0;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x1852, (int)STATECOUNT_BUFFER, 0x09);

	// RCM_MAP_PC_BANG_MILEAGE_INFO 0x1A20
	//GetPCBangPoint(pDynamic);

	/*** Assassin Info ***/
	pThis = pDynamic;
	AssassinRank(pThis);

	addrs = (DWORD)pPlayer + 0x1980;
	Mode = *(reinterpret_cast<int*>(addrs));
	if (Mode == 1)
	{
		pThis = pDynamic;
		LoadAssassinInfo(pThis);
	}

	/*** Trinity Weapon Info ***/
	addrs = (DWORD)pPlayer + 0x2C;
	CType = *(reinterpret_cast<int*>(addrs));

	if ((CType == 213046) || (CType == 213047))
	{
		pThis = pPlayer;
		TrinityWeaponInfo(pThis);
	}
}

/************* RCM_MAP_STARTGAME 0xD10E ***************/
// 2018 RCM_MAP_STARTGAME 0xD10E Patch
void StartGame()
{
	// pPlayer
	__asm mov ecx,dword ptr ss:[ebp-0x65C]
	__asm mov START_PLAYER, ecx

	/*** VIP Reward ***/
	SetVIPStatus(START_PLAYER);
	VIPReward(START_PLAYER);

	InitTransState(START_PLAYER);
	LoadTransAbility(START_PLAYER);

	__asm mov edi, STARTGAME_ADDRS
	// +0 dword 0
	__asm mov dword ptr es:[edi],eax
	// +4 byte 0
	__asm mov byte ptr es:[edi+0x4],0x0
	// +5 CharStatus
	__asm add edi, 0x5
	__asm push edi
	//pPlayer
	__asm mov ecx,dword ptr ss:[ebp-0x65C]
	__asm push ecx
	__asm call GETSTATUS
	__asm mov eax,CHARSTATUS_SIZE
	__asm add edi, eax
	// pPlayer
	__asm mov ecx,dword ptr ss:[ebp-0x65C]
	// Write Experience L Dword
	__asm mov eax,dword ptr ds:[ecx+0x1950]
	__asm mov dword ptr es:[edi],eax
	// Write Experience H Dword
	__asm mov eax,dword ptr ds:[ecx+0x1954]
	__asm mov dword ptr es:[edi+0x4],eax
	__asm add edi, 0x8
	// Get Property Point
	__asm push 0x17
	__asm mov ecx,dword ptr ss:[ebp-0x65C]
	__asm call GETABILITY
	// Write Property Point
	__asm mov dword ptr es:[edi],eax
	__asm add edi, 0x4
	// Get Skill Point
	__asm push 0x16
	__asm mov ecx,dword ptr ss:[ebp-0x65C]
	__asm call GETABILITY
	// Write Skill Point
	__asm mov dword ptr es:[edi],eax
	__asm add edi, 0x4

	// Send Packet
	// 2021 PacketSize 0xC5; 2018 PacketSize 0x81;
	__asm mov edi, STARTGAME_ADDRS
	__asm mov eax, START_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0xD10E
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call SENDPACKET_FUN

	__asm jmp STARTGAME_RET
}

/*********** Enter / Leave World Functions ************/
void EnterWorldProc()
{
	// Original Code
	__asm mov dword ptr ss:[ebp-0x94],eax

	// pDynamic
	__asm mov ecx,dword ptr ss:[ebp-0x100]
	__asm mov ENTERWORD_THIS,ecx
	
	EnterWorld(ENTERWORD_THIS);

	__asm jmp ENTERWORLD_RET
}

void EnterWorld(int pDynamic)
{
	int addrs;
	int pPlayer;
	int CType;
	//int pRewardCron;

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	
	if (pPlayer != 0)
	{
		addrs = (DWORD)pPlayer + 0x2C;
		CType = *(reinterpret_cast<int*>(addrs));
		
		AffectSkillON(pPlayer);
		// Initialization Trinity Points
		if ((CType == 213046) || (CType == 213047))
		{
			InitTP(pPlayer);
			SendTPBroadcast(pPlayer);
		}
	}

	// Initialization Acquire RewardCron
	//pRewardCron = (DWORD)Packet_146B;
	//SendPacket(pDynamic, 0x146B, pRewardCron, 0x08);
}

/********************** Respawn ***********************/
void RespawnProc()
{
	// pDynamic
	__asm mov ecx,dword ptr ss:[ebp-0x2F0]
	__asm mov RESPAWN_THIS,ecx
	
	EnterWorld(RESPAWN_THIS);

	__asm mov eax,dword ptr ss:[ebp-0x1E4]

	__asm jmp RESPAWN_RET
}

/***
void LeaveWorldProc()
{
	int pDynamic

	__asm mov edx,dword ptr ss:[ebp+0xFFFF8468]
	__asm mov Dynamic_Pointer, edx

	LeaveWorld(pDynamic);
	
	__asm mov edx,dword ptr ss:[ebp+0xFFFF8468]

	__asm mov edi,0x00419D42
	__asm jmp edi
}

void LeaveWorld(int pDynamic)
{
	int addrs;
	int pPlayer;

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));

	// Trinity Affect Skill Disable
	AffectSkillOFF(pPlayer);
}
***/
