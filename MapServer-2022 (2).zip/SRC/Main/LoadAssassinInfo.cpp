#include <RHMain.h>
#include <MapFunctions.h>
#include <RHDB.h>
#include <sqlext.h>

using namespace std;

extern int ASSRANK_ADDRS;

unsigned char ASSASSIN_INFO_MAIN[20] = {0};
unsigned char ASSASSIN_LIMIT_TYPE_MAIN[4] = {0};
unsigned char ASSASSIN_RANK_MAIN[39] = {0};

void LoadAssassinInfo(int pDynamic)
{
	int addrs;
	int pPlayer;
	int pThis;
	int AccumulatedKillCount = 0;
	int WeeklyKillCount = 0;
	int AccumulatedKillPoint = 0;
	int WeeklyKillPoint = 0;
	int ChangeTime = 0;
	int AssType = 0;
	int AssPK = 0;
	int AssMK = 0;

	pThis = pDynamic;
	GetAssassinInfo(pThis);

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));

	// Load Assassin Info
	addrs = (DWORD)pPlayer + 0x2080;
	AccumulatedKillCount = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x2084;
	AccumulatedKillPoint = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x2088;
	WeeklyKillCount = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x208C;
	WeeklyKillPoint = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x2090;
	ChangeTime = *(reinterpret_cast<int*>(addrs));

	// Client Packet
	addrs = (int)ASSASSIN_INFO_MAIN;
	*(reinterpret_cast<int*>(addrs)) = ChangeTime;
	addrs = (int)ASSASSIN_INFO_MAIN + 0x4;
	*(reinterpret_cast<int*>(addrs)) = AccumulatedKillCount;
	addrs = (int)ASSASSIN_INFO_MAIN + 0x8;
	*(reinterpret_cast<int*>(addrs)) = AccumulatedKillPoint;
	addrs = (int)ASSASSIN_INFO_MAIN + 0xC;
	*(reinterpret_cast<int*>(addrs)) = WeeklyKillCount;
	addrs = (int)ASSASSIN_INFO_MAIN + 0x10;
	*(reinterpret_cast<int*>(addrs)) = WeeklyKillPoint;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x1311, (int)ASSASSIN_INFO_MAIN, 0x14);

	// Assassin Limit Type
	addrs = (DWORD)pPlayer + 0x2094;
	AssType = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x2098;
	AssPK = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x209C;
	AssMK = *(reinterpret_cast<int*>(addrs));

	// Client Packet
	addrs = (int)ASSASSIN_LIMIT_TYPE_MAIN;
	*(reinterpret_cast<char*>(addrs)) = (char)AssType;
	addrs = (int)ASSASSIN_LIMIT_TYPE_MAIN + 1;
	*(reinterpret_cast<char*>(addrs)) = (char)AssPK;
	addrs = (int)ASSASSIN_LIMIT_TYPE_MAIN + 2;
	*(reinterpret_cast<short*>(addrs)) = (short)AssMK;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x1473, (int)ASSASSIN_LIMIT_TYPE_MAIN, 0x4);
}

void GetAssassinInfo(int pDynamic)
{
	//define handles and variables
	SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
	SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
	SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	int addrs;
	int pPlayer;
	int CharID;
	int AccumulatedKillCount = 0;
	int WeeklyKillCount = 0;
	int AccumulatedKillPoint = 0;
	int WeeklyKillPoint = 0;
	int ChangeTime = 0;
	int AssType = 0;
	int AssPK = 0;
	int AssMK = 0;

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));

	unsigned char cmdstr0[] = "SELECT accumulated_killcount, accumulated_killpoint, weekly_killcount, weekly_killpoint, change_time, type, pk, mk From RohanGame.dbo.TAssassinInfo Where char_id = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr0, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &AccumulatedKillCount, 0, NULL);
			SQLGetData(SHSTMT, 2, SQL_C_ULONG, &AccumulatedKillPoint, 0, NULL);
			SQLGetData(SHSTMT, 3, SQL_C_ULONG, &WeeklyKillCount, 0, NULL);
			SQLGetData(SHSTMT, 4, SQL_C_ULONG, &WeeklyKillPoint, 0, NULL);
			SQLGetData(SHSTMT, 5, SQL_C_ULONG, &ChangeTime, 0, NULL);
			SQLGetData(SHSTMT, 6, SQL_C_ULONG, &AssType, 0, NULL);
			SQLGetData(SHSTMT, 7, SQL_C_ULONG, &AssPK, 0, NULL);
			SQLGetData(SHSTMT, 8, SQL_C_ULONG, &AssMK, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);

	addrs = (DWORD)pPlayer + 0x2080;
	*(reinterpret_cast<int*>(addrs)) = AccumulatedKillCount;
	addrs = (DWORD)pPlayer + 0x2084;
	*(reinterpret_cast<int*>(addrs)) = AccumulatedKillPoint;
	addrs = (DWORD)pPlayer + 0x2088;
	*(reinterpret_cast<int*>(addrs)) = WeeklyKillCount;
	addrs = (DWORD)pPlayer + 0x208C;
	*(reinterpret_cast<int*>(addrs)) = WeeklyKillPoint;
	addrs = (DWORD)pPlayer + 0x2090;
	*(reinterpret_cast<int*>(addrs)) = ChangeTime;
	addrs = (DWORD)pPlayer + 0x2094;
	*(reinterpret_cast<int*>(addrs)) = AssType;
	addrs = (DWORD)pPlayer + 0x2098;
	*(reinterpret_cast<int*>(addrs)) = AssPK;
	addrs = (DWORD)pPlayer + 0x209C;
	*(reinterpret_cast<int*>(addrs)) = AssMK;
}

void AssassinRank(int pDynamic)
{
	int addrs;
	int pThis;
	int Rank;
	int CharID;
	int KillCount;
	int KillPoint;

	memset(ASSASSIN_RANK_MAIN, 0, 39);

	for (int i = 0; i < 3; i++ )
	{
		Rank = 0;
		CharID = 0;
		KillCount = 0;
		KillPoint = 0;

		addrs = ASSRANK_ADDRS + (i * 0xC);
		CharID = *(reinterpret_cast<int*>(addrs));
		if (CharID != 0)
		{
			Rank = i + 1;
			addrs = ASSRANK_ADDRS + 0x4 + (i * 0xC);
			KillCount = *(reinterpret_cast<int*>(addrs));
			addrs = ASSRANK_ADDRS + 0x8 + (i * 0xC);
			KillPoint = *(reinterpret_cast<int*>(addrs));

			addrs = (int)ASSASSIN_RANK_MAIN + (i * 0xD);
			*(reinterpret_cast<char*>(addrs)) = (char)Rank;

			addrs = (int)ASSASSIN_RANK_MAIN + 1 + (i * 0xD);
			*(reinterpret_cast<int*>(addrs)) = CharID;

			addrs = (int)ASSASSIN_RANK_MAIN + 5 + (i * 0xD);
			*(reinterpret_cast<int*>(addrs)) = KillCount;

			addrs = (int)ASSASSIN_RANK_MAIN + 9 + (i * 0xD);
			*(reinterpret_cast<int*>(addrs)) = KillPoint;
		}
	}

	pThis = pDynamic;
	SendPacket(pThis, 0x1312, (int)ASSASSIN_RANK_MAIN, 0x27);
}
