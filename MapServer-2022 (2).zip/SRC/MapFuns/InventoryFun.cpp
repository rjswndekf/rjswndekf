#include <MapFunctions.h>

using namespace std; 

/******* ASM Funs *******/
int SETITEMPTR = 0x006997E0;
int GETITEMPTR = 0x006998B0;
int GETITEMDATA = 0x0055B660;
int GETITEMCURCOUNT = 0x00699AA0;
int GETINVMAXSLOT = 0x00699A40;
int INVSLOTINIT = 0x006990C0;
int RESETINV = 0x00699710;
int GETBINDATA = 0x006DFE20;
int WEIGHTSTATE_BROADCAST = 0x0056AAA0;

int OPENITEMSCRIPT = 0x00686220;
int GETITEMTIMER = 0x0057C7C0;
int RELEASEITEMTIMER = 0x0057C8D0;
int REMOVEITEMTIMER = 0x0057C990;
int GETQUESTSTATUS = 0x005974C0;
int GETITEMLIMIT = 0x005602A0;
int OPENITEMEXP = 0x004FABE0;
int OPENITEMIP = 0x004FB6B0;
int OPENITEMMONEY = 0x004FB140;
int GETSCRIPTATTR = 0x006799E0;

/****************************************************************************************
 *** Inventory Functions
 ****************************************************************************************/
int SetItem(int pInventory, int Inventory, int Slot, int pItem)
{
	int ItemPointer;
	__asm mov ecx, pItem
	__asm push ecx
	__asm mov eax, Slot
	__asm push eax
	__asm mov edx, Inventory
	__asm push edx
	__asm mov ecx, pInventory
	__asm call SETITEMPTR
	__asm mov ItemPointer, eax
	return ItemPointer;
	
}
int GetItem(int pInventory, int Inventory, int Slot)
{
	int ItemPointer;
	__asm mov eax, Slot
	__asm mov edx, Inventory
	__asm push eax
	__asm push edx
	__asm mov ecx, pInventory
	__asm call GETITEMPTR
	__asm mov ItemPointer, eax
	return ItemPointer;
}

int GetItemData(int pItemGR)
{
	int pItem;

	__asm mov eax, pItemGR
	__asm push 0x0
	__asm push eax
	__asm mov ecx,dword ptr ds:[0x7F1CA4]
	__asm call GETITEMDATA
	__asm mov pItem, eax

	return pItem;	
}


int GetCurCount(int pInventory, int Inventory)
{
	int ItemCount;
	__asm mov eax, Inventory
	__asm push eax
	__asm mov ecx, pInventory
	__asm call GETITEMCURCOUNT
	__asm mov ItemCount, eax
	return ItemCount;

}

int GetAllowCount(int pInventory, int Inventory)
{
	int MaxSlot;
	__asm mov eax, Inventory
	__asm push eax
	__asm mov ecx, pInventory
	__asm call GETINVMAXSLOT
	__asm mov MaxSlot, eax
	return MaxSlot;
}

int InventorySlotInit(int pBag, int pItem)
{
	int Result;
	__asm mov eax,pItem
	__asm push eax
	__asm mov ecx,pBag
	__asm call INVSLOTINIT
	__asm mov Result, eax
	return Result;
}

int ResetInventory(int pInventory, int Inventory)
{
	int Result;
	__asm mov eax,Inventory
	__asm push eax
	__asm mov ecx,pInventory
	__asm call RESETINV
	__asm mov Result, eax
	return Result;
}

int GetItemBinAttribute(int pItemScript, unsigned int AttributeType)
{
	int ListAttribute;
	__asm mov eax, AttributeType
	__asm push eax
	__asm mov ecx, pItemScript
	__asm mov edx,dword ptr ds:[ecx]
	__asm call dword ptr ds:[edx+0x4]
	__asm mov ListAttribute, eax
	return ListAttribute;
}

int GetItemBinScriptInfo(unsigned int ItemID)
{
	int pBinInfo;
	__asm mov eax, ItemID
	__asm push eax
	__asm mov ecx,dword ptr ds:[0x7F1CAC]
	__asm call GETBINDATA
	__asm mov pBinInfo, eax
	return pBinInfo;
}

int GetItemMallScriptInfo(unsigned int ItemID)
{
	int pBinInfo;
	__asm mov eax, ItemID
	__asm push eax
	__asm mov edx,dword ptr ds:[0x7F1D34]
	__asm mov ecx,dword ptr ds:[edx+0x4]
	__asm call GETBINDATA
	__asm mov pBinInfo, eax
	return pBinInfo;
}

void WeightStateBroadcast(int pInventory)
{
	__asm mov ecx,pInventory
	__asm call WEIGHTSTATE_BROADCAST
}

/*** OpenUseItem Funs ***/
int GetOpenUseItemScript(int ItemID)
{
	int pScript;
	__asm mov eax,ItemID
	__asm push eax
	__asm mov ecx,dword ptr ds:[0x7F1CAC]
	__asm call OPENITEMSCRIPT
	__asm mov pScript,eax
	return pScript;
}

int GetItemTimer(int pPlayer, int pItem)
{
	int Result;
	__asm mov eax,pItem
	__asm push eax
	__asm mov ecx,pPlayer
	__asm add ecx,0x1A28
	__asm call GETITEMTIMER
	__asm mov Result,eax
	return Result;
}

void ReleaseItemTimer(int pPlayer, int nID)
{
	__asm mov eax,nID
	__asm push eax
	__asm mov ecx,pPlayer
	__asm add ecx,0x1A28
	__asm call RELEASEITEMTIMER
}

void RemoveItemTimer(int pPlayer, int nID)
{
	__asm mov eax,nID
	__asm push eax
	__asm mov ecx,pPlayer
	__asm add ecx,0x1A28
	__asm call REMOVEITEMTIMER	
}

int GetQusetIDStatus(int Status, int RunQuestID)
{
	int Result;
	__asm mov eax,RunQuestID
	__asm push eax
	__asm mov ecx,Status
	__asm call GETQUESTSTATUS
	__asm movzx eax,al
	__asm mov Result,eax
	return Result;
	
}

int GetItemLimitList(int GetItemID, int Count)
{
	int Result;
	__asm mov edx,Count
	__asm push edx
	__asm mov eax,GetItemID
	__asm push eax
	__asm call GETITEMLIMIT
	__asm mov Result,eax
	return Result;
}

int GetItemScriptAttrbute(int pScript, int AttrbuteValue)
{
	int Value;
	__asm mov edx,AttrbuteValue
	__asm push edx
	__asm mov ecx,pScript
	__asm call GETSCRIPTATTR
	__asm mov Value,eax
	return Value;
}

void OpenItemAddExp(int pPlayer, int ExpL, int ExpH)
{
	__asm push 0x0
	__asm push 0x3F800000
	__asm mov edx,ExpH
	__asm mov eax,ExpL
	__asm push edx
	__asm push eax
	__asm push edx
	__asm push eax
	__asm mov ecx,pPlayer
	__asm call OPENITEMEXP
}

void OpenItemAddIP(int pPlayer, int IpL, int IpH)
{
	__asm push 0x0
	__asm push 0x3A
	__asm mov edx,IpH
	__asm mov eax,IpL
	__asm push edx
	__asm push eax
	__asm mov ecx,pPlayer
	__asm call OPENITEMIP
}

void OpenItemAddMoney(int pPlayer, int MoneyL, int MoneyH)
{
	__asm push 0x0
	__asm push 0x3A
	__asm mov edx,MoneyH
	__asm mov eax,MoneyL
	__asm push edx
	__asm push eax
	__asm mov ecx,pPlayer
	__asm call OPENITEMMONEY
}
