#include <MapFunctions.h>

using namespace std; 

/******* ASM Funs *******/
int GETATTRIBUTE = 0x0068B2E0;
int SETATTRIBUTE = 0x0068B440;
int ITEMOPTGETTYPE = 0x0068B460;
int ITEMOPTSETTYPE = 0x0066E0B0;
int ITEMOPTGETVALUE = 0x00679A10;
int ITEMOPTSETVALUE = 0x0068B490;
int GETITEMGR = 0x0068B5C0;
int TGRITEMINIT = 0x004160E0;
int ALLOCITEM = 0x004D5AD0;
int CREATEITEM = 0x0055B590;
int GETITEMSTAMP = 0x0055A070;
int TIMERITEM = 0x0050FD00;
int GETOPTTYPE = 0x00688340;
int GETPLAYERCALVALUE = 0x004F8590;
int GETCTYPECALVALUE = 0x004F85D0;
int CALITEMOPT = 0x005769F0;
int ITEMCALQUALCAL = 0x004EACF0;
int GETEQUIPINFO = 0x006C7CF0;
int SETITEMSCRIPT = 0x0067E1D0;

// Charm Funs
int GETCHARMATTRVALUE = 0x00572810;
// Type 1
int SETCHARMEXPBONUS = 0x00515420;
// Type 34
int SETCHARMADDEXPBONUS = 0x005154F0;
// Type 2
int SETCHARMPARTYEXPBONUS = 0x0054BC10;
// Type 3
int SETCHARMMKBONUS = 0x00515750;
// Type 4
int SETCHARMPARTYMKBONUS = 0x0054BCC0;
// Type 5
int SETCHARMPARTYELEMENT = 0x0054BD70;
// MarriageRingCastingTime
int SETCASTINGTIME = 0x00510C80;

/****************************************************************************************
 *** EpochItem Functions
 ****************************************************************************************/
int GetAttribute(int pItem, int AttributeType)
{
	int Result;
	__asm mov eax, AttributeType
	__asm push eax
	__asm mov ecx, pItem
	__asm call GETATTRIBUTE
	__asm mov Result, eax
	return Result;
}

int SetAttribute(int pItem, int AttributeType, int Value)
{
	int Result;
	__asm mov ecx, Value
	__asm push ecx
	__asm mov eax, AttributeType
	__asm push eax
	__asm mov ecx, pItem
	__asm call SETATTRIBUTE
	__asm mov Result, eax
	return Result;
}

int ItemOptionGetType(int pItem, int OptionType)
{
	int Result;
	__asm mov eax, OptionType
	__asm push eax
	__asm mov ecx, pItem
	__asm call ITEMOPTGETTYPE
	__asm mov Result, eax
	return Result;
}

int ItemOptionSetType(int pItem, int OptionType, int Value)
{
	int Result;
	__asm mov ecx, Value
	__asm push ecx
	__asm mov eax, OptionType
	__asm push eax
	__asm mov ecx, pItem
	__asm add ecx,0x38
	__asm call ITEMOPTSETTYPE
	__asm mov Result, eax
	return Result;
}

int ItemOptionGetValue(int pItemScript, int OptionType)
{
	int Result = 0;
	__asm mov eax, OptionType
	__asm push eax
	__asm mov ecx, pItemScript
	__asm call ITEMOPTGETVALUE
	__asm mov Result, eax
	return Result;
}

int ItemOptionSetValue(int pItem, int OptionType, int Value)
{
	int Result = 0;
	__asm mov edx, Value
	__asm push edx
	__asm mov eax, OptionType
	__asm push eax
	__asm mov ecx, pItem
	__asm call ITEMOPTSETVALUE
	__asm mov Result, eax
	return Result;
}

void SetItemBinOptionValue(int pItem)
{
	int addrs;
	int pThis;
	int pItemScript;
	int Value;
	
	addrs = pItem + 0x1C;
	pItemScript = *(reinterpret_cast<int*>(addrs));
	
	if (pItemScript != 0)
	{
		for(int i = 1; i < 100; i++ )
		{
			pThis = pItem;
			Value = ItemOptionGetValue(pItemScript, i);
			if (Value != 0)
			{
				pThis = pItem;
				ItemOptionSetValue(pThis, i, Value);
			}
		}
	}
}

void EpochItemBaseGetItemGR(int pItem, int pItemGR)
{
	__asm mov eax, pItemGR
	__asm push eax
	__asm mov ecx, pItem
	__asm call GETITEMGR
}

void tagItemInit(int pItemGR)
{
	__asm mov ecx, pItemGR
	__asm call TGRITEMINIT
}


void AllocItem(int pResult, unsigned int ItemID)
{
	__asm mov eax,ItemID
	__asm push eax
	__asm mov edx,pResult
	__asm push edx
	__asm mov ecx,0x7F852C
	__asm call ALLOCITEM
}

int CreateItem(int pResult, int Stack)
{
	int pItem;
	__asm mov eax,Stack
	__asm push eax
	__asm mov edx,pResult
	__asm push edx
	__asm mov ecx,dword ptr ds:[0x7F1CA4]
	__asm call CREATEITEM
	__asm mov pItem,eax
	return pItem;
}

void GetItemStamp(int pItem, int pStamp)
{
	__asm push 0x0
	__asm push 0x0
	__asm mov ecx,pItem
	__asm call GETITEMSTAMP
	__asm mov ecx,pStamp
	__asm mov dword ptr ds:[ecx],eax
	__asm mov dword ptr ds:[ecx+0x4],edx
}

void TimerItemManager(int pPlayer, int pItem, int pStamp)
{
	__asm mov ecx,pStamp
	__asm mov eax,dword ptr ds:[ecx]
	__asm mov edx,dword ptr ds:[ecx+0x4]
	__asm push edx
	__asm push eax
	__asm mov eax,pItem
	__asm push eax
	__asm mov ecx,pPlayer
	__asm call TIMERITEM
}

int GetItemOptionType(int AttributeType, int Opt)
{
	int Option;
	__asm mov eax,Opt
	__asm push eax
	__asm mov edx,AttributeType
	__asm push edx
	__asm call GETOPTTYPE
	__asm mov Option,eax
	return Option;

}

int GetPlayerCalValue(int pPlayer, int Value)
{
	int Result;
	__asm mov eax,Value
	__asm push eax
	__asm mov ecx,pPlayer
	__asm call GETPLAYERCALVALUE
	__asm mov Result,eax
	return Result;
}

int GetCTypeCalValue(int pPlayer, int Value)
{
	int Result;
	__asm mov eax,Value
	__asm push eax
	__asm mov ecx,pPlayer
	__asm call GETCTYPECALVALUE
	__asm mov Result,eax
	return Result;
}

void CalItemOption(int pInventory, int OptionType, int CalValue, int Active)
{
	__asm mov eax,Active
	__asm push eax
	__asm mov ecx,CalValue
	__asm push ecx
	__asm mov edx,OptionType
	__asm push edx
	__asm mov ecx,pInventory
	__asm call CALITEMOPT
}

void ItemCalQualities(int pInventory, int OptionType, int Value, int Active)
{
	__asm mov eax, Active
	__asm push eax
	
	__asm mov eax, Value
	__asm push eax
	
	__asm mov eax, OptionType
	__asm push eax

	__asm mov ecx, pInventory
	__asm add ecx,0x38
	__asm call ITEMCALQUALCAL
}

int GetEquipInfo(int ItemID)
{
	int pEquipInfo;
	__asm mov eax, ItemID
	__asm push eax
	__asm mov ecx,dword ptr ds:[0x4BEF024]
	__asm call GETEQUIPINFO
	__asm mov pEquipInfo,eax
	return pEquipInfo;
}

int GetReinforceType(int pItem)
{
	int ReinforceType = 0x4F;
	int ItemType;
	int ItemDesc;

	ItemType = GetAttribute(pItem, 0);
	ItemDesc = GetAttribute(pItem, 1);

	// Weapon
	if (((ItemType > 0) && (ItemType < 13)) || (ItemType == 234) || (ItemType == 235))
	{
		if ((ItemDesc == 11) || (ItemDesc == 21)) ReinforceType = 0x55;
	}
	else
	{
		// Armor
		if (((ItemType > 12) && (ItemType < 19)) || ((ItemType > 227) && (ItemType < 233)))
		{
			if (ItemDesc == 11) ReinforceType = 0x56;
		}
	}

	return ReinforceType;
}

void SetItemScriptAttrbute(int pThis, int Option, int Value)
{
	__asm mov ecx, Value
	__asm push ecx
	__asm mov eax, Option
	__asm push eax
	__asm mov ecx, pThis
	__asm call ITEMOPTSETTYPE
}

void SetItemScript(int pThis, int ItemID, int pItemScript)
{
	__asm mov ecx, pItemScript
	__asm push ecx
	__asm mov eax, ItemID
	__asm push eax
	__asm mov ecx, pThis
	__asm call SETITEMSCRIPT
}

/****************************************************************************************
 *** Charm Functions
 ****************************************************************************************/

int GetCharmAttribute(int pInventory, int CharmSubType, int AttributeType)
{
	int AttributeValue;

	__asm mov edx, AttributeType
	__asm push edx
	__asm mov eax, CharmSubType
	__asm push eax
	__asm mov ecx, pInventory
	__asm call GETCHARMATTRVALUE
	__asm mov AttributeValue,eax

	return AttributeValue;
}

void SetCharmExpBonus(int pPlayer, int CharmValue)
{
	__asm mov eax, CharmValue
	__asm push eax
	__asm mov ecx, pPlayer
	__asm call SETCHARMEXPBONUS
}

void SetCharmAddExpBonus(int pPlayer, int CharmValue)
{
	__asm mov eax, CharmValue
	__asm push eax
	__asm mov ecx, pPlayer
	__asm call SETCHARMADDEXPBONUS
}
 
void SetCharmPartyExpBonus(int pParty)
{
	__asm mov eax, pParty
	__asm push eax
	__asm mov ecx, 0x00B35820
	__asm call SETCHARMPARTYEXPBONUS
}

void SetCharmMKBonus(int pPlayer, int CharmValue)
{
	__asm mov eax, CharmValue
	__asm push eax
	__asm mov ecx, pPlayer
	__asm call SETCHARMMKBONUS
}

void SetCharmPartyMKBonus(int pParty)
{
	__asm mov eax, pParty
	__asm push eax
	__asm mov ecx, 0x00B35820
	__asm call SETCHARMPARTYMKBONUS
}

void SetCharmPartyElement(int pParty)
{
	__asm mov eax, pParty
	__asm push eax
	__asm mov ecx, 0x00B35820
	__asm call SETCHARMPARTYELEMENT
}

void SetCastingTime(int pPlayer, int AttributeValue)
{
	__asm mov eax, AttributeValue
	__asm push eax
	__asm mov ecx, pPlayer
	__asm call SETCASTINGTIME
}