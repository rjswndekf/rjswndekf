#include <MapFunctions.h>
#include <RHDB.h>
#include <sqlext.h>

using namespace std;

unsigned char ARRENDALINFO_BUFFER[64] = {0};
int ARRENDALINFO_ADDRS = (DWORD)ARRENDALINFO_BUFFER;

/****************************************************************************************
 *** Arrendal Functions
 ****************************************************************************************/
void TrinityWeaponInfo(int PlayerPTR)
{
	int addrs;
	int pThis;
	unsigned int CType;
	unsigned int CharID = 0;
	unsigned int EpochID = 0;
	unsigned int ItemID = 0;
	unsigned int nID = 0;
	int Level = 0;
	__int64 EXP64 = 0;
	float ArendaExpRate = 0.0;
	int pBindArrendal;

	pThis = PlayerPTR;
	addrs = (DWORD)pThis + 0x30;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));

	// Get WeaponBindData
	pThis = PlayerPTR;
	pBindArrendal = GetWeaponBindData(pThis);
	addrs = (DWORD)pBindArrendal;
	nID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = (DWORD)pBindArrendal + 0x4;
	EXP64 = *(reinterpret_cast<__int64*>(addrs));
	addrs = (DWORD)pBindArrendal + 0xC;
	Level = *(reinterpret_cast<int*>(addrs));

	if (nID == 0)
	{
		pThis = PlayerPTR;
		DelWeaponBindData(pThis);

		// Create Trinity Weapon Info
		pThis = PlayerPTR;
		addrs = (DWORD)pThis + 0x2C;
		CType = *(reinterpret_cast<unsigned int*>(addrs));

		if (CType == 213046) ItemID = 2641460;
		if (CType == 213047) ItemID = 2642460;

		pThis = PlayerPTR;
		EpochID = GetWeaponBindEpochID(pThis, ItemID);
		if (EpochID != 0)
		{
			pThis = PlayerPTR;
			InsWeaponBindData(pThis, ItemID, EpochID);

			pBindArrendal = GetWeaponBindData(pThis);
			addrs = (DWORD)pBindArrendal;
			nID = *(reinterpret_cast<unsigned int*>(addrs));
			addrs = (DWORD)pBindArrendal + 0x4;
			EXP64 = *(reinterpret_cast<__int64*>(addrs));
			addrs = (DWORD)pBindArrendal + 0xC;
			Level = *(reinterpret_cast<int*>(addrs));

			pThis = PlayerPTR;
			ArendaExpRate = GetArrendalExpRate(pThis, ItemID);

			addrs = ARRENDALINFO_ADDRS;
			*(reinterpret_cast<int*>(addrs)) = 0x1;
			addrs = ARRENDALINFO_ADDRS + 0x4;
			*(reinterpret_cast<unsigned int*>(addrs)) = nID;
			addrs = ARRENDALINFO_ADDRS + 0x8;
			*(reinterpret_cast<unsigned int*>(addrs)) = Level;
			addrs = ARRENDALINFO_ADDRS + 0xC;
			*(reinterpret_cast<float*>(addrs)) = ArendaExpRate;

			addrs = PlayerPTR + 0x1098;
			pThis = *(reinterpret_cast<int*>(addrs));

			SendPacketEX(pThis, 0x3005, ARRENDALINFO_ADDRS, 0x40);
		}
	}
	else
	{
		pThis = PlayerPTR;
		ItemID = GetWeaponBindItem(pThis, nID);
		if (ItemID == 0)
		{
			pThis = PlayerPTR;
			DelWeaponBindData(pThis);
		}
		else
		{
			pThis = PlayerPTR;
			addrs = (DWORD)pThis + 0x2060;
			*(reinterpret_cast<__int64*>(addrs)) = EXP64;

			pThis = PlayerPTR;
			ArendaExpRate = GetArrendalExpRate(pThis, ItemID);

			addrs = ARRENDALINFO_ADDRS;
			*(reinterpret_cast<int*>(addrs)) = 0x1;
			addrs = ARRENDALINFO_ADDRS + 0x4;
			*(reinterpret_cast<unsigned int*>(addrs)) = nID;
			addrs = ARRENDALINFO_ADDRS + 0x8;
			*(reinterpret_cast<unsigned int*>(addrs)) = Level;
			addrs = ARRENDALINFO_ADDRS + 0xC;
			*(reinterpret_cast<float*>(addrs)) = ArendaExpRate;

			addrs = PlayerPTR + 0x1098;
			pThis = *(reinterpret_cast<int*>(addrs));

			SendPacketEX(pThis, 0x3005, ARRENDALINFO_ADDRS, 0x40);
		}
	}
}

float GetArrendalExpRate(int PlayerPTR, unsigned int ItemID)
{
	float CurEXPRate = 0.0;
	int addrs;
	int pWeaponInfo;
	unsigned int ItemIDdown;
	__int64 LEXP = 0;
	__int64 HEXP = 0;
	__int64 Diff = 0;
	
	float DiffFP = 0.0;
	float BaseRATE = 0.0;
	__int64 CurArrendalEXP = 0;
	__int64 CurGetEXP = 0;
	float CurGetEXPFP = 0.0;


	ItemIDdown = ItemID - 1;
	pWeaponInfo = GetItemBinScriptInfo(ItemIDdown);
	addrs = (DWORD)pWeaponInfo + 0x288;
	LEXP = *(reinterpret_cast<__int64*>(addrs));

	pWeaponInfo = GetItemBinScriptInfo(ItemID);
	addrs = (DWORD)pWeaponInfo + 0x288;
	HEXP = *(reinterpret_cast<__int64*>(addrs));

	// Arrendal Lv135
	if (ItemID == 2641576) LEXP = 0;
	if (ItemID == 2642575) LEXP = 0;

	Diff = HEXP - LEXP;

	addrs = (DWORD)PlayerPTR + 0x2060;
	CurArrendalEXP = *(reinterpret_cast<__int64*>(addrs));
	CurGetEXP = CurArrendalEXP - LEXP;

	DiffFP = (float)Diff;
	CurGetEXPFP = (float)CurGetEXP;

	BaseRATE = DiffFP / 100;

	CurEXPRate = CurGetEXPFP / BaseRATE;

	return CurEXPRate;
}

int GetWeaponBindData(int PlayerPTR)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);
	int addrs;
	int pThis;
	unsigned int CharID = 0;
	unsigned int nID = 0;
	__int64 EXP64 = 0;
	int level = 0;
	unsigned char ArrendalData[16] = {0};
	int pBindArrendal = (DWORD)ArrendalData;

	unsigned char cmdstr1[] = "SELECT nid, exp, level FROM RohanGame.dbo.TTrinityWeaponInfo WHERE charid = ?";

	pThis = PlayerPTR;
	addrs = (DWORD)pThis + 0x30;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));
	
	// Get Inventory 0 Items
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			// nid
			SQLGetData(SHSTMT, 1, SQL_C_BINARY, &ArrendalData[0], 4, NULL);
			// EXP
			SQLGetData(SHSTMT, 2, SQL_C_BINARY, &ArrendalData[4], 8, NULL);
			// Level
			SQLGetData(SHSTMT, 3, SQL_C_BINARY, &ArrendalData[12], 4, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);
	

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
	
	return pBindArrendal;
}

unsigned int GetWeaponBindItem(int PlayerPTR, unsigned int nID)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);
	
	int addrs;
	int pThis;
	unsigned int CharID = 0;
	unsigned int ItemID = 0;
	unsigned char cmdstr2[] = "SELECT type FROM RohanGame.dbo.TItem WHERE char_id = ? and id = ?";

	pThis = PlayerPTR;
	addrs = (DWORD)pThis + 0x30;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));

	// Get ItemID
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &nID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr2, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &ItemID, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);


	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
	
	return ItemID;
}

unsigned int GetWeaponBindEpochID(int PlayerPTR, unsigned int ItemID)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);
	
	int addrs;
	int pThis;
	unsigned int CharID = 0;
	unsigned int EpochID = 0;
	unsigned char cmdstry[] = "SELECT id FROM RohanGame.dbo.TItem WHERE char_id =? and type = ?";
	
	pThis = PlayerPTR;
	addrs = (DWORD)pThis + 0x30;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));

	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &ItemID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstry, SQL_NTS))
	{
			SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &EpochID, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
	
	return EpochID;

}

void InsWeaponBindData(int PlayerPTR, unsigned int ItemID, unsigned int EpochID)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	int addrs;
	int pThis;
	unsigned int CharID = 0;
	int ItemIDdown;
	int Level = 0;
	__int64 EXP64 = 0;
	int pWeaponInfo;
	unsigned char cmdstrz[] = "INSERT INTO RohanGame.dbo.TTrinityWeaponInfo Values(?, ?, ?, ?)";
	
	pThis = PlayerPTR;
	addrs = (DWORD)pThis + 0x30;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));

	ItemIDdown = ItemID - 1;
	pWeaponInfo = GetItemBinScriptInfo(ItemIDdown);
	addrs = (DWORD)pWeaponInfo + 0x288;
	EXP64 = *(reinterpret_cast<__int64*>(addrs));
	
	pWeaponInfo = GetItemBinScriptInfo(ItemID);
	addrs = (DWORD)pWeaponInfo + 0x27C;
	Level = *(reinterpret_cast<int*>(addrs));

	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &EpochID, 0, 0);
	SQLBindParameter(SHSTMT, 3, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &EXP64, 0, 0);
	SQLBindParameter(SHSTMT, 4, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &Level, 0, 0);
	SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstrz, SQL_NTS);
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	pThis = PlayerPTR;
	addrs = (DWORD)pThis + 0x2060;
	*(reinterpret_cast<__int64*>(addrs)) = EXP64;

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);	

}

void DelWeaponBindData(int PlayerPTR)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	int addrs;
	int pThis;
	unsigned int CharID = 0;
	unsigned char cmdstrx[] = "DELETE FROM RohanGame.dbo.TTrinityWeaponInfo WHERE charid = ?";

	pThis = PlayerPTR;
	addrs = (DWORD)pThis + 0x30;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));

	// Delete Trinity Weapon Info
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstrx, SQL_NTS);
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);	
}

void SaveTrinityWeaponInfo(int PlayerPTR, unsigned int nID, unsigned int ItemID, int FullRate)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	int addrs;
	//int pThis;
	unsigned int CharID;
	__int64 PAEXP;
	int pWeaponInfo;
	unsigned char cmdstr1[] = "UPDATE RohanGame.dbo.TTrinityWeaponInfo SET exp = ? WHERE charid = ? and nid = ?";
	
	addrs = (DWORD)PlayerPTR + 0x30;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));
	
	if (FullRate == 1)
	{
		pWeaponInfo = GetItemBinScriptInfo(ItemID);
		addrs = (DWORD)pWeaponInfo + 0x288;
		PAEXP = *(reinterpret_cast<__int64*>(addrs));
	}
	else
	{
		addrs = (DWORD)PlayerPTR + 0x2060;
		PAEXP = *(reinterpret_cast<__int64*>(addrs));
	}

	// Save Trinity Weapon Info
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &PAEXP, 0, 0);
	SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	SQLBindParameter(SHSTMT, 3, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &nID, 0, 0);
	SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS);
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);

}

void UpgradeTrinityWeaponInfo(int PlayerPTR, unsigned int nID, unsigned int ItemID, int AutoUpgrade)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	int addrs;
	int pThis;
	unsigned int CharID;
	__int64 PAEXP;
	int pWeaponInfo;
	int Level;
	int UpLevel;

	unsigned char cmdstr1[] = "UPDATE RohanGame.dbo.TTrinityWeaponInfo SET exp = ?, level = ? WHERE charid = ? and nid = ?";

	pThis = PlayerPTR;
	addrs = (DWORD)pThis + 0x30;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));
	
	pWeaponInfo = GetItemBinScriptInfo(ItemID);
	addrs = (DWORD)pWeaponInfo + 0x27C;
	Level = *(reinterpret_cast<unsigned int*>(addrs));

	UpLevel = Level + 1;

	if (AutoUpgrade == 1)
	{
		pThis = PlayerPTR;
		addrs = (DWORD)pThis + 0x2060;
		PAEXP = *(reinterpret_cast<__int64*>(addrs));
	}
	else
	{
		pWeaponInfo = GetItemBinScriptInfo(ItemID);
		addrs = (DWORD)pWeaponInfo + 0x288;
		PAEXP = *(reinterpret_cast<__int64*>(addrs));
	}

	// Upgrade Trinity Weapon Info
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &PAEXP, 0, 0);
	SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UpLevel, 0, 0);
	SQLBindParameter(SHSTMT, 3, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	SQLBindParameter(SHSTMT, 4, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &nID, 0, 0);
	SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS);
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
}

void ArrendalInitBroadcast(int PlayerPTR, unsigned int ItemID, unsigned int nID)
{
	int addrs;
	int pThis;
	int pWeaponInfo;
	int Level;
	float ArendaExpRate;

	pWeaponInfo = GetItemBinScriptInfo(ItemID);
	addrs = (DWORD)pWeaponInfo + 0x27C;
	Level = *(reinterpret_cast<int*>(addrs));

	pThis = PlayerPTR;
	ArendaExpRate = GetArrendalExpRate(pThis, ItemID);

	addrs = ARRENDALINFO_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0x1;
	addrs = ARRENDALINFO_ADDRS + 0x4;
	*(reinterpret_cast<unsigned int*>(addrs)) = nID;
	addrs = ARRENDALINFO_ADDRS + 0x8;
	*(reinterpret_cast<unsigned int*>(addrs)) = Level;
	addrs = ARRENDALINFO_ADDRS + 0xC;
	*(reinterpret_cast<float*>(addrs)) = ArendaExpRate;

	addrs = PlayerPTR + 0x1098;
	pThis = *(reinterpret_cast<int*>(addrs));
	SendPacketEX(pThis, 0x3005, ARRENDALINFO_ADDRS, 0x40);
}
