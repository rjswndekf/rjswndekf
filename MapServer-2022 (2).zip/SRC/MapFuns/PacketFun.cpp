#include <MapHooks.h>

using namespace std; 


/******* ASM Funs *******/
int CHARPACKET_FUN = 0x0053D6E0;
int SENDPACKET_FUN = 0x0066A2C0;
int SENDPACKETEX_FUN = 0x00661850;
int SENDCRYPTPACKET_FUN = 0x0066A250;
int SENDOPTPACKET_FUN = 0x00669F10;

/****************************************************************************************
 *** Packet Functions
 ****************************************************************************************/
void CharStatusPacket(int pPacketType)
{
	__asm mov eax,pPacketType
	__asm push eax
	__asm mov ecx,0x4BEBF34
	__asm call CHARPACKET_FUN
}

void SendPacket(int DynamicPTR, int PacketType, int PacketPTR, int PacketSize)
{
	// Packet Size
	__asm mov eax,PacketSize
	__asm push eax
	// Packet Data PTR
	__asm mov ecx,PacketPTR
	__asm push ecx
	// Packet Type
	__asm mov edx,PacketType
	__asm push edx
	// DynamicPTR
	__asm mov ecx,DynamicPTR
	// Send NoCrypt Packer Fun
	__asm call SENDPACKET_FUN

}

void SendPacketEX(int DynamicPTR, int PacketType, int PacketPTR, int PacketSize)
{
	// Packet Size
	__asm mov eax,PacketSize
	__asm push eax
	// Packet Data PTR
	__asm mov ecx,PacketPTR
	__asm push ecx
	// Packet Type
	__asm mov edx,PacketType
	__asm push edx
	// DynamicPTR
	__asm mov ecx,DynamicPTR
	// Send NoCrypt Packer Fun
	__asm call SENDPACKETEX_FUN

}

void SendCryptPacket(int DynamicPTR, int PacketType, int PacketPTR, int PacketSize)
{
	// Packet Size
	__asm mov eax,PacketSize
	__asm push eax
	// Packet Data PTR
	__asm mov ecx,PacketPTR
	__asm push ecx
	// Packet Type
	__asm mov edx,PacketType
	__asm push edx
	// DynamicPTR
	__asm mov ecx,DynamicPTR
	// Send Crypt Packer Fun
	__asm call SENDCRYPTPACKET_FUN
}

void SendOptPacket(int DynamicPTR, int PacketType, int PacketPTR, int PacketSize, int OPT)
{
	
	// Packet OPT
	__asm mov edx,OPT
	__asm push edx
	// Packet Size
	__asm mov eax,PacketSize
	__asm push eax
	// Packet Data PTR
	__asm mov ecx,PacketPTR
	__asm push ecx
	// Packet Type
	__asm mov edx,PacketType
	__asm push edx
	// DynamicPTR
	__asm mov ecx,DynamicPTR
	// Send Crypt Packer Fun
	__asm call SENDOPTPACKET_FUN
}
