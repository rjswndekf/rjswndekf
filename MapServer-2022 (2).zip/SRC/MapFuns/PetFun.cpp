#include <MapFunctions.h>

using namespace std; 

/******* ASM Funs *******/
int PETCALOPT = 0x004EACF0;
int PETSETOPT = 0x004EACD0;

/****************************************************************************************
 *** Pet Functions
 ****************************************************************************************/
void PetCalOption(int InventoryPTR, int OptionType, int Param, int Active)
{
	__asm mov eax, Active
	__asm push eax
	
	__asm mov eax, Param
	__asm push eax
	
	__asm mov eax, OptionType
	__asm push eax

	__asm mov ecx, InventoryPTR
	__asm add ecx,0x38
	__asm call PETCALOPT
}
void PetSetOption(int InventoryPTR, int OptionType, int Param)
{
	__asm mov eax, Param
	__asm push eax
	__asm mov edx, OptionType
	__asm push edx
	__asm mov ecx, InventoryPTR
	__asm add ecx,0x28
	__asm call PETSETOPT
}

int GetPetParams(int RDPTR, int Pnum)
{
	int addrs;
	int ItemPTR;
	int PetLevel;
	int PARAM1_OPTION = 0x25;
	int PARAM2_OPTION = 0x5A;
	int PARAM3_OPTION = 0x5D;
	int PARAM4_OPTION = 0x6E;
	int PARAM5_OPTION = 0x71;
	int AttributeType;
	int Params = 0;

	addrs = (DWORD)RDPTR + 0x8;
	ItemPTR = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)RDPTR + 0xC;
	PetLevel = *(reinterpret_cast<int*>(addrs));
	
	if (Pnum == 1)
	{
		AttributeType = PARAM1_OPTION + PetLevel;
		Params = GetAttribute(ItemPTR, AttributeType);
	}
	if (Pnum == 2)
	{
		AttributeType = PARAM2_OPTION + PetLevel;
		Params = GetAttribute(ItemPTR, AttributeType);
	}
	if (Pnum == 3)
	{
		AttributeType = PARAM3_OPTION + PetLevel;
		Params = GetAttribute(ItemPTR, AttributeType);
	}
	if (Pnum == 4)
	{
		AttributeType = PARAM4_OPTION + PetLevel;
		Params = GetAttribute(ItemPTR, AttributeType);
	}
	if (Pnum == 5)
	{
		AttributeType = PARAM5_OPTION + PetLevel;
		Params = GetAttribute(ItemPTR, AttributeType);
	}
	return Params;

}
