#include <MapFunctions.h>
#include <RHDB.h>
#include <sqlext.h>

using namespace std; 

extern int CHARSTATUS_SIZE;

/******* ASM Funs *******/
int SENDSTATUS = (DWORD)PlayerSendStatus;
int SENDUPLEVEL = (DWORD)PlayerBroadcastUpLevel;
int SENDGETEXP = (DWORD)PlayerSendGetExperience;

int SUBMONEY = 0x004FB420;
int GETHASHDATA = 0x0066B450;
int BROADCASTUPLEVEL = 0x004F87B0;
int SENDCONQUERORLEVEL = 0x00516610;
int GETCUREXPRATE = 0x004F1AD0;
int GETEXPSCRIPT = 0x006C7630;
int GETNAME = 0x004F02A0;
int GETCURLIFE = 0x004EED80;
int GETCURMANA = 0x004EEE20;
int CHECKSELFITEMWORK = 0x00509C10;
int CHECKWORKITEM = 0x0050A5C0;
int CHECKTRADEITEMWORK = 0x00509E20;
int CONQUEROR_READ = 0x006DC530;
int CALALLABILITY = 0x004F2C00;
int CALABILITY = 0x004F37E0;
int CALCHATABI = 0x004D63C0;
int SENDNOTICE = 0x00504120;
int GETGUILD = 0x005B6990;
int GETPARTY = 0x0054A770;

unsigned char GETSTATUS_BUFFER[204] = {0};
int GETSTATUS_BUFFER_ADDRS = (DWORD)GETSTATUS_BUFFER;

unsigned char INCABILITY_BUFFER[212];
int INCABILITY_BUFFER_ADDRS = (DWORD)INCABILITY_BUFFER;

unsigned char DBTASK_INCABILITY[18];
int DBTASK_INCABILITY_ADDRS = (DWORD)DBTASK_INCABILITY;

unsigned char GETEXPERIENCE_BUFFER[12] = {0};

unsigned char CRON_BUFFER[8] = {0};
int CRON_BUFFER_ADDRS = (DWORD)CRON_BUFFER;

unsigned char DBSUBMONEY_BUFFER[16] = {0};
int DBSUBMONEY_BUFFER_ADDRS = (DWORD)DBSUBMONEY_BUFFER;

unsigned char SUBMONEY_BUFFER[17] = {0};
int SUBMONEY_BUFFER_ADDRS = (DWORD)SUBMONEY_BUFFER;

/****************************************************************************************
 *** Player Functions
 ****************************************************************************************/
void PlayerSendStatus(int pPlayer)
{
	int addrs;
	int PacketSize;
	int PropertyPoint;
	int StrVar;
	int DexVar;
	int VitVar;
	int IntVar;
	int PsyVar;
	int AgiVar;
	int DynamicPTR;
	
	addrs = GETSTATUS_BUFFER_ADDRS;
	PlayerGetStatusInfo(pPlayer, GETSTATUS_BUFFER_ADDRS);

	PropertyPoint = BioticBaseGetAbility(pPlayer, 0x17);
	// 2021 CharDataSize 0xB0; 2018 CharDataSize 0x6C;
	addrs += CHARSTATUS_SIZE;
	*(reinterpret_cast<int*>(addrs)) = PropertyPoint;
	
	StrVar = BioticBaseGetAbility(pPlayer, 0x0);
	addrs += 4;
	*(reinterpret_cast<short*>(addrs)) = (short)StrVar;

	DexVar = BioticBaseGetAbility(pPlayer, 0x3);
	addrs += 2;
	*(reinterpret_cast<short*>(addrs)) = (short)DexVar;

	VitVar = BioticBaseGetAbility(pPlayer, 0x1);
	addrs += 2;
	*(reinterpret_cast<short*>(addrs)) = (short)VitVar;

	IntVar = BioticBaseGetAbility(pPlayer, 0x2);
	addrs += 2;
	*(reinterpret_cast<short*>(addrs)) = (short)IntVar;

	PsyVar = BioticBaseGetAbility(pPlayer, 0x4);
	addrs += 2;
	*(reinterpret_cast<short*>(addrs)) = (short)PsyVar;

	AgiVar = BioticBaseGetAbility(pPlayer, 0x5);
	addrs += 2;
	*(reinterpret_cast<short*>(addrs)) = (short)AgiVar;
	
	addrs = (DWORD)pPlayer + 0x1098;
	DynamicPTR = *(reinterpret_cast<int*>(addrs));
	if (DynamicPTR != 0)
	{
		// 2021 PacketSize 0xC0; 2018 PacketSize 0x7C;
		PacketSize = CHARSTATUS_SIZE + 0x10;
		SendPacket(DynamicPTR, 0x1801, GETSTATUS_BUFFER_ADDRS, PacketSize);
	}
}

// Client Packet
void PlayerBroadcastIncAbility(int pPlayer)
{
	int addrs;
	int PacketSize;
	unsigned int CType;
	unsigned int EntityID;
	//int CharDataSize;
	int PropertyPoint;
	int StrVar;
	int DexVar;
	int VitVar;
	int IntVar;
	int PsyVar;
	int AgiVar;
	int DynamicPTR;
	
	addrs = (DWORD)pPlayer + 0x2C;
	CType = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = (DWORD)pPlayer + 0x30;
	EntityID = *(reinterpret_cast<unsigned int*>(addrs));

	addrs = INCABILITY_BUFFER_ADDRS;
	*(reinterpret_cast<unsigned int*>(addrs)) = CType;

	addrs = INCABILITY_BUFFER_ADDRS + 0x4;
	*(reinterpret_cast<unsigned int*>(addrs)) = EntityID;

	addrs = INCABILITY_BUFFER_ADDRS + 0x8;
	PlayerGetStatusInfo(pPlayer, addrs);

	PropertyPoint = BioticBaseGetAbility(pPlayer, 0x17);
	// 2021 CharDataSize 0xB0; 2018 CharDataSize 0x6C;
	addrs += CHARSTATUS_SIZE;
	*(reinterpret_cast<int*>(addrs)) = PropertyPoint;
	
	StrVar = BioticBaseGetAbility(pPlayer, 0x0);
	addrs += 4;
	*(reinterpret_cast<short*>(addrs)) = (short)StrVar;

	DexVar = BioticBaseGetAbility(pPlayer, 0x3);
	addrs += 2;
	*(reinterpret_cast<short*>(addrs)) = (short)DexVar;

	VitVar = BioticBaseGetAbility(pPlayer, 0x1);
	addrs += 2;
	*(reinterpret_cast<short*>(addrs)) = (short)VitVar;

	IntVar = BioticBaseGetAbility(pPlayer, 0x2);
	addrs += 2;
	*(reinterpret_cast<short*>(addrs)) = (short)IntVar;

	PsyVar = BioticBaseGetAbility(pPlayer, 0x4);
	addrs += 2;
	*(reinterpret_cast<short*>(addrs)) = (short)PsyVar;

	AgiVar = BioticBaseGetAbility(pPlayer, 0x5);
	addrs += 2;
	*(reinterpret_cast<short*>(addrs)) = (short)AgiVar;
	
	addrs = (DWORD)pPlayer + 0x1098;
	DynamicPTR = *(reinterpret_cast<int*>(addrs));
	if (DynamicPTR != 0)
	{
		// 2021 PacketSize 0xC8; 2018 PacketSize 0x84;
		PacketSize = 0x18 + CHARSTATUS_SIZE;
		SendPacket(DynamicPTR, 0x1808, INCABILITY_BUFFER_ADDRS, PacketSize);
	}

	PacketSize = 0x8 + CHARSTATUS_SIZE;
	BioticBroadCastAroundPlayers(pPlayer, 0x1808, INCABILITY_BUFFER_ADDRS, PacketSize, 0, 2);
}

// DBSK Packet
int PlayerDBTaskIncAbility(int pPlayer, int AbilityType, int Value)
{
	int addrs;
	int pThis;
	int LV;
	int HLV;
	int AllLV;
	int pExpScript;
	int AllStat = 0;
	int Point = 0;
	int CharID;
	int STR;
	int VIT;
	int INT;
	int DEX;
	int PSY;
	int AGI;

	pThis = pPlayer;
	LV = BioticBaseGetAbility(pThis, 0x15);
	if (LV > 115) LV = 115;

	pThis = pPlayer;
	HLV = BioticBaseGetAbility(pThis, 0x65);

	pThis = pPlayer;
	Point = BioticBaseGetAbility(pThis, 0x17);
	if (Point < Value) return 1;

	pThis = pPlayer + 0x1140;
	EntityBaseStatusIncAbility(pThis, AbilityType, Value);

	Point -= Value;
	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x17, Point);

	pThis = pPlayer;
	PlayerCalAllAbility(pThis);

	if (HLV > 0)
	{
		AllLV = LV + HLV;
		if (AllLV > 165) AllLV = 165;

		pExpScript = GetExpScript(AllLV);
		// All Stats Attribute 99 0x63
		addrs = pExpScript + 0x3C;
		AllStat = *(reinterpret_cast<int*>(addrs));	
	}

	// Create DBTASK Packet
	addrs = pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));
	addrs = DBTASK_INCABILITY_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = CharID;

	pThis = pPlayer;
	Point = BioticBaseGetAbility(pThis, 0x17);
	addrs = DBTASK_INCABILITY_ADDRS + 0x4;
	*(reinterpret_cast<short*>(addrs)) = (short)Point;

	pThis = pPlayer + 0x1140;
	STR = EntityBaseStatusGetAbility(pThis, 0);
	STR -= AllStat;
	addrs = DBTASK_INCABILITY_ADDRS + 0x6;
	*(reinterpret_cast<short*>(addrs)) = (short)STR;

	pThis = pPlayer + 0x1140;
	DEX = EntityBaseStatusGetAbility(pThis, 3);
	DEX -= AllStat;
	addrs = DBTASK_INCABILITY_ADDRS + 0x8;
	*(reinterpret_cast<short*>(addrs)) = (short)DEX;

	pThis = pPlayer + 0x1140;
	INT = EntityBaseStatusGetAbility(pThis, 2);
	INT -= AllStat;
	addrs = DBTASK_INCABILITY_ADDRS + 0xA;
	*(reinterpret_cast<short*>(addrs)) = (short)INT;

	pThis = pPlayer + 0x1140;
	PSY = EntityBaseStatusGetAbility(pThis, 4);
	PSY -= AllStat;
	addrs = DBTASK_INCABILITY_ADDRS + 0xC;
	*(reinterpret_cast<short*>(addrs)) = (short)PSY;

	pThis = pPlayer + 0x1140;
	VIT = EntityBaseStatusGetAbility(pThis, 1);
	VIT -= AllStat;
	addrs = DBTASK_INCABILITY_ADDRS + 0xE;
	*(reinterpret_cast<short*>(addrs)) = (short)VIT;

	pThis = pPlayer + 0x1140;
	AGI = EntityBaseStatusGetAbility(pThis, 5);
	AGI -= AllStat;
	addrs = DBTASK_INCABILITY_ADDRS + 0x10;
	*(reinterpret_cast<short*>(addrs)) = (short)AGI;
	
	SendPacketEX(0x7F23A0, 0x4A04, DBTASK_INCABILITY_ADDRS, 0x12);

	return 0;
}

void PlayerSendGetExperience(int pPlayer)
{
	int addrs;
	int DynamicPTR;
	int LV;
	unsigned int EXP_LDWOED;
	unsigned int EXP_HDWOED;
	unsigned short STATE;
	unsigned char GETEXPERIENCE_BUFFER[12];
	int pData;
	
	LV = BioticBaseGetAbility(pPlayer, 0x15);
	if (LV > 165) LV = 165;

	addrs = (DWORD)pPlayer + 0x1950;
	EXP_LDWOED = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = (DWORD)pPlayer + 0x1954;
	EXP_HDWOED = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = (DWORD)pPlayer + 0x1984;
	STATE = *(reinterpret_cast<unsigned short*>(addrs));

	addrs = (DWORD)GETEXPERIENCE_BUFFER;
	*(reinterpret_cast<unsigned short*>(addrs)) = (short)LV;
	addrs = (DWORD)GETEXPERIENCE_BUFFER + 0x2;
	*(reinterpret_cast<unsigned int*>(addrs)) = EXP_LDWOED;
	addrs = (DWORD)GETEXPERIENCE_BUFFER + 0x6;
	*(reinterpret_cast<unsigned int*>(addrs)) = EXP_HDWOED;
	addrs = (DWORD)GETEXPERIENCE_BUFFER + 0xA;
	*(reinterpret_cast<unsigned short*>(addrs)) = STATE;

	addrs = (DWORD)pPlayer + 0x1098;
	DynamicPTR = *(reinterpret_cast<int*>(addrs));
	if (DynamicPTR != 0)
	{
		pData = (DWORD)GETEXPERIENCE_BUFFER;
		SendPacket(DynamicPTR, 0x1809, pData, 0x0C);
	}
}

void PlayerCheckUpLevel(int pPlayer)
{
	int UPPLAYERLEVEL = 0x004F18A0;
	int pThis;

	float CurEXP;
	float MixRate = 100.0;
	float MinRate = 0.0;
	int CurLevel;

	CurLevel = BioticBaseGetAbility(pPlayer, 0x15);
	if (CurLevel < 115)
	{
		pThis = pPlayer;
		CurEXP = PlayerGetCurExpRate(pThis);
		pThis = pPlayer;
		if (CurEXP >= MixRate)
		{
			__asm push 0x1
			__asm mov ecx,pThis
			__asm call UPPLAYERLEVEL
		}
	}
}

void PlayerSubMoney(int pPlayer, unsigned int PriceL, unsigned int PriceH, int Reason, int SendClient)
{
	int addrs;
	int pThis;
	unsigned int CharID;
	__int64 Price;
	__int64 Cron;
	__int64 Diff;
	unsigned int CurCronL;
	unsigned int CurCronH;
	unsigned int Hash;

	// Price
	addrs = CRON_BUFFER_ADDRS;
	*(reinterpret_cast<unsigned int*>(addrs)) = PriceL;
	addrs = CRON_BUFFER_ADDRS + 0x4;
	*(reinterpret_cast<unsigned int*>(addrs)) = PriceH;
	addrs = CRON_BUFFER_ADDRS;
	Price = *(reinterpret_cast<__int64*>(addrs));

	// Current Cron
	addrs = pPlayer + 0x1958;
	Cron = *(reinterpret_cast<__int64*>(addrs));
	Cron -= Price;
	*(reinterpret_cast<__int64*>(addrs)) = Cron;

	addrs = pPlayer + 0x1958;
	CurCronL = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pPlayer + 0x195C;
	CurCronH = *(reinterpret_cast<unsigned int*>(addrs));

	// CharID
	addrs = pPlayer + 0x30;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));

	// DBPacket
	Diff = 0 - Price;
	addrs = DBSUBMONEY_BUFFER_ADDRS;
	*(reinterpret_cast<unsigned int*>(addrs)) = CharID;
	addrs = DBSUBMONEY_BUFFER_ADDRS + 0x4;
	*(reinterpret_cast<__int64*>(addrs)) = Diff;
	Hash = GetHashData(CurCronL, CurCronH, CharID);
	addrs = DBSUBMONEY_BUFFER_ADDRS + 0xC;
	*(reinterpret_cast<unsigned int*>(addrs)) = Hash;

	SendPacketEX(0x7F23A0, 0x4A17, DBSUBMONEY_BUFFER_ADDRS, 0x10);
	
	// ClientPacket
	if (SendClient == 1)
	{
		addrs = SUBMONEY_BUFFER_ADDRS;
		*(reinterpret_cast<unsigned char*>(addrs)) = (unsigned char)Reason;
		addrs = SUBMONEY_BUFFER_ADDRS + 0x1;
		*(reinterpret_cast<unsigned int*>(addrs)) = PriceL;
		addrs = SUBMONEY_BUFFER_ADDRS + 0x5;
		*(reinterpret_cast<unsigned int*>(addrs)) = PriceH;
		addrs = SUBMONEY_BUFFER_ADDRS + 0x9;
		*(reinterpret_cast<unsigned int*>(addrs)) = CurCronL;
		addrs = SUBMONEY_BUFFER_ADDRS + 0xD;
		*(reinterpret_cast<unsigned int*>(addrs)) = CurCronH;

		addrs = pPlayer + 0x1098;
		pThis = *(reinterpret_cast<int*>(addrs));
		if (pThis != 0)
		{
			SendPacketEX(pThis, 0x1506, SUBMONEY_BUFFER_ADDRS, 0x11);
		}
	}
}

unsigned int GetHashData(unsigned int CurCronL, unsigned int CurCronH, unsigned int CharID)
{
	unsigned int Hash;

	__asm mov eax, CharID
	__asm push eax
	__asm mov ecx, CurCronH
	__asm push ecx
	__asm mov edx, CurCronL
	__asm push edx
	__asm call GETHASHDATA
	__asm add esp,0xC
	__asm mov Hash, eax

	return Hash;
}

void PlayerBroadcastUpLevel(int pPlayer)
{
	__asm mov ecx, pPlayer
	__asm call BROADCASTUPLEVEL
}

void PlayerSendConquerorLevel(int pPlayer)
{
	__asm mov ecx, pPlayer
	__asm push ecx
	__asm call SENDCONQUERORLEVEL
}

float PlayerGetCurExpRate(int pPlayer)
{
	float CurExpRate;

	__asm mov ecx,pPlayer
	__asm call GETCUREXPRATE
	__asm fstp dword ptr ss:[ebp-0x8]

	__asm mov eax,dword ptr ss:[ebp-0x8]
	__asm mov CurExpRate, eax

	return CurExpRate;
}

float GetIndunRewardExpRate(int pPlayer, int pRewardExp)
{
	float RewardExpRate;
	float FRewardExp;
	float FEXP64DIFF;
	int addrs;
	int pThis;
	int LV;
	int HLV;
	int Level;
	int pExpScript;
	__int64 EXP64Min;
	__int64 EXP64Max;
	__int64 EXP64DIFF;
	__int64 RewardExp;

	pThis = pPlayer;
	LV = BioticBaseGetAbility(pThis, 0x15);
	if (LV > 115) LV = 115;

	pThis = pPlayer;
	HLV = BioticBaseGetAbility(pThis, 0x65);
	if (HLV > 50) HLV = 50;
	Level = LV + HLV;

	pExpScript = GetExpScript(Level);
	addrs = pExpScript + 0x10;
	EXP64Max = *(reinterpret_cast<__int64*>(addrs));

	Level -= 1;
	pExpScript = GetExpScript(Level);
	addrs = pExpScript + 0x10;
	EXP64Min = *(reinterpret_cast<__int64*>(addrs));

	addrs = pRewardExp;
	RewardExp = *(reinterpret_cast<__int64*>(addrs));

	EXP64DIFF = EXP64Max - EXP64Min;

	FRewardExp = (float)RewardExp;
	FEXP64DIFF = (float)EXP64DIFF;

	RewardExpRate = (FRewardExp * 100) / FEXP64DIFF;

	return RewardExpRate;
}

/**************************
 +10 PlayerEXP
 +18 MonExp
 +1C MaxExp
 +20 MaxExpdan
 +24 ProductExp
 +28 CraftPoint
 +2C BoostRate
 +30 ReinforceRate
 +34 StatPoint
 **************************/
int GetExpScript(int Level)
{
	int pEXP = 0;

	__asm mov eax,Level
	__asm push eax
	__asm mov ecx,dword ptr ds:[0x7F1CA8]
	__asm call GETEXPSCRIPT
	__asm mov pEXP, eax

	return pEXP;
}

int PlayerGetName(int pPlayer)
{
	int CharNamePTR;

	__asm mov ecx, pPlayer
	__asm mov edx,dword ptr ds:[ecx]
	__asm mov ecx, pPlayer
	__asm call GETNAME
	__asm mov CharNamePTR, eax

	return CharNamePTR;
}

int PlayerGetCurLife(int pPlayer)
{
	int CurLife;
	// CurLife = pPlayer+0xAC
	__asm mov ecx, pPlayer
	__asm call GETCURLIFE
	__asm mov CurLife, eax
	return CurLife;
	
}

int PlayerGetCurMana(int pPlayer)
{
	int CurMana;
	// CurMana = pPlayer+0xB0
	__asm mov ecx, pPlayer
	__asm call GETCURMANA	
	__asm mov CurMana, eax
	return CurMana;
}

int PlayerCheckSelfItemWork(int pPlayer, int Prisoner)
{
	int CheckWork;

	__asm mov eax, Prisoner
	__asm push eax
	__asm mov ecx, pPlayer
	__asm call CHECKSELFITEMWORK
	__asm mov CheckWork, eax

	return CheckWork;	
}

int PlayerCheckWorkItem(int pPlayer, unsigned int EpochID)
{
	int CheckWork;

	__asm mov eax, EpochID
	__asm push eax
	__asm mov ecx, pPlayer
	__asm call CHECKWORKITEM
	__asm mov CheckWork, eax

	return CheckWork;	
}

int PlayerCheckTradeItemWork(int pPlayer, int Prisoner)
{
	int CheckWork;

	__asm mov eax, Prisoner
	__asm push eax
	__asm mov ecx, pPlayer
	__asm call CHECKTRADEITEMWORK
	__asm mov CheckWork, eax

	return CheckWork;	
}

int PlayerGetConquerorData(int ConquerorLevel)
{
	int ConquerorPTR;

	__asm mov eax, ConquerorLevel
	__asm push eax
	__asm mov ecx,dword ptr ds:[0x7F1C5C]
	__asm call CONQUEROR_READ
	__asm mov ConquerorPTR, eax

	return ConquerorPTR;
}

void PlayerCalAllAbility(int pPlayer)
{
	__asm mov ecx, pPlayer
	__asm call CALALLABILITY

}

void PlayerCalAbility(int pPlayer, int AbilityType)
{
	__asm mov eax, AbilityType
	__asm push eax
	__asm mov ecx, pPlayer
	__asm call CALABILITY
}

void CalCharAbility(int pPlayer)
{
	__asm mov ecx, pPlayer
	__asm call CALCHATABI	
}

void PlayerSendNotice(int pPlayer, int PacketType, int pData, int PacketSize, int CharNameSize)
{
	__asm mov edx,CharNameSize
	__asm push edx
	__asm mov ecx,PacketSize
	__asm push ecx
	__asm mov eax,pData
	__asm push eax
	__asm mov edx,PacketType
	__asm push edx
	__asm mov ecx,pPlayer
	__asm call SENDNOTICE
}

void SetTransMode(int CharID)
{
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	unsigned char cmdstr[] = "UPDATE RohanGame.dbo.TUltimateAbility SET transmode = 1 WHERE char_id = ?";
	// Setting Transcendence Mode
	// Connect
	ODBCConnectDB(SHENV, SHDBC, SHSTMT);
	// Exec
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr, SQL_NTS);
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);
	// Disconnect
	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
}

void SetTransStat(int pPlayer)
{
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	int addrs;
	int pThis;
	int CharID;
	int STR;
	int DEX;
	int INT;
	int PSY;
	int VIT;
	int AGI;
	int STATECOUNT;
	int ULV;
	int SkillPoint;

	pThis = pPlayer;
	addrs = (DWORD)pThis + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));
	
	// SetCharTransState
	pThis = pPlayer;
	STR = BioticBaseGetAbility(pThis, 0x70);
	pThis = pPlayer;
	VIT = BioticBaseGetAbility(pThis, 0x71);
	pThis = pPlayer;
	INT = BioticBaseGetAbility(pThis, 0x72);
	pThis = pPlayer;
	DEX = BioticBaseGetAbility(pThis, 0x73);
	pThis = pPlayer;
	PSY = BioticBaseGetAbility(pThis, 0x74);
	pThis = pPlayer;
	AGI = BioticBaseGetAbility(pThis, 0x75);
	pThis = pPlayer;
	STATECOUNT = BioticBaseGetAbility(pThis, 0x77);
	pThis = pPlayer;
	ULV = BioticBaseGetAbility(pThis, 0x78);
	// Add ULV Point
	pThis = pPlayer;
	SkillPoint = BioticBaseGetAbility(pThis, 0x16);
	

	unsigned char cmdstr1[] = "UPDATE RohanGame.dbo.TUltimateAbility SET strength = ?, dexterity = ?, intelligence = ?, mentality = ?, health = ?, quickness = ?, statecount = ?, ulevel = ? WHERE char_id = ?";
	unsigned char cmdstr2[] = "UPDATE RohanGame.dbo.TCharacterAbility SET skill_point = ? WHERE char_id = ?";
	// Setting Transcendence Mode
	// Connect
	ODBCConnectDB(SHENV, SHDBC, SHSTMT);
	// Exec
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &STR, 0, 0);
	SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &DEX, 0, 0);
	SQLBindParameter(SHSTMT, 3, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &INT, 0, 0);
	SQLBindParameter(SHSTMT, 4, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &PSY, 0, 0);
	SQLBindParameter(SHSTMT, 5, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &VIT, 0, 0);
	SQLBindParameter(SHSTMT, 6, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &AGI, 0, 0);
	SQLBindParameter(SHSTMT, 7, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &STATECOUNT, 0, 0);
	SQLBindParameter(SHSTMT, 8, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &ULV, 0, 0);
	SQLBindParameter(SHSTMT, 9, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);

	SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS);
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// Exec
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &SkillPoint, 0, 0);
	SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);

	SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr2, SQL_NTS);
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// Disconnect
	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
}

void ShowTransMode(int CharID, int pLevel, int pTrans)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle
	
	int LV = 0;
	int HLV = 0;
	int ULV = 0;
	int TRANS = 0;

	unsigned char cmdstr1[] = "SELECT level From RohanGame.dbo.TCharacterAbility Where char_id = ?";
	unsigned char cmdstr2[] = "SELECT conquerorlevel From RohanGame.dbo.TConqueror Where char_id = ?";
	unsigned char cmdstr3[] = "SELECT ulevel From RohanGame.dbo.TUltimateAbility Where char_id = ?";
	unsigned char cmdstr4[] = "UPDATE RohanGame.dbo.TCharacterAbility SET level = ? WHERE char_id = ?";
	unsigned char cmdstr5[] = "SELECT transmode From RohanGame.dbo.TUltimateAbility Where char_id = ?";

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	// Level
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &LV, 0, NULL);

		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// ConquerorLevel
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr2, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &HLV, 0, NULL);

		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	if (HLV > 50) HLV = 50;

	// ULV
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr3, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &ULV, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// Update Level
	if (LV > 115) LV = 115;
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &LV, 0, 0);
	SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr4, SQL_NTS);
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// Transmode
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr5, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &TRANS, 0, NULL);

		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);

	// Set Shew Level
	LV += HLV;
	LV += ULV;

	*(reinterpret_cast<char*>(pLevel)) = (char)LV;

	// Set Show Trans Mode
	*(reinterpret_cast<char*>(pTrans)) = (char)TRANS;
}

void InitTransState(int pPlayer)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle
	
	int addrs;
	int pThis;
	int CharID;

	int STR = 0;
	int DEX = 0;
	int INT = 0;
	int PSY = 0;
	int VIT = 0;
	int AGI = 0;
	int TRANS = 0;
	int STATECOUNT = 0;
	int ULV = 0;

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);
	
	pThis = pPlayer;
	addrs = (DWORD)pThis + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));

	// STR
	unsigned char cmdstr1[] = "SELECT strength From RohanGame.dbo.TUltimateAbility Where char_id = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &STR, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// DEX
	unsigned char cmdstr2[] = "SELECT dexterity From RohanGame.dbo.TUltimateAbility Where char_id = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr2, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &DEX, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// INT
	unsigned char cmdstr3[] = "SELECT intelligence From RohanGame.dbo.TUltimateAbility Where char_id = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr3, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &INT, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// PSY
	unsigned char cmdstr4[] = "SELECT mentality From RohanGame.dbo.TUltimateAbility Where char_id = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr4, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &PSY, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// VIT
	unsigned char cmdstr5[] = "SELECT health From RohanGame.dbo.TUltimateAbility Where char_id = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr5, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &VIT, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// AGI
	unsigned char cmdstr6[] = "SELECT quickness From RohanGame.dbo.TUltimateAbility Where char_id = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr6, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &AGI, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// Trans
	unsigned char cmdstr7[] = "SELECT transmode From RohanGame.dbo.TUltimateAbility Where char_id = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr7, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &TRANS, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// StateCount
	unsigned char cmdstr8[] = "SELECT statecount From RohanGame.dbo.TUltimateAbility Where char_id = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr8, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &STATECOUNT, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// ULV
	unsigned char cmdstr9[] = "SELECT ulevel From RohanGame.dbo.TUltimateAbility Where char_id = ?";
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr9, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &ULV, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
	
	// SetCharTransState
	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x70, STR);
	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x71, VIT);
	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x72, INT);
	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x73, DEX);
	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x74, PSY);
	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x75, AGI);
	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x76, TRANS);
	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x77, STATECOUNT);
	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x78, ULV);
}

void SetCharAllLevel(int pPlayer)
{
	//define handles and variables
	SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
	SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
	SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	int addrs;
	int CharID;
	int pThis;
	int Level = 0;
	int HLV = 0;
	int ULV = 0;
	
	unsigned char cmdstr1[] = "SELECT level From RohanGame.dbo.TCharacterAbility Where char_id = ?";
	unsigned char cmdstr2[] = "SELECT conquerorlevel From RohanGame.dbo.TConqueror Where char_id = ?";
	unsigned char cmdstr3[] = "SELECT ulevel From RohanGame.dbo.TUltimateAbility Where char_id = ?";

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	addrs = (DWORD)pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));

	// Level
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &Level, 0, NULL);

		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// ConquerorLevel
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr2, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &HLV, 0, NULL);

		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// ULV
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr3, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &ULV, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);

	if (Level > 115) Level = 115;
	if (HLV > 50) Level = 50;
	if (ULV > 400) Level = 400;

	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x15, Level);
	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x65, HLV);	
	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x78, ULV);
}

/****************************************************************************************
 *** Guild Functions
 ****************************************************************************************/
int GetGuildInfo(int CharID)
{
	int pGuildInfo;

	__asm mov eax, CharID
	__asm push eax
	__asm mov ecx, 0x00B58A9C
	__asm call GETGUILD
	__asm mov pGuildInfo, eax

	return pGuildInfo;
}

/****************************************************************************************
 *** Party Functions
 ****************************************************************************************/
int GetParty(int EntityID)
{
	int PartyPTR;

	__asm mov eax, EntityID
	__asm push eax
	__asm mov ecx, 0xB35820
	__asm call GETPARTY
	__asm mov PartyPTR, eax

	return PartyPTR;
}
