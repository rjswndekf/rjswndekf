#include <MapFunctions.h>

using namespace std;

int CHARSTATUS_SIZE = 0xB4;

/******* ASM Funs *******/
int GETSTATUS = (DWORD)PlayerGetStatusInfo;
extern int GETABILITY;

/******* Character Status Version 2021 AESIR Size 0xB4 *******/
void PlayerGetStatusInfo(int PlayerPTR, int pAddrs)
{
	// STR
	__asm push 0x0
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[ecx],eax
	// DEX
	__asm push 0x3
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[edx+0x4],eax
	// Vitality
	__asm push 0x1
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[ecx+0x8],eax
	// INT
	__asm push 0x2
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[edx+0xC],eax
	// Psyche
	__asm push 0x4
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[ecx+0x10],eax 
	// Agility
	__asm push 0x5
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[edx+0x14],eax
	// Melee Attack
	__asm push 0x6
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[ecx+0x18],eax
	// Ranged Attack
	__asm push 0x7
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[edx+0x1C],eax
	// Magic Attack Power
	__asm push 0x8
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[ecx+0x20],eax
	// Physocal Defense
	__asm push 0x9
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[edx+0x24],eax
	// Magic Defense
	__asm push 0xA
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[ecx+0x28],eax
	// Accuracy
	__asm push 0xB
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[edx+0x2C],eax
	// Evasion
	__asm push 0xC
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[ecx+0x30],eax
	// Health HP
	__asm push 0xD
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[edx+0x34],eax
	// Health Recovery HP
	__asm push 0xE
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[ecx+0x38],eax
	// Mana MP
	__asm push 0xF
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[edx+0x3C],eax
	// Mana Recovery MP
	__asm push 0x10
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[ecx+0x40],eax
	// Full Resistance
	__asm push 0x11
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[edx+0x44],eax
	// Movement Speed
	__asm push 0x12
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov word ptr ds:[ecx+0x48],ax
	// Attack Speed
	__asm push 0x13
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov word ptr ds:[edx+0x4A],ax
	// Max Weight
	__asm push 0x14
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[ecx+0x4C],eax
	// Fire Resistance
	__asm push 0x2F
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov word ptr ds:[edx+0x50],ax
	// Water Resistance
	__asm push 0x30
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov word ptr ds:[ecx+0x52],ax
	// Dark Resistance
	__asm push 0x31
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov word ptr ds:[edx+0x54],ax
	// Holy Resistance
	__asm push 0x32
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov word ptr ds:[ecx+0x56],ax

	// Trans State
	// TransSTR
	__asm push 0x70
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x58],eax

	// TransDEX
	__asm push 0x73
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x5C],eax

	// TransVIT
	__asm push 0x71
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x60],eax

	// TransINT
	__asm push 0x72
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x64],eax

	// TransPSY
	__asm push 0x74
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x68],eax

	// TransAGI
	__asm push 0x75
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x6C],eax
	
	// 2020 Addon * 17
	// Critical Hit Rate
	__asm push 0x1D
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ds:[ecx+0x70],eax

	// Critical Damage
	__asm push 0x6B
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x74],eax 

	// Health Absorption
	__asm push 0x25
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x78],eax
	
	// Mana Absorption
	__asm push 0x26
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x7C],eax

	// Damage Reduction
	__asm push 0x2B
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]	
	__asm mov dword ptr ss:[ecx+0x80],eax

	// Damage Reduction Penetration
	__asm push 0x6A
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x84],eax
	
	// Defense Penetration
	__asm push 0x6C
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x88],eax

	// Critical Damage Reduction
	__asm push 0x42
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x8C],eax
	
	// PVP Attack Power increase
	__asm push 0x6D
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x90],eax
	
	// PVP Defense increase
	__asm push 0x6E
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x94],eax

	// PVE Attack Power increase
	__asm push 0x80
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x98],eax

	// PVE Defense increase
	__asm push 0x81
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0x9C],eax

	// Skill Attack
	__asm push 0x79
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0xA0],eax

	// Skill Defense
	__asm push 0x62
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0xA4],eax

	// Potion Recovery Amount
	__asm push 0x27
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0xA8],eax
	
	// Chance of Invalidating Attack
	__asm push 0x28
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0xAC],eax
	
	// Damage Reflection
	__asm push 0x43
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETABILITY
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr ss:[ecx+0xB0],eax 
}
