#include <MapFunctions.h>

using namespace std; 

/******* ASM Funs *******/
int GETENTITYSTATUS = 0x006C00B0;
int INCENTITYSTATUS = 0x006C00E0;
int SETENTITYSTATUS = 0x006C0120;
int GETCOLGRADE = 0x0068EDD0;
int GETPLAYER = 0x004DE5F0;
int BROADCASTALLPLAYER = 0x004DED50;
int GETNPC = 0x004DE5D0;
int GETNPCPTR = 0x004DE650;

/****************************************************************************************
 *** Entity Functions
 ****************************************************************************************/
int EntityBaseStatusGetAbility(int TargetPTR, int Ability)
{
	int AbilityVar;

	__asm mov eax, Ability
	__asm push eax
	__asm mov ecx, TargetPTR
	__asm call GETENTITYSTATUS
	__asm mov AbilityVar, eax

	return AbilityVar;
}

void EntityBaseStatusIncAbility(int TargetPTR, int AbilityType, int Value)
{
	__asm mov edx, Value
	__asm push edx
	__asm mov eax, AbilityType
	__asm push eax
	__asm mov ecx, TargetPTR
	__asm call INCENTITYSTATUS
}

void EntityBaseStatusSetAbility(int TargetPTR, int AbilityType, int Value)
{
	__asm mov edx, Value
	__asm push edx
	__asm mov eax, AbilityType
	__asm push eax
	__asm mov ecx, TargetPTR
	__asm call SETENTITYSTATUS
}

int CalAttackForce(int Value, int Level)
{
	int AttackForce = 0;
	if (Level < 51)
	{
		AttackForce = (Value * 3) + (Level * 2);
	}
	else
	{
		if (Level < 71)
		{
			AttackForce = (Value * 3) + (Level * 3);
		}
		else
		{
			AttackForce = (Value * 3) + (Level * 4);
		}
	}
	return AttackForce;
}

int GetCollectGrade(int ARG1, int ARG2)
{
	int Grade;
	__asm mov eax,ARG2
	__asm push eax
	__asm mov edx,ARG1
	__asm push edx
	__asm mov ecx,dword ptr ds:[0x4BEEB50]
	__asm call GETCOLGRADE
	__asm mov Grade,eax
	return Grade;
}

int EntityManagerGetPlayer(unsigned int EntityID)
{
	int PartyPlayerPTR;

	__asm mov eax, EntityID
	__asm push eax
	__asm mov ecx,0x007F8A60
	__asm call GETPLAYER
	__asm mov PartyPlayerPTR, eax

	return PartyPlayerPTR;
}

void EntityManagerBroadcastAllPlayer(int PacketType, int PacketData, int PacketSize)
{
	__asm mov ecx, PacketSize
	__asm push ecx
	__asm mov edx, PacketData
	__asm push edx
	__asm mov eax, PacketType
	__asm push eax
	__asm mov ecx,0x007F8A60
	__asm call BROADCASTALLPLAYER
}

int GetNpc(int NpcEntityID)
{
	int pNpc;
	__asm mov eax, NpcEntityID
	__asm push eax
	__asm mov ecx, 0x007F8A60
	__asm call GETNPC
	__asm mov pNpc,eax

	return pNpc;
}

int GetNpcPTR(int pNpcType)
{
	int pNpc;

	__asm push 0x2
	__asm mov eax,pNpcType
	__asm push eax
	__asm mov ecx, 0x007F8A60
	__asm call GETNPCPTR
	__asm mov pNpc, eax

	return pNpc;
}

int CheckNpc(int NpcType)
{
	int pNpc = 0;

	char BOSSIDSTR[16];
	int BOSSIDSTR_ADDR = (DWORD)BOSSIDSTR;

	memset(BOSSIDSTR,0,sizeof(char)*16);

	sprintf(BOSSIDSTR, "%d", NpcType);

	pNpc = GetNpcPTR(BOSSIDSTR_ADDR);
	
	return pNpc;
}
