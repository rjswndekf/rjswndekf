#include <MapFunctions.h>

using namespace std; 

/******* ASM Funs *******/
int GETABILITY = 0x004EEC50;
int SETABILITY = 0x004EEBF0;
int ADDABILITY = 0x004EEC20;
int BROADCASTAROUNDPLAYERS = 0x004D6400;
int GETRANDOM = 0x004D7A10;
int FINDBIOTICID = 0x004DE4E0;
int GETRACEBASEATTR = 0x004D54F0;
int GETALLSTATPOINT = 0x006C0B20;

/****************************************************************************************
 *** BioticBase Functions
 ****************************************************************************************/
int BioticBaseGetAbility(int TargetPTR, int AbilityType)
{
	int Ability;

	__asm mov eax, AbilityType
	__asm push eax
	__asm mov ecx, TargetPTR
	__asm call GETABILITY
	__asm mov Ability, eax

	return Ability;
}

int BioticBaseSetAbility(int TargetPTR, int AbilityType, int Value)
{
	int SetPTR;

	__asm mov edx, Value
	__asm push edx
	__asm mov eax, AbilityType
	__asm push eax
	__asm mov ecx, TargetPTR
	__asm call SETABILITY

	__asm mov SetPTR, eax
	return SetPTR;
}

void BioticBaseAddAbility(int TargetPTR, int AbilityType, int Value)
{
	__asm mov edx, Value
	__asm push edx
	__asm mov eax, AbilityType
	__asm push eax
	__asm mov ecx, TargetPTR
	__asm call ADDABILITY
}

void BioticBroadCastAroundPlayers(int PlayerPTR, int PacketType, int pData, int PacketSize, int IncludeMe, int CellRange)
{
	__asm mov edx, CellRange
	__asm push edx
	__asm mov eax, IncludeMe
	__asm push eax
	__asm mov ecx, PacketSize
	__asm push ecx
	__asm mov edx, pData
	__asm push edx
	__asm mov eax, PacketType
	__asm push eax
	__asm mov ecx, PlayerPTR
	__asm call BROADCASTAROUNDPLAYERS
}

int BioticBaseGetRandom(int PlayerPTR, int nMax)
{
	int RandomVar;
	__asm mov eax, nMax
	__asm push eax
	__asm mov ecx,PlayerPTR
	__asm call GETRANDOM
	__asm mov RandomVar, eax
	return RandomVar;
}

int FindBioticID(unsigned int EntityID)
{
	int BioticID;
	__asm mov edx, EntityID
	__asm push edx
	__asm mov ecx, 0x007F8A60
	__asm call FINDBIOTICID
	__asm mov BioticID, eax
	return BioticID;
}

int GetCharAllLevel(int PlayerPTR)
{
	int CharLevel = 0;
	int ConquerorLevel = 0;
	int UltimateLevel = 0;
	int pThis = 0;

	pThis = PlayerPTR;
	CharLevel = BioticBaseGetAbility(pThis, 0x15);
	if (CharLevel > 115) CharLevel = 115;

	pThis = PlayerPTR;
	ConquerorLevel = BioticBaseGetAbility(pThis, 0x65);

	pThis = PlayerPTR;
	UltimateLevel = BioticBaseGetAbility(pThis, 0x78);

	CharLevel += ConquerorLevel;
	CharLevel += UltimateLevel;

	return CharLevel;
}

int GetRaceBaseAttrVaule(int CType, int Attribute)
{
	int AttrValue = 0;
	__asm mov edx,Attribute
	__asm push edx
	__asm mov eax,CType
	__asm push eax
	__asm mov ecx,0x007F8514
	__asm call GETRACEBASEATTR
	__asm mov AttrValue,eax
	return AttrValue;
}

int GetAllStatPoints(int Level)
{
	int Point = 0;
	__asm mov eax,Level
	__asm push eax
	__asm call GETALLSTATPOINT
	__asm mov Point,eax
	return Point;
}
