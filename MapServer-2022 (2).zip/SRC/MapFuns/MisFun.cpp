#include <MapFunctions.h>

using namespace std; 

/******* ASM Funs *******/
int RTDYNAMICCAST = 0x00753FAB;
int OBJRELEASE = 0x005E5130;
int ITEMRELEASE = 0x0055B730;
int CRAFTRELEASE = 0x00513A40;
int CURSECONDS = 0x0075487B;
int CALITEMTIMER = 0x004620B0;
int SCRIPTINIT = 0x00679000;
int STESCRIPTSTR = 0x004040E0;

int GETPORTALINFO = 0x004040E0;
int SETPORTALINFO = 0x00404030;
int SETPORTAL = 0x006A7580;
int GETPORTALLOCK = 0x006A8F90;
int SETPORTALLOCK = 0x006A8EC0;

/****************************************************************************************
 *** Mis Functions
 ****************************************************************************************/
int RTDynamicCast(int pDynamic, int VfDelta, int SrcType, int TargetType, int isReference)
{
	int CheckThisPTR;

	__asm mov eax, isReference
	__asm push eax

	__asm mov eax, TargetType
	__asm push eax

	__asm mov eax, SrcType
	__asm push eax

	__asm mov eax, VfDelta
	__asm push eax

	__asm mov ecx, pDynamic
	__asm push ecx

	__asm call RTDYNAMICCAST
	__asm add esp,0x14

	__asm mov CheckThisPTR, eax

	return CheckThisPTR;

}

void CIOObjectRelease(int pTarget)
{
	__asm mov ecx, pTarget
	__asm add ecx,0x14
	__asm push ecx
	__asm mov ecx, pTarget
	__asm call OBJRELEASE
}

void CIOItemRelease(int pItem)
{
	__asm mov ecx, pItem
	__asm push ecx
	__asm mov ecx,dword ptr ds:[0x7F1CA4]
	__asm call ITEMRELEASE
}

void CIOCraftRelease(int pPlayer)
{
	__asm mov ecx,pPlayer
	__asm call CRAFTRELEASE	
}

void StringsCopy(int DST, int SRC, int StrSize)
{
	__asm mov edx, StrSize
	__asm push edx
	__asm mov eax, SRC
	__asm push eax
	__asm mov ecx, DST
	__asm push ecx
	__asm call dword ptr ds:[0x7951FC]
}

int GetCutTime()
{
	int CutTime;
	__asm call dword ptr ds:[0x795598]
	__asm mov CutTime, eax
	return CutTime;
}

// #include <ctime>
// time_t seconds = time(NULL);
// second32 = (int)seconds;
int GetCurSeconds()
{
	int Seconds;

	__asm push 0x0
	__asm call CURSECONDS
	__asm add esp,0x4
	__asm mov Seconds, eax

	return Seconds;
}

int GetStringSize(int pStrings)
{
	int StrSize;

	__asm xor ecx,ecx
	__asm mov edi, pStrings
CALSIZE:
	__asm add edi,0x1
	__asm add ecx,0x1
	__asm mov al,byte ptr es:[edi]
	__asm cmp al,0x0
	__asm jne CALSIZE

	__asm mov StrSize,ecx
	return StrSize;
}

int ItemScriptInit(int pItemScript)
{
	int pScript;

	__asm mov ecx,pItemScript
	__asm call SCRIPTINIT
	__asm mov pScript,eax

	return pScript;
}

void SetScriptStrings(int DST, int SRC, int StrSize)
{
	__asm mov ecx, StrSize
	__asm push ecx
	__asm mov edx, SRC
	__asm push edx
	__asm mov ecx, DST
	__asm call STESCRIPTSTR
}

/****************************************************************************************
 *** Protal Functions
 ****************************************************************************************/
void GetPortalInfo(int pProtalInfo, int pStr, int StrSize)
{
	__asm mov eax, StrSize
	__asm push eax
	__asm mov edx, pStr
	__asm push edx
	__asm mov ecx, pProtalInfo
	__asm call GETPORTALINFO
}

void SetPortalInfo(int pProtalInfo, int Action, int Option)
{
	__asm mov eax, Option
	__asm push eax
	__asm mov edx, Action
	__asm push edx
	__asm mov ecx, pProtalInfo
	__asm call SETPORTALINFO
}

void SetPortal(int pProtal, int pProtalInfo, int PortalID)
{
	__asm mov eax, PortalID
	__asm push eax
	__asm mov edx, pProtalInfo
	__asm push edx
	__asm mov ecx, pProtal
	__asm call SETPORTAL
}

int GetPortalLock(int pThis, int pProtalInfo)
{
	int Result;

	__asm mov edx, pProtalInfo
	__asm push edx
	__asm mov ecx, pThis
	__asm call GETPORTALLOCK

	return Result;
}

int SetPortalLock(int pThis, int pProtalInfo)
{
	int Result;

	__asm mov edx, pProtalInfo
	__asm push edx
	__asm mov ecx, pThis
	__asm call SETPORTALLOCK

	return Result;
}

int GeoBaseIsLocked(int pThis)
{
	int Result;
	int addrs;
	
	addrs = pThis + 0x4;
	Result = *(reinterpret_cast<int*>(addrs));

	return Result;
}
