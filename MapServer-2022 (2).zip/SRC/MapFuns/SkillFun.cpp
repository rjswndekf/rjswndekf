#include <MapFunctions.h>

using namespace std; 

/******* ASM Funs *******/
int GETTOTALSKILLLEVEL = 0x004ADDC0;
int GETSKILLINFO = 0x00437010;
int ADDAFFECTSKILL = 0x004AA8F0;
int REFLECTSKILL = 0x004AB030;
int QUALCALOPT = 0x004EACF0;
int QUALSETOPT = 0x004EACD0;
int QUALGETOPT = 0x0066E010;
int SKILLDMGCAL = 0x0050B940;
int GETAFFECTOPTVAR = 0x0060B080;
int CHECKASENABLE = 0x00694800;
int ISAFFECTSKILL = 0x00694770;
int ENDAFFECTSKILL = 0x004A9C50;
int ENABLEAFFECTSKILL = 0x0049FD30;
int GETASLIST = 0x004A97D0;
int GETBUFFLIST = 0x00694350;
int ENDBUFF = 0x00692EC0;
int CHANGCONDBYSKILL = 0x004DAD00;
int CLEARSKILLGCOND = 0x004EF120;
int ERASEBUFFSKILL = 0x004AC8B0;
int CHECKCONDRESIST = 0x004A4840;
int AROUNDPLAYER = 0x00538030;
int ASINIT = 0x004165F0;
int GETSKILLLEVELINFO = 0x00437070;
int CHAGELIFE = 0x004A7CB0;
int CHAGEMANA = 0x004A7C60;
int SENDLIFIMANABROADCAST = 0x004D6440;
int GETCHARAFFECTSKILL = 0x004A97D0;
int DELCHARAFFECTSKILL = 0x004A8C70;
int GETRESISTANCE = 0x0052F5B0;
int CHECKRESISTANCE = 0x004A47C0;
int CALATTACHDMG = 0x004D7A30;
int GETRANGRCOUNT = 0x0049E110;

/****************************************************************************************
 *** Skill Functions
 ****************************************************************************************/
int GetTotalDynamicLevel(int TargetPTR, int Kind)
{
	int KindLV;

	__asm mov eax, Kind
	__asm push eax
	__asm mov ecx, TargetPTR
	__asm add ecx, 0x100
	__asm call GETTOTALSKILLLEVEL
	__asm movzx edx,al
	__asm mov KindLV, edx

	return KindLV;
}

int GetSkillInfo(int Kind)
{
	int pSkillInfo;
	__asm mov eax, Kind
	__asm push eax
	__asm call GETSKILLINFO
	__asm add esp,0x4
	__asm mov pSkillInfo,eax
	return pSkillInfo;	
}

int GetParamPTR(int TargetPTR, int Kind)
{
	int ParamAddr;
	int KLV;

	__asm mov eax, Kind
	__asm push eax
	__asm mov ecx, TargetPTR
	__asm add ecx, 0x100
	__asm call GETTOTALSKILLLEVEL
	__asm movzx edx,al
	__asm mov KLV, edx

	__asm mov eax, Kind
	__asm push eax
	__asm call GETSKILLINFO
	__asm add esp,0x4

	//CLC KLV
	__asm mov ecx, KLV
	__asm imul ecx,ecx,0x1A5
	__asm lea edx,dword ptr ds:[eax+ecx+0x58]
	__asm add edx,0x11
	__asm mov ParamAddr, edx

	return ParamAddr;
}

void AddAffectSkill(int CalAffectPTR, int AffectedSkillPTR)
{
	__asm mov eax, AffectedSkillPTR
	__asm Push eax
	__asm mov ecx, CalAffectPTR
	__asm mov edx,dword ptr ds:[ecx]
	__asm mov ecx, CalAffectPTR
	__asm call ADDAFFECTSKILL
}

int ReflectSkill(int CalAffectPTR, int pAffectedSkill)
{
	int Result;

	__asm mov eax, pAffectedSkill
	__asm Push eax
	__asm mov ecx, CalAffectPTR
	__asm call REFLECTSKILL
	__asm mov Result, eax

	return Result;
}

void tagAffectSkillInit(int tagAffectSkillPTR)
{
	int addrs;
	
	addrs = (DWORD)tagAffectSkillPTR;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)tagAffectSkillPTR + 0x4;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)tagAffectSkillPTR + 0x8;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)tagAffectSkillPTR + 0xC;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)tagAffectSkillPTR + 0x10;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)tagAffectSkillPTR + 0x14;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)tagAffectSkillPTR + 0x18;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)tagAffectSkillPTR + 0x1C;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)tagAffectSkillPTR + 0x20;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)tagAffectSkillPTR + 0xB;
	*(reinterpret_cast<char*>(addrs)) = 5;

}

int GetParams(int Paddrs, int Pnum)
{
	int Params = 0;
	int addrs;

	if (Pnum == 1)
	{
		addrs = (DWORD)Paddrs;
		Params = *(reinterpret_cast<int*>(addrs));
	}
	if (Pnum == 2)
	{
		addrs = (DWORD)Paddrs + 0x4;
		Params = *(reinterpret_cast<int*>(addrs));
	}
	if (Pnum == 3)
	{
		addrs = (DWORD)Paddrs + 0x8;
		Params = *(reinterpret_cast<int*>(addrs));
	}
	if (Pnum == 4)
	{
		addrs = (DWORD)Paddrs + 0xC;
		Params = *(reinterpret_cast<int*>(addrs));
	}
	if (Pnum == 5)
	{
		addrs = (DWORD)Paddrs + 0x10;
		Params = *(reinterpret_cast<int*>(addrs));
	}

	return Params;

}

void QualitiesCalOption(int CalAffectPTR, int AffectOption, int Param, int ActiveOption)
{
	__asm mov eax, ActiveOption
	__asm push eax
	
	__asm mov eax, Param
	__asm push eax
	
	__asm mov eax, AffectOption
	__asm push eax

	__asm mov ecx, CalAffectPTR
	__asm add ecx,0x60
	__asm call QUALCALOPT
	//__asm retn
}

void QualitiesSetOption(int CalAffectPTR, int OptionType, int Value)
{
	__asm mov eax, Value
	__asm push eax
	__asm mov edx, OptionType
	__asm push edx
	__asm mov ecx, CalAffectPTR
	__asm add ecx,0x60
	__asm call QUALSETOPT
}

int QualitiesGetOption(int CalAffectPTR, int OptionType)
{
	int Value;

	__asm mov edx, OptionType
	__asm push edx
	__asm mov ecx, CalAffectPTR
	__asm add ecx,0x60
	__asm call QUALGETOPT
	__asm mov Value, eax

	return Value;
	
}

int SkillDamageCalculation(int DynamicPTR, int SkillDamage, int OptionType)
{
	int SkillDamageCal;
	__asm mov edx, OptionType
	__asm push edx
	__asm mov eax, SkillDamage
	__asm push eax
	__asm mov ecx, DynamicPTR
	__asm call SKILLDMGCAL
	__asm mov SkillDamageCal, eax

	return SkillDamageCal;

}

int GetAffectOptionValue(int CalAffectPTR, int AffectOption)
{
	int ParamValue;

	__asm lea edx, AffectOption
	__asm push edx
	__asm mov ecx, CalAffectPTR
	__asm add ecx, 0x60
	__asm call GETAFFECTOPTVAR
	__asm cmp eax, 0x0
	__asm je RETADDR
	__asm mov edx,dword ptr ds:[eax+0x10]
	__asm mov ParamValue, edx

	return ParamValue;

RETADDR:
	__asm mov ParamValue, 0
	return ParamValue;
}

int CheckAffectSkillStatus(int CalAffectPTR, unsigned int Kind)
{
	int State;
	__asm mov eax, Kind
	__asm push eax
	__asm mov ecx, CalAffectPTR
	__asm call CHECKASENABLE
	__asm mov State, eax
	return State;
}

int IsAffectSkill(int CalAffectPTR, unsigned int Kind, int pAffectedSkill)
{
	int State;
	__asm mov eax, pAffectedSkill
	__asm push eax
	__asm mov edx, Kind
	__asm push edx
	__asm mov ecx, CalAffectPTR
	__asm call ISAFFECTSKILL
	__asm mov State, eax
	return State;
}

void EndAffectSkill(int CalAffectPTR, unsigned int Kind, unsigned int Reason, unsigned int Param, unsigned int Skiller)
{
	// For Example: EndAffectSkill(CalAffectPTR, Kind, 0x1, 0x0, 0x0);
	__asm mov eax, Skiller
	__asm push eax
	
	__asm mov edx, Param
	__asm push edx
	
	__asm mov ecx, Reason
	__asm push ecx
	
	__asm mov eax, Kind
	__asm push eax

	__asm mov ecx, CalAffectPTR
	__asm call ENDAFFECTSKILL
}

void EnableAffectSkill(int CalAffectPTR, unsigned int Kind)
{
	__asm mov eax, Kind
	__asm push eax
	__asm mov ecx, CalAffectPTR
	__asm call ENABLEAFFECTSKILL
}
int GetAffectSkillList(int CalAffectPTR, int pSkills, int MaxCount)
{
	int ASCount;

	__asm mov eax,MaxCount
	__asm push eax
	__asm mov edx,pSkills
	__asm push edx
	__asm mov ecx, CalAffectPTR
	__asm call GETASLIST
	__asm mov ASCount,eax

	return ASCount;
}

int CheckAffectStatus(int CalAffectPTR, int Kind)
{
	int State = 0;
	int addrs = 0;
	int Skill = 0;
	int ASCount = 0;
	unsigned char AFFECTSKILL_BUFFER[3600] = {0};
	int AFFECTSKILL_ADDRS = (DWORD)AFFECTSKILL_BUFFER;

	memset(AFFECTSKILL_BUFFER,0,sizeof(char)*3600);
	ASCount = GetAffectSkillList(CalAffectPTR, AFFECTSKILL_ADDRS, 100);

	if (ASCount == 0) return 0;

	addrs = (DWORD)AFFECTSKILL_ADDRS;
	for(int i = 0; i < ASCount; i++ )
	{
		Skill = *(reinterpret_cast<unsigned short*>(addrs));
		if (Skill == Kind)
		{
			State = 1;
			break;
		}
		addrs += 36;
	}

	return State;

}

int GetBuffSkillList(int CalAffectPTR, int pSkills, int MaxCount)
{
	int BuffCount;

	__asm push 0x2
	__asm push 0x1
	__asm mov eax,MaxCount
	__asm push eax
	__asm mov edx,pSkills
	__asm push edx
	__asm mov ecx, CalAffectPTR
	__asm call GETBUFFLIST
	__asm mov BuffCount,eax

	return BuffCount;
}

int CheckBuffSkillStatus(int CalAffectPTR, int Kind)
{
	int State = 0;
	int addrs = 0;
	int Skill = 0;
	int BuffCount = 0;
	unsigned char BUFFSKILL_BUFFER[1400] = {0};
	int BUFFSKILL_ADDRS = (DWORD)BUFFSKILL_BUFFER;

	memset(BUFFSKILL_BUFFER,0,sizeof(char)*1400);
	BuffCount = GetBuffSkillList(CalAffectPTR, BUFFSKILL_ADDRS, 100);

	if (BuffCount == 0) return 0;

	addrs = (DWORD)BUFFSKILL_ADDRS;
	for(int i = 0; i < BuffCount; i++ )
	{
		Skill = *(reinterpret_cast<unsigned short*>(addrs));
		if (Skill == Kind)
		{
			State = 1;
			break;
		}
		addrs += 14;
	}

	return State;
}

int EndBuffSkill(int CalAffectPTR, unsigned int Kind, int Operate)
{
	int Result;
	__asm mov edx, Operate
	__asm push edx
	__asm mov eax, Kind
	__asm push eax
	__asm mov ecx, CalAffectPTR
	__asm call ENDBUFF
	__asm mov Result, eax
	return Result;
}

void ChangeConditionBySkill(int TargetPTR, unsigned int Condition, int MilliSecond, int Kind)
{
	__asm mov eax, Kind
	__asm push eax
	__asm mov edx, MilliSecond
	__asm push edx
	__asm mov ecx, Condition
	__asm push ecx
	__asm mov eax, TargetPTR
	__asm mov edx,dword ptr ds:[eax]
	__asm mov ecx, TargetPTR
	__asm call CHANGCONDBYSKILL
}

void ClearSkillCondition(int TargetPTR, unsigned int Condition, int Kind)
{
	__asm mov eax, Kind
	__asm push eax
	__asm mov edx, Condition
	__asm push edx
	__asm mov ecx, TargetPTR
	__asm call CLEARSKILLGCOND	
}

void EraseBuffSkill(int TargetPTR, int RemoveCount)
{
	__asm mov eax,RemoveCount
	__asm push eax
	__asm mov ecx,TargetPTR
	__asm call ERASEBUFFSKILL
}

int CheckConditionResist(int CalAffectPTR, int Kind)
{
	int Resist;
	__asm mov eax, Kind
	__asm push eax
	__asm mov ecx, CalAffectPTR
	__asm call CHECKCONDRESIST
	__asm mov Resist, eax
	return Resist;
}

void AroundPlayers(int PlayerPTR, unsigned int EntityID, int Diff)
{
	__asm mov eax, Diff
	__asm push eax
	__asm mov edx, EntityID
	__asm push edx
	__asm mov ecx, PlayerPTR
	__asm add ecx,0xD78
	__asm call AROUNDPLAYER
}

void InitTP(int PlayerPTR)
{
	int addrs;
	addrs = (DWORD)PlayerPTR + 0x2050;
	*(reinterpret_cast<int*>(addrs)) = 0;
}

int GetCurTP(int PlayerPTR)
{
	int addrs;
	int TPValue;
	addrs = (DWORD)PlayerPTR + 0x2050;
	TPValue = *(reinterpret_cast<int*>(addrs));
	return TPValue;
}

void IncTP(int PlayerPTR, int Value)
{
	int CurTP;
	int Diff;
	int addrs;
	
	addrs = (DWORD)PlayerPTR + 0x2050;
	CurTP = *(reinterpret_cast<int*>(addrs));
	Diff = CurTP + Value;
	
	if (Diff > 1000) Diff = 1000;
	
	addrs = (DWORD)PlayerPTR + 0x2050;
	*(reinterpret_cast<int*>(addrs)) = Diff;

}

void DecTP(int PlayerPTR, int Value)
{
	int CurTP;
	int Diff;
	int addrs;
	int State;
	int CalAffectPTR;
	
	CalAffectPTR = (DWORD)PlayerPTR + 0x100;

	// Skill 8239 0x202F Eternal Aria
	State = CheckAffectStatus(CalAffectPTR, 0x202F);
	if (State == 0)
	{
		addrs = (DWORD)PlayerPTR + 0x2050;
		CurTP = *(reinterpret_cast<int*>(addrs));
		Diff = CurTP - Value;
	
		if (Diff < 0) Diff = 0;
	
		addrs = (DWORD)PlayerPTR + 0x2050;
		*(reinterpret_cast<int*>(addrs)) = Diff;
	}
}

void SendTPBroadcast(int PlayerPTR)
{
	int addrs;
	int DynamicPTR;
	int CurTP;
	int pData;
	unsigned char TPBROADCAST_BUFFER[8];

	
	addrs = (DWORD)PlayerPTR + 0x2050;
	CurTP = *(reinterpret_cast<int*>(addrs));
	
	addrs = (DWORD)TPBROADCAST_BUFFER;
	*(reinterpret_cast<int*>(addrs)) = CurTP;
	addrs = (DWORD)TPBROADCAST_BUFFER + 0x4;
	*(reinterpret_cast<int*>(addrs)) = 1000;
	
	addrs = (DWORD)PlayerPTR + 0x1098;
	DynamicPTR = *(reinterpret_cast<int*>(addrs));
	
	pData = (DWORD)TPBROADCAST_BUFFER;
	SendPacket(DynamicPTR, 0x1848, pData, 0x08);
}

/*** OPT=1 IncLife OPT=0 DecLife ***/
void ChangeLife(int CalAffectPTR, int Diff, int OPT)
{
	// MinLife 0
	__asm push 0x0
	// Diff
	__asm mov edx, Diff
	__asm cmp OPT, 0x1
	__asm je IncLife

	__asm neg edx
IncLife:
	__asm push edx

	__asm mov ecx, CalAffectPTR
	__asm call CHAGELIFE
}

/*** OPT=1 IncMana OPT=0 DecMana ***/
void ChangeMana(int CalAffectPTR, int Diff, int OPT)
{
	// Diff
	__asm mov edx, Diff
	__asm cmp OPT, 0x1
	__asm je IncMana

	__asm neg edx
IncMana:
	__asm push edx

	__asm mov ecx, CalAffectPTR
	__asm call CHAGEMANA
}

void SendLifeManaBroadcast(int PlayerPTR)
{
	__asm push 0x0
	__asm mov ecx, PlayerPTR
	__asm call SENDLIFIMANABROADCAST
}

/*** Cal Stat to AttackRate ***/
int StateToAttackRate(int StateValue, int Params)
{
	int AttackRate;

	float StateFP;
	float StateRateFP;
	float ParamFP;
	float AtkRateFP;

	StateFP = (float)StateValue;
	ParamFP = (float)Params;
	
	StateRateFP = ParamFP / 100;
	AtkRateFP = (StateFP * StateRateFP) / 100;
	AtkRateFP += 0.5;
	AttackRate = (int)AtkRateFP;
	
	return AttackRate;
}

int GetCharAffectSkill(int CalAffectPTR, int pASkill, int Count)
{
	int SkillCount;

	__asm mov eax,Count
	__asm push eax
	__asm mov edx,pASkill
	__asm push edx
	__asm mov ecx, CalAffectPTR
	__asm call GETCHARAFFECTSKILL
	__asm mov SkillCount,eax

	return SkillCount;
}

void DeleteCharAffectSkill(int CalAffectPTR, int Kind)
{
	__asm lea eax,Kind
	__asm push eax
	__asm mov ecx, CalAffectPTR
	__asm call DELCHARAFFECTSKILL
}

void ReduceDamage(int CalAffectPTR, int FullRate, int RemainderRate, int Active)
{
	int addrs;

	// Active
	addrs = (DWORD)CalAffectPTR + 0x10C;
	*(reinterpret_cast<int*>(addrs)) = 0;
	//addrs = (DWORD)CalAffectPTR + 0x110;
	//*(reinterpret_cast<int*>(addrs)) = Active;

	if (Active == 1)
	{
		// FullRate
		addrs = (DWORD)CalAffectPTR + 0x114;
		*(reinterpret_cast<int*>(addrs)) = FullRate;
		// RemainderRate
		addrs = (DWORD)CalAffectPTR + 0x118;
		*(reinterpret_cast<int*>(addrs)) = RemainderRate;
	}
	else
	{
		// FullRate
		addrs = (DWORD)CalAffectPTR + 0x114;
		*(reinterpret_cast<int*>(addrs)) = 1;
		// RemainderRate
		addrs = (DWORD)CalAffectPTR + 0x118;
		*(reinterpret_cast<int*>(addrs)) = 10;
	}
}

int GetTargetResistance(int pAttack, int Target, int Resistance, int Kind)
{
	int TResistance = 0;
	__asm mov ecx,Kind
	__asm push ecx
	__asm mov eax,Resistance
	__asm push eax
	__asm mov edx,Target
	__asm push edx
	__asm mov ecx,pAttack
	__asm call GETRESISTANCE
	__asm mov TResistance,eax

	return TResistance;
}
int CheckResistance(int CalAffectPTR, int Kind)
{
	int TResistance = 0;

	__asm mov eax,Kind
	__asm push eax
	__asm mov ecx,CalAffectPTR
	__asm call CHECKRESISTANCE
	__asm mov TResistance,eax

	return TResistance;
}

int CalAttachDamage(int Target, int LowDamage, int HighDamage)
{
	int AttachDamage = 0;

	__asm mov eax,HighDamage
	__asm push eax
	__asm mov edx,LowDamage
	__asm push edx
	__asm mov ecx,Target
	__asm call CALATTACHDMG

	__asm mov AttachDamage,eax

	return AttachDamage;
}

int GetTargetCount(int CalAffectPTR, int pSkill, int pCharIDList, int pMaxCount)
{
	int AttackCount;

	__asm mov eax,pMaxCount
	__asm push eax
	__asm mov ecx,pCharIDList
	__asm push ecx
	__asm mov edx,pSkill
	__asm push edx
	__asm mov ecx,CalAffectPTR
	__asm call GETRANGRCOUNT

	__asm mov AttackCount,eax

	return AttackCount;
}