#include <MapFunctions.h>
#include <RHDB.h>
#include <sqlext.h>

using namespace std; 

/******* ASM Funs *******/
int GETSOCKETOPT = 0x00520580;
int GETSOCKETATTR = 0x00520630;
int GETSOCKETINFO = 0x005204C0;
int GETEQUIPTYPE = 0x00568F70;
int GHKSOCKETOPT = 0x00520F40;
int CLEARSOCKETSLOTS = 0x00520B80;
int SOCKETSLOTADD = 0x0051FFF0;
int ISSHIELD = 0x00568FD0;
int REMOVEITEM = 0x0056B730;
int CLEARITEM = 0x00699850;
//int CLEANEITEM = 0x0056B930;
//int CLEANITEMINFO = 0x0056BA70;
//int CLEANITEMBUFFER = 0x005738B0;
//int CLEANITEMDATA = 0x0055B730;
int GETFREEINVSLOT = 0x00571FE0;
int GETFREESLOTCNT = 0x00572100;
int USEITEM = 0x0056A9E0;
int USEITEMMATERIALS = 0x0056B500;
int ADDITEM = 0x00576EE0;
int ADDTIMERITEM = 0x00512EE0;
int CREATEMALLITEM = 0x00572480;
int GETITEMCURSTACK = 0x00568490;
int FINDBAGITEM = 0x00569400;
int REMOVEITEMINBAG = 0x00574FC0;

int GETBANK = 0x005533C0;
int ISBANKOWNER = 0x0050E630;
int GETBANKMAXSLOT = 0x00553A70;
int GETBANKRXPIRETIME = 0x00553AE0;
int CHECKBANKEXPIRETIME = 0x00557C70;

int CHKRECIPEINFO = 0x00523280;
int GETRECIPEINFO = 0x006D1110;
int GETRECUPERESLIST = 0x006CD940;
int SETCRAFTITEM = 0x005139E0;
int UPDRECIPE = 0x00522EA0;
int UPDRECIPEINFO = 0x005130D0;

/****************************************************************************************
 *** PlayerItemSlot Functions
 ****************************************************************************************/
int GetSocketOption(int pThis, int nType)
{
	int Value;
	__asm mov eax,nType
	__asm push eax
	__asm mov ecx,pThis
	__asm call GETSOCKETOPT
	__asm mov Value, eax
	return Value;
}

int GetSocketAttribute(int pThis, int nType)
{
	int Value;
	__asm mov eax,nType
	__asm push eax
	__asm mov ecx,pThis
	__asm call GETSOCKETATTR
	__asm mov Value, eax
	return Value;
}

int GetSocketInfo(int pSocket, int nId, int pSlocketInfo)
{
	int Result;

	__asm mov edx,pSlocketInfo
	__asm push edx
	__asm mov eax,nId
	__asm push eax
	__asm mov ecx,pSocket
	__asm call GETSOCKETINFO
	__asm mov Result, eax

	return Result;
}

int CheckSocketOptionType(int pSocket, int OptionType1, int OptionType2)
{
	int Result;

	__asm mov edx,OptionType2
	__asm push edx
	__asm mov eax,OptionType1
	__asm push eax
	__asm mov ecx,pSocket
	__asm call GHKSOCKETOPT
	__asm mov Result, eax

	return Result;
}

int ClearSocketSlot(int pSocket, int nID, int SocketSlot)
{
	int Result;

	__asm mov edx,SocketSlot
	__asm push edx
	__asm mov eax,nID
	__asm push eax
	__asm mov ecx,pSocket
	__asm call CLEARSOCKETSLOTS
	__asm mov Result, eax

	return Result;
}

int SocketSlotAdd(int pSocket, int nID, int SocketSlot, int ItemIDStore, int Timestamp)
{
	int Result;

	__asm mov eax,Timestamp
	__asm push eax
	__asm mov ecx,ItemIDStore
	__asm push ecx
	__asm mov edx,SocketSlot
	__asm push edx
	__asm mov eax,nID
	__asm push eax
	__asm mov ecx,pSocket
	__asm call SOCKETSLOTADD
	__asm mov Result, eax

	return Result;
}

int GetEquipItemType(int pInventory, int pEquipType)
{
	int result;
	__asm mov eax,pEquipType
	__asm push eax
	__asm mov ecx,pInventory
	__asm call GETEQUIPTYPE
	__asm mov result, eax
	return result;
}

int IsEquipShield(int pInventory)
{
	int result;
	__asm mov ecx,pInventory
	__asm call ISSHIELD
	__asm mov result, eax
	return result;
}

int RemoveItem(int InventoryPTR, int ItemPTR)
{
	int Removed;

	__asm mov eax, ItemPTR
	__asm push eax
	__asm mov ecx, InventoryPTR
	__asm call REMOVEITEM
	__asm mov Removed, eax
	// return Var 1
	return Removed;
}

void ClearItem(int pInventory, int Inventory, int Slot)
{
	__asm mov eax,Slot
	__asm push eax
	__asm mov edx,Inventory
	__asm push edx
	__asm mov ecx,pInventory
	__asm call CLEARITEM

}

int GetFreeInventorySlot(int InventoryPTR, int pInventory, int pSlot)
{
	int FreeSlot;
	__asm mov eax, pSlot
	__asm push eax
	__asm mov edx, pInventory
	__asm push edx
	__asm mov ecx, InventoryPTR
	__asm call GETFREEINVSLOT
	__asm mov FreeSlot, eax
	return FreeSlot;	
}

int GetFreeSlotCount(int pInventory)
{
	int result;
	__asm mov ecx, pInventory
	__asm call GETFREESLOTCNT
	__asm mov result, eax
	return result;	
}

int UseItem(int InventoryPTR, int pItem, int CurStack)
{
	int Used;

	__asm lea eax, CurStack
	__asm push eax
	__asm mov edx, pItem
	__asm push edx
	__asm mov ecx, InventoryPTR
	__asm call USEITEM
	__asm mov Used, eax

	return Used;
}

int UseItemMaterial(int pInventory, int pItem, int Stack, int pCurStack)
{
	int Result;

	__asm mov ecx, pCurStack
	__asm push ecx
	__asm mov eax, Stack
	__asm push eax
	__asm mov edx, pItem
	__asm push edx
	__asm mov ecx, pInventory
	__asm call USEITEMMATERIALS
	__asm mov Result, eax

	return Result;
}

int AddItem(int InventoryPTR, int pItem, int Inventory, int Slot, int SendDB)
{
	int result;
	
	__asm mov edx,SendDB
	__asm push edx
	__asm mov ecx,Slot
	__asm push ecx
	__asm mov eax,Inventory
	__asm push eax
	__asm mov edx,pItem
	__asm push edx
	__asm mov ecx,InventoryPTR
	__asm call ADDITEM
	__asm mov result, eax

	return result;
}

int AddTimerItem(int pPlayer, int pItem, int pRecipeInfo, int Timestamp)
{
	int Result;

	__asm mov ecx, Timestamp
	__asm push ecx
	__asm mov eax, pRecipeInfo
	__asm push eax
	__asm mov edx, pItem
	__asm push edx
	__asm mov ecx, pPlayer
	__asm call ADDTIMERITEM
	__asm mov Result, eax

	return Result;
}

int CreateMallItem(int InventoryPTR, int ItemID, int Count, int pItemGR, int pAddCurStack)
{
	int Result;

	__asm mov edx, pAddCurStack
	__asm push edx
	__asm mov ecx, pItemGR
	__asm push ecx
	__asm mov eax, Count
	__asm push eax
	__asm mov edx, ItemID
	__asm push edx
	__asm mov ecx, InventoryPTR
	__asm call CREATEMALLITEM
	__asm mov Result, eax

	return Result;
}

int GetItemCurrentStack(int pInventory, int ItemID)
{
	int Stack;

	__asm mov eax,ItemID
	__asm push eax
	__asm mov ecx,pInventory
	__asm call GETITEMCURSTACK
	__asm mov Stack, eax

	return Stack;
}

int FindItem(int pInventory, int ItemID)
{
	int pItem;

	__asm mov eax,ItemID
	__asm push eax
	__asm mov ecx,pInventory
	__asm call FINDBAGITEM
	__asm mov pItem, eax

	return pItem;
}

void RemoveItemsInInventory(int pInventory, int pItem, int nNumber)
{
	__asm mov eax,nNumber
	__asm push eax
	__asm mov edx,pItem
	__asm push edx
	__asm mov ecx,pInventory
	__asm call REMOVEITEMINBAG
}

int GetBank(unsigned int UserID)
{
	int pBank;
	__asm mov edx, UserID
	__asm push edx
	__asm mov ecx, 0x00B35920
	__asm call GETBANK
	__asm mov pBank,eax
	return pBank;
}

int IsBankOwner(int PlayerPTR, unsigned int UserID, unsigned int CharID)
{
	int IsOwner = 0;
	
	__asm mov eax, CharID
	__asm push eax
	__asm mov edx, UserID
	__asm push edx
	__asm mov ecx, PlayerPTR
	__asm call ISBANKOWNER
	__asm mov IsOwner,eax

	return IsOwner;
	
}

int GetBankMaxSlot(int BankPTR, unsigned int UserID)
{
	int MaxSolt;
	__asm mov eax, UserID
	__asm push eax
	__asm mov ecx, BankPTR
	__asm call GETBANKMAXSLOT
	__asm mov MaxSolt,eax
	return MaxSolt;
}

unsigned int GetBankExpireTime(int BankPTR, unsigned int UserID)
{
	int ExpireTime;
	__asm mov eax, UserID
	__asm push eax
	__asm mov ecx, BankPTR
	__asm call GETBANKRXPIRETIME
	__asm mov ExpireTime,eax
	return ExpireTime;
}

int CheckExpireTime(int BankPTR)
{
	int IsLoad;
	__asm mov ecx, BankPTR
	__asm call CHECKBANKEXPIRETIME
	__asm mov IsLoad,eax
	return IsLoad;
}

unsigned int GetDBBankExpireTime(unsigned int UserID)
{
	//define handles and variables
	SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
	SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
	SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle
	
	unsigned int ExpireTime = 0;

	unsigned char cmdstr1[] = "SELECT expire_time From RohanGame.dbo.TBank Where user_id = ?";

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	// BankExpireTime
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UserID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &ExpireTime, 0, NULL);

		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);
	
	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
	
	return ExpireTime;
}

void SetDBBankExpireTime(unsigned int UserID, unsigned int ExpireTime)
{
	//define handles and variables
	SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
	SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
	SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	unsigned char cmdstr1[] = "UPDATE RohanGame.dbo.TBank SET expire_time = ? WHERE user_id = ?";

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &ExpireTime, 0, 0);
	SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &UserID, 0, 0);
	SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS);
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);

}

int SoltToInventory(int Slot)
{
	int Inventory = 1;

	switch(Slot)
	{
		case 15: Inventory = 2; break;
		case 16: Inventory = 3; break;
		case 17: Inventory = 4; break;
		case 29: Inventory = 5; break;
		case 36: Inventory = 6; break;
		case 37: Inventory = 7; break;
		case 38: Inventory = 8; break;
		case 39: Inventory = 9; break;
		case 40: Inventory = 10; break;
	}

	return Inventory;
}

/****************************************************************************************
 *** RecipeManager Functions
 ****************************************************************************************/
int GetRecipeData(int pRecipeManager, int RecipeID, int pRecipeData)
{
	int Result;

	__asm mov eax,pRecipeData
	__asm push eax
	__asm mov edx,RecipeID
	__asm push edx
	__asm mov ecx,pRecipeManager
	__asm call CHKRECIPEINFO

	__asm mov Result, eax
	return Result;
}

int GetRecipeInfo(int pThis, int RecipeID)
{
	int pRecipeInfo;

	__asm mov edx,RecipeID
	__asm push edx
	__asm mov ecx,pThis
	__asm call GETRECIPEINFO

	__asm mov pRecipeInfo, eax
	return pRecipeInfo;
}

int GetRecipeResourceList(int pInventory, int pRecipeInfo, int pList)
{
	int pRecipeResourceList;

	__asm mov eax,pList
	__asm push eax
	__asm mov edx,pRecipeInfo
	__asm push edx
	__asm mov ecx,pInventory
	__asm call GETRECUPERESLIST

	__asm mov pRecipeResourceList, eax
	return pRecipeResourceList;
	
}

void SetCraftItem(int pPlayer, int pItem)
{
	__asm mov edx,pItem
	__asm push edx
	__asm mov ecx,pPlayer
	__asm call SETCRAFTITEM
}

void UpdateRecipe(int pRecipeManager, int RecipeID, int Timestamp)
{
	__asm mov eax,Timestamp
	__asm push eax
	__asm mov edx,RecipeID
	__asm push edx
	__asm mov ecx,pRecipeManager
	__asm call UPDRECIPE
}

void UpdateRecipeInfo(int pPlayer)
{
	__asm mov edx,pPlayer
	__asm push edx
	__asm mov ecx,pPlayer
	__asm call UPDRECIPEINFO

}