#include <RHPet.h>
#include <MapFunctions.h>

using namespace std;

int PETDATAINIT_ORIG_RET = 0x0050C8EF;
int PETDATAINIT_PICKUP_RET = 0x0050C977;

int PETDATASET_ORIG_RET = 0x005EDDB6;
int PETDATASET_CURE_RET = 0x005EDDDF;

int GETPETAFFECT = (DWORD)GetPetAffect;

void PetDataInit()
{
	// Original Code
	__asm mov dword ptr ss:[ebp-0x34],eax
	
	// Pet Type 246
	__asm cmp eax, 0xF6
	__asm je PET_PICKUP
	// Pet Type 257
	__asm cmp eax, 0x101
	__asm je PET_PICKUP
	// Pet Type 274
	__asm cmp eax, 0x112
	__asm je PET_PICKUP
	
	__asm mov ecx,dword ptr ss:[ebp-0x34]
	__asm jmp PETDATAINIT_ORIG_RET

PET_PICKUP:
	__asm jmp PETDATAINIT_PICKUP_RET
}

void PetDataSet()
{
	// Original Code
	__asm mov dword ptr ss:[ebp-0x14],eax

	// Pet Type 188
	__asm cmp eax, 0xBC
	__asm je PET_CURE
	
	__asm mov ecx,dword ptr ss:[ebp-0x14]
	__asm jmp PETDATASET_ORIG_RET

PET_CURE:
	__asm jmp PETDATASET_CURE_RET
}

void PetAffectProc(int Active)
{
	// Original Code
	__asm mov dword ptr ss:[ebp-0xF4],eax
	
	// Active
	__asm mov edx, dword ptr ss:[ebp+0x08]
	// RDPTR
	__asm mov ecx, dword ptr ss:[ebp-0xF0]
	__asm push edx
	__asm push ecx
	__asm call GETPETAFFECT

	__asm jmp eax
}

int GetPetAffect(int RDPTR, int Active)
{
	int RetAddr = 0x005EF3B6;
	int addrs;
	int PlayerPTR;
	int ItemPTR;
	int InventoryPTR;
	int CalAffectPTR;
	int PetType;
	int Damage;
	int CharLevel;
	int Param1, Param2, Param3, Param4, Param5;

	addrs = (DWORD)RDPTR + 0x4;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)RDPTR + 0x8;
	ItemPTR = *(reinterpret_cast<int*>(addrs));
	
	InventoryPTR = (DWORD)PlayerPTR + 0xCC8;

	CalAffectPTR = (DWORD)PlayerPTR + 0x100;

	CharLevel = BioticBaseGetAbility(PlayerPTR, 0x15);

	Param1 = GetPetParams(RDPTR, 1);
	Param2 = GetPetParams(RDPTR, 2);
	Param3 = GetPetParams(RDPTR, 3);
	Param4 = GetPetParams(RDPTR, 4);
	Param5 = GetPetParams(RDPTR, 5);
	
	PetType = GetAttribute(ItemPTR, 0);

	// Pet Unicorn
	if (PetType == 188) RetAddr = 0x005EF66C;
	// Pet Holy Lion
	if (PetType == 189) RetAddr = 0x005EF6A2;
	// Pet Fire Fox
	if (PetType == 190) RetAddr = 0x005EF8B2;
	// Pet Power Tiger 10TH
	if (PetType == 245)
	{
		if (Active == 1)
		{
			PetSetOption(InventoryPTR, 0x29, Param2);
			PetSetOption(InventoryPTR, 0x27, Param3);
		}
		else
		{
			PetSetOption(InventoryPTR, 0x29, 0);
			PetSetOption(InventoryPTR, 0x27, 0);
		}
		RetAddr = 0x005EF965;
	}
	// Pet Sweet Fairy 10TH
	if (PetType == 246)
	{
		if (Active == 1)
		{
			PetSetOption(InventoryPTR, 0x27, Param2);
		}
		else
		{
			PetSetOption(InventoryPTR, 0x27, 0);
		}
		RetAddr = 0x005EF965;
	}
	// Pet Honey Bear 10TH
	if (PetType == 247)
	{
		if (Active == 1)
		{
			PetSetOption(InventoryPTR, 0x25, Param1);
		}
		else
		{
			PetSetOption(InventoryPTR, 0x25, 0);
		}
		PetCalOption(InventoryPTR, 0x17, Param2, Active);
		RetAddr = 0x005EF965;
	}
	// Pet Speedy Hawk 10TH
	if (PetType == 248)
	{
		if (Active == 1)
		{
			PetSetOption(InventoryPTR, 0x27, Param2);
			PetSetOption(InventoryPTR, 0x25, Param3);
		}
		else
		{
			PetSetOption(InventoryPTR, 0x27, 0);
			PetSetOption(InventoryPTR, 0x25, 0);
		}
		RetAddr = 0x005EF965;
	}
	// Pet Brave Dragon 10TH
	if (PetType == 249)
	{
		if (Active == 1)
		{
			Damage = CharLevel * Param2 / 100;
			addrs = (DWORD)PlayerPTR + 0x1AD8;
			*(reinterpret_cast<int*>(addrs)) = Damage;

			PetSetOption(InventoryPTR, 0x2C, Param3);
			PetSetOption(InventoryPTR, 0x27, Param4);
		}
		else
		{
			addrs = (DWORD)PlayerPTR + 0x1AD8;
			*(reinterpret_cast<int*>(addrs)) = 0;
			PetSetOption(InventoryPTR, 0x2C, 0);
			PetSetOption(InventoryPTR, 0x27, 0);
		}
		RetAddr = 0x005EF965;
	}
	// Pet Pixie
	if (PetType == 257)
	{
		if (Active == 1)
		{
			PetSetOption(InventoryPTR, 0x25, Param2);
		}
		else
		{
			PetSetOption(InventoryPTR, 0x25, 0);
		}
		PetCalOption(InventoryPTR, 0x1, Param3, Active);
		PetCalOption(InventoryPTR, 0x2, Param3, Active);
		PetCalOption(InventoryPTR, 0x3, Param3, Active);
		PetCalOption(InventoryPTR, 0x4, Param3, Active);
		PetCalOption(InventoryPTR, 0x5, Param3, Active);
		PetCalOption(InventoryPTR, 0x6, Param3, Active);
		RetAddr = 0x005EF965;
	}
	// Pet SILVA A
	if (PetType == 258)
	{
		PetCalOption(InventoryPTR, 0x17, Param1, Active);
		if (Active == 1)
		{
			PetSetOption(InventoryPTR, 0x27, Param2);
		}
		else
		{
			PetSetOption(InventoryPTR, 0x27, 0);
		}
		PetCalOption(InventoryPTR, 0x61, Param3, Active);
		RetAddr = 0x005EF965;
	}
	// Pet SILVA B
	if (PetType == 259)
	{
		PetCalOption(InventoryPTR, 0x17, Param1, Active);
		if (Active == 1)
		{
			PetSetOption(InventoryPTR, 0x27, Param2);
			QualitiesSetOption(CalAffectPTR, 0xEC, Param3);
		}
		else
		{
			PetSetOption(InventoryPTR, 0x27, 0);
			QualitiesSetOption(CalAffectPTR, 0xEC, 0);
		}
		RetAddr = 0x005EF965;
	}
	// Pet SILVA C
	if (PetType == 260)
	{
		PetCalOption(InventoryPTR, 0x17, Param1, Active);
		if (Active == 1)
		{
			PetSetOption(InventoryPTR, 0x27, Param2);
		}
		else
		{
			PetSetOption(InventoryPTR, 0x27, 0);
		}
		PetCalOption(InventoryPTR, 0x26, Param3, Active);
		RetAddr = 0x005EF965;
	}
	// Pet SILVA D
	if (PetType == 261)
	{
		PetCalOption(InventoryPTR, 0x17, Param1, Active);
		if (Active == 1)
		{
			PetSetOption(InventoryPTR, 0x27, Param2);
		}
		else
		{
			PetSetOption(InventoryPTR, 0x27, 0);
		}
		PetCalOption(InventoryPTR, 0x19, Param3, Active);
		PetCalOption(InventoryPTR, 0x1A, Param3, Active);
		PetCalOption(InventoryPTR, 0x1B, Param3, Active);
		RetAddr = 0x005EF965;
	}
	// Pet Mini Mock Duck 14TH
	if (PetType == 274)
	{
		// PetCalOption(InventoryPTR, 0x66, Param2, Active);
		if (Active == 1)
		{
			QualitiesSetOption(CalAffectPTR, 0x70, Param3);
		}
		else
		{
			QualitiesSetOption(CalAffectPTR, 0x70, 0);
		}
		RetAddr = 0x005EF965;
	}

	return RetAddr;
}