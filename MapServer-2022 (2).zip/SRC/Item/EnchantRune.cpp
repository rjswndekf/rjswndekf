#include <RHItem.h>
#include <MapFunctions.h>
#include <Party.h>

using namespace std;

unsigned char ENCHANTITEM_RUNE[12] = {0};
int ENCHANTITEM_RUNE_ADDRS = (DWORD)ENCHANTITEM_RUNE;

extern int RUNEREINFORCE_ADDRS;
extern int RUNEREINFORCE_SIZE;

void EnchantRune(int pDynamic, int pSendPacket)
{
	int Result;
	int pSendData;
	pSendData = pSendPacket + 4;
	Result = GetEnchantRune(pDynamic, pSendData);
	if (Result != 0)
	{
		*(reinterpret_cast<char*>(ENCHANTITEM_RUNE_ADDRS)) = (char)Result;
		SendPacketEX(pDynamic, 0x147A, ENCHANTITEM_RUNE_ADDRS, 0x1);
	}
}

int GetEnchantRune(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int CharID;
	int pThis;
	//int Result;
	int pItem;
	int pItemUse;
	int pItemMaterial;
	int CheckMaterial;

	int ItemID;
	int nID;
	int Inventory;
	int Slot;
	
	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;

	int pReinfScript = 0;
	int MaterialID = 0;
	int MaterialCount = 0;

	int BootsLevel = 0;
	int Vaule = 0;
	int Chance = 0;

	int PartyID;
	int pParty;

	memset(ENCHANTITEM_RUNE,0,sizeof(char)*12);

	unsigned char DBTASK_INSITEM[65] = {0};
	int DBTASK_INSITEM_ADDRS = (DWORD)DBTASK_INSITEM;

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 2;

	// Send Packet
	addrs = (DWORD)pSendData + 0x0;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x4;
	nID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x9;
	Slot = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0xA;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xE;
	nIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x12;
	InventoryUse = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x13;
	SlotUse = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)ENCHANTITEM_RUNE_ADDRS + 0x1;
	*(reinterpret_cast<int*>(addrs)) = ItemID;
	addrs = (DWORD)ENCHANTITEM_RUNE_ADDRS + 0x5;
	*(reinterpret_cast<int*>(addrs)) = nID;
	addrs = (DWORD)ENCHANTITEM_RUNE_ADDRS + 0x9;
	*(reinterpret_cast<char*>(addrs)) = (char)Inventory;
	addrs = (DWORD)ENCHANTITEM_RUNE_ADDRS + 0xA;
	*(reinterpret_cast<char*>(addrs)) = (char)Slot;
	addrs = (DWORD)ENCHANTITEM_RUNE_ADDRS + 0xB;
	*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
	addrs = (DWORD)ENCHANTITEM_RUNE_ADDRS + 0xF;
	*(reinterpret_cast<int*>(addrs)) = nIDUse;
	addrs = (DWORD)ENCHANTITEM_RUNE_ADDRS + 0x13;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryUse;
	addrs = (DWORD)ENCHANTITEM_RUNE_ADDRS + 0x14;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotUse;

	// Check Item
	pReinfScript = GetRuneScript(ItemID);
	if (pReinfScript == 0) return 5;

	addrs = (DWORD)pReinfScript + 0xC;
	MaterialID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pReinfScript + 0x10;
	MaterialCount = *(reinterpret_cast<int*>(addrs));

	pThis = pPlayer + 0xCC8;
	pItemUse = GetItem(pThis, InventoryUse, SlotUse);
	if (pItemUse == 0) return 5;

	addrs = pItemUse + 0x20;
	CheckMaterial = *(reinterpret_cast<int*>(addrs));
	if (CheckMaterial != ItemIDUse) return 0x37;

	addrs = pItemUse + 0x24;
	CheckMaterial = *(reinterpret_cast<int*>(addrs));
	if (CheckMaterial != nIDUse) return 0x37;

	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);
	if (pItem == 0) return 5;

	addrs = pItem + 0x20;
	CheckMaterial = *(reinterpret_cast<int*>(addrs));
	if (CheckMaterial != ItemID) return 0x37;

	addrs = pItem + 0x24;
	CheckMaterial = *(reinterpret_cast<int*>(addrs));
	if (CheckMaterial != nID) return 0x37;

	// Check Badge of Victory
	pThis = pPlayer + 0xCC8;
	pItemMaterial = FindItem(pThis, MaterialID);
	if (pItemMaterial == 0) return 0x37;
	pThis = pPlayer + 0xCC8;
	CheckMaterial = GetItemCurrentStack(pThis, MaterialID);
	if (CheckMaterial < MaterialCount) return 0x37;

	BootsLevel = ItemOptionGetType(pItem, 0x4F);
	if (BootsLevel > 5) return 1;

	addrs = (DWORD)pReinfScript + 0x40 + (BootsLevel * 0x4);
	Chance = *(reinterpret_cast<int*>(addrs));

	Vaule = BioticBaseGetRandom(pPlayer, 1000000);
	if (Vaule < Chance)
	{
		/************** Success **************/
		//Set Boost Level
		BootsLevel += 1;
		if (BootsLevel > 5) BootsLevel = 6;
		ItemOptionSetType(pItem, 0x4F, BootsLevel);

		// Client Packet
		addrs = ENCHANTITEM_RUNE_ADDRS;
		*(reinterpret_cast<char*>(addrs)) = 0;
		addrs = ENCHANTITEM_RUNE_ADDRS + 0xB;
		*(reinterpret_cast<char*>(addrs)) = 1;

		// Create DBTask Packet 0x4A09
		addrs = DBTASK_INSITEM_ADDRS + 0x4;
		tagItemInit(addrs);
		addrs = DBTASK_INSITEM_ADDRS + 0x4;
		EpochItemBaseGetItemGR(pItem, addrs);

		addrs = (DWORD)pPlayer + 0x30;
		CharID = *(reinterpret_cast<int*>(addrs));
		addrs = DBTASK_INSITEM_ADDRS;
		*(reinterpret_cast<int*>(addrs)) = CharID;

		// Send DB Packet
		SendPacketEX(0x7F23A0, 0x4A09, DBTASK_INSITEM_ADDRS, 0x41);
		
		// Reset Rune
		addrs = (DWORD)pPlayer + 0x1108;
		PartyID = *(reinterpret_cast<int*>(addrs));
		if (PartyID != 0)
		{
			pParty = GetParty(PartyID);
			RuneAttrButeUnload(pParty);
			RuneAttrButeSetting(pParty);
			RuneAttrButeLoad(pParty);			
		}
	}
	else
	{
		/**************** Fail ***************/
		// Client Packet
		addrs = ENCHANTITEM_RUNE_ADDRS;
		*(reinterpret_cast<char*>(addrs)) = 0;
		addrs = ENCHANTITEM_RUNE_ADDRS + 0xB;
		*(reinterpret_cast<char*>(addrs)) = 0;
	}

	// Remove Item
	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemUse);

	pThis = pPlayer + 0xCC8;
	RemoveItemsInInventory(pThis, pItemMaterial, MaterialCount);

	pThis = pDynamic;
	SendPacket(pThis, 0x147A, ENCHANTITEM_RUNE_ADDRS, 0xC);

	return 0;
}

int GetRuneScript(int ItemID)
{
	int pRuneScript = 0;
	int addrs;
	int BinItemID = 0;
	int MaxCount = 0;
	int Offset = 0;

	MaxCount = RUNEREINFORCE_SIZE / 0x68;
	Offset = (DWORD)RUNEREINFORCE_ADDRS;
	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x4;
		BinItemID = *(reinterpret_cast<int*>(addrs));
		if (BinItemID == ItemID)
		{
			pRuneScript = Offset;
			break;
		}
		else
		{
			Offset += 0x68;
		}
	}

	return pRuneScript;	
}
