#include <RHItem.h>

using namespace std;

int SOCKET_REINFORCE_RET = 0x00471C69;
int SOCKET_ERROR_RET = 0x00471E9E;

int CALTYPE_RIGHT_RET = 0x0056901C;
int CALTYPE_ERROR_RET = 0x00569018;

// Cal State Guarder Type
void CalStateGuarderType()
{
	// Shield
	__asm cmp eax,0x12
	__asm je CALTYPE_RIGHT
	// Guarder
	__asm cmp eax,0xFD
	__asm jne CALTYPE_ERROR

CALTYPE_RIGHT:
	__asm jmp CALTYPE_RIGHT_RET

CALTYPE_ERROR:
	__asm jmp CALTYPE_ERROR_RET

}
