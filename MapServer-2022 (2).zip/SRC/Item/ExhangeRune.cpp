#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

unsigned char EXHANGERUNE[82] = {0};
int EXHANGERUNE_ADDRS = (DWORD)EXHANGERUNE;

void ExhangeRune(int pDynamic, int pSendPacket)
{
	int Result;
	int pSendData;
	pSendData = pSendPacket + 4;
	Result = GetExhangeRune(pDynamic, pSendData);
	if (Result != 0)
	{
		*(reinterpret_cast<char*>(EXHANGERUNE_ADDRS)) = (char)Result;
		SendPacketEX(pDynamic, 0x2325, EXHANGERUNE_ADDRS, 0x1);
	}
}

int GetExhangeRune(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int pThis;
	int Result;
	int pItem;
	int pItemUse;
	int pItemMaterial;
	int CheckMaterial;
	int BootsLevel;

	int ItemID;
	int nID;
	int pNID;
	int Inventory;
	int Slot;
	int pInventory;
	int pSlot;

	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;

	int ItemIDMaterial;
	int nIDMaterial;
	int InventoryMaterial;
	int SlotMaterial;

	int PartyID;
	//int pParty;

	unsigned char RACIPITEMID[8] = {0};
	int RACIPITEMID_ADDRS = (DWORD)RACIPITEMID;

	unsigned char FREESPACE[8] = {0};
	int FREESPACE_ADDRS = (DWORD)FREESPACE;

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 2;

	addrs = (DWORD)pPlayer + 0x1108;
	PartyID = *(reinterpret_cast<int*>(addrs));
	if (PartyID != 0) return 7;

	// Send Packet
	addrs = (DWORD)pSendData;
	ItemID = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)pSendData + 0x4;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	nIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xC;
	InventoryUse = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0xD;
	SlotUse = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)pSendData + 0xE;
	ItemIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x12;
	nIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x16;
	InventoryMaterial = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x17;
	SlotMaterial = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)EXHANGERUNE_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)EXHANGERUNE_ADDRS + 1;
	*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
	addrs = (DWORD)EXHANGERUNE_ADDRS + 5;
	*(reinterpret_cast<int*>(addrs)) = nIDUse;
	addrs = (DWORD)EXHANGERUNE_ADDRS + 9;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryUse;
	addrs = (DWORD)EXHANGERUNE_ADDRS + 10;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotUse;
	addrs = (DWORD)EXHANGERUNE_ADDRS + 11;
	*(reinterpret_cast<int*>(addrs)) = ItemIDMaterial;
	addrs = (DWORD)EXHANGERUNE_ADDRS + 15;
	*(reinterpret_cast<int*>(addrs)) = nIDMaterial;
	addrs = (DWORD)EXHANGERUNE_ADDRS + 19;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryMaterial;
	addrs = (DWORD)EXHANGERUNE_ADDRS + 20;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotMaterial;

	// Check Item
	pThis = pPlayer + 0xCC8;
	pItemUse = GetItem(pThis, InventoryUse, SlotUse);
	if (pItemUse == 0) return 5;

	addrs = pItemUse + 0x20;
	CheckMaterial = *(reinterpret_cast<int*>(addrs));
	if (CheckMaterial != ItemIDUse) return 0x37;

	addrs = pItemUse + 0x24;
	CheckMaterial = *(reinterpret_cast<int*>(addrs));
	if (CheckMaterial != nIDUse) return 0x37;

	pThis = pPlayer + 0xCC8;
	pItemMaterial = GetItem(pThis, InventoryMaterial, SlotMaterial);
	if (pItemMaterial == 0) return 5;

	addrs = pItemMaterial + 0x20;
	CheckMaterial = *(reinterpret_cast<int*>(addrs));
	if (CheckMaterial != ItemIDMaterial) return 0x37;

	addrs = pItemMaterial + 0x24;
	CheckMaterial = *(reinterpret_cast<int*>(addrs));
	if (CheckMaterial != nIDMaterial) return 0x37;

	addrs = (DWORD)pSendData + 0x2;
	CheckMaterial = *(reinterpret_cast<char*>(addrs));
	CheckMaterial &= 0xFF;
	if (CheckMaterial != 0x54) return 0x37;

	// Get Option
	BootsLevel = ItemOptionGetType(pItemMaterial, 0x4F);
	if (BootsLevel > 5) BootsLevel = 6;

	// Cerate Item
	addrs = EXHANGERUNE_ADDRS + 0x15;
	tagItemInit(addrs);

	AllocItem(RACIPITEMID_ADDRS, ItemID);
	pNID = RACIPITEMID_ADDRS + 4;
	nID = *(reinterpret_cast<int*>(pNID));
	if (nID < 1) return 0x8E;

	pItem = CreateItem(RACIPITEMID_ADDRS, 1);

	addrs = (DWORD)FREESPACE_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;
	addrs = (DWORD)FREESPACE_ADDRS + 4;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;

	pInventory = FREESPACE_ADDRS;
	pSlot = FREESPACE_ADDRS + 4;

	pThis = pPlayer + 0xCC8;
	Result = GetFreeInventorySlot(pThis, pInventory, pSlot);
	if (Result == 0) return 0x37;

	addrs = FREESPACE_ADDRS;
	Inventory = *(reinterpret_cast<int*>(addrs));
	addrs = FREESPACE_ADDRS + 4;
	Slot = *(reinterpret_cast<int*>(addrs));

	ItemOptionSetType(pItem, 0x4F, BootsLevel);

	pThis = pPlayer + 0xCC8;
	Result = AddItem(pThis, pItem, Inventory, Slot, 0);
	if (Result == 0) return 0x37;

	addrs = EXHANGERUNE_ADDRS + 0x15;
	EpochItemBaseGetItemGR(pItem, addrs);

	// Remove Item
	pThis = pPlayer + 0xCC8;
	RemoveItemsInInventory(pThis, pItemUse, 1);

	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemMaterial);

	pThis = pDynamic;
	SendPacketEX(pThis, 0x2325, EXHANGERUNE_ADDRS, 0x52);

	return 0;
}
