#include <RHItem.h>
//#include <MapFunctions.h>

using namespace std;

int BINATTR_TYPE;
int BINATTR_CLASS;
int BINATTR_RESULT;

void ItemAttr()
{
	__asm mov dword ptr ss:[ebp-0x4],0xFFFFFFFF

	__asm lea edx,dword ptr ss:[ebp-0x4]
	__asm mov BINATTR_RESULT,edx

	__asm mov eax,dword ptr ss:[ebp+0xC]
	__asm mov BINATTR_CLASS,eax

	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov BINATTR_TYPE,eax
	
	BinAttributeExt(BINATTR_TYPE, BINATTR_CLASS, BINATTR_RESULT);

	__asm jmp eax
}

int BinAttributeExt(int BinAttribute, int AttributeClass, int pRes)
{
	int addrs;
	int RetAddrs = 0x0068834D;
	int RetEnd = 0x0068855C;
	int RetType = -1;
	
	switch(BinAttribute)
	{
		case 176: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 179: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 180: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 181: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 182: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 183: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 184: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 185: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 188: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 189: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 193: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 194: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 195: RetType = 179; RetAddrs = RetEnd; break;
		case 196: RetType = 183; RetAddrs = RetEnd; break;
		case 197: RetType = 18; RetAddrs = RetEnd; break;
		case 198: RetType = 188; RetAddrs = RetEnd; break;
		case 199: RetType = 19; RetAddrs = RetEnd; break;
		case 200: RetType = 17; RetAddrs = RetEnd; break;
		case 201: RetType = 182; RetAddrs = RetEnd; break;
		case 202: RetType = 181; RetAddrs = RetEnd; break;
		case 203: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 204: RetType = 76; RetAddrs = RetEnd; break;
		case 205: RetType = 185; RetAddrs = RetEnd; break;
		case 206: RetType = 47; RetAddrs = RetEnd; break;
		case 207: RetType = 15; RetAddrs = RetEnd; break;
		case 208: RetType = 45; RetAddrs = RetEnd; break;
		case 210: RetType = 45; RetAddrs = RetEnd; break;
		case 211: RetType = 30; RetAddrs = RetEnd; break;
		case 212: RetType = 46; RetAddrs = RetEnd; break;
		case 213: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 215: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 216: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 219: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 221: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 222: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 223: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 224: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 225: RetType = BinAttribute; RetAddrs = RetEnd; break;
		case 226: RetType = BinAttribute; RetAddrs = RetEnd; break;
	}

	addrs = (DWORD)pRes;
	*(reinterpret_cast<int*>(addrs)) = RetType;

	return RetAddrs;
}