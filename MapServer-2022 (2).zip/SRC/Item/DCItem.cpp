#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

unsigned char DCITEM_BUFFER[132] = {0};
int DCITEM_ADDRS = (DWORD)DCITEM_BUFFER;
int DCITEM_RET = 0x00461E1D;

unsigned char DCITEMEXP_BUFFER[8] = {0};
int DCITEMEXP_ADDRS = (DWORD)DCITEMEXP_BUFFER;

int DCItemID;
int GETDCEXPFUN = 0x004FABE0;
int CHECKDCEXP_RET = 0x0046161A;

// **** 2021 RCM_MAP_USE_DC_ITEM 0x1459 Patch *******************************
void UseDCItemPacket()
{
	__asm lea esi,dword ptr ss:[ebp-0xD8]
	__asm mov edi, DCITEM_ADDRS
	__asm mov ecx,0x2F

	__asm rep movs byte ptr es:[edi],byte ptr ds:[esi]

	__asm mov dword ptr ds:[edi],0x0
	__asm add edi,0x4

	__asm mov ecx,0x51
	__asm rep movs byte ptr es:[edi],byte ptr ds:[esi]

	// Send Packet 0x1459
	__asm mov edi, DCITEM_ADDRS
	__asm push 0x84
	__asm push edi
	__asm push 0x1459
	__asm mov edx,dword ptr ss:[ebp-0x2D4]
	__asm mov eax,dword ptr ds:[edx]
	__asm mov ecx,dword ptr ss:[ebp-0x2D4]
	__asm call dword ptr ds:[eax+0x2C]

	__asm jmp DCITEM_RET

}
