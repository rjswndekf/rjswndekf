#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

unsigned char RANDOBOX_REWARD[62] = {0};

extern int ITEMRANDOBOX_REWARD_ADDRS;
extern int ITEMRANDOBOX_REWARD_SIZE;

void RandomBoxReward(int pDynamic, int pSendPacket)
{
	int addrs;
	int Result;
	int pSendData;
	
	memset(RANDOBOX_REWARD, 0, 62);

	pSendData = pSendPacket + 4;
	Result = GetRandomBoxReward(pDynamic, pSendData);
	if (Result != 0)
	{
		addrs = (int)RANDOBOX_REWARD;
		*(char*)addrs = (char)Result;
		SendPacketEX(pDynamic, 0x1479, (int)RANDOBOX_REWARD, 0x1);
	}
}

int GetRandomBoxReward(int pDynamic, int pSendData)
{
	int pPlayer;
	int pThis;
	int Amount = 0;
	int pScript;

	int ItemID;
	int nID;
	int Inventory = 0xFF;
	int Slot = 0xFF;
	int pItem;

	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;

	int pItemUse;
	int ItemType;
	int Chance;
	int RewardGrade;
	int Result;

	unsigned char NEWNID[8] = {0};

	// Check
	pPlayer = *(int*)(pDynamic + 0x534);
	if (pPlayer == 0) return 0x1;

	ItemIDUse = *(unsigned int*)pSendData;
	nIDUse = *(unsigned int*)(pSendData + 0x4);
	InventoryUse = *(unsigned char*)(pSendData + 0x8);
	SlotUse = *(unsigned char*)(pSendData + 0x9);

	pThis = pPlayer + 0xCC8;
	pItemUse = FindItem(pThis, ItemIDUse);
	if (pItemUse == 0) return 0x4;

	ItemType = GetAttribute(pItemUse, 0);
	if (ItemType != 263) return 0x16;

	RewardGrade = GetAttribute(pItemUse, 0x3A);
	Chance = BioticBaseGetRandom(pPlayer, 1000000);
	pScript = GetRandomBoxRewardScript(RewardGrade, Chance);
	if (pScript == 0) return 0x16;

	ItemID = *(unsigned int*)(pScript + 0xC);
	Amount = *(unsigned int*)(pScript + 0x14);

	// Cerate Item
	AllocItem((int)NEWNID, ItemID);
	nID = *(int*)((int)NEWNID + 4);
	if (nID < 1) return 0x8E;
	pItem = CreateItem((int)NEWNID, Amount);

	pThis = (DWORD)pPlayer + 0xCC8;
	Result = GetFreeInventorySlot(pThis, (int)&Inventory, (int)&Slot);
	if (Result == 0) return 0x37;

	pThis = (DWORD)pPlayer + 0xCC8;
	Result = AddItem(pThis, pItem, Inventory, Slot, 0);
	if (Result == 0) return 0x37;

	// Client Packet
	tagItemInit((int)RANDOBOX_REWARD + 0x1);
	EpochItemBaseGetItemGR(pItem, (int)RANDOBOX_REWARD + 0x1);

	pThis = pDynamic;
	SendPacketEX(pThis, 0x1479, (int)RANDOBOX_REWARD, 0x3E);

	// Remove Item
	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemUse);

	return 0;
}

int GetRandomBoxRewardScript(int RewardGrade, int Chance)
{
	int pScript = 0;
	int BinGeade = 0;
	int BinRate = 0;
	int MaxCount = 0;
	int Offset = 0;

	MaxCount = ITEMRANDOBOX_REWARD_SIZE / 0x18;
	Offset = (DWORD)ITEMRANDOBOX_REWARD_ADDRS;

	for( int i = 0; i < MaxCount; i++ )
	{
		BinGeade = *(unsigned int*)(Offset + 0x8);
		if (BinGeade == RewardGrade)
		{
			BinRate = *(unsigned int*)(Offset + 0x10);
			if (BinRate > Chance)
			{
				pScript = Offset;
				break;
			}
		}
		Offset += 0x18;
	}

	return pScript;
}