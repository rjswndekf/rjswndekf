#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

unsigned char SORT0_BUFFER[240] = {0};
unsigned char SORT1_BUFFER[240] = {0};
unsigned char SORT2_BUFFER[240] = {0};
unsigned char SORT3_BUFFER[240] = {0};
unsigned char SORT4_BUFFER[240] = {0};
unsigned char SORT5_BUFFER[240] = {0};
unsigned char SORT6_BUFFER[240] = {0};
unsigned char SORT7_BUFFER[240] = {0};

unsigned char DBTASK_SAVEITEM[11] = {0};
unsigned char ITEMSORT_BUFFER[664] = {0};

int SORT0_ADDRS = (DWORD)SORT0_BUFFER;
int SORT1_ADDRS = (DWORD)SORT1_BUFFER;
int SORT2_ADDRS = (DWORD)SORT2_BUFFER;
int SORT3_ADDRS = (DWORD)SORT3_BUFFER;
int SORT4_ADDRS = (DWORD)SORT4_BUFFER;
int SORT5_ADDRS = (DWORD)SORT5_BUFFER;
int SORT6_ADDRS = (DWORD)SORT6_BUFFER;
int SORT7_ADDRS = (DWORD)SORT7_BUFFER;

int DBTASK_SAVEITEM_ADDRS = (DWORD)DBTASK_SAVEITEM;
int ITEMSORT_ADDRS = (DWORD)ITEMSORT_BUFFER;

void ItemsSort(int DynamicPTR, int SendPacketPTR)
{
	int addrs;
	int SendData;
	int pData;
	int PlayerPTR;
	int pThis;
	unsigned int CharID;
	int Inventory = 1;
	int Slot = 0;
	int Stack;
	unsigned int ItemID;
	unsigned int nID;
	int CurItemCount;
	//int MaxAllowSlot;
	int pItem;
	
	int ItemSort;
	int Sort1 = 0;
	int Sort2 = 0;
	int Sort3 = 0;
	int Sort4 = 0;
	int Sort5 = 0;
	int Sort6 = 0;
	int Sort7 = 0;
	int SRC;
	int DST;
	int offset = 0;
	int BagBasePTR;
	int BagPTR;

	memset(SORT0_BUFFER,0,sizeof(char)*240);
	memset(SORT1_BUFFER,0,sizeof(char)*240);
	memset(SORT2_BUFFER,0,sizeof(char)*240);
	memset(SORT3_BUFFER,0,sizeof(char)*240);
	memset(SORT4_BUFFER,0,sizeof(char)*240);
	memset(SORT5_BUFFER,0,sizeof(char)*240);
	memset(SORT6_BUFFER,0,sizeof(char)*240);
	memset(SORT7_BUFFER,0,sizeof(char)*240);
	memset(DBTASK_SAVEITEM,0,sizeof(char)*11);
	memset(ITEMSORT_BUFFER,0,sizeof(char)*664);

	addrs = (DWORD)DynamicPTR + 0x534;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	if (PlayerPTR != 0)
	{
		SendData = (DWORD)SendPacketPTR + 0x4;
		addrs = (DWORD)SendData;
		Inventory = *(reinterpret_cast<char*>(addrs));
		
		pThis = (DWORD)PlayerPTR + 0xCC8;
		CurItemCount = GetCurCount(pThis, Inventory);
		//pThis = (DWORD)PlayerPTR + 0xCC8;
		//MaxAllowSlot = GetAllowCount(InventoryPTR, Inventory);

		// ItemSort Arrangement
		for(Slot = 0; Slot < 60; Slot++ )
		{
			pThis = (DWORD)PlayerPTR + 0xCC8;
			pItem = GetItem(pThis, Inventory, Slot);
			if (pItem != 0)
			{
				ItemSort = GetItemSort(pItem);
				if (ItemSort == 1)
				{
					addrs = (DWORD)SORT1_ADDRS + (Sort1 * 4);
					*(reinterpret_cast<int*>(addrs)) = pItem;
					Sort1++;
				}
				if (ItemSort == 2)
				{
					addrs = (DWORD)SORT2_ADDRS + (Sort2 * 4);
					*(reinterpret_cast<int*>(addrs)) = pItem;
					Sort2++;
				}
				if (ItemSort == 3)
				{
					addrs = (DWORD)SORT3_ADDRS + (Sort3 * 4);
					*(reinterpret_cast<int*>(addrs)) = pItem;
					Sort3++;
				}
				if (ItemSort == 4)
				{
					addrs = (DWORD)SORT4_ADDRS + (Sort4 * 4);
					*(reinterpret_cast<int*>(addrs)) = pItem;
					Sort4++;
				}
				if (ItemSort == 5)
				{
					addrs = (DWORD)SORT5_ADDRS + (Sort5 * 4);
					*(reinterpret_cast<int*>(addrs)) = pItem;
					Sort5++;
				}
				if (ItemSort == 6)
				{
					addrs = (DWORD)SORT6_ADDRS + (Sort6 * 4);
					*(reinterpret_cast<int*>(addrs)) = pItem;
					Sort6++;
				}
				if (ItemSort == 7)
				{
					addrs = (DWORD)SORT7_ADDRS + (Sort7 * 4);
					*(reinterpret_cast<int*>(addrs)) = pItem;
					Sort7++;
				}
			}
		}

		// Sort1-7 Arrangement
		SRC = SORT1_ADDRS;
		DST = SORT0_ADDRS;
		SortsArrangement(SRC, DST, Sort1, 236);
		offset = (Sort1 * 4);

		SRC = SORT2_ADDRS;
		DST += offset;
		SortsArrangement(SRC, DST, Sort2, 254);
		offset = (Sort2 * 4);

		SRC = SORT3_ADDRS;
		DST += offset;
		SortsArrangement(SRC, DST, Sort3, 98);
		offset = (Sort3 * 4);
		
		SRC = SORT4_ADDRS;
		DST += offset;
		SortsArrangement(SRC, DST, Sort4, 121);
		offset = (Sort4 * 4);

		SRC = SORT5_ADDRS;
		DST += offset;
		SortsArrangement(SRC, DST, Sort5, 275);
		offset = (Sort5 * 4);

		SRC = SORT6_ADDRS;
		DST += offset;
		SortsArrangement(SRC, DST, Sort6, 118);
		offset = (Sort6 * 4);

		SRC = SORT7_ADDRS;
		DST += offset;
		SortsArrangement(SRC, DST, Sort7, 281);
		
		// Copy New pItem to BagPTR
		pThis = (DWORD)PlayerPTR + 0xCC8;
		addrs = (DWORD)pThis + 0x4;
		BagBasePTR = *(reinterpret_cast<int*>(addrs));
		BagPTR = (DWORD)BagBasePTR + (Inventory * 0x81C);
		
		for(Slot = 0; Slot < 60; Slot++ )
		{
			SRC = (DWORD)SORT0_ADDRS + (Slot * 4);
			pItem = *(reinterpret_cast<int*>(SRC));
			DST = (DWORD)BagPTR + (Slot * 4);
			*(reinterpret_cast<int*>(DST)) = pItem;
		}
		
		// Set Item Slot
		for(Slot = 0; Slot < 60; Slot++ )
		{
			addrs = (DWORD)SORT0_ADDRS + (Slot * 4);
			pItem = *(reinterpret_cast<int*>(addrs));
			if (pItem != 0)
			{
				SetAttribute(pItem, 0xD, Slot);
				
				addrs = (DWORD)PlayerPTR + 0x30;
				CharID = *(reinterpret_cast<unsigned int*>(addrs));

				addrs = (DWORD)pItem + 0x24;
				nID = *(reinterpret_cast<unsigned int*>(addrs));

				Inventory = GetAttribute(pItem, 0xC);
				Stack = GetAttribute(pItem, 0x9);
				
				addrs = (DWORD)pItem + 0x20;
				ItemID = *(reinterpret_cast<unsigned int*>(addrs));

				addrs = DBTASK_SAVEITEM_ADDRS;
				*(reinterpret_cast<unsigned int*>(addrs)) = CharID;
				addrs = DBTASK_SAVEITEM_ADDRS + 0x4;
				*(reinterpret_cast<unsigned int*>(addrs)) = nID;
				addrs = DBTASK_SAVEITEM_ADDRS + 0x8;
				*(reinterpret_cast<char*>(addrs)) = (char)Inventory;
				addrs = DBTASK_SAVEITEM_ADDRS + 0x9;
				*(reinterpret_cast<char*>(addrs)) = (char)Slot;
				addrs = DBTASK_SAVEITEM_ADDRS + 0xA;
				*(reinterpret_cast<char*>(addrs)) = (char)Stack;

				pData = ITEMSORT_ADDRS + (Slot * 11) + 4;
				addrs = pData;
				*(reinterpret_cast<unsigned int*>(addrs)) = ItemID;
				addrs = pData + 0x4;
				*(reinterpret_cast<unsigned int*>(addrs)) = nID;
				addrs = pData + 0x8;
				*(reinterpret_cast<char*>(addrs)) = (char)Inventory;
				addrs = pData + 0x9;
				*(reinterpret_cast<char*>(addrs)) = (char)Slot;
				addrs = pData + 0xA;
				*(reinterpret_cast<char*>(addrs)) = (char)Stack;

				SendPacketEX(0x7F23A0, 0x4A0B, DBTASK_SAVEITEM_ADDRS, 0xB);
			}
		}

		pThis = DynamicPTR;
		SendPacketEX(DynamicPTR, 0x151C, ITEMSORT_ADDRS, 0x298);

	}
}

void SortsArrangement(int SRC, int DST, int SortsCount, int MaxType)
{
	int raddrs;
	int waddrs;
	int wcount = 0;
	int pItem;
	int ItemType;

	for(int i = 0; i < MaxType; i++ )
	{
		for(int j = 0; j < SortsCount; j++ )
		{
			raddrs = (DWORD)SRC + (j * 4);
			pItem = *(reinterpret_cast<int*>(raddrs));
			ItemType = GetAttribute(pItem, 0);
			if (ItemType == i)
			{
				waddrs = (DWORD)DST + (wcount * 4);
				*(reinterpret_cast<int*>(waddrs)) = pItem;
				wcount++;
			}
		}
	}
}

/***************************
 Sort 1: Weapon
 Sort 2: Armor
 Sort 3: Accessory
 Sort 4: Talisman
 Sort 5: Pet
 Sort 6: Costume
 Sort 7: Misc
***************************/
int GetItemSort(int pItem)
{
	int ItemSort = 7;
	int ItemType;
	int Description;

	ItemType = GetAttribute(pItem, 0);
	Description = GetAttribute(pItem, 1);

	switch(ItemType)
	{
		case 0: ItemSort = 6; break;
		case 1: ItemSort = 1; break;
		case 2: ItemSort = 1; break;
		case 3: ItemSort = 1; break;
		case 4: ItemSort = 1; break;
		case 5: ItemSort = 1; break;
		case 6: ItemSort = 1; break;
		case 7: ItemSort = 1; break;
		case 8: ItemSort = 1; break;
		case 9: ItemSort = 1; break;
		case 10: ItemSort = 1; break;
		case 11: ItemSort = 1; break;
		case 12: ItemSort = 1; break;
		case 13: ItemSort = 2; break;
		case 14: ItemSort = 2; break;
		case 15: ItemSort = 2; break;
		case 16: ItemSort = 2; break;
		case 17: ItemSort = 2; break;
		case 18: ItemSort = 2; break;
		case 19: ItemSort = 3; break;
		case 20: ItemSort = 3; break;
		case 21: ItemSort = 3; break;
		case 22: ItemSort = 3; break;
		case 23: ItemSort = 3; break;
		case 66: ItemSort = 5; break;
		case 67: ItemSort = 5; break;
		case 68: ItemSort = 5; break;
		case 85: ItemSort = 6; break;
		case 88: ItemSort = 6; break;
		case 93: ItemSort = 5; break;
		case 95: ItemSort = 3; break;
		case 96: ItemSort = 6; break;
		case 97: ItemSort = 3; break;
		case 109: ItemSort = 6; break;
		case 117: ItemSort = 6; break;
		case 120: ItemSort = 4; break;
		case 121: ItemSort = 5; break;
		case 122: ItemSort = 5; break;
		case 123: ItemSort = 5; break;
		case 135: ItemSort = 2; break;
		case 136: ItemSort = 2; break;
		case 137: ItemSort = 2; break;
		case 138: ItemSort = 1; break;
		case 139: ItemSort = 2; break;
		case 140: ItemSort = 2; break;
		case 141: ItemSort = 2; break;
		case 142: ItemSort = 2; break;
		case 143: ItemSort = 1; break;
		case 144: ItemSort = 2; break;
		case 148: ItemSort = 5; break;
		case 149: ItemSort = 5; break;
		case 150: ItemSort = 5; break;
		case 151: ItemSort = 5; break;
		case 152: ItemSort = 5; break;
		case 188: ItemSort = 5; break;
		case 189: ItemSort = 5; break;
		case 190: ItemSort = 5; break;
		case 228: ItemSort = 2; break;
		case 229: ItemSort = 2; break;
		case 230: ItemSort = 2; break;
		case 231: ItemSort = 2; break;
		case 232: ItemSort = 2; break;
		case 234: ItemSort = 1; break;
		case 235: ItemSort = 1; break;
		case 245: ItemSort = 5; break;
		case 246: ItemSort = 5; break;
		case 247: ItemSort = 5; break;
		case 248: ItemSort = 5; break;
		case 253: ItemSort = 2; break;
		case 257: ItemSort = 5; break;
		case 258: ItemSort = 5; break;
		case 259: ItemSort = 5; break;
		case 260: ItemSort = 5; break;
		case 261: ItemSort = 5; break;
		case 274: ItemSort = 5; break;
	}
	return ItemSort;
}
