#include <RHItem.h>
#include <MapFunctions.h>

using namespace std; 

unsigned char ARRENDAL_ADDEXP[8] = {0};
unsigned char ARRENDAL_GROWTHA[75] = {0};
unsigned char ARRENDAL_GROWTHM[89] = {0};
unsigned char ITEMGR_ARRENDAL_GROWTHA[65] = {0};
unsigned char ITEMGR_ARRENDAL_GROWTHM[65] = {0};

void ArrendalGrowthAutomatic(int pPlayer, int pExp)
{
	int addrs;
	int pThis;
	int pItem;
	int ItemDesc = 0;
	unsigned int ItemID;
	unsigned int EpochID;
	int pWeaponInfo;
	int nID;
	int Level;
	int pBindArrendal;

	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, 0, 5);
	if (pItem != 0)
	{
		ItemDesc = GetAttribute(pItem, 1);
		if (ItemDesc == 21)
		{
			addrs = pItem + 0x20;
			ItemID = *(reinterpret_cast<unsigned int*>(addrs));
			addrs = pItem + 0x24;
			EpochID = *(reinterpret_cast<unsigned int*>(addrs));

			pWeaponInfo = GetItemBinScriptInfo(ItemID);
			addrs = pWeaponInfo + 0x27C;
			Level = *(reinterpret_cast<int*>(addrs));
			if ((Level > 19) && (Level < 135))
			{
				pThis = pPlayer;
				pBindArrendal = GetWeaponBindData(pThis);
				addrs = pBindArrendal;
				nID = *(reinterpret_cast<unsigned int*>(addrs));

				if (EpochID == nID)
				{
					pThis = pPlayer;
					GetArrendalGrowthAutomatic(pThis, pExp);
				}
			}
		}
	}
}

void GetArrendalGrowthAutomatic(int pPlayer, int pExp)
{
	int addrs;
	int pThis;
	int CharID = 0;
	int pWeaponInfo = 0;
	int Level = 0;
	int UpLevel = 0;
	int pItem = 0;
	int pNewItem;
	unsigned int ItemID = 0;
	unsigned int nID = 0;
	unsigned int UpItemID = 0;
	int ItemDesc = 0;
	int Description = 0;
	__int64 EXP64 = 0;
	__int64 PAEXP = 0;
	int pPAEXP = 0;
	float ArendaExpRate = 0.0;
	int IsEvolution = 0;
	int pAttribute;
	int AttributeType;
	int AttributeValue;

	unsigned char NEWITEM[8] = {0};
	unsigned char STAMP[8] = {0};

	//Check Weapon
	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, 0, 5);

	addrs = pItem + 0x20;
	ItemID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pItem + 0x24;
	nID = *(reinterpret_cast<unsigned int*>(addrs));

	addrs = pPlayer + 0x30;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));

	// Cal EXP
	addrs = pExp;
	EXP64 = *(reinterpret_cast<__int64*>(addrs));

	pPAEXP = pPlayer + 0x2060;
	PAEXP = *(reinterpret_cast<__int64*>(pPAEXP));

	PAEXP += EXP64;
	*(reinterpret_cast<__int64*>(pPAEXP)) = PAEXP;

	pWeaponInfo = GetItemBinScriptInfo(ItemID);
	addrs = pWeaponInfo + 0x27C;
	Level = *(reinterpret_cast<int*>(addrs));
	addrs = pWeaponInfo + 0x290;
	UpItemID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pWeaponInfo + 0x288;
	PAEXP = *(reinterpret_cast<__int64*>(addrs));
	addrs = pWeaponInfo + 0x280;
	IsEvolution = *(reinterpret_cast<int*>(addrs));

	pThis = pPlayer;
	ArendaExpRate = GetArrendalExpRate(pThis, ItemID);
	if (ArendaExpRate >= 100.0)
	{
		// Cal Upgrade EXP
		pWeaponInfo = GetItemBinScriptInfo(ItemID);

		if (IsEvolution == 0)
		{
			if (Level < 134)
			{
				/*** Upgrade Arrendal ***/
				addrs = (int)ITEMGR_ARRENDAL_GROWTHA + 0x4;
				tagItemInit(addrs);
				addrs = (int)ITEMGR_ARRENDAL_GROWTHA + 0x4;
				EpochItemBaseGetItemGR(pItem, addrs);

				pThis = pPlayer;
				UpgradeTrinityWeaponInfo(pThis, nID, ItemID, 1);

				pThis = pPlayer + 0xCC8;
				RemoveItem(pThis, pItem);

				addrs = (int)NEWITEM;
				*(reinterpret_cast<unsigned int*>(addrs)) = UpItemID;
				addrs = (int)NEWITEM + 0x4;
				*(reinterpret_cast<unsigned int*>(addrs)) = nID;

				pNewItem = CreateItem((int)NEWITEM, 1);

				GetItemStamp(pNewItem, (int)STAMP);

				pThis = pPlayer + 0xCC8;
				AddItem(pThis, pNewItem, 0, 5, 0);

				pThis = pPlayer;
				TimerItemManager(pThis, pNewItem, (int)STAMP);

				// Setting Item Attribute
				pAttribute = (int)ITEMGR_ARRENDAL_GROWTHA + 0xC;
				for(int i = 0; i < 14; i++ )
				{
					addrs = pAttribute + (i * 3);
					AttributeType = *(reinterpret_cast<char*>(addrs));
					if (AttributeType != 0)
					{
						addrs = pAttribute + (i * 3) + 1;
						AttributeValue = *(reinterpret_cast<unsigned short*>(addrs));

						ItemOptionSetType(pNewItem, AttributeType, AttributeValue);
					}
				}

				// DBTask Packet
				addrs = (int)ITEMGR_ARRENDAL_GROWTHA;
				*(reinterpret_cast<unsigned int*>(addrs)) = CharID;
				addrs = (int)ITEMGR_ARRENDAL_GROWTHA + 0x4;
				tagItemInit(addrs);
				addrs = (int)ITEMGR_ARRENDAL_GROWTHA + 0x4;
				EpochItemBaseGetItemGR(pNewItem, addrs);

				// Send DB Packet
				SendPacketEX(0x7F23A0, 0x4A09, (int)ITEMGR_ARRENDAL_GROWTHA, 0x41);

				// Client Packet
				addrs = (int)ARRENDAL_GROWTHA + 0xA;
				tagItemInit(addrs);
				addrs = (int)ARRENDAL_GROWTHA + 0xA;
				EpochItemBaseGetItemGR(pNewItem, addrs);

				UpLevel = Level + 1;

				addrs = (int)ARRENDAL_GROWTHA;
				*(reinterpret_cast<unsigned int*>(addrs)) = ItemID;
				addrs = (int)ARRENDAL_GROWTHA + 0x4;
				*(reinterpret_cast<unsigned int*>(addrs)) = nID;
				addrs = (int)ARRENDAL_GROWTHA + 0x8;
				*(reinterpret_cast<char*>(addrs)) = 0x0;
				addrs = (int)ARRENDAL_GROWTHA + 0x9;
				*(reinterpret_cast<char*>(addrs)) = 0x5;
				addrs = (int)ARRENDAL_GROWTHA + 0x47;
				*(reinterpret_cast<int*>(addrs)) = UpLevel;

				addrs = pPlayer + 0x1098;
				pThis = *(reinterpret_cast<int*>(addrs));
				SendPacketEX(pThis, 0x3002, (int)ARRENDAL_GROWTHA, 0x4B);
			}
			else
			{
				// Level 134 Set Exp To 100%
				pThis = pPlayer;
				SaveTrinityWeaponInfo(pThis, nID, ItemID, 1);

				pPAEXP = pPlayer + 0x2060;
				*(reinterpret_cast<__int64*>(pPAEXP)) = PAEXP;

				addrs = (int)ARRENDAL_ADDEXP;
				*(reinterpret_cast<unsigned int*>(addrs)) = nID;

				ArendaExpRate = 100.0;
				addrs = (int)ARRENDAL_ADDEXP + 0x4;
				*(reinterpret_cast<float*>(addrs)) = ArendaExpRate;

				addrs = pPlayer + 0x1098;
				pThis = *(reinterpret_cast<int*>(addrs));
				SendPacketEX(pThis, 0x3001, (int)ARRENDAL_ADDEXP, 0x8);
			}
		}
		else
		{
			// Need Evolution Set EXP To 100% 
			pThis = pPlayer;
			SaveTrinityWeaponInfo(pThis, nID, ItemID, 1);

			pPAEXP = pPlayer + 0x2060;
			*(reinterpret_cast<__int64*>(pPAEXP)) = PAEXP;

			addrs = (int)ARRENDAL_ADDEXP;
			*(reinterpret_cast<unsigned int*>(addrs)) = nID;

			ArendaExpRate = 100.0;
			addrs = (int)ARRENDAL_ADDEXP + 0x4;
			*(reinterpret_cast<float*>(addrs)) = ArendaExpRate;
			
			addrs = pPlayer + 0x1098;
			pThis = *(reinterpret_cast<int*>(addrs));

			SendPacketEX(pThis, 0x3001, (int)ARRENDAL_ADDEXP, 0x8);
		}
	}
	else
	{
		// Add EXP
		pThis = pPlayer;
		SaveTrinityWeaponInfo(pThis, nID, ItemID, 0);

		addrs = (int)ARRENDAL_ADDEXP;
		*(reinterpret_cast<unsigned int*>(addrs)) = nID;

		addrs = (int)ARRENDAL_ADDEXP + 0x4;
		*(reinterpret_cast<float*>(addrs)) = ArendaExpRate;
	
		addrs = pPlayer + 0x1098;
		pThis = *(reinterpret_cast<int*>(addrs));

		SendPacketEX(pThis, 0x3001, (int)ARRENDAL_ADDEXP, 0x8);
	}
}



// Packet 0x3007 Size 0x59
void ArrendalGrowthManual(int pDynamic, int pSendPacket)
{
	int result;
	int addrs;
	int pSendData;
	
	memset(ARRENDAL_GROWTHM,0,sizeof(char)*89);

	pSendData = pSendPacket + 4;

	result = GetArrendalGrowthManual(pDynamic, pSendData);
	if (result != 0)
	{
		addrs = (int)ARRENDAL_GROWTHM;
		*(reinterpret_cast<char*>(addrs)) = (char)result;
		SendPacket(pDynamic, 0x3007, (int)ARRENDAL_GROWTHM, 0x1);
	}
}

int GetArrendalGrowthManual(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int pThis;
	int CharID;
	int CType;
	int RaceID;
	int DisableGrowth = 0;

	unsigned int ItemID;
	unsigned int UpItemID = 0;
	unsigned int nID;
	int Inventory;
	int Slot;

	unsigned int ItemIDUse;
	unsigned int nIDUse;
	int InventoryUse;
	int SlotUse;

	unsigned int ItemDesc;

	int pItem;
	int pItemUse;
	int pNewItem;

	int pWeaponInfo = 0;
	float ArendaExpRate = 0.0;
	int IsEvolution = 0;
	int Level = 0;
	int UpLevel = 0;
	int Chance;
	int pAttribute;
	int AttributeType;
	int AttributeValue;

	int MeteriaLevel;
	int pExpScript;
	int pPAEXP = 0;
	__int64 PAEXP = 0;
	unsigned int PAEXPADD = 0;
	unsigned int MeteriaExp = 0;

	unsigned char NEWITEM[8] = {0};
	unsigned char STAMP[8] = {0};

	addrs = pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 1;

	pThis = pPlayer;
	addrs = pThis + 0x30;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pThis + 0x2C;
	CType = *(reinterpret_cast<unsigned int*>(addrs));
	RaceID = CType & 0xFF00;

	addrs = pSendData;
	ItemIDUse = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pSendData + 0x4;
	nIDUse = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pSendData + 0x8;
	InventoryUse = *(reinterpret_cast<char*>(addrs));
	addrs = pSendData + 0x9;
	SlotUse = *(reinterpret_cast<char*>(addrs));

	addrs = pSendData + 0xA;
	ItemID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pSendData + 0xE;
	nID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pSendData + 0x12;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = pSendData + 0x13;
	Slot = *(reinterpret_cast<char*>(addrs));

	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);
	pThis = pPlayer + 0xCC8;
	pItemUse = GetItem(pThis, InventoryUse, SlotUse);

	pWeaponInfo = GetItemBinScriptInfo(ItemID);
	addrs = pWeaponInfo + 0x27C;
	Level = *(reinterpret_cast<int*>(addrs));
	addrs = pWeaponInfo + 0x290;
	UpItemID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pWeaponInfo + 0x280;
	IsEvolution = *(reinterpret_cast<int*>(addrs));

	if (Level < 20) DisableGrowth = 1;
	if (RaceID != 0x4000) DisableGrowth = 1;

	// GetItemGR
	addrs = (int)ARRENDAL_GROWTHM + 0xA;
	tagItemInit(addrs);
	addrs = (int)ARRENDAL_GROWTHM + 0xA;
	EpochItemBaseGetItemGR(pItem, addrs);

	if (DisableGrowth)
	{
		addrs = (int)ARRENDAL_GROWTHM + 0x47;
		*(reinterpret_cast<unsigned int*>(addrs)) = nID;
		addrs = (int)ARRENDAL_GROWTHM + 0x4B;
		*(reinterpret_cast<int*>(addrs)) = Level;
		// Disable Growth
		addrs = (int)ARRENDAL_GROWTHM + 0x53;
		*(reinterpret_cast<int*>(addrs)) = 1;
		/**************** Fail ***************/
		pThis = pDynamic;
		SendPacket(pThis, 0x3007, (int)ARRENDAL_GROWTHM, 0x59);
		return 0;
	}

	// Create Packet
	addrs = (int)ARRENDAL_GROWTHM;
	*(reinterpret_cast<unsigned int*>(addrs)) = ItemIDUse;
	addrs = (int)ARRENDAL_GROWTHM + 0x4;
	*(reinterpret_cast<unsigned int*>(addrs)) = nIDUse;
	addrs = (int)ARRENDAL_GROWTHM + 0x8;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryUse;
	addrs = (int)ARRENDAL_GROWTHM + 0x9;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotUse;

	addrs = (int)ARRENDAL_GROWTHM + 0x47;
	*(reinterpret_cast<unsigned int*>(addrs)) = nID;
	addrs = (int)ARRENDAL_GROWTHM + 0x4B;
	*(reinterpret_cast<int*>(addrs)) = Level;
	// EXP Rate
	addrs = (int)ARRENDAL_GROWTHM + 0x4F;
	*(reinterpret_cast<float*>(addrs)) = 0;
	// Disable Growth
	addrs = (int)ARRENDAL_GROWTHM + 0x53;
	*(reinterpret_cast<int*>(addrs)) = 0;
	// Update Level: 1
	addrs = (int)ARRENDAL_GROWTHM + 0x57;
	*(reinterpret_cast<char*>(addrs)) = 0;
	// Success 1 / Fail 0
	addrs = (int)ARRENDAL_GROWTHM + 0x58;
	*(reinterpret_cast<char*>(addrs)) = 0;


	// Cal EXP
	MeteriaLevel = GetAttribute(pItemUse, 5);
	pExpScript = GetExpScript(MeteriaLevel);
	addrs = pExpScript + 0x18;
	MeteriaExp = *(reinterpret_cast<unsigned int*>(addrs));

	ItemDesc = GetAttribute(pItemUse, 1);
	if (ItemDesc != 0)
	{
		PAEXPADD = MeteriaExp * ItemDesc;
	}

	// Clean Meteria
	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemUse);

	pThis = pPlayer;
	ArendaExpRate = GetArrendalExpRate(pThis, ItemID);

	addrs = (int)ARRENDAL_GROWTHM + 0x4F;
	*(reinterpret_cast<float*>(addrs)) = ArendaExpRate;


	pThis = pPlayer;
	Chance = BioticBaseGetRandom(pThis, 1000000);
	if (Chance < 700000)
	{
		/************** Success **************/
		if (Level < 140)
		{
			pPAEXP = pPlayer + 0x2060;
			PAEXP = *(reinterpret_cast<__int64*>(pPAEXP));

			PAEXP += (__int64)PAEXPADD;
			*(reinterpret_cast<__int64*>(pPAEXP)) = PAEXP;

			// Level 20 - 139
			pThis = pPlayer;
			ArendaExpRate = GetArrendalExpRate(pThis, ItemID);
			if (ArendaExpRate >= 100.0)
			{
				if (IsEvolution == 0)
				{
					/*** Upgrade Arrendal ***/
					if (Level == 134)
					{
						// Set EXP 0.0%
						pPAEXP = pPlayer + 0x2060;
						*(reinterpret_cast<__int64*>(pPAEXP)) = 0;
					}
					addrs = (int)ITEMGR_ARRENDAL_GROWTHM + 0x4;
					tagItemInit(addrs);
					addrs = (int)ITEMGR_ARRENDAL_GROWTHM + 0x4;
					EpochItemBaseGetItemGR(pItem, addrs);

					pThis = pPlayer;
					UpgradeTrinityWeaponInfo(pThis, nID, ItemID, 0);

					pThis = pPlayer + 0xCC8;
					RemoveItem(pThis, pItem);

					addrs = (int)NEWITEM;
					*(reinterpret_cast<unsigned int*>(addrs)) = UpItemID;
					addrs = (int)NEWITEM + 0x4;
					*(reinterpret_cast<unsigned int*>(addrs)) = nID;

					pNewItem = CreateItem((int)NEWITEM, 1);

					GetItemStamp(pNewItem, (int)STAMP);

					pThis = pPlayer + 0xCC8;
					AddItem(pThis, pNewItem, Inventory, Slot, 0);

					pThis = pPlayer;
					TimerItemManager(pThis, pNewItem, (int)STAMP);

					// Setting Item Attribute
					pAttribute = (int)ITEMGR_ARRENDAL_GROWTHM + 0xC;
					for(int i = 0; i < 14; i++ )
					{
						addrs = (DWORD)pAttribute + (i * 3);
						AttributeType = *(reinterpret_cast<char*>(addrs));
						if (AttributeType != 0)
						{
							addrs = (DWORD)pAttribute + (i * 3) + 1;
							AttributeValue = *(reinterpret_cast<unsigned short*>(addrs));

							ItemOptionSetType(pNewItem, AttributeType, AttributeValue);
						}
					}

					// DBTask Packet
					addrs = (int)ITEMGR_ARRENDAL_GROWTHM;
					*(reinterpret_cast<unsigned int*>(addrs)) = CharID;
					addrs = (int)ITEMGR_ARRENDAL_GROWTHM + 0x4;
					tagItemInit(addrs);
					addrs = (int)ITEMGR_ARRENDAL_GROWTHM + 0x4;
					EpochItemBaseGetItemGR(pItem, addrs);

					// Send DB Packet
					SendPacketEX(0x7F23A0, 0x4A09, (int)ITEMGR_ARRENDAL_GROWTHM, 0x41);

					// Client
					UpLevel = Level + 1;

					addrs = (int)ARRENDAL_GROWTHM + 0xA;
					tagItemInit(addrs);
					addrs = (int)ARRENDAL_GROWTHM + 0xA;
					EpochItemBaseGetItemGR(pNewItem, addrs);

					addrs = (int)ARRENDAL_GROWTHM + 0x4B;
					*(reinterpret_cast<int*>(addrs)) = UpLevel;
					//ArendaExpRate = 0.0;
					addrs = (int)ARRENDAL_GROWTHM + 0x4F;
					*(reinterpret_cast<int*>(addrs)) = 0;
					// Update 1
					addrs = (int)ARRENDAL_GROWTHM + 0x57;
					*(reinterpret_cast<char*>(addrs)) = 1;
				}
				else
				{
					// Need Evolution Set EXP To 100% 
					pThis = pPlayer;
					SaveTrinityWeaponInfo(pThis, nID, ItemID, 1);

					pPAEXP = pPlayer + 0x2060;
					*(reinterpret_cast<__int64*>(pPAEXP)) = PAEXP;

					ArendaExpRate = 100.0;
					addrs = (int)ARRENDAL_GROWTHM + 0x4F;
					*(reinterpret_cast<float*>(addrs)) = ArendaExpRate;
				}
			}
			else
			{
				// Add EXP
				pThis = pPlayer;
				SaveTrinityWeaponInfo(pThis, nID, ItemID, 0);

				addrs = (int)ARRENDAL_GROWTHM + 0x4F;
				*(reinterpret_cast<float*>(addrs)) = ArendaExpRate;
			}
		}
		else
		{
			// Level 140+ Set EXP To 0% 
			pThis = pPlayer;
			SaveTrinityWeaponInfo(pThis, nID, ItemID, 1);

			pPAEXP = pPlayer + 0x2060;
			*(reinterpret_cast<__int64*>(pPAEXP)) = 0;

			//ArendaExpRate = 0.0;
			addrs = (int)ARRENDAL_GROWTHM + 0x4F;
			*(reinterpret_cast<float*>(addrs)) = 0;
		}

		// Success 1 / Fail 0
		addrs = (int)ARRENDAL_GROWTHM + 0x58;
		*(reinterpret_cast<char*>(addrs)) = 1;

		pThis = pDynamic;
		SendPacket(pThis, 0x3007, (int)ARRENDAL_GROWTHM, 0x59);
		return 0;
	}
	else
	{
		/**************** Fail ***************/
		// Success 1 / Fail 0
		addrs = (int)ARRENDAL_GROWTHM + 0x58;
		*(reinterpret_cast<char*>(addrs)) = 0;
		pThis = pDynamic;
		SendPacket(pThis, 0x3007, (int)ARRENDAL_GROWTHM, 0x59);
		return 0;
	}

	return 6;
}
