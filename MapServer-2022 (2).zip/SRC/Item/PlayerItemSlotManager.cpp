#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

unsigned char ITEM_BUFFER[3666] = {0};

// **** 2018 RCM_MAP_GETITEMOFCHARACTER 0xD102 ***************************************
void GetCharItemProc(int Inventory)
{
	//int Inventory;
	int Result;
	int pDynamic;

	__asm mov pDynamic,ecx

	Result = GetItemOfCharacter(pDynamic, Inventory);

	__asm mov eax, Result
}

int GetItemOfCharacter(int pDynamic, int Inventory)
{
	int addrs;
	int pPlayer;
	int pInventory;
	int pThis;
	int Slot = 0;
	int MaxSlot = 60;
	int SlotSize = 61;
	int pItem;
	int CheckpItem;
	int pItemGR;
	int CurItemCount = 0;
	int ClcItemCount = 0;
	int MaxAllowSlot;
	int PacketSize;

	memset(ITEM_BUFFER,0,sizeof(char)*3666);

	addrs = pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 6;

	pInventory = pPlayer + 0xCC8;

	// +0 Res
	addrs = (int)ITEM_BUFFER;
	*(reinterpret_cast<int*>(addrs)) = 0;

	// +1 Inventory
	addrs = (int)ITEM_BUFFER + 1;
	*(reinterpret_cast<int*>(addrs)) = Inventory;

	// +6 ItemGR Start
	pItemGR = (int)ITEM_BUFFER + 6;

	if (Inventory == 0) MaxSlot = 30;
	else MaxSlot = 60;

	for(Slot = 0; Slot < MaxSlot; Slot++ )
	{
		tagItemInit(pItemGR);
		pItemGR += SlotSize;
	}

	CurItemCount = GetCurCount(pInventory, Inventory);

	// +5 Item Count
	addrs = (int)ITEM_BUFFER + 5;
	*(reinterpret_cast<char*>(addrs)) = (char)CurItemCount;

	MaxAllowSlot = GetAllowCount(pInventory, Inventory);

	pItemGR = (int)ITEM_BUFFER + 6;

	for(Slot = 0; Slot < MaxAllowSlot; Slot++ )
	{
		pItem = GetItem(pInventory, Inventory, Slot);
		CheckpItem = RTDynamicCast(pItem, 0, 0x7E9778, 0x7E9794, 0);
		if (CheckpItem != 0)
		{
			addrs = pItemGR + (ClcItemCount * SlotSize);
			EpochItemBaseGetItemGR(pItem, addrs);
			ClcItemCount += 1;
		}
	}

	if (ClcItemCount != CurItemCount) return 14;

	PacketSize = (CurItemCount * SlotSize) + 6;
	pThis = pDynamic;
	SendPacket(pThis, 0xD102, (int)ITEM_BUFFER, PacketSize);
	return 0;
}

// **** 2021 Inventory Fix ***********************************************************
void InitItemPacket()
{
	int PacketType = 0;
	
	PacketType = 0xD101;
	CharStatusPacket((int)&PacketType);
	PacketType = 0xD109;
	CharStatusPacket((int)&PacketType);

	// Inventory 0
	PacketType = 0xD102;
	CharStatusPacket((int)&PacketType);
	// Inventory 1
	PacketType = 0xD102;
	CharStatusPacket((int)&PacketType);
	// Inventory 2
	PacketType = 0xD102;
	CharStatusPacket((int)&PacketType);
	// Inventory 3
	PacketType = 0xD102;
	CharStatusPacket((int)&PacketType);
	// Inventory 4
	PacketType = 0xD102;
	CharStatusPacket((int)&PacketType);
	// Inventory 5
	PacketType = 0xD102;
	CharStatusPacket((int)&PacketType);

	PacketType = 0xD103;
	CharStatusPacket((int)&PacketType);
	PacketType = 0xD104;
	CharStatusPacket((int)&PacketType);
	PacketType = 0xD107;
	CharStatusPacket((int)&PacketType);
	PacketType = 0xD108;
	CharStatusPacket((int)&PacketType);
	PacketType = 0xD10B;
	CharStatusPacket((int)&PacketType);
	PacketType = 0xD10C;
	CharStatusPacket((int)&PacketType);
	PacketType = 0xD10D;
	CharStatusPacket((int)&PacketType);
	PacketType = 0xD10F;
	CharStatusPacket((int)&PacketType);
	PacketType = 0xD111;
	CharStatusPacket((int)&PacketType);
	PacketType = 0xD113;
	CharStatusPacket((int)&PacketType);
	PacketType = 0xD114;
	CharStatusPacket((int)&PacketType);
	PacketType = 0xD10E;
	CharStatusPacket((int)&PacketType);
}
