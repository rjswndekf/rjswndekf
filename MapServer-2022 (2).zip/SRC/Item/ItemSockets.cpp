/*******************************************
 2021 RCM_MAP_X_SOCKET_REINFORCE 0x2310 / 0x2320 / 0x2328 Packet Struct
 00          +00
 30 75 28 00 +01 ItemID
 36 00 00 00 +05 nID
 01          +09 Inv
 02          +0A Slot
 FC 2A 4E 00 +0B ItemIDStore
 37 00 00 00 +0F nIDStore
 01          +13 InvStore
 03          +14 SlotStore
 01          +15 RES 1 Susses 0 Fail
 00          +16 SlocketSlot
 E2 80 D6 60 +17 Timestamp
 *******************************************/

#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

unsigned char SOCKET_REINFORCEA[27] = {0};
int SOCKET_REINFORCEA_ADDRS = (DWORD)SOCKET_REINFORCEA;

unsigned char SOCKET_REINFORCEB[27] = {0};
int SOCKET_REINFORCEB_ADDRS = (DWORD)SOCKET_REINFORCEB;

unsigned char SOCKET_REINFORCEC[27] = {0};
int SOCKET_REINFORCEC_ADDRS = (DWORD)SOCKET_REINFORCEC;

unsigned char MASK_TEMP[14] = {0};
int MASK_TEMP_ADDRS = (DWORD)MASK_TEMP;

unsigned char SOCKETINFO[50] = {0};
int pSocketInfo = (DWORD)SOCKETINFO;

unsigned char SOCKETSLOT_CLEAR[5] = {0};
int SOCKETSLOT_CLEAR_ADDRS = (DWORD)SOCKETSLOT_CLEAR;

unsigned char NOTICE_FO13[47] = {0};
int NOTICE_FO13_ADDRS = (DWORD)NOTICE_FO13;

unsigned char NOTICE_FO14[33] = {0};
int NOTICE_FO14_ADDRS = (DWORD)NOTICE_FO14;

// *** RCM_MAP_SOCKET_REINFORCE 0x2310 Patch *******************************/
void ItemSocketReinforce(int pDynamic, int pSendPacket)
{
	int addrs;
	int Result;
	int pSendData;

	pSendData = pSendPacket + 4;

	Result = GetItemSocket(pDynamic, pSendData);
	if (Result != 0)
	{
		addrs = (DWORD)SOCKET_REINFORCEA_ADDRS;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;

		SendPacketEX(pDynamic, 0x2310, SOCKET_REINFORCEA_ADDRS, 0x1);
	}
}

int GetItemSocket(int pDynamic, int pSendData)
{
	int i;
	int addrs;
	int pPlayer;
	int pThis;
	int Result;

	int ItemID;
	int nID;
	int Inventory;
	int Slot;

	int ItemIDStore;
	int nIDStore;
	int InventoryStore;
	int SlotStore;
	int SocketSlot;

	int CheckPointer;
	int IDCheck;

	int pItem;
	int pItemStore;
	int ItemTypeStore;
	int pItemScript;
	int pItemStoreScript;
	int pBinStoreSocketScript;
	int ItemType;
	int BooserType;
	int MaxSocketMask;
	int Mask;
	int CalVaule;
	int MaxSocketSlot;
	int MaxSlot;
	int CurSocketCount;
	int Offset;
	int ItemStoreSocketType;
	int InfoStoreSocketType;
	int ItemStoreOptionType;
	int InfoStoreOptionType;
	int InfoSlot;
	int ItemIDInfo;

	int ChanceRate;
	int CalRate;
	int Random;
	int ItemGrade;
	int ItemStoreGrade;
	int Timestamp;
	int Res;
	int AddTimer;

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 4;

	// SendData
	addrs = (DWORD)pSendData + 0x0;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x4;
	nID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x9;
	Slot = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0xA;
	ItemIDStore = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xE;
	nIDStore = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x12;
	InventoryStore = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x13;
	SlotStore = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x14;
	SocketSlot = *(reinterpret_cast<char*>(addrs));
	SocketSlot &= 0xFF;

	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);
	CheckPointer = RTDynamicCast(pItem, 0, 0x7E9778, 0x7E9794, 0);
	if (CheckPointer == 0) return 31;

	addrs = pItem + 0x20;
	IDCheck = *(reinterpret_cast<int*>(addrs));
	if (IDCheck != ItemID) return 55;

	addrs = pItem + 0x24;
	IDCheck = *(reinterpret_cast<int*>(addrs));
	if (IDCheck != nID) return 3;

	pThis = pPlayer + 0xCC8;
	pItemStore = GetItem(pThis, InventoryStore, SlotStore);
	CheckPointer = RTDynamicCast(pItemStore, 0, 0x7E9778, 0x7E9794, 0);
	if (CheckPointer == 0) return 31;

	addrs = pItemStore + 0x20;
	IDCheck = *(reinterpret_cast<int*>(addrs));
	if (IDCheck != ItemIDStore) return 55;

	addrs = pItemStore + 0x24;
	IDCheck = *(reinterpret_cast<int*>(addrs));
	if (IDCheck != nIDStore) return 3;

	// Check ItemType
	pThis = pItem;
	ItemType = GetAttribute(pThis, 0x0);

	pThis = pItemStore;
	ItemTypeStore = GetAttribute(pThis, 0x0);

	pThis = pItemStore;
	BooserType = GetAttribute(pThis, 0x78);

	// Weapon
	if (((ItemType > 0) && (ItemType < 13)) || (ItemType == 234) || (ItemType == 235))
	{
		if ((ItemTypeStore == 171) || (ItemTypeStore == 172))
		{
			if (BooserType != 1) return 35;
		}
		else
		{
			return 35;
		}

	}
	// Armor
	else if (((ItemType > 12) && (ItemType < 18)) || ((ItemType > 227) && (ItemType < 233)))
	{
		if ((ItemTypeStore == 174) || (ItemTypeStore == 175))
		{
			if (BooserType != 2) return 35;
		}
		else
		{
			return 35;
		}
	}
	// shield
	else if (ItemType == 18)
	{
		if (ItemTypeStore == 178)
		{
			if (BooserType != 3) return 35;
		}
		else
		{
			return 35;
		}
	}
	// Guarder
	else if (ItemType == 253)
	{
		if (ItemTypeStore == 181)
		{
			if (BooserType != 4) return 35;
		}
		else
		{
			return 35;
		}
	}
	// Other
	else return 33;

	// Check Slot
	addrs = pItem + 0x1C;
	pItemScript = *(reinterpret_cast<int*>(addrs));
	if (pItemScript == 0) return 4;

	addrs = pItemScript + 0x274;
	MaxSocketMask = *(reinterpret_cast<int*>(addrs));
	Mask = 10000;
	for(i = 4; i > -1; i--)
	{
		CalVaule = MaxSocketMask / Mask;
		addrs = MASK_TEMP_ADDRS + (i * 4);
		*(reinterpret_cast<int*>(addrs)) = CalVaule;

		CalVaule = MaxSocketMask % Mask;
		MaxSocketMask = CalVaule;

		CalVaule = Mask / 10;
		Mask = CalVaule;
	}
	
	MaxSocketSlot = ItemOptionGetType(pItem, 0x4B);
	if ((MaxSocketSlot > 4) && (MaxSocketSlot < 0)) return 53;

	addrs = MASK_TEMP_ADDRS + ((MaxSocketSlot - 1) * 4);
	MaxSlot = *(reinterpret_cast<int*>(addrs));

	if (SocketSlot >= MaxSlot ) return 47;

	// Check SocketInfo
	addrs = pItem + 0x24;
	nID = *(reinterpret_cast<int*>(addrs));

	pThis = pPlayer + 0x1E40;
	Result = GetSocketInfo(pThis, nID, pSocketInfo);
	if (Result == 0) return 38;

	addrs = pItemStore + 0x1C;
	pItemStoreScript = *(reinterpret_cast<int*>(addrs));
	CheckPointer = RTDynamicCast(pItemStoreScript, 0, 0x7E97C4, 0x7E99F4, 0);
	if (CheckPointer == 0) return 4;

	addrs = pSocketInfo + 0x4;
	CurSocketCount = *(reinterpret_cast<char*>(addrs));
	CurSocketCount &= 0xFF;

	Offset = pSocketInfo + 5;
	for(i = 0; i < CurSocketCount; i++)
	{
		addrs = Offset + (i * 9);
		InfoSlot = *(reinterpret_cast<char*>(addrs));
		InfoSlot &= 0xFF;
		if (InfoSlot != SocketSlot)
		{
			addrs = Offset + 1 + (i * 9);
			ItemIDInfo = *(reinterpret_cast<int*>(addrs));
			pBinStoreSocketScript = GetItemBinScriptInfo(ItemIDInfo);
			CheckPointer = RTDynamicCast(pBinStoreSocketScript, 0, 0x7E97C4, 0x7E99F4, 0);
			if (CheckPointer == 0) return 4;
			
			addrs = pItemStoreScript + 0x284;
			ItemStoreSocketType = *(reinterpret_cast<int*>(addrs));
			addrs = pBinStoreSocketScript + 0x284;
			InfoStoreSocketType = *(reinterpret_cast<int*>(addrs));
			if ((ItemStoreSocketType == 2) && (InfoStoreSocketType == 2))
			{
				addrs = pItemStoreScript + 0x288;
				ItemStoreOptionType = *(reinterpret_cast<int*>(addrs));
				addrs = pBinStoreSocketScript + 0x288;
				InfoStoreOptionType = *(reinterpret_cast<int*>(addrs));
				pThis = pPlayer + 0x1E40;
				Result = CheckSocketOptionType(pThis, ItemStoreOptionType, InfoStoreOptionType);
				if (Result == 1) return 56;
			}
		}
	}

	Offset = pSocketInfo + 5;
	for(i = 0; i < CurSocketCount; i++)
	{
		addrs = Offset + (i * 9);
		InfoSlot = *(reinterpret_cast<char*>(addrs));
		InfoSlot &= 0xFF;
		if (InfoSlot == SocketSlot)
		{
			addrs = Offset + 1 + (i * 9);
			ItemIDInfo = *(reinterpret_cast<int*>(addrs));
			if (ItemIDInfo == 0xFFFFFFFF) return 46;

			pThis = pPlayer + 0x1E40;
			Result = ClearSocketSlot(pThis, nID, SocketSlot);
			if (Result == 0) return 44;

			addrs = SOCKETSLOT_CLEAR_ADDRS;
			*(reinterpret_cast<int*>(addrs)) = nID;
			addrs = SOCKETSLOT_CLEAR_ADDRS + 4;
			*(reinterpret_cast<char*>(addrs)) = (char)SocketSlot;
			pThis = pDynamic;
			SendPacketEX(pThis, 0x2319, SOCKETSLOT_CLEAR_ADDRS, 0x5);
			
			// NOTICE 0xFO14
			addrs = NOTICE_FO14_ADDRS + 0x15;
			*(reinterpret_cast<char*>(addrs)) = 1;
			addrs = NOTICE_FO14_ADDRS + 0x16;
			*(reinterpret_cast<int*>(addrs)) = nID;
			addrs = NOTICE_FO14_ADDRS + 0x1A;
			*(reinterpret_cast<int*>(addrs)) = ItemID;
			addrs = NOTICE_FO14_ADDRS + 0x20;
			*(reinterpret_cast<char*>(addrs)) = (char)SocketSlot;

			pThis = pPlayer;
			PlayerSendNotice(pThis, 0xF014, NOTICE_FO14_ADDRS, 0x21, 0x15);
		}
		else
		{
			addrs = Offset + 1 + (i * 9);
			ItemIDInfo = *(reinterpret_cast<int*>(addrs));
			if (ItemIDInfo != 0xFFFFFFFF)
			{
				pBinStoreSocketScript = GetItemBinScriptInfo(ItemIDInfo);
				CheckPointer = RTDynamicCast(pBinStoreSocketScript, 0, 0x7E97C4, 0x7E99F4, 0);
				if (CheckPointer == 0) return 4;

				addrs = pItemStoreScript + 0x284;
				ItemStoreSocketType = *(reinterpret_cast<int*>(addrs));
				addrs = pBinStoreSocketScript + 0x284;
				InfoStoreSocketType = *(reinterpret_cast<int*>(addrs));
				if (InfoStoreSocketType == ItemStoreSocketType)
				{
					addrs = pItemStoreScript + 0x288;
					ItemStoreOptionType = *(reinterpret_cast<int*>(addrs));
					addrs = pBinStoreSocketScript + 0x288;
					InfoStoreOptionType = *(reinterpret_cast<int*>(addrs));
					if (InfoStoreOptionType == ItemStoreOptionType) return 39;
				}
			}
		}
	}

	// Client Packet
	addrs = SOCKET_REINFORCEA_ADDRS;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = SOCKET_REINFORCEA_ADDRS + 0x1;
	*(reinterpret_cast<int*>(addrs)) = ItemID;
	addrs = SOCKET_REINFORCEA_ADDRS + 0x5;
	*(reinterpret_cast<int*>(addrs)) = nID;
	addrs = SOCKET_REINFORCEA_ADDRS + 0x9;
	*(reinterpret_cast<char*>(addrs)) = (char)Inventory;
	addrs = SOCKET_REINFORCEA_ADDRS + 0xA;
	*(reinterpret_cast<char*>(addrs)) = (char)Slot;

	addrs = SOCKET_REINFORCEA_ADDRS + 0xB;
	*(reinterpret_cast<int*>(addrs)) = ItemIDStore;
	addrs = SOCKET_REINFORCEA_ADDRS + 0xF;
	*(reinterpret_cast<int*>(addrs)) = nIDStore;
	addrs = SOCKET_REINFORCEA_ADDRS + 0x13;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryStore;
	addrs = SOCKET_REINFORCEA_ADDRS + 0x14;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotStore;

	addrs = SOCKET_REINFORCEA_ADDRS + 0x16;
	*(reinterpret_cast<char*>(addrs)) = (char)SocketSlot;

	// Chance Rate
	addrs = pItemStoreScript + 0x27C;
	ChanceRate = *(reinterpret_cast<int*>(addrs));

	pThis = pItem;
	ItemGrade = GetAttribute(pThis, 0x79);

	pThis = pItemStore;
	ItemStoreGrade = GetAttribute(pThis, 0x79);

	if (ItemGrade < ItemStoreGrade)
	{
		ItemStoreGrade -= ItemGrade;
		CalRate = (ItemStoreGrade * ChanceRate) / 10;
		ChanceRate = CalRate;
	}

	pThis = pPlayer;
	Random = BioticBaseGetRandom(pThis, 1000000);

	if (ChanceRate > Random)
	{
		Timestamp = GetCurSeconds();
	
		addrs = pItem + 0x24;
		nID = *(reinterpret_cast<int*>(addrs));
		
		addrs = pItemStore + 0x20;
		ItemIDStore = *(reinterpret_cast<int*>(addrs));

		addrs = (DWORD)pSendData + 0x14;
		SocketSlot = *(reinterpret_cast<char*>(addrs));
		SocketSlot &= 0xFF;

		pThis = pPlayer + 0x1E40;
		Result = SocketSlotAdd(pThis, nID, SocketSlot, ItemIDStore, Timestamp);
		if (Result == 0) return 44;
		
		Res = 1;
		addrs = SOCKET_REINFORCEA_ADDRS + 0x15;
		*(reinterpret_cast<char*>(addrs)) = (char)Res;
		addrs = SOCKET_REINFORCEA_ADDRS + 0x17;
		*(reinterpret_cast<int*>(addrs)) = Timestamp;
	}
	else
	{
		addrs = pItemStoreScript + 0x280;
		ChanceRate = *(reinterpret_cast<int*>(addrs));

		pThis = pPlayer;
		Random = BioticBaseGetRandom(pThis, 1000000);
		
		Timestamp = 0;
		
		if (ChanceRate > Random)
		{
			addrs = pItem + 0x24;
			nID = *(reinterpret_cast<int*>(addrs));

			addrs = (DWORD)pSendData + 0x14;
			SocketSlot = *(reinterpret_cast<char*>(addrs));
			SocketSlot &= 0xFF;

			pThis = pPlayer + 0x1E40;
			Result = SocketSlotAdd(pThis, nID, SocketSlot, 0xFFFFFFFF, 0);
			if (Result == 0)
			{
				Res = 2;
				addrs = SOCKET_REINFORCEA_ADDRS + 0x15;
				*(reinterpret_cast<char*>(addrs)) = (char)Res;
				addrs = SOCKET_REINFORCEA_ADDRS + 0x17;
				*(reinterpret_cast<int*>(addrs)) = Timestamp;
			}
			else
			{
				Res = 3;
				addrs = SOCKET_REINFORCEA_ADDRS + 0x15;
				*(reinterpret_cast<char*>(addrs)) = (char)Res;
				addrs = SOCKET_REINFORCEA_ADDRS + 0x17;
				*(reinterpret_cast<int*>(addrs)) = Timestamp;
			}
		}
		else
		{
			Res = 2;
			addrs = SOCKET_REINFORCEA_ADDRS + 0x15;
			*(reinterpret_cast<char*>(addrs)) = (char)Res;
			addrs = SOCKET_REINFORCEA_ADDRS + 0x17;
			*(reinterpret_cast<int*>(addrs)) = Timestamp;
		}
	}

	if (Timestamp != 0)
	{
		addrs = pItemStoreScript + 0x278;
		AddTimer = *(reinterpret_cast<int*>(addrs));
		Timestamp += AddTimer;
	}

	// Remove Store
	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemStore);

	// NOTICE 0xFO13
	addrs = NOTICE_FO13_ADDRS + 0x15;
	*(reinterpret_cast<int*>(addrs)) = nID;
	addrs = NOTICE_FO13_ADDRS + 0x19;
	*(reinterpret_cast<int*>(addrs)) = ItemID;
	addrs = NOTICE_FO13_ADDRS + 0x1F;
	*(reinterpret_cast<int*>(addrs)) = nIDStore;
	addrs = NOTICE_FO13_ADDRS + 0x23;
	*(reinterpret_cast<int*>(addrs)) = ItemIDStore;
	addrs = NOTICE_FO13_ADDRS + 0x29;
	*(reinterpret_cast<char*>(addrs)) = (char)Res;
	addrs = NOTICE_FO13_ADDRS + 0x2A;
	*(reinterpret_cast<char*>(addrs)) = (char)SocketSlot;
	addrs = NOTICE_FO13_ADDRS + 0x2B;
	*(reinterpret_cast<int*>(addrs)) = Timestamp;

	pThis = pPlayer;
	PlayerSendNotice(pThis, 0xF013, NOTICE_FO13_ADDRS, 0x2F, 0x15);

	// Send Client Packet
	pThis = pDynamic;
	SendPacketEX(pThis, 0x2310, SOCKET_REINFORCEA_ADDRS, 0x1B);

	return 0;
}

// *** RCM_MAP_TRANS_SOCKET_REINFORCE 0x2320 Patch *******************************/
void TransItemSocketReinforce(int pDynamic, int pSendPacket)
{
	int addrs;
	int Result;
	int pSendData;

	pSendData = pSendPacket + 4;

	Result = GetTransItemSocket(pDynamic, pSendData);
	if (Result != 0)
	{
		addrs = (DWORD)SOCKET_REINFORCEB_ADDRS;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;

		SendPacketEX(pDynamic, 0x2320, SOCKET_REINFORCEB_ADDRS, 0x1);
	}
}

int GetTransItemSocket(int pDynamic, int pSendData)
{
	int i;
	int addrs;
	int pPlayer;
	int pThis;
	int Result;

	int ItemID;
	int nID;
	int Inventory;
	int Slot;

	int ItemIDStore;
	int nIDStore;
	int InventoryStore;
	int SlotStore;
	int SocketSlot;

	int CheckPointer;
	int IDCheck;

	int pItem;
	int pItemStore;
	int ItemTypeStore;
	int pItemScript;
	int pItemStoreScript;
	int pBinStoreSocketScript;
	int ItemType;
	int BooserType;
	int MaxSocketMask;
	int Mask;
	int CalVaule;
	int MaxSocketSlot;
	int MaxSlot;
	int CurSocketCount;
	int Offset;
	int ItemStoreSocketType;
	int InfoStoreSocketType;
	int ItemStoreOptionType;
	int InfoStoreOptionType;
	int InfoSlot;
	int ItemIDInfo;

	int ChanceRate;
	int CalRate;
	int Random;
	int ItemGrade;
	int ItemStoreGrade;
	int Timestamp;
	int Res;
	int AddTimer;

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 4;

	// SendData
	addrs = (DWORD)pSendData + 0x0;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x4;
	nID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x9;
	Slot = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0xA;
	ItemIDStore = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xE;
	nIDStore = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x12;
	InventoryStore = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x13;
	SlotStore = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x14;
	SocketSlot = *(reinterpret_cast<char*>(addrs));
	SocketSlot &= 0xFF;

	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);
	CheckPointer = RTDynamicCast(pItem, 0, 0x7E9778, 0x7E9794, 0);
	if (CheckPointer == 0) return 31;

	addrs = pItem + 0x20;
	IDCheck = *(reinterpret_cast<int*>(addrs));
	if (IDCheck != ItemID) return 55;

	addrs = pItem + 0x24;
	IDCheck = *(reinterpret_cast<int*>(addrs));
	if (IDCheck != nID) return 3;

	pThis = pPlayer + 0xCC8;
	pItemStore = GetItem(pThis, InventoryStore, SlotStore);
	CheckPointer = RTDynamicCast(pItemStore, 0, 0x7E9778, 0x7E9794, 0);
	if (CheckPointer == 0) return 31;

	addrs = pItemStore + 0x20;
	IDCheck = *(reinterpret_cast<int*>(addrs));
	if (IDCheck != ItemIDStore) return 55;

	addrs = pItemStore + 0x24;
	IDCheck = *(reinterpret_cast<int*>(addrs));
	if (IDCheck != nIDStore) return 3;

	// Check ItemType
	pThis = pItem;
	ItemType = GetAttribute(pThis, 0x0);

	pThis = pItemStore;
	ItemTypeStore = GetAttribute(pThis, 0x0);

	pThis = pItemStore;
	BooserType = GetAttribute(pThis, 0x78);

	// Weapon
	if (((ItemType > 0) && (ItemType < 13)) || (ItemType == 234) || (ItemType == 235))
	{
		if ((ItemTypeStore == 171) || (ItemTypeStore == 172) || (ItemTypeStore == 173))
		{
			if (BooserType != 1) return 35;
		}
		else
		{
			return 35;
		}
	}
	// Armor
	else if (((ItemType > 12) && (ItemType < 18)) || ((ItemType > 227) && (ItemType < 233)))
	{
		if ((ItemTypeStore == 174) || (ItemTypeStore == 175) || (ItemTypeStore == 176))
		{
			if (BooserType != 2) return 35;
		}
		else
		{
			return 35;
		}
	}
	// shield
	else if (ItemType == 18)
	{
		if (ItemTypeStore == 179)
		{
			if (BooserType != 3) return 35;
		}
		else
		{
			return 35;
		}
	}
	// Guarder
	else if (ItemType == 253)
	{
		if ((ItemTypeStore == 181) || (ItemTypeStore == 182))
		{
			if (BooserType != 4) return 35;
		}
		else
		{
			return 35;
		}
	}
	// Other
	else return 33;

	// Check Slot
	addrs = pItem + 0x1C;
	pItemScript = *(reinterpret_cast<int*>(addrs));
	if (pItemScript == 0) return 4;

	addrs = pItemScript + 0x274;
	MaxSocketMask = *(reinterpret_cast<int*>(addrs));
	Mask = 10000;
	for(i = 4; i > -1; i--)
	{
		CalVaule = MaxSocketMask / Mask;
		addrs = MASK_TEMP_ADDRS + (i * 4);
		*(reinterpret_cast<int*>(addrs)) = CalVaule;

		CalVaule = MaxSocketMask % Mask;
		MaxSocketMask = CalVaule;

		CalVaule = Mask / 10;
		Mask = CalVaule;
	}
	
	MaxSocketSlot = ItemOptionGetType(pItem, 0x4B);
	if ((MaxSocketSlot > 4) && (MaxSocketSlot < 0)) return 53;

	addrs = MASK_TEMP_ADDRS + ((MaxSocketSlot - 1) * 4);
	MaxSlot = *(reinterpret_cast<int*>(addrs));

	if (SocketSlot >= MaxSlot ) return 47;

	// Check SocketInfo
	addrs = pItem + 0x24;
	nID = *(reinterpret_cast<int*>(addrs));

	pThis = pPlayer + 0x1E40;
	Result = GetSocketInfo(pThis, nID, pSocketInfo);
	if (Result == 0) return 38;

	addrs = pItemStore + 0x1C;
	pItemStoreScript = *(reinterpret_cast<int*>(addrs));
	CheckPointer = RTDynamicCast(pItemStoreScript, 0, 0x7E97C4, 0x7E99F4, 0);
	if (CheckPointer == 0) return 4;

	addrs = pSocketInfo + 0x4;
	CurSocketCount = *(reinterpret_cast<char*>(addrs));
	CurSocketCount &= 0xFF;

	Offset = pSocketInfo + 5;
	for(i = 0; i < CurSocketCount; i++)
	{
		addrs = Offset + (i * 9);
		InfoSlot = *(reinterpret_cast<char*>(addrs));
		InfoSlot &= 0xFF;
		if (InfoSlot != SocketSlot)
		{
			addrs = Offset + 1 + (i * 9);
			ItemIDInfo = *(reinterpret_cast<int*>(addrs));
			pBinStoreSocketScript = GetItemBinScriptInfo(ItemIDInfo);
			CheckPointer = RTDynamicCast(pBinStoreSocketScript, 0, 0x7E97C4, 0x7E99F4, 0);
			if (CheckPointer == 0) return 4;
			
			addrs = pItemStoreScript + 0x284;
			ItemStoreSocketType = *(reinterpret_cast<int*>(addrs));
			addrs = pBinStoreSocketScript + 0x284;
			InfoStoreSocketType = *(reinterpret_cast<int*>(addrs));
			if ((ItemStoreSocketType == 2) && (InfoStoreSocketType == 2))
			{
				addrs = pItemStoreScript + 0x288;
				ItemStoreOptionType = *(reinterpret_cast<int*>(addrs));
				addrs = pBinStoreSocketScript + 0x288;
				InfoStoreOptionType = *(reinterpret_cast<int*>(addrs));
				pThis = pPlayer + 0x1E40;
				Result = CheckSocketOptionType(pThis, ItemStoreOptionType, InfoStoreOptionType);
				if (Result == 1) return 56;
			}
		}
	}

	Offset = pSocketInfo + 5;
	for(i = 0; i < CurSocketCount; i++)
	{
		addrs = Offset + (i * 9);
		InfoSlot = *(reinterpret_cast<char*>(addrs));
		InfoSlot &= 0xFF;
		if (InfoSlot == SocketSlot)
		{
			addrs = Offset + 1 + (i * 9);
			ItemIDInfo = *(reinterpret_cast<int*>(addrs));
			if (ItemIDInfo == 0xFFFFFFFF) return 46;

			pThis = pPlayer + 0x1E40;
			Result = ClearSocketSlot(pThis, nID, SocketSlot);
			if (Result == 0) return 44;

			addrs = SOCKETSLOT_CLEAR_ADDRS;
			*(reinterpret_cast<int*>(addrs)) = nID;
			addrs = SOCKETSLOT_CLEAR_ADDRS + 4;
			*(reinterpret_cast<char*>(addrs)) = (char)SocketSlot;
			pThis = pDynamic;
			SendPacketEX(pThis, 0x2319, SOCKETSLOT_CLEAR_ADDRS, 0x5);
			
			// NOTICE 0xFO14
			addrs = NOTICE_FO14_ADDRS + 0x15;
			*(reinterpret_cast<char*>(addrs)) = 1;
			addrs = NOTICE_FO14_ADDRS + 0x16;
			*(reinterpret_cast<int*>(addrs)) = nID;
			addrs = NOTICE_FO14_ADDRS + 0x1A;
			*(reinterpret_cast<int*>(addrs)) = ItemID;
			addrs = NOTICE_FO14_ADDRS + 0x20;
			*(reinterpret_cast<char*>(addrs)) = (char)SocketSlot;

			pThis = pPlayer;
			PlayerSendNotice(pThis, 0xF014, NOTICE_FO14_ADDRS, 0x21, 0x15);
		}
		else
		{
			addrs = Offset + 1 + (i * 9);
			ItemIDInfo = *(reinterpret_cast<int*>(addrs));
			if (ItemIDInfo != 0xFFFFFFFF)
			{
				pBinStoreSocketScript = GetItemBinScriptInfo(ItemIDInfo);
				CheckPointer = RTDynamicCast(pBinStoreSocketScript, 0, 0x7E97C4, 0x7E99F4, 0);
				if (CheckPointer == 0) return 4;

				addrs = pItemStoreScript + 0x284;
				ItemStoreSocketType = *(reinterpret_cast<int*>(addrs));
				addrs = pBinStoreSocketScript + 0x284;
				InfoStoreSocketType = *(reinterpret_cast<int*>(addrs));
				if (InfoStoreSocketType == ItemStoreSocketType)
				{
					addrs = pItemStoreScript + 0x288;
					ItemStoreOptionType = *(reinterpret_cast<int*>(addrs));
					addrs = pBinStoreSocketScript + 0x288;
					InfoStoreOptionType = *(reinterpret_cast<int*>(addrs));
					if (InfoStoreOptionType == ItemStoreOptionType) return 39;
				}
			}
		}
	}

	// Client Packet
	addrs = SOCKET_REINFORCEB_ADDRS;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = SOCKET_REINFORCEB_ADDRS + 0x1;
	*(reinterpret_cast<int*>(addrs)) = ItemID;
	addrs = SOCKET_REINFORCEB_ADDRS + 0x5;
	*(reinterpret_cast<int*>(addrs)) = nID;
	addrs = SOCKET_REINFORCEB_ADDRS + 0x9;
	*(reinterpret_cast<char*>(addrs)) = (char)Inventory;
	addrs = SOCKET_REINFORCEB_ADDRS + 0xA;
	*(reinterpret_cast<char*>(addrs)) = (char)Slot;

	addrs = SOCKET_REINFORCEB_ADDRS + 0xB;
	*(reinterpret_cast<int*>(addrs)) = ItemIDStore;
	addrs = SOCKET_REINFORCEB_ADDRS + 0xF;
	*(reinterpret_cast<int*>(addrs)) = nIDStore;
	addrs = SOCKET_REINFORCEB_ADDRS + 0x13;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryStore;
	addrs = SOCKET_REINFORCEB_ADDRS + 0x14;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotStore;

	addrs = SOCKET_REINFORCEB_ADDRS + 0x16;
	*(reinterpret_cast<char*>(addrs)) = (char)SocketSlot;

	// Chance Rate
	addrs = pItemStoreScript + 0x27C;
	ChanceRate = *(reinterpret_cast<int*>(addrs));

	pThis = pItem;
	ItemGrade = GetAttribute(pThis, 0x79);

	pThis = pItemStore;
	ItemStoreGrade = GetAttribute(pThis, 0x79);

	if (ItemGrade < ItemStoreGrade)
	{
		ItemStoreGrade -= ItemGrade;
		CalRate = (ItemStoreGrade * ChanceRate) / 10;
		ChanceRate = CalRate;
	}

	pThis = pPlayer;
	Random = BioticBaseGetRandom(pThis, 1000000);

	if (ChanceRate > Random)
	{
		Timestamp = GetCurSeconds();
	
		addrs = pItem + 0x24;
		nID = *(reinterpret_cast<int*>(addrs));
		
		addrs = pItemStore + 0x20;
		ItemIDStore = *(reinterpret_cast<int*>(addrs));

		addrs = (DWORD)pSendData + 0x14;
		SocketSlot = *(reinterpret_cast<char*>(addrs));
		SocketSlot &= 0xFF;

		pThis = pPlayer + 0x1E40;
		Result = SocketSlotAdd(pThis, nID, SocketSlot, ItemIDStore, Timestamp);
		if (Result == 0) return 44;
		
		Res = 1;
		addrs = SOCKET_REINFORCEB_ADDRS + 0x15;
		*(reinterpret_cast<char*>(addrs)) = (char)Res;
		addrs = SOCKET_REINFORCEB_ADDRS + 0x17;
		*(reinterpret_cast<int*>(addrs)) = Timestamp;
	}
	else
	{
		addrs = pItemStoreScript + 0x280;
		ChanceRate = *(reinterpret_cast<int*>(addrs));

		pThis = pPlayer;
		Random = BioticBaseGetRandom(pThis, 1000000);
		
		Timestamp = 0;
		
		if (ChanceRate > Random)
		{
			addrs = pItem + 0x24;
			nID = *(reinterpret_cast<int*>(addrs));

			addrs = (DWORD)pSendData + 0x14;
			SocketSlot = *(reinterpret_cast<char*>(addrs));
			SocketSlot &= 0xFF;

			pThis = pPlayer + 0x1E40;
			Result = SocketSlotAdd(pThis, nID, SocketSlot, 0xFFFFFFFF, 0);
			if (Result == 0)
			{
				Res = 2;
				addrs = SOCKET_REINFORCEB_ADDRS + 0x15;
				*(reinterpret_cast<char*>(addrs)) = (char)Res;
				addrs = SOCKET_REINFORCEB_ADDRS + 0x17;
				*(reinterpret_cast<int*>(addrs)) = Timestamp;
			}
			else
			{
				Res = 3;
				addrs = SOCKET_REINFORCEB_ADDRS + 0x15;
				*(reinterpret_cast<char*>(addrs)) = (char)Res;
				addrs = SOCKET_REINFORCEB_ADDRS + 0x17;
				*(reinterpret_cast<int*>(addrs)) = Timestamp;
			}
		}
		else
		{
			Res = 2;
			addrs = SOCKET_REINFORCEB_ADDRS + 0x15;
			*(reinterpret_cast<char*>(addrs)) = (char)Res;
			addrs = SOCKET_REINFORCEB_ADDRS + 0x17;
			*(reinterpret_cast<int*>(addrs)) = Timestamp;
		}
	}

	if (Timestamp != 0)
	{
		addrs = pItemStoreScript + 0x278;
		AddTimer = *(reinterpret_cast<int*>(addrs));
		Timestamp += AddTimer;
	}

	// Remove Store
	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemStore);

	// NOTICE 0xFO13
	addrs = NOTICE_FO13_ADDRS + 0x15;
	*(reinterpret_cast<int*>(addrs)) = nID;
	addrs = NOTICE_FO13_ADDRS + 0x19;
	*(reinterpret_cast<int*>(addrs)) = ItemID;
	addrs = NOTICE_FO13_ADDRS + 0x1F;
	*(reinterpret_cast<int*>(addrs)) = nIDStore;
	addrs = NOTICE_FO13_ADDRS + 0x23;
	*(reinterpret_cast<int*>(addrs)) = ItemIDStore;
	addrs = NOTICE_FO13_ADDRS + 0x29;
	*(reinterpret_cast<char*>(addrs)) = (char)Res;
	addrs = NOTICE_FO13_ADDRS + 0x2A;
	*(reinterpret_cast<char*>(addrs)) = (char)SocketSlot;
	addrs = NOTICE_FO13_ADDRS + 0x2B;
	*(reinterpret_cast<int*>(addrs)) = Timestamp;

	pThis = pPlayer;
	PlayerSendNotice(pThis, 0xF013, NOTICE_FO13_ADDRS, 0x2F, 0x15);

	// Send Client Packet
	pThis = pDynamic;
	SendPacketEX(pThis, 0x2320, SOCKET_REINFORCEB_ADDRS, 0x1B);

	return 0;
}

// *** RCM_MAP_ACCESSORY_SOCKET_REINFORCE 0x2328 Patch *******************************/
void AccessorySocketReinforce(int pDynamic, int pSendPacket)
{
	int addrs;
	int Result;
	int pSendData;

	pSendData = pSendPacket + 4;

	Result = GetAccessorySocket(pDynamic, pSendData);
	if (Result != 0)
	{
		addrs = (DWORD)SOCKET_REINFORCEC_ADDRS;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;

		SendPacketEX(pDynamic, 0x2328, SOCKET_REINFORCEC_ADDRS, 0x1);
	}
}

int GetAccessorySocket(int pDynamic, int pSendData)
{
	int i;
	int addrs;
	int pPlayer;
	int pThis;
	int Result;

	int ItemID;
	int nID;
	int Inventory;
	int Slot;

	int ItemIDStore;
	int nIDStore;
	int InventoryStore;
	int SlotStore;
	int SocketSlot;

	int CheckPointer;
	int IDCheck;

	int pItem;
	int pItemStore;
	int ItemTypeStore;
	int pItemScript;
	int pItemStoreScript;
	int pBinStoreSocketScript;
	int ItemType;
	int BooserType;
	int MaxSocketSlot;
	int MaxSlot;
	int CurSocketCount;
	int Offset;
	int ItemStoreSocketType;
	int InfoStoreSocketType;
	int ItemStoreOptionType;
	int InfoStoreOptionType;
	int InfoSlot;
	int ItemIDInfo;

	int ChanceRate;
	int CalRate;
	int Random;
	int ItemGrade;
	int ItemStoreGrade;
	int Timestamp;
	int Res;
	int AddTimer;

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 4;

	// SendData
	addrs = (DWORD)pSendData + 0x0;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x4;
	nID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x9;
	Slot = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0xA;
	ItemIDStore = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xE;
	nIDStore = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x12;
	InventoryStore = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x13;
	SlotStore = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x14;
	SocketSlot = *(reinterpret_cast<char*>(addrs));
	SocketSlot &= 0xFF;

	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);
	CheckPointer = RTDynamicCast(pItem, 0, 0x7E9778, 0x7E9794, 0);
	if (CheckPointer == 0) return 31;

	addrs = pItem + 0x20;
	IDCheck = *(reinterpret_cast<int*>(addrs));
	if (IDCheck != ItemID) return 55;

	addrs = pItem + 0x24;
	IDCheck = *(reinterpret_cast<int*>(addrs));
	if (IDCheck != nID) return 3;

	pThis = pPlayer + 0xCC8;
	pItemStore = GetItem(pThis, InventoryStore, SlotStore);
	CheckPointer = RTDynamicCast(pItemStore, 0, 0x7E9778, 0x7E9794, 0);
	if (CheckPointer == 0) return 31;

	addrs = pItemStore + 0x20;
	IDCheck = *(reinterpret_cast<int*>(addrs));
	if (IDCheck != ItemIDStore) return 55;

	addrs = pItemStore + 0x24;
	IDCheck = *(reinterpret_cast<int*>(addrs));
	if (IDCheck != nIDStore) return 3;

	// Check ItemType
	pThis = pItem;
	ItemType = GetAttribute(pThis, 0x0);

	pThis = pItemStore;
	ItemTypeStore = GetAttribute(pThis, 0x0);

	pThis = pItemStore;
	BooserType = GetAttribute(pThis, 0x78);

	// Accessory
	if (ItemType == 95)
	{
		if (ItemTypeStore == 275)
		{
			if (BooserType != 1) return 35;
		}
		else
		{
			return 35;
		}
	}
	// Other
	else return 33;

	// Check Slot
	addrs = pItem + 0x1C;
	pItemScript = *(reinterpret_cast<int*>(addrs));
	if (pItemScript == 0) return 4;

	MaxSocketSlot = ItemOptionGetType(pItem, 0x4B);
	if ((MaxSocketSlot > 2) && (MaxSocketSlot < 0)) return 53;

	MaxSlot = 1;
	if (SocketSlot > MaxSlot ) return 47;

	// Check SocketInfo
	addrs = pItem + 0x24;
	nID = *(reinterpret_cast<int*>(addrs));

	pThis = pPlayer + 0x1E40;
	Result = GetSocketInfo(pThis, nID, pSocketInfo);
	if (Result == 0) return 38;

	addrs = pItemStore + 0x1C;
	pItemStoreScript = *(reinterpret_cast<int*>(addrs));
	CheckPointer = RTDynamicCast(pItemStoreScript, 0, 0x7E97C4, 0x7E99F4, 0);
	if (CheckPointer == 0) return 4;

	addrs = pSocketInfo + 0x4;
	CurSocketCount = *(reinterpret_cast<char*>(addrs));
	CurSocketCount &= 0xFF;

	Offset = pSocketInfo + 5;
	for(i = 0; i < CurSocketCount; i++)
	{
		addrs = Offset + (i * 9);
		InfoSlot = *(reinterpret_cast<char*>(addrs));
		InfoSlot &= 0xFF;
		if (InfoSlot != SocketSlot)
		{
			addrs = Offset + 1 + (i * 9);
			ItemIDInfo = *(reinterpret_cast<int*>(addrs));
			pBinStoreSocketScript = GetItemBinScriptInfo(ItemIDInfo);
			CheckPointer = RTDynamicCast(pBinStoreSocketScript, 0, 0x7E97C4, 0x7E99F4, 0);
			if (CheckPointer == 0) return 4;
			
			addrs = pItemStoreScript + 0x284;
			ItemStoreSocketType = *(reinterpret_cast<int*>(addrs));
			addrs = pBinStoreSocketScript + 0x284;
			InfoStoreSocketType = *(reinterpret_cast<int*>(addrs));
			if ((ItemStoreSocketType == 2) && (InfoStoreSocketType == 2))
			{
				addrs = pItemStoreScript + 0x288;
				ItemStoreOptionType = *(reinterpret_cast<int*>(addrs));
				addrs = pBinStoreSocketScript + 0x288;
				InfoStoreOptionType = *(reinterpret_cast<int*>(addrs));
				pThis = pPlayer + 0x1E40;
				Result = CheckSocketOptionType(pThis, ItemStoreOptionType, InfoStoreOptionType);
				if (Result == 1) return 56;
			}
		}
	}

	Offset = pSocketInfo + 5;
	for(i = 0; i < CurSocketCount; i++)
	{
		addrs = Offset + (i * 9);
		InfoSlot = *(reinterpret_cast<char*>(addrs));
		InfoSlot &= 0xFF;
		if (InfoSlot == SocketSlot)
		{
			addrs = Offset + 1 + (i * 9);
			ItemIDInfo = *(reinterpret_cast<int*>(addrs));
			if (ItemIDInfo == 0xFFFFFFFF) return 46;

			pThis = pPlayer + 0x1E40;
			Result = ClearSocketSlot(pThis, nID, SocketSlot);
			if (Result == 0) return 44;

			addrs = SOCKETSLOT_CLEAR_ADDRS;
			*(reinterpret_cast<int*>(addrs)) = nID;
			addrs = SOCKETSLOT_CLEAR_ADDRS + 4;
			*(reinterpret_cast<char*>(addrs)) = (char)SocketSlot;
			pThis = pDynamic;
			SendPacketEX(pThis, 0x2319, SOCKETSLOT_CLEAR_ADDRS, 0x5);
			
			// NOTICE 0xFO14
			addrs = NOTICE_FO14_ADDRS + 0x15;
			*(reinterpret_cast<char*>(addrs)) = 1;
			addrs = NOTICE_FO14_ADDRS + 0x16;
			*(reinterpret_cast<int*>(addrs)) = nID;
			addrs = NOTICE_FO14_ADDRS + 0x1A;
			*(reinterpret_cast<int*>(addrs)) = ItemID;
			addrs = NOTICE_FO14_ADDRS + 0x20;
			*(reinterpret_cast<char*>(addrs)) = (char)SocketSlot;

			pThis = pPlayer;
			PlayerSendNotice(pThis, 0xF014, NOTICE_FO14_ADDRS, 0x21, 0x15);
		}
		else
		{
			addrs = Offset + 1 + (i * 9);
			ItemIDInfo = *(reinterpret_cast<int*>(addrs));
			if (ItemIDInfo != 0xFFFFFFFF)
			{
				pBinStoreSocketScript = GetItemBinScriptInfo(ItemIDInfo);
				CheckPointer = RTDynamicCast(pBinStoreSocketScript, 0, 0x7E97C4, 0x7E99F4, 0);
				if (CheckPointer == 0) return 4;

				addrs = pItemStoreScript + 0x284;
				ItemStoreSocketType = *(reinterpret_cast<int*>(addrs));
				addrs = pBinStoreSocketScript + 0x284;
				InfoStoreSocketType = *(reinterpret_cast<int*>(addrs));
				if (InfoStoreSocketType == ItemStoreSocketType)
				{
					addrs = pItemStoreScript + 0x288;
					ItemStoreOptionType = *(reinterpret_cast<int*>(addrs));
					addrs = pBinStoreSocketScript + 0x288;
					InfoStoreOptionType = *(reinterpret_cast<int*>(addrs));
					if (InfoStoreOptionType == ItemStoreOptionType) return 39;
				}
			}
		}
	}

	// Client Packet
	addrs = SOCKET_REINFORCEC_ADDRS;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = SOCKET_REINFORCEC_ADDRS + 0x1;
	*(reinterpret_cast<int*>(addrs)) = ItemID;
	addrs = SOCKET_REINFORCEC_ADDRS + 0x5;
	*(reinterpret_cast<int*>(addrs)) = nID;
	addrs = SOCKET_REINFORCEC_ADDRS + 0x9;
	*(reinterpret_cast<char*>(addrs)) = (char)Inventory;
	addrs = SOCKET_REINFORCEC_ADDRS + 0xA;
	*(reinterpret_cast<char*>(addrs)) = (char)Slot;

	addrs = SOCKET_REINFORCEC_ADDRS + 0xB;
	*(reinterpret_cast<int*>(addrs)) = ItemIDStore;
	addrs = SOCKET_REINFORCEC_ADDRS + 0xF;
	*(reinterpret_cast<int*>(addrs)) = nIDStore;
	addrs = SOCKET_REINFORCEC_ADDRS + 0x13;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryStore;
	addrs = SOCKET_REINFORCEC_ADDRS + 0x14;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotStore;

	addrs = SOCKET_REINFORCEC_ADDRS + 0x16;
	*(reinterpret_cast<char*>(addrs)) = (char)SocketSlot;

	// Chance Rate
	addrs = pItemStoreScript + 0x27C;
	ChanceRate = *(reinterpret_cast<int*>(addrs));

	pThis = pItem;
	ItemGrade = GetAttribute(pThis, 0x79);

	pThis = pItemStore;
	ItemStoreGrade = GetAttribute(pThis, 0x79);

	if (ItemGrade < ItemStoreGrade)
	{
		ItemStoreGrade -= ItemGrade;
		CalRate = (ItemStoreGrade * ChanceRate) / 10;
		ChanceRate = CalRate;
	}

	pThis = pPlayer;
	Random = BioticBaseGetRandom(pThis, 1000000);

	if (ChanceRate > Random)
	{
		Timestamp = GetCurSeconds();
	
		addrs = pItem + 0x24;
		nID = *(reinterpret_cast<int*>(addrs));
		
		addrs = pItemStore + 0x20;
		ItemIDStore = *(reinterpret_cast<int*>(addrs));

		addrs = (DWORD)pSendData + 0x14;
		SocketSlot = *(reinterpret_cast<char*>(addrs));
		SocketSlot &= 0xFF;

		pThis = pPlayer + 0x1E40;
		Result = SocketSlotAdd(pThis, nID, SocketSlot, ItemIDStore, Timestamp);
		if (Result == 0) return 44;
		
		Res = 1;
		addrs = SOCKET_REINFORCEC_ADDRS + 0x15;
		*(reinterpret_cast<char*>(addrs)) = (char)Res;
		addrs = SOCKET_REINFORCEC_ADDRS + 0x17;
		*(reinterpret_cast<int*>(addrs)) = Timestamp;
	}
	else
	{
		addrs = pItemStoreScript + 0x280;
		ChanceRate = *(reinterpret_cast<int*>(addrs));

		pThis = pPlayer;
		Random = BioticBaseGetRandom(pThis, 1000000);
		
		Timestamp = 0;
		
		if (ChanceRate > Random)
		{
			addrs = pItem + 0x24;
			nID = *(reinterpret_cast<int*>(addrs));

			addrs = (DWORD)pSendData + 0x14;
			SocketSlot = *(reinterpret_cast<char*>(addrs));
			SocketSlot &= 0xFF;

			pThis = pPlayer + 0x1E40;
			Result = SocketSlotAdd(pThis, nID, SocketSlot, 0xFFFFFFFF, 0);
			if (Result == 0)
			{
				Res = 2;
				addrs = SOCKET_REINFORCEC_ADDRS + 0x15;
				*(reinterpret_cast<char*>(addrs)) = (char)Res;
				addrs = SOCKET_REINFORCEC_ADDRS + 0x17;
				*(reinterpret_cast<int*>(addrs)) = Timestamp;
			}
			else
			{
				Res = 3;
				addrs = SOCKET_REINFORCEC_ADDRS + 0x15;
				*(reinterpret_cast<char*>(addrs)) = (char)Res;
				addrs = SOCKET_REINFORCEC_ADDRS + 0x17;
				*(reinterpret_cast<int*>(addrs)) = Timestamp;
			}
		}
		else
		{
			Res = 2;
			addrs = SOCKET_REINFORCEC_ADDRS + 0x15;
			*(reinterpret_cast<char*>(addrs)) = (char)Res;
			addrs = SOCKET_REINFORCEC_ADDRS + 0x17;
			*(reinterpret_cast<int*>(addrs)) = Timestamp;
		}
	}

	if (Timestamp != 0)
	{
		addrs = pItemStoreScript + 0x278;
		AddTimer = *(reinterpret_cast<int*>(addrs));
		Timestamp += AddTimer;
	}

	// Remove Store
	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemStore);

	// NOTICE 0xFO13
	addrs = NOTICE_FO13_ADDRS + 0x15;
	*(reinterpret_cast<int*>(addrs)) = nID;
	addrs = NOTICE_FO13_ADDRS + 0x19;
	*(reinterpret_cast<int*>(addrs)) = ItemID;
	addrs = NOTICE_FO13_ADDRS + 0x1F;
	*(reinterpret_cast<int*>(addrs)) = nIDStore;
	addrs = NOTICE_FO13_ADDRS + 0x23;
	*(reinterpret_cast<int*>(addrs)) = ItemIDStore;
	addrs = NOTICE_FO13_ADDRS + 0x29;
	*(reinterpret_cast<char*>(addrs)) = (char)Res;
	addrs = NOTICE_FO13_ADDRS + 0x2A;
	*(reinterpret_cast<char*>(addrs)) = (char)SocketSlot;
	addrs = NOTICE_FO13_ADDRS + 0x2B;
	*(reinterpret_cast<int*>(addrs)) = Timestamp;

	pThis = pPlayer;
	PlayerSendNotice(pThis, 0xF013, NOTICE_FO13_ADDRS, 0x2F, 0x15);

	// Send Client Packet
	pThis = pDynamic;
	SendPacketEX(pThis, 0x2328, SOCKET_REINFORCEC_ADDRS, 0x1B);

	return 0;
}
