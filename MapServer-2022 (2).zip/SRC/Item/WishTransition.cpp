#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

unsigned char DBSK_ITEMGR_WT[65] = {0};
unsigned char DBSK_MATERIALGR_WT[65] = {0};
unsigned char WISH_TRANSITION[72] = {0};

extern int WISHTRANSITIONBIN_ADDRS;
extern int WISHTRANSITIONBIN_SIZE;
extern int WISHTRANSGROUPBIN_ADDRS;
extern int WISHTRANSGROUPBIN_SIZE;

// RCM_MAP_WISH_TICKET_TRANSITION 0x1482
void WishTransition(int pDynamic, int pSendPacket)
{
	int Result;
	int addrs;
	int pSendData;
	unsigned char WISH_RESULT[1] = {0};

	pSendData = pSendPacket + 4;
	Result = GetWishTransition(pDynamic, pSendData);
	if (Result != 0)
	{
		addrs = (int)WISH_RESULT;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;
		SendPacketEX(pDynamic, 0x1482, (int)WISH_RESULT, 0x1);
	}
}

int GetWishTransition(int pDynamic, int pSendData)
{
	int Result = 0;
	int addrs;
	int pPlayer;
	int CharID;
	int pThis;

	int Status;
	int NpcID;
	int pNpc;
	int pScript;

	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;
	int ItemUseCount;

	int ItemIDMaterial;
	int nIDMaterial;
	int InventoryMaterial;
	int SlotMaterial;

	int ItemID;
	int nID;
	int Inventory;
	int Slot;

	int pItem;
	int pItemUse;
	int pItemMaterial;
	int GroupID;
	int CheckID;
	int AttrbuteOption;
	int AttrbuteValue;

	unsigned char REMOVEITEM[12] = {0};

	// Check
	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 0x19;

	addrs = (DWORD)pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));
	addrs = (int)DBSK_ITEMGR_WT;
	*(reinterpret_cast<int*>(addrs)) = CharID;

	pThis = (DWORD)pPlayer;
	Status = PlayerCheckTradeItemWork(pThis, 0x0);
	if (Status == 0) return 0x55;

	addrs = (DWORD)pSendData + 0x4;
	NpcID = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)pSendData + 0x8;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xC;
	nID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x10;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x11;
	Slot = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)pSendData + 0x12;
	ItemIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x16;
	nIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x1A;
	InventoryMaterial = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x1B;
	SlotMaterial = *(reinterpret_cast<char*>(addrs));

	// Check NPC
	if (NpcID == 0) return 0x1;
	pNpc = GetNpc(NpcID);
	if (pNpc == 0) return 0x1;

	// Check ItemID
	pScript = GetWishTransitionScript(ItemID);
	if (pScript == 0) return 0x5;
	pScript = GetWishTransitionScript(ItemIDMaterial);
	if (pScript == 0) return 0x5;

	// Check Item
	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);
	if (pItem == 0) return 5;

	addrs = pItem + 0x20;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != ItemID) return 5;
	addrs = pItem + 0x24;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != nID) return 5;

	// Check Material
	pThis = pPlayer + 0xCC8;
	pItemMaterial = GetItem(pThis, InventoryMaterial, SlotMaterial);
	if (pItemMaterial == 0) return 5;

	addrs = pItemMaterial + 0x20;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != ItemIDMaterial) return 5;
	addrs = pItemMaterial + 0x24;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != nIDMaterial) return 5;

	// Get Material Option
	addrs = (int)DBSK_MATERIALGR_WT + 0x4;
	tagItemInit(addrs);
	addrs = (int)DBSK_MATERIALGR_WT + 0x4;
	EpochItemBaseGetItemGR(pItemMaterial, addrs);
	// Get Item Option
	addrs = (int)DBSK_ITEMGR_WT + 0x4;
	tagItemInit(addrs);
	addrs = (int)DBSK_ITEMGR_WT + 0x4;
	EpochItemBaseGetItemGR(pItem, addrs);

	// Check WishTicket
	addrs = (DWORD)pScript + 0x10;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pScript + 0x14;
	ItemUseCount = *(reinterpret_cast<int*>(addrs));
	if (ItemIDUse == 0) return 0x89;
	addrs = (DWORD)pScript +0x20;
	GroupID = *(reinterpret_cast<int*>(addrs));

	for( int i = 0; i < ItemUseCount; i++ )
	{
		pThis = (DWORD)pPlayer + 0xCC8;
		pItemUse = FindItem(pThis, ItemIDUse);
		if (pItemUse == 0) return 0x89;

		addrs = (DWORD)pItemUse + 0x20;
		ItemIDUse = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)pItemUse + 0x24;
		nIDUse = *(reinterpret_cast<int*>(addrs));;
		InventoryUse = GetAttribute(pItemUse, 0xC);
		SlotUse = GetAttribute(pItemUse, 0xD);

		// Remove WishTicket
		addrs = (int)REMOVEITEM;
		*(reinterpret_cast<char*>(addrs)) = 0;
		addrs = (int)REMOVEITEM + 0x1;
		*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
		addrs = (int)REMOVEITEM + 0x5;
		*(reinterpret_cast<int*>(addrs)) = nIDUse;
		addrs = (int)REMOVEITEM + 0x9;
		*(reinterpret_cast<char*>(addrs)) = (char)InventoryUse;
		addrs = (int)REMOVEITEM + 0xA;
		*(reinterpret_cast<char*>(addrs)) = (char)SlotUse;
		addrs = (int)REMOVEITEM + 0xB;
		*(reinterpret_cast<char*>(addrs)) = 0;

		pThis = (DWORD)pDynamic;
		SendPacketEX(pThis, 0x1512, (int)REMOVEITEM, 0xC);

		pThis = pPlayer + 0xCC8;
		RemoveItemsInInventory(pThis, pItemUse, 1);		
	}

	// Clean Item Option
	for( i = 0; i < 14; i++ )
	{
		addrs = (int)DBSK_ITEMGR_WT + 0xC + (i * 3);
		AttrbuteOption = *(reinterpret_cast<char*>(addrs));
		if (AttrbuteOption != 0)
		{
			ItemOptionSetType(pItem, AttrbuteOption, 0);
		}
	}
	// Setting Item Option
	for( i = 0; i < 14; i++ )
	{
		addrs = (int)DBSK_MATERIALGR_WT + 0xC + (i * 3);
		AttrbuteOption = *(reinterpret_cast<char*>(addrs));
		if (AttrbuteOption != 0)
		{
			Result = CheckWishTransitionOption(GroupID, AttrbuteOption);
			if (Result == 1)
			{
				addrs = (int)DBSK_MATERIALGR_WT + 0xD + (i * 3);
				AttrbuteValue = *(reinterpret_cast<unsigned short*>(addrs));
				ItemOptionSetType(pItem, AttrbuteOption, AttrbuteValue);
			}
		}
	}

	// Get Item Option
	addrs = (int)DBSK_ITEMGR_WT + 0x4;
	tagItemInit(addrs);
	addrs = (int)DBSK_ITEMGR_WT + 0x4;
	EpochItemBaseGetItemGR(pItem, addrs);
	// Send DB Packet
	SendPacketEX(0x7F23A0, 0x4A09, (int)DBSK_ITEMGR_WT, 0x41);

	// Client Packet
	// Client Item Option
	addrs = (int)WISH_TRANSITION + 0x1;
	tagItemInit(addrs);
	addrs = (int)WISH_TRANSITION + 0x1;
	EpochItemBaseGetItemGR(pItem, addrs);

	addrs = (int)WISH_TRANSITION + 0x3E;
	*(reinterpret_cast<int*>(addrs)) = ItemIDMaterial;
	addrs = (int)WISH_TRANSITION + 0x42;
	*(reinterpret_cast<int*>(addrs)) = nIDMaterial;
	addrs = (int)WISH_TRANSITION + 0x46;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryMaterial;
	addrs = (int)WISH_TRANSITION + 0x47;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotMaterial;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x1482, (int)WISH_TRANSITION, 0x48);

	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemMaterial);

	return 0;
}

int GetWishTransitionScript(int ItemID)
{
	int pScript = 0;
	int addrs;
	int BinItemID;
	int MaxCount = 0;
	int Offset = 0;

	MaxCount = WISHTRANSITIONBIN_SIZE / 0x24;
	Offset = (DWORD)WISHTRANSITIONBIN_ADDRS;
	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x18;
		BinItemID = *(reinterpret_cast<int*>(addrs));
		if (BinItemID == ItemID)
		{
			pScript = Offset;
			break;
		}
		else
		{
			Offset += 0x24;
		}
	}

	return pScript;
}

int CheckWishTransitionOption(int GroupID, int AttrbuteOption)
{
	int Result = 0;
	int addrs;
	int BinGroupID;
	int BinOption;
	int MaxCount = 0;
	int Offset = 0;

	MaxCount = WISHTRANSGROUPBIN_SIZE / 0xC;
	Offset = (DWORD)WISHTRANSGROUPBIN_ADDRS;
	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x4;
		BinGroupID = *(reinterpret_cast<int*>(addrs));
		if (BinGroupID == GroupID)
		{
			addrs = Offset + 0x8;
			BinOption = *(reinterpret_cast<int*>(addrs));
			if (BinOption == AttrbuteOption)
			{
				Result = 1;
				break;
			}
		}
		Offset += 0xC;
	}

	return Result;
}