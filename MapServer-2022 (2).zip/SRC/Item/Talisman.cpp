#include <RHItem.h>
#include <Player.h>
#include <MapFunctions.h>

using namespace std;

extern int CHARSTATUS_SIZE;
int TALISMAN_EQUIP_PKSIZE = 0xB + CHARSTATUS_SIZE;

unsigned char EQUIP_TALISMAN[191] = {0};
int EQUIP_TALISMAN_ADDRS = (DWORD)EQUIP_TALISMAN;

void TalismanRegister(int ItemSubType, int TargetAddrs)
{
	int addrs;

	switch(ItemSubType)
	{
		case 6: addrs = TargetAddrs; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 7: addrs = TargetAddrs + 1; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 8: addrs = TargetAddrs + 2; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 9: addrs = TargetAddrs + 3; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 10: addrs = TargetAddrs + 4; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 11: addrs = TargetAddrs + 5; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 12: addrs = TargetAddrs + 6; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 13: addrs = TargetAddrs + 7; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 14: addrs = TargetAddrs + 8; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 15: addrs = TargetAddrs + 9; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 22: addrs = TargetAddrs + 10; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 23: addrs = TargetAddrs + 11; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 24: addrs = TargetAddrs + 12; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 25: addrs = TargetAddrs + 13; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 26: addrs = TargetAddrs + 14; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 27: addrs = TargetAddrs + 15; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 28: addrs = TargetAddrs + 16; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 29: addrs = TargetAddrs + 17; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 30: addrs = TargetAddrs + 18; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 31: addrs = TargetAddrs + 19; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 32: addrs = TargetAddrs + 20; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 35: addrs = TargetAddrs + 21; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 21: addrs = TargetAddrs + 22; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 1: addrs = TargetAddrs + 23; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 34: addrs = TargetAddrs + 24; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 2: addrs = TargetAddrs + 25; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 3: addrs = TargetAddrs + 26; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 4: addrs = TargetAddrs + 27; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
		case 5: addrs = TargetAddrs + 28; *(reinterpret_cast<unsigned char*>(addrs)) = 1; break;
	}
}

int GetUnRegType(int IconOrder)
{
	int SubType;

	switch(IconOrder)
	{
		case 0: SubType = 0x06; break;
		case 1: SubType = 0x07; break;
		case 2: SubType = 0x08; break;
		case 3: SubType = 0x09; break;
		case 4: SubType = 0x0A; break;
		case 5: SubType = 0x0B; break;
		case 6: SubType = 0x0C; break;
		case 7: SubType = 0x0D; break;
		case 8: SubType = 0x0E; break;
		case 9: SubType = 0x0F; break;
		case 10: SubType = 0x16; break;
		case 11: SubType = 0x17; break;
		case 12: SubType = 0x18; break;
		case 13: SubType = 0x19; break;
		case 14: SubType = 0x1A; break;
		case 15: SubType = 0x1B; break;
		case 16: SubType = 0x1C; break;
		case 17: SubType = 0x1D; break;
		case 18: SubType = 0x1E; break;
		case 19: SubType = 0x1F; break;
		case 20: SubType = 0x20; break;
		case 21: SubType = 0x23; break;
		case 22: SubType = 0x15; break;
		case 23: SubType = 0x01; break;
		case 24: SubType = 0x22; break;
		case 25: SubType = 0x02; break;
		case 26: SubType = 0x03; break;
		case 27: SubType = 0x04; break;
		case 28: SubType = 0x05; break;
	}

	return SubType;
}

void TalismanList(int pDynamic, int pSendPacket)
{
	int pInventory;
	int pPlayer;
	int pThis;
	int Inventory;
	int MaxSlot;
	int Slot;
	int ItemCount;
	int pItem;
	int ItemType;
	int ItemSubType;
	int UnRegCount;
	int IconOrder;
	int addrs;
	unsigned char RegState;
	int UnRegType;
	int i;
	int TargetAddrs;
	int pData;

	unsigned char TALISMANM_BUFFER[751] = {0};
	int pList = (DWORD)TALISMANM_BUFFER + 16;
	char TALISMANM_ICON[29];


	memset(TALISMANM_BUFFER,0,sizeof(char)*751);
	memset(TALISMANM_ICON,0,sizeof(char)*29);

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return;

	pInventory = (DWORD)pPlayer + 0xCC8;
	
	UnRegCount = 49;

	// Registered
	for(Inventory=1; Inventory < 6; Inventory++ )
	{
		ItemCount = GetCurCount(pInventory, Inventory);
		if (ItemCount > 0)
		{
			MaxSlot = GetAllowCount(pInventory, Inventory);
			for( Slot=0; Slot < MaxSlot; Slot++ )
			{
				pItem = GetItem(pInventory, Inventory, Slot);
				if (pItem != 0)
				{
					ItemType = GetAttribute(pItem, 0x0);
					if (ItemType == 120)
					{
						ItemSubType = GetAttribute(pItem, 0x58);
						if (ItemSubType != 33)
						{
							*(reinterpret_cast<unsigned char*>(pList)) = (unsigned char)ItemSubType;
							pList += 13;

							*(reinterpret_cast<unsigned char*>(pList)) = (unsigned char)Inventory;
							pList += 1;

							*(reinterpret_cast<unsigned char*>(pList)) = (unsigned char)Slot;
							pList += 1;

							TargetAddrs = (DWORD)TALISMANM_ICON;
							TalismanRegister(ItemSubType, TargetAddrs);

							UnRegCount -= 1;
						}
					}
				}
			}
		}
	}

	// UnRegister
	for(IconOrder = 0; IconOrder < 29; IconOrder++ )
	{
		addrs = (DWORD)TALISMANM_ICON + IconOrder;
		RegState = *(reinterpret_cast<unsigned char*>(addrs));
		if (RegState == 0)
		{
			UnRegType = GetUnRegType(IconOrder);
			*(reinterpret_cast<unsigned char*>(pList)) = (unsigned char)UnRegType;
			pList += 15;
			UnRegCount -= 1;
		}
	}

	if (UnRegCount > 2)
	{
		// Type
		*(reinterpret_cast<unsigned char*>(pList)) = 0x10;
		pList += 4;
		// Disable
		*(reinterpret_cast<unsigned char*>(pList)) = 0x01;
		pList += 11;

		// Type
		*(reinterpret_cast<unsigned char*>(pList)) = 0x11;
		pList += 4;
		// Disable
		*(reinterpret_cast<unsigned char*>(pList)) = 0x01;
		pList += 11;

		// Type
		*(reinterpret_cast<unsigned char*>(pList)) = 0x11;
		pList += 4;
		// Disable
		*(reinterpret_cast<unsigned char*>(pList)) = 0x01;
		pList += 11;

		UnRegCount -= 3;
	}

	for(i = 0; i < UnRegCount; i++ )
	{
		// Type
		*(reinterpret_cast<unsigned char*>(pList)) = 0x00;
		pList += 4;
		// Disable
		*(reinterpret_cast<unsigned char*>(pList)) = 0x01;
		pList += 11;
	}

	pData = (DWORD)TALISMANM_BUFFER;
	pThis = pDynamic;
	SendPacketEX(pThis, 0x1853, pData, 0x2EF);
}


int EguipTalisman(int pItem, int Active)
{
	int pInventory;
	__asm mov pInventory,ecx
	int addrs = 0;
	int pPlayer = 0;
	int pDynamic = 0;
	int pThis = 0;
	int ItemType = 0;
	int ItemSubType = 0;
	int Enable = 0;
	int pItemScript;
	int AttributeType;
	int CalValue;
	int OptionType;
	int UseMinLevel;
	int UseMaxLevel;
	int PlayerLevel;
	int EquipLevel;
	int ItemID;
	int nID;

	__int64 bOffest;
	__int64 bCurSubType;
	__int64 bSubType;
	__int64 bCheckSubType;
	__int64 bAddSubType;
	__int64 bDelSubType;

	if (pItem == 0) return 0x16;

	addrs = pInventory + 0x24;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 0x16;
	
	ItemType = GetAttribute(pItem, 0);
	if (ItemType != 120) return 0x3;

	ItemSubType = GetAttribute(pItem, 0x58);
	if (ItemSubType == 33) return 0x3;
	if (ItemSubType > 35) return 0x3;
	if (ItemSubType < 1) return 0x3;
	
	addrs = pInventory + 0x80;
	bCurSubType = *(reinterpret_cast<__int64*>(addrs));
	
	bOffest = (__int64)ItemSubType - 1;

	bSubType = 1 << bOffest;

	if (Active == 1)
	{
		bCheckSubType = bCurSubType & bSubType;
		if (bCheckSubType == bSubType) return 0x86;
	}

	// Check Item Level Limit
	pThis = pPlayer;
	PlayerLevel = GetCharAllLevel(pThis);

	EquipLevel = GetAttribute(pItem, 5);

	addrs = pItem + 0x1C;
	pItemScript = *(reinterpret_cast<int*>(addrs));
	addrs = pItemScript + 0x1CC;
	UseMaxLevel = *(reinterpret_cast<int*>(addrs));
	addrs = pItemScript + 0x1D0;
	UseMinLevel = *(reinterpret_cast<int*>(addrs));

	if ((UseMaxLevel == 0) && (UseMinLevel == 0))
	{
		if (PlayerLevel > EquipLevel) Enable = 1;
	}
	else
	{
		if ((PlayerLevel > UseMinLevel) && (PlayerLevel < UseMaxLevel)) Enable = 1;
	}

	for(int i = 0; i < 4; i++ )
	{
		addrs = pItemScript + 0x264 + (i * 2);
		AttributeType = *(reinterpret_cast<unsigned short*>(addrs));
		if (AttributeType != 0xFFFF)
		{
			CalValue = GetAttribute(pItem, AttributeType);
			if (CalValue != 0)
			{
				OptionType = GetItemOptionType(AttributeType, 0);
				if (OptionType != 0xFFFFFFFF)
				{
					if (Enable == 1)
					{
						CalItemOption(pInventory, OptionType, CalValue, Active);
					}
				}
			}
		}
	}

	pThis = pPlayer;
	ApplyCalAbility(pThis);

	addrs = pItem + 0x20;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = pItem + 0x24;
	nID = *(reinterpret_cast<int*>(addrs));

	// Clinet Packet
	addrs = EQUIP_TALISMAN_ADDRS;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = EQUIP_TALISMAN_ADDRS + 0x1;
	*(reinterpret_cast<int*>(addrs)) = ItemID;
	addrs = EQUIP_TALISMAN_ADDRS + 0x5;
	*(reinterpret_cast<int*>(addrs)) = nID;
	addrs = EQUIP_TALISMAN_ADDRS + 0x9;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = EQUIP_TALISMAN_ADDRS + 0xA;
	*(reinterpret_cast<char*>(addrs)) = 0x1F;

	addrs = EQUIP_TALISMAN_ADDRS + 0xB;
	pThis = pPlayer;
	PlayerGetStatusInfo(pThis, addrs);

	addrs = pPlayer + 0x1098;
	pDynamic = *(reinterpret_cast<int*>(addrs));

	if (Active == 1)
	{
		// Equip Talisman
		bAddSubType = bCurSubType | bSubType;
		addrs = pInventory + 0x80;
		*(reinterpret_cast<__int64*>(addrs)) = bAddSubType;

		if (pDynamic != 0)
		{
			SendPacket(pDynamic, 0x150B, EQUIP_TALISMAN_ADDRS, TALISMAN_EQUIP_PKSIZE);
		}
	}
	else
	{
		// UnEquip Talisman
		bDelSubType = bCurSubType & ~bSubType;
		addrs = pInventory + 0x80;
		*(reinterpret_cast<__int64*>(addrs)) = bDelSubType;

		if (pDynamic != 0)
		{
			SendPacket(pDynamic, 0x150D, EQUIP_TALISMAN_ADDRS, TALISMAN_EQUIP_PKSIZE);
		}
	}

	return 0;
}

void EquipTalismanType(int pItem)
{
	int pInventory;
	__asm mov pInventory,ecx

	int addrs;
	int pPlayer;
	int pThis;
	int ItemType;
	int ItemSubType;
	int pItemScript;
	int UseMinLevel;
	int UseMaxLevel;
	int EquipLevel;
	int PlayerLevel;
	int ItemID;
	int nID;
	int CharmValue;
	int ExpRate;
	int PartyExpRate;
	int pParty;
	int CastingTime;

	unsigned char BUFFITEM_ADAPTING[9] = {0};

	addrs = pInventory + 0x24;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return;

	ItemType = GetAttribute(pItem, 0);
	if (ItemType == 120)
	{
		addrs = pItem + 0x1C;
		pItemScript = *(reinterpret_cast<int*>(addrs));
		addrs = pItemScript + 0x1CC;
		UseMaxLevel = *(reinterpret_cast<int*>(addrs));
		addrs = pItemScript + 0x1D0;
		UseMinLevel = *(reinterpret_cast<int*>(addrs));
		pThis = pPlayer;
		PlayerLevel = GetCharAllLevel(pThis);

		if ((UseMaxLevel == 0) && (UseMinLevel == 0))
		{
			EquipLevel = GetAttribute(pItem, 5);
			if (EquipLevel > PlayerLevel) return;
		}
		else
		{
			addrs = pItem + 0x20;
			ItemID = *(reinterpret_cast<int*>(addrs));
			addrs = pItem + 0x24;
			nID = *(reinterpret_cast<int*>(addrs));

			if ((PlayerLevel > UseMinLevel) && (PlayerLevel < UseMaxLevel))
			{
				addrs = (int)BUFFITEM_ADAPTING;
				*(reinterpret_cast<char*>(addrs)) = 1;
				addrs = (int)BUFFITEM_ADAPTING + 1;
				*(reinterpret_cast<int*>(addrs)) = ItemID;
				addrs = (int)BUFFITEM_ADAPTING + 5;
				*(reinterpret_cast<int*>(addrs)) = nID;

				addrs = pPlayer + 0x1098;
				pThis = *(reinterpret_cast<int*>(addrs));
				if (pThis != 0)
				{
					SendPacket(pThis, 0x1454, (int)BUFFITEM_ADAPTING, 9);
				}
			}
			else
			{
				addrs = (int)BUFFITEM_ADAPTING;
				*(reinterpret_cast<char*>(addrs)) = 3;
				addrs = (int)BUFFITEM_ADAPTING + 1;
				*(reinterpret_cast<int*>(addrs)) = ItemID;
				addrs = (int)BUFFITEM_ADAPTING + 5;
				*(reinterpret_cast<int*>(addrs)) = nID;

				addrs = pPlayer + 0x1098;
				pThis = *(reinterpret_cast<int*>(addrs));
				if (pThis != 0)
				{
					SendPacket(pThis, 0x1454, (int)BUFFITEM_ADAPTING, 9);
				}
				return;
			}
		}
		
		// ItemSubType
		ItemSubType = GetAttribute(pItem, 88);

		// Type 1 ExpBonus
		if (ItemSubType == 1)
		{
			addrs = pPlayer + 0x1AA4;
			ExpRate = *(reinterpret_cast<int*>(addrs));

			pThis = pInventory;
			CharmValue = GetCharmAttribute(pThis, ItemSubType, 86);

			// Charm 0x1AC4
			pThis = pPlayer;
			SetCharmExpBonus(pThis, CharmValue);

			ExpRate += CharmValue;

			addrs = pPlayer + 0x1AA4;
			*(reinterpret_cast<int*>(addrs)) = ExpRate;
		}
		// Type 34 AddExpBonus
		if (ItemSubType == 34)
		{
			addrs = pPlayer + 0x1AA4;
			ExpRate = *(reinterpret_cast<int*>(addrs));

			pThis = pInventory;
			CharmValue = GetCharmAttribute(pThis, ItemSubType, 86);
			// Charm 0x1AC8
			pThis = pPlayer;
			SetCharmAddExpBonus(pThis, CharmValue);

			ExpRate += CharmValue;

			addrs = pPlayer + 0x1AA4;
			*(reinterpret_cast<int*>(addrs)) = ExpRate;
		}
		// Type 3 MKBonus
		if (ItemSubType == 3)
		{
			pThis = pInventory;
			CharmValue = GetCharmAttribute(pThis, ItemSubType, 87);

			// Charm 0x1AA8
			pThis = pPlayer;
			SetCharmMKBonus(pThis, CharmValue);
		}
		// Type 2 PartyExpBonus
		if (ItemSubType == 2)
		{
			addrs = pPlayer + 0x1AB0;
			PartyExpRate = *(reinterpret_cast<int*>(addrs));

			pThis = pInventory;
			CharmValue = GetCharmAttribute(pThis, ItemSubType, 86);
			
			addrs = pPlayer + 0x1AD0;
			*(reinterpret_cast<int*>(addrs)) = CharmValue;

			PartyExpRate += CharmValue;

			addrs = pPlayer + 0x1AB0;
			*(reinterpret_cast<int*>(addrs)) = PartyExpRate;

			// Set Party
			addrs = pPlayer + 0x1108;
			pParty = *(reinterpret_cast<int*>(addrs));
			if (pParty != 0)
			{
				SetCharmPartyExpBonus(pParty);
			}
		}
		// Type 39 AddPartyExpBonus
		if (ItemSubType == 39)
		{
			addrs = pPlayer + 0x1AB0;
			PartyExpRate = *(reinterpret_cast<int*>(addrs));

			pThis = pInventory;
			CharmValue = GetCharmAttribute(pThis, ItemSubType, 86);
			
			addrs = pPlayer + 0x1AD4;
			*(reinterpret_cast<int*>(addrs)) = CharmValue;

			PartyExpRate += CharmValue;

			addrs = pPlayer + 0x1AB0;
			*(reinterpret_cast<int*>(addrs)) = PartyExpRate;

			// Set Party
			addrs = pPlayer + 0x1108;
			pParty = *(reinterpret_cast<int*>(addrs));
			if (pParty != 0)
			{
				SetCharmPartyExpBonus(pParty);
			}
		}
		// Type 4 PartyMKBonus
		if (ItemSubType == 4)
		{
			pThis = pInventory;
			CharmValue = GetCharmAttribute(pThis, ItemSubType, 87);
			// Charm 0x1AB4
			addrs = pPlayer + 0x1AB4;
			*(reinterpret_cast<int*>(addrs)) = CharmValue;

			addrs = pPlayer + 0x1AB8;
			*(reinterpret_cast<int*>(addrs)) = 1;

			// Set Party
			addrs = pPlayer + 0x1108;
			pParty = *(reinterpret_cast<int*>(addrs));
			if (pParty != 0)
			{
				SetCharmPartyMKBonus(pParty);
			}
		}
		// Type 5 PartyElement
		if (ItemSubType == 5)
		{
			pThis = pInventory;
			CharmValue = GetCharmAttribute(pThis, ItemSubType, 102);

			// Charm 0x1AC0
			addrs = pPlayer + 0x1AC0;
			*(reinterpret_cast<int*>(addrs)) = CharmValue;

			// Set Party
			addrs = pPlayer + 0x1108;
			pParty = *(reinterpret_cast<int*>(addrs));
			if (pParty != 0)
			{
				SetCharmPartyElement(pParty);
			}
		}
	}
	else
	{
		// Marriage Ring Casting Time
		if (ItemType == 130)
		{
			pThis = pItem;
			CastingTime = ItemOptionGetType(pThis, 0x49);
			pThis = pPlayer;
			SetCastingTime(pThis, CastingTime);
		}
	}
}

void UnEquipTalismanType(int pItem)
{
	int pInventory;
	__asm mov pInventory,ecx

	int addrs;
	int pPlayer;
	int pThis;
	int ItemType;
	int ItemSubType;
	int pItemScript;
	int UseMinLevel;
	int UseMaxLevel;
	int EquipLevel;
	int PlayerLevel;
	int ItemID;
	int nID;
	int CharmValue;
	int ExpRate;
	int PartyExpRate;
	int pParty;

	unsigned char BUFFITEM_ADAPTING[9] = {0};

	addrs = pInventory + 0x24;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return;

	ItemType = GetAttribute(pItem, 0);
	if (ItemType == 120)
	{
		addrs = pItem + 0x1C;
		pItemScript = *(reinterpret_cast<int*>(addrs));
		addrs = pItemScript + 0x1CC;
		UseMaxLevel = *(reinterpret_cast<int*>(addrs));
		addrs = pItemScript + 0x1D0;
		UseMinLevel = *(reinterpret_cast<int*>(addrs));
		pThis = pPlayer;
		PlayerLevel = GetCharAllLevel(pThis);

		if ((UseMaxLevel == 0) && (UseMinLevel == 0))
		{
			EquipLevel = GetAttribute(pItem, 5);
			if (EquipLevel > PlayerLevel) return;
		}
		else
		{
			addrs = pItem + 0x20;
			ItemID = *(reinterpret_cast<int*>(addrs));
			addrs = pItem + 0x24;
			nID = *(reinterpret_cast<int*>(addrs));

			if ((PlayerLevel > UseMinLevel) && (PlayerLevel < UseMaxLevel))
			{
				addrs = (int)BUFFITEM_ADAPTING;
				*(reinterpret_cast<char*>(addrs)) = 2;
				addrs = (int)BUFFITEM_ADAPTING + 1;
				*(reinterpret_cast<int*>(addrs)) = ItemID;
				addrs = (int)BUFFITEM_ADAPTING + 5;
				*(reinterpret_cast<int*>(addrs)) = nID;

				addrs = pPlayer + 0x1098;
				pThis = *(reinterpret_cast<int*>(addrs));
				if (pThis != 0)
				{
					SendPacket(pThis, 0x1454, (int)BUFFITEM_ADAPTING, 9);
				}
			}
		}

		// ItemSubType
		ItemSubType = GetAttribute(pItem, 88);

		// Type 1 ExpBonus
		if (ItemSubType == 1)
		{
			addrs = pPlayer + 0x1AA4;
			ExpRate = *(reinterpret_cast<int*>(addrs));

			// Charm 0x1AC4
			addrs = pPlayer + 0x1AC4;
			CharmValue = *(reinterpret_cast<int*>(addrs));

			ExpRate -= CharmValue;

			pThis = pInventory;
			CharmValue = GetCharmAttribute(pThis, ItemSubType, 86);

			pThis = pPlayer;
			SetCharmExpBonus(pThis, CharmValue);

			// Charm 0x1AC4
			addrs = pPlayer + 0x1AC4;
			CharmValue = *(reinterpret_cast<int*>(addrs));

			ExpRate += CharmValue;

			addrs = pPlayer + 0x1AA4;
			*(reinterpret_cast<int*>(addrs)) = ExpRate;
		}
		// Type 34 AddExpBonus
		if (ItemSubType == 34)
		{
			addrs = pPlayer + 0x1AA4;
			ExpRate = *(reinterpret_cast<int*>(addrs));

			// Charm 0x1AC8
			addrs = pPlayer + 0x1AC8;
			CharmValue = *(reinterpret_cast<int*>(addrs));

			ExpRate -= CharmValue;

			pThis = pInventory;
			CharmValue = GetCharmAttribute(pThis, ItemSubType, 86);

			pThis = pPlayer;
			SetCharmAddExpBonus(pThis, CharmValue);

			// Charm 0x1AC8
			addrs = pPlayer + 0x1AC8;
			CharmValue = *(reinterpret_cast<int*>(addrs));

			ExpRate += CharmValue;

			addrs = pPlayer + 0x1AA4;
			*(reinterpret_cast<int*>(addrs)) = ExpRate;
		}
		// Type 3 MKBonus
		if (ItemSubType == 3)
		{
			pThis = pInventory;
			CharmValue = GetCharmAttribute(pThis, ItemSubType, 87);

			// Charm 0x1AA8
			pThis = pPlayer;
			SetCharmMKBonus(pThis, CharmValue);
		}
		// Type 2 PartyExpBonus
		if (ItemSubType == 2)
		{
			addrs = pPlayer + 0x1AB0;
			PartyExpRate = *(reinterpret_cast<int*>(addrs));

			// Charm 0x1AD0
			addrs = pPlayer + 0x1AD0;
			CharmValue = *(reinterpret_cast<int*>(addrs));

			PartyExpRate -= CharmValue;

			pThis = pInventory;
			CharmValue = GetCharmAttribute(pThis, ItemSubType, 86);

			// Set PartyExp
			addrs = pPlayer + 0x1AD0;
			*(reinterpret_cast<int*>(addrs)) = CharmValue;

			// Charm 0x1AD0
			addrs = pPlayer + 0x1AD0;
			CharmValue = *(reinterpret_cast<int*>(addrs));

			PartyExpRate += CharmValue;

			addrs = pPlayer + 0x1AB0;
			*(reinterpret_cast<int*>(addrs)) = PartyExpRate;

			// Set Party
			addrs = pPlayer + 0x1108;
			pParty = *(reinterpret_cast<int*>(addrs));
			if (pParty != 0)
			{
				SetCharmPartyExpBonus(pParty);
			}
		}
		// Type 39 AddPartyExpBonus
		if (ItemSubType == 39)
		{
			addrs = pPlayer + 0x1AB0;
			PartyExpRate = *(reinterpret_cast<int*>(addrs));

			// Charm 0x1AD4
			addrs = pPlayer + 0x1AD4;
			CharmValue = *(reinterpret_cast<int*>(addrs));

			PartyExpRate -= CharmValue;

			pThis = pInventory;
			CharmValue = GetCharmAttribute(pThis, ItemSubType, 86);

			// Set PartyExp
			addrs = pPlayer + 0x1AD4;
			*(reinterpret_cast<int*>(addrs)) = CharmValue;

			// Charm 0x1AD4
			addrs = pPlayer + 0x1AD4;
			CharmValue = *(reinterpret_cast<int*>(addrs));

			PartyExpRate += CharmValue;

			addrs = pPlayer + 0x1AB0;
			*(reinterpret_cast<int*>(addrs)) = PartyExpRate;

			// Set Party
			addrs = pPlayer + 0x1108;
			pParty = *(reinterpret_cast<int*>(addrs));
			if (pParty != 0)
			{
				SetCharmPartyExpBonus(pParty);
			}
		}
		// Type 4 PartyMKBonus
		if (ItemSubType == 4)
		{
			pThis = pInventory;
			CharmValue = GetCharmAttribute(pThis, ItemSubType, 87);
			// Charm 0x1AB4
			addrs = pPlayer + 0x1AB4;
			*(reinterpret_cast<int*>(addrs)) = CharmValue;

			addrs = pPlayer + 0x1AB8;
			*(reinterpret_cast<int*>(addrs)) = 0;

			// Set Party
			addrs = pPlayer + 0x1108;
			pParty = *(reinterpret_cast<int*>(addrs));
			if (pParty != 0)
			{
				SetCharmPartyMKBonus(pParty);
			}
		}
		// Type 5 PartyElement
		if (ItemSubType == 5)
		{
			pThis = pInventory;
			CharmValue = GetCharmAttribute(pThis, ItemSubType, 102);

			// Charm 0x1AC0
			addrs = pPlayer + 0x1AC0;
			*(reinterpret_cast<int*>(addrs)) = CharmValue;

			// Set Party
			addrs = pPlayer + 0x1108;
			pParty = *(reinterpret_cast<int*>(addrs));
			if (pParty != 0)
			{
				SetCharmPartyElement(pParty);
			}
		}
	}
}
