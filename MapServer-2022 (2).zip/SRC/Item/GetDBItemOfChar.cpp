#include <RHItem.h>
#include <MapFunctions.h>
#include <RHDB.h>
#include <sqlext.h>

using namespace std;

unsigned char ItemBuffer[20146] = {0};

//int DBITEM_CHARID;
int DBGETITEMDATA = (DWORD)DBGetItemData;
int DBITEM_RET = 0x004093D2;

void DBGetItem()
{
	// This
	__asm mov eax,dword ptr ss:[ebp-0xBA0]
	// PlayerPTR
	__asm mov ecx,dword ptr ds:[eax+0x534]
	// CharID
	__asm mov edx,dword ptr ds:[ecx+0x30]
	//__asm mov DBITEM_CHARID,edx

	__asm push edx
	__asm call DBGETITEMDATA
	__asm add esp,0x4
	//DBGetItemData(DBITEM_CHARID);

	__asm mov dword ptr ss:[ebp-0xB98],eax
	__asm mov edx, dword ptr ss:[ebp-0xB98]

	__asm jmp DBITEM_RET

}

int DBGetItemData(int CharID)
{
	//define handles and variables
    SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);
	
	memset(ItemBuffer,0,sizeof(char)*20146);

	int DBItemAddr = 0;
	int offset = 0;
	int ItemCount = 0;
	int addrs = 0;

	unsigned char cmdstr0[] = "SELECT type, [id], attr, inventory, slot, stack, rank, equip_level, equip_strength, equip_dexterity, equip_intelligence FROM RohanGame.dbo.TItem with (nolock) WHERE char_id = ? and inventory = 0";
	unsigned char cmdstr1[] = "SELECT type, [id], attr, inventory, slot, stack, rank, equip_level, equip_strength, equip_dexterity, equip_intelligence FROM RohanGame.dbo.TItem with (nolock) WHERE char_id = ? and inventory = 1";
	unsigned char cmdstr2[] = "SELECT type, [id], attr, inventory, slot, stack, rank, equip_level, equip_strength, equip_dexterity, equip_intelligence FROM RohanGame.dbo.TItem with (nolock) WHERE char_id = ? and inventory = 2";
	unsigned char cmdstr3[] = "SELECT type, [id], attr, inventory, slot, stack, rank, equip_level, equip_strength, equip_dexterity, equip_intelligence FROM RohanGame.dbo.TItem with (nolock) WHERE char_id = ? and inventory = 3";
	unsigned char cmdstr4[] = "SELECT type, [id], attr, inventory, slot, stack, rank, equip_level, equip_strength, equip_dexterity, equip_intelligence FROM RohanGame.dbo.TItem with (nolock) WHERE char_id = ? and inventory = 4";
	unsigned char cmdstr5[] = "SELECT type, [id], attr, inventory, slot, stack, rank, equip_level, equip_strength, equip_dexterity, equip_intelligence FROM RohanGame.dbo.TItem with (nolock) WHERE char_id = ? and inventory = 5";

	addrs = (DWORD)ItemBuffer;
	 *(reinterpret_cast<int*>(addrs)) = 0x0;
	addrs = (DWORD)ItemBuffer + 0x4;
	 *(reinterpret_cast<int*>(addrs)) = 0x1;
	addrs = (DWORD)ItemBuffer + 0x8;
	 *(reinterpret_cast<int*>(addrs)) = CharID;

	offset = 0x10;

	// Get Inventory 0 Items
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr0, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {

			// type(ItemID)
			SQLGetData(SHSTMT, 1, SQL_C_BINARY, &ItemBuffer[offset], 4, NULL);
			offset += 4;
			// iD
			SQLGetData(SHSTMT, 2, SQL_C_BINARY, &ItemBuffer[offset], 4, NULL);
			offset += 4;
			// attr
			SQLGetData(SHSTMT, 3, SQL_C_BINARY, &ItemBuffer[offset], 42, NULL);
			offset += 42;
			// inventory
			SQLGetData(SHSTMT, 4, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// slot
			SQLGetData(SHSTMT, 5, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// stack
			SQLGetData(SHSTMT, 6, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// rank
			SQLGetData(SHSTMT, 7, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// equip_level
			SQLGetData(SHSTMT, 8, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// equip_strength
			SQLGetData(SHSTMT, 9, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;
			// equip_dexterity
			SQLGetData(SHSTMT, 10, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;
			// equip_intelligence
			SQLGetData(SHSTMT, 11, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;

			ItemCount++;
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// Get Inventory 1 Items
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr1, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {

			// type(ItemID)
			SQLGetData(SHSTMT, 1, SQL_C_BINARY, &ItemBuffer[offset], 4, NULL);
			offset += 4;
			// iD
			SQLGetData(SHSTMT, 2, SQL_C_BINARY, &ItemBuffer[offset], 4, NULL);
			offset += 4;
			// attr
			SQLGetData(SHSTMT, 3, SQL_C_BINARY, &ItemBuffer[offset], 42, NULL);
			offset += 42;
			// inventory
			SQLGetData(SHSTMT, 4, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// slot
			SQLGetData(SHSTMT, 5, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// stack
			SQLGetData(SHSTMT, 6, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// rank
			SQLGetData(SHSTMT, 7, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// equip_level
			SQLGetData(SHSTMT, 8, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// equip_strength
			SQLGetData(SHSTMT, 9, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;
			// equip_dexterity
			SQLGetData(SHSTMT, 10, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;
			// equip_intelligence
			SQLGetData(SHSTMT, 11, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;

			ItemCount++;
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// Get Inventory 2 Items
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr2, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {

			// type(ItemID)
			SQLGetData(SHSTMT, 1, SQL_C_BINARY, &ItemBuffer[offset], 4, NULL);
			offset += 4;
			// iD
			SQLGetData(SHSTMT, 2, SQL_C_BINARY, &ItemBuffer[offset], 4, NULL);
			offset += 4;
			// attr
			SQLGetData(SHSTMT, 3, SQL_C_BINARY, &ItemBuffer[offset], 42, NULL);
			offset += 42;
			// inventory
			SQLGetData(SHSTMT, 4, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// slot
			SQLGetData(SHSTMT, 5, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// stack
			SQLGetData(SHSTMT, 6, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// rank
			SQLGetData(SHSTMT, 7, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// equip_level
			SQLGetData(SHSTMT, 8, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// equip_strength
			SQLGetData(SHSTMT, 9, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;
			// equip_dexterity
			SQLGetData(SHSTMT, 10, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;
			// equip_intelligence
			SQLGetData(SHSTMT, 11, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;

			ItemCount++;
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// Get Inventory 3 Items
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr3, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {

			// type(ItemID)
			SQLGetData(SHSTMT, 1, SQL_C_BINARY, &ItemBuffer[offset], 4, NULL);
			offset += 4;
			// iD
			SQLGetData(SHSTMT, 2, SQL_C_BINARY, &ItemBuffer[offset], 4, NULL);
			offset += 4;
			// attr
			SQLGetData(SHSTMT, 3, SQL_C_BINARY, &ItemBuffer[offset], 42, NULL);
			offset += 42;
			// inventory
			SQLGetData(SHSTMT, 4, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// slot
			SQLGetData(SHSTMT, 5, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// stack
			SQLGetData(SHSTMT, 6, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// rank
			SQLGetData(SHSTMT, 7, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// equip_level
			SQLGetData(SHSTMT, 8, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// equip_strength
			SQLGetData(SHSTMT, 9, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;
			// equip_dexterity
			SQLGetData(SHSTMT, 10, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;
			// equip_intelligence
			SQLGetData(SHSTMT, 11, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;

			ItemCount++;
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// Get Inventory 4 Items
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr4, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {

			// type(ItemID)
			SQLGetData(SHSTMT, 1, SQL_C_BINARY, &ItemBuffer[offset], 4, NULL);
			offset += 4;
			// iD
			SQLGetData(SHSTMT, 2, SQL_C_BINARY, &ItemBuffer[offset], 4, NULL);
			offset += 4;
			// attr
			SQLGetData(SHSTMT, 3, SQL_C_BINARY, &ItemBuffer[offset], 42, NULL);
			offset += 42;
			// inventory
			SQLGetData(SHSTMT, 4, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// slot
			SQLGetData(SHSTMT, 5, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// stack
			SQLGetData(SHSTMT, 6, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// rank
			SQLGetData(SHSTMT, 7, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// equip_level
			SQLGetData(SHSTMT, 8, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// equip_strength
			SQLGetData(SHSTMT, 9, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;
			// equip_dexterity
			SQLGetData(SHSTMT, 10, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;
			// equip_intelligence
			SQLGetData(SHSTMT, 11, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;

			ItemCount++;
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	// Get Inventory 5 Items
	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);
	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr5, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {

			// type(ItemID)
			SQLGetData(SHSTMT, 1, SQL_C_BINARY, &ItemBuffer[offset], 4, NULL);
			offset += 4;
			// iD
			SQLGetData(SHSTMT, 2, SQL_C_BINARY, &ItemBuffer[offset], 4, NULL);
			offset += 4;
			// attr
			SQLGetData(SHSTMT, 3, SQL_C_BINARY, &ItemBuffer[offset], 42, NULL);
			offset += 42;
			// inventory
			SQLGetData(SHSTMT, 4, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// slot
			SQLGetData(SHSTMT, 5, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// stack
			SQLGetData(SHSTMT, 6, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// rank
			SQLGetData(SHSTMT, 7, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// equip_level
			SQLGetData(SHSTMT, 8, SQL_C_BINARY, &ItemBuffer[offset], 1, NULL);
			offset += 1;
			// equip_strength
			SQLGetData(SHSTMT, 9, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;
			// equip_dexterity
			SQLGetData(SHSTMT, 10, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;
			// equip_intelligence
			SQLGetData(SHSTMT, 11, SQL_C_BINARY, &ItemBuffer[offset], 2, NULL);
			offset += 2;

			ItemCount++;
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	addrs = (DWORD)ItemBuffer + 0xC;
	*(reinterpret_cast<int*>(addrs)) = ItemCount;

	DBItemAddr = (DWORD)ItemBuffer;

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);

	return DBItemAddr;
}