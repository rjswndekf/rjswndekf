#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

int ITEMCOM_EX = 0x00451770;
int ITEMCOM_SEND_RET = 0x00451DDE;

unsigned char ITEMCOMEX[6] = {0};

/******* ASM Funs *******/
extern int SENDPACKET_FUN;

void ItemCombinationEX(int pDynamic, int pSendPacket)
{
	int addrs;
	int Result;
	int pSendData;

	pSendData = pSendPacket + 4;
	*(int*)(pSendData + 0x34) = 0;
	*(int*)(pSendData + 0x38) = 0;
	*(short*)(pSendData + 0x3C) = 0;

	Result = GetItemCombinationEX(pDynamic, pSendData);
	if (Result != 0)
	{
		addrs = (int)ITEMCOMEX;
		*(char*)addrs = (char)Result;
		*(int*)(addrs + 1 ) = 0;
		*(char*)(addrs + 5 ) = 0;
		SendPacketEX(pDynamic, 0x1484, (int)ITEMCOMEX, 0x6);
	}
}

int GetItemCombinationEX(int pDynamic, int pSendData)
{
	int Result;
	__asm mov eax,pSendData
	__asm push eax
	__asm mov ecx,pDynamic
	__asm call ITEMCOM_EX
	__asm mov Result, eax
	return Result;
}

void __declspec(naked) CombinationEXSend43()
{
	// PacketSize
	__asm push 0x43
	// PacketData
	__asm lea edx,dword ptr ss:[ebp-0x50]
	__asm push edx
	// PacketType
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm sub eax,0x4
	__asm movzx edx,word ptr ds:[eax]
	__asm push edx
	// This
	__asm mov ecx,dword ptr ss:[ebp-0x188]
	__asm call SENDPACKET_FUN
	__asm JMP ITEMCOM_SEND_RET
}

void __declspec(naked) CombinationEXSend6()
{
	// PacketSize
	__asm push 0x6
	// PacketData
	__asm lea ecx,dword ptr ss:[ebp-0x50]
	__asm push ecx
	// PacketType
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm sub eax,0x4
	__asm movzx edx,word ptr ds:[eax]
	__asm push edx
	// This
	__asm mov ecx,dword ptr ss:[ebp-0x18C]
	__asm call SENDPACKET_FUN
	__asm JMP ITEMCOM_SEND_RET
}
