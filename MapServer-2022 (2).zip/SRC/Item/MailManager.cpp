#include <RHItem.h>
//#include <MapFunctions.h>

using namespace std;

int GETMAILLIST_RET = 0x0041365C;

// RCM_MAP_POST_GET_MAILLIST 0x2602
void GetMailList()
{
	__asm mov ecx,dword ptr ss:[ebp+0xFFFF05EC]
	__asm mov edx,dword ptr ds:[ecx+0xC]
	__asm mov dword ptr ss:[ebp+0xFFFF0349],edx
	__asm cmp edx,0x100B
	__asm jne RET_TARGET
	__asm mov byte ptr ss:[ebp+0xFFFF0348],0x16
	__asm mov dword ptr ss:[ebp+0xFFFF034D],0x0

RET_TARGET:
	__asm jmp GETMAILLIST_RET
}
