#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

unsigned char ARRENDAL_TRANSMUTA[95] = {0};
unsigned char TRANSMUTA_MATERIALGR[65] = {0};
unsigned char TRANSMUTA_ITEMGR[65] = {0};

extern int WEAPONETRANSITION_ADDRS;
extern int WEAPONETRANSITION_SIZE;

// Packet 0x3004 Size 0x5F
void ArrendalTransmutation(int pDynamic, int pSendPacket)
{
	int addrs;
	int Result;
	int pSendData;

	pSendData = pSendPacket + 4;
	Result = GetArrendalTransmutation(pDynamic, pSendData);
	if (Result != 0)
	{
		addrs = (int)ARRENDAL_TRANSMUTA;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;
		SendPacketEX(pDynamic, 0x3004, (int)ARRENDAL_TRANSMUTA, 0x5F);
	}
}

int GetArrendalTransmutation(int pDynamic, int pSendData)
{
	int Result = 0;
	int addrs;
	int pPlayer;
	int CharID;
	int pThis;
	int pItemAttr;
	int pMaterialAttr;
	int pClientAttr;
	int ItemsOption;
	int MaterialOption;
	int MaterialValue;
	//int ClientOption;
	//int ClientValue;

	int ItemCheck = 0;
	int MaterialCheck = 0;
	int StoreCheck = 0;

	int ItemID;
	int nID;
	int Inventory;
	int Slot;

	int ItemIDMaterial;
	int nIDMaterial;
	int InventoryMaterial;
	int SlotMaterial;

	int ItemIDStore;
	int nIDStore;
	int InventoryStore;
	int SlotStore;

	int pItem = 0;
	int pItemMaterial = 0;
	int pItemStore = 0;
	
	int pTransmutationInfo;
	
	__int64 CurMoney = 0;
	__int64 Price = 0;

	int Rate = 0;
	int Chance = 0;
	int i;

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));

	if (pPlayer == 0) return 2;

	// Send Packet
	addrs = (DWORD)pSendData;
	ItemIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x4;
	nIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	InventoryMaterial = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x9;
	SlotMaterial = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)pSendData + 0xA;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xE;
	nID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x12;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x13;
	Slot = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)pSendData + 0x14;
	ItemIDStore = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x18;
	nIDStore = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x1C;
	InventoryStore = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x1D;
	SlotStore = *(reinterpret_cast<char*>(addrs));

	// Clinet Packet Init
	// (00 fail / 01 success)
	addrs = (int)ARRENDAL_TRANSMUTA + 0x59;
	*(reinterpret_cast<char*>(addrs)) = 0;
	// (00 Enable / 01 Disable Transmutation)
	addrs = (int)ARRENDAL_TRANSMUTA + 0x5B;
	*(reinterpret_cast<int*>(addrs)) = 1;
	// Current Money
	pThis = pPlayer + 0x1958;
	CurMoney = *(reinterpret_cast<__int64*>(pThis));
	addrs = (int)ARRENDAL_TRANSMUTA + 0x51;
	*(reinterpret_cast<__int64*>(addrs)) = CurMoney;

	// Check Money
	pTransmutationInfo = GetTransmutationInfo(ItemIDMaterial);
	if (pTransmutationInfo == 0) return 5;

	addrs = pTransmutationInfo + 0x10;
	Price = *(reinterpret_cast<__int64*>(addrs));

	addrs = pPlayer + 0x1958;
	CurMoney = *(reinterpret_cast<__int64*>(addrs));

	if (CurMoney < Price) return 2;

	// Sub Money
	pThis = pPlayer;
	PlayerSubMoney(pThis, (int)Price, 0, 0, 0);

	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);
	if (pItem == 0) return 5;

	// Check Item
	addrs = pItem + 0x24;
	ItemCheck = *(reinterpret_cast<int*>(addrs));
	if (ItemCheck != nID) return 5;

	pThis = pPlayer + 0xCC8;
	pItemMaterial = GetItem(pThis, InventoryMaterial, SlotMaterial);
	if (pItemMaterial == 0) return 5;

	// Check Material
	addrs = pItemMaterial + 0x24;
	MaterialCheck = *(reinterpret_cast<int*>(addrs));
	if (MaterialCheck != nIDMaterial) return 5;

	if (ItemIDStore != 0)
	{
		pThis = pPlayer + 0xCC8;
		pItemStore = GetItem(pThis, InventoryStore, SlotStore);
		if (pItemStore == 0) return 5;

		// Check Store
		addrs = pItemStore + 0x24;
		StoreCheck = *(reinterpret_cast<int*>(addrs));
		if (StoreCheck != nIDStore) return 5;
	}

	addrs = pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));
	addrs = (int)TRANSMUTA_MATERIALGR;
	*(reinterpret_cast<int*>(addrs)) = CharID;
	addrs = (int)TRANSMUTA_ITEMGR;
	*(reinterpret_cast<int*>(addrs)) = CharID;

	// Get Material Option
	addrs = (int)TRANSMUTA_MATERIALGR + 0x4;
	tagItemInit(addrs);
	addrs = (int)TRANSMUTA_MATERIALGR + 0x4;
	EpochItemBaseGetItemGR(pItemMaterial, addrs);

	// Get Item Option
	addrs = (int)TRANSMUTA_ITEMGR + 0x4;
	tagItemInit(addrs);
	addrs = (int)TRANSMUTA_ITEMGR + 0x4;
	EpochItemBaseGetItemGR(pItem, addrs);

	// Clinet Packet ItemGR
	addrs = (int)ARRENDAL_TRANSMUTA + 0x14;
	tagItemInit(addrs);
	addrs = (int)ARRENDAL_TRANSMUTA + 0x14;
	EpochItemBaseGetItemGR(pItem, addrs);

	pThis = pPlayer;
	Chance = BioticBaseGetRandom(pThis, 1000000);
	
	addrs = pTransmutationInfo + 0xC;
	Rate = *(reinterpret_cast<int*>(addrs));
	if (Rate > Chance) Result = 1;
	else Result = 0;

	if (Result == 1)
	{
		/************** Success **************/
		// Clean Item Option
		pItemAttr = (int)TRANSMUTA_ITEMGR + 0xC;
		pClientAttr = (int)ARRENDAL_TRANSMUTA + 0x1C;
		for( i = 0; i < 14; i++ )
		{
			addrs = (DWORD)pItemAttr;
			ItemsOption = *(reinterpret_cast<char*>(addrs));
			if ((ItemsOption != 0x4F) && (ItemsOption != 0x55) && (ItemsOption != 0x56) && (ItemsOption != 0))
			{
				ItemOptionSetType(pItem, ItemsOption, 0);
				addrs = (DWORD)pItemAttr;
				*(reinterpret_cast<char*>(addrs)) = 0;
				addrs = (DWORD)pItemAttr + 1;
				*(reinterpret_cast<unsigned short*>(addrs)) = 0;

				addrs = (DWORD)pClientAttr;
				*(reinterpret_cast<char*>(addrs)) = 0;
				addrs = (DWORD)pClientAttr + 1;
				*(reinterpret_cast<unsigned short*>(addrs)) = 0;
			}
			pItemAttr += 3;
			pClientAttr += 3;
		}

		// Setting Item Option
		// Item Option (ItemGR + 8)
		pMaterialAttr = (int)TRANSMUTA_MATERIALGR + 0xC;
		for( i = 0; i < 14; i++ )
		{
			addrs = (DWORD)pMaterialAttr;
			MaterialOption = *(reinterpret_cast<char*>(addrs));
			if ((MaterialOption != 0x4F) && (MaterialOption != 0x55) && (MaterialOption != 0x56) && (MaterialOption != 0))
			{
				addrs = (DWORD)pMaterialAttr + 1;
				MaterialValue = *(reinterpret_cast<unsigned short*>(addrs));

				ItemOptionSetType(pItem, MaterialOption, MaterialValue);
			}
			pMaterialAttr += 3;
		}

		// Clean Material Option
		pMaterialAttr = (int)TRANSMUTA_MATERIALGR + 0xC;
		for( i = 0; i < 14; i++ )
		{
			addrs = (DWORD)pMaterialAttr;
			MaterialOption = *(reinterpret_cast<char*>(addrs));
			if (MaterialOption != 0)
			{
				ItemOptionSetType(pItemMaterial, MaterialOption, 0);

				addrs = (DWORD)pMaterialAttr;
				*(reinterpret_cast<char*>(addrs)) = 0;
				addrs = (DWORD)pMaterialAttr + 1;
				*(reinterpret_cast<unsigned short*>(addrs)) = 0;
			}
			pMaterialAttr += 3;
		}

		// Get Item Option
		addrs = (int)TRANSMUTA_ITEMGR + 0x4;
		tagItemInit(addrs);
		addrs = (int)TRANSMUTA_ITEMGR + 0x4;
		EpochItemBaseGetItemGR(pItem, addrs);

		// Clinet Packet ItemGR
		addrs = (int)ARRENDAL_TRANSMUTA + 0x14;
		tagItemInit(addrs);
		addrs = (int)ARRENDAL_TRANSMUTA + 0x14;
		EpochItemBaseGetItemGR(pItem, addrs);

		// Send DB Packet
		SendPacketEX(0x7F23A0, 0x4A09, (int)TRANSMUTA_MATERIALGR, 0x41);
		SendPacketEX(0x7F23A0, 0x4A09, (int)TRANSMUTA_ITEMGR, 0x41);
	}

	// ItemStore
	if (pItemStore != 0)
	{
		// Remove ItemStore
		addrs = (int)ARRENDAL_TRANSMUTA + 0x5A;
		*(reinterpret_cast<char*>(addrs)) = 1;

		pThis = pPlayer + 0xCC8;
		RemoveItem(pThis, pItemStore);		

		// Fail
		if (Result == 0)
		{
			// Keep Material Item
			addrs = (int)ARRENDAL_TRANSMUTA;
			*(reinterpret_cast<int*>(addrs)) = 0;
			addrs = (int)ARRENDAL_TRANSMUTA + 0x4;
			*(reinterpret_cast<int*>(addrs)) = 0;
			addrs = (int)ARRENDAL_TRANSMUTA + 0x8;
			*(reinterpret_cast<char*>(addrs)) = 0;
			addrs = (int)ARRENDAL_TRANSMUTA + 0x9;
			*(reinterpret_cast<char*>(addrs)) = 0;
		}
		else
		{
			// Remove Material Item
			pThis = pPlayer + 0xCC8;
			RemoveItem(pThis, pItemMaterial);

			addrs = (int)ARRENDAL_TRANSMUTA;
			*(reinterpret_cast<int*>(addrs)) = ItemIDMaterial;
			addrs = (int)ARRENDAL_TRANSMUTA + 0x4;
			*(reinterpret_cast<int*>(addrs)) = nIDMaterial;
			addrs = (int)ARRENDAL_TRANSMUTA + 0x8;
			*(reinterpret_cast<char*>(addrs)) = (char)InventoryMaterial;
			addrs = (int)ARRENDAL_TRANSMUTA + 0x9;
			*(reinterpret_cast<char*>(addrs)) = (char)SlotMaterial;
		}
	}
	else
	{
		// Remove Material Item
		pThis = pPlayer + 0xCC8;
		RemoveItem(pThis, pItemMaterial);

		addrs = (int)ARRENDAL_TRANSMUTA;
		*(reinterpret_cast<int*>(addrs)) = ItemIDMaterial;
		addrs = (int)ARRENDAL_TRANSMUTA + 0x4;
		*(reinterpret_cast<int*>(addrs)) = nIDMaterial;
		addrs = (int)ARRENDAL_TRANSMUTA + 0x8;
		*(reinterpret_cast<char*>(addrs)) = (char)InventoryMaterial;
		addrs = (int)ARRENDAL_TRANSMUTA + 0x9;
		*(reinterpret_cast<char*>(addrs)) = (char)SlotMaterial;

		// No ItemStore
		addrs = (int)ARRENDAL_TRANSMUTA + 0x5A;
		*(reinterpret_cast<char*>(addrs)) = 0;
	}

	addrs = (int)ARRENDAL_TRANSMUTA + 0xA;
	*(reinterpret_cast<int*>(addrs)) = ItemIDStore;
	addrs = (int)ARRENDAL_TRANSMUTA + 0xE;
	*(reinterpret_cast<int*>(addrs)) = nIDStore;
	addrs = (int)ARRENDAL_TRANSMUTA + 0x12;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryStore;
	addrs = (int)ARRENDAL_TRANSMUTA + 0x13;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotStore;

	// Current Money
	pThis = pPlayer + 0x1958;
	CurMoney = *(reinterpret_cast<__int64*>(pThis));
	addrs = (int)ARRENDAL_TRANSMUTA + 0x51;
	*(reinterpret_cast<__int64*>(addrs)) = CurMoney;

	// (00 fail / 01 success)
	addrs = (int)ARRENDAL_TRANSMUTA + 0x59;
	*(reinterpret_cast<char*>(addrs)) = (char)Result;

	// (00 Enable / 01 Disable Transmutation)
	addrs = (int)ARRENDAL_TRANSMUTA + 0x5B;
	*(reinterpret_cast<int*>(addrs)) = 0;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x3004, (int)ARRENDAL_TRANSMUTA, 0x5F);

	return 0;
}

int GetTransmutationInfo(int ItemIDMaterial)
{
	int addrs;
	int MaxCount;
	int BinMaterialID;
	int Offset = 0;
	int pTransmutationInfo = 0;

	MaxCount = WEAPONETRANSITION_SIZE / 0x18;

	Offset = (DWORD)WEAPONETRANSITION_ADDRS;

	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x8;
		BinMaterialID = *(reinterpret_cast<int*>(addrs));
		if (BinMaterialID == ItemIDMaterial)
		{
			pTransmutationInfo = Offset;
			break;
		}
		else
		{
			Offset += 0x18;
		}
	}

	return pTransmutationInfo;
}
