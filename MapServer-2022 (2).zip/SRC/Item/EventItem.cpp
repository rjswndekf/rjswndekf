#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

int EVENTMOVE_RET = 0x0056DBB9;
int EVENTMOVE_ITEM;
int EVENTMOVE_INSITEM = 0x005771A0;

/******* ASM Funs *******/
extern int GETATTRIBUTE;


void EventItemSetOptionValue()
{
	__asm mov ecx,dword ptr ss:[ebp-0xC]
	__asm mov EVENTMOVE_ITEM,ecx

	SetItemBinOptionValue(EVENTMOVE_ITEM);

	// Send DBTask 0x4A09
	// pItem
	__asm mov eax,dword ptr ss:[ebp-0xC]
	__asm push eax
	// pInventory
	__asm mov ecx,dword ptr ss:[ebp-0x290]
	__asm call EVENTMOVE_INSITEM

	__asm push 0x4E
	__asm mov ecx,dword ptr ss:[ebp-0xC]
	__asm call GETATTRIBUTE

	__asm jmp EVENTMOVE_RET;
}

