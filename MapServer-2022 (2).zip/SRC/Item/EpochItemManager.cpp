#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

/**** Equip ****/
int EquipItem(int ToSlot, int pItem)
{
	int Result = 0;
	int addrs = 0;
	int pInventory;
	int CheckEquip = 0;
	int Equiped = 0;
	int ItemType = 0;
	int ToInventory = 0;
	int BagOffset = 0;
	int pBag = 0;

	__asm mov pInventory,ecx

	if (pItem != 0)
	{
		CheckEquip = GetItem(pInventory, 0, ToSlot);
		if (CheckEquip == 0)
		{
			CheckEquip = EquipAllow(pInventory, ToSlot, pItem);
			if (CheckEquip != 0)
			{
				Equiped = SetItem(pInventory, 0, ToSlot, pItem);
				if (Equiped != 0)
				{
					ItemType = GetAttribute(pItem, 0);
					if (ItemType == 28)
					{
						if ((ToSlot == 15) || (ToSlot == 16) || (ToSlot == 17) || (ToSlot == 29))
						{
							ToInventory = ToSlot - 13;
							if (ToInventory > 4 ) ToInventory = 5;

							BagOffset = ToInventory * 0x81C;

							addrs = (DWORD)pInventory + 0x4;
							pBag = *(reinterpret_cast<int*>(addrs));

							pBag += BagOffset;

							Equiped = InventorySlotInit(pBag, pItem);
							if (Equiped == 0)
							{
								ClearItem(pInventory, 0, ToSlot);
								Result = 0;
							}
							else
							{
								Result = 1;
							}
						}
					}
					else
					{
						Result = 1;
					}
				}
			}
		}
	}

	return Result;
}

/**** UnEquip ****/
int UnEquipItem(int FormSlot, int ToInventory, int ToSlot)
{
	int Result = 0;
	int addrs = 0;
	int pInventory;
	int pItemFormSlot = 0;
	int pItemToSlot = 0;
	int FormInventory = 0;
	int TargetInvCount = 0;
	int CheckUnEquip = 0;
	int SetTarget = 0;
	
	__asm mov pInventory,ecx
	
	pItemFormSlot = GetItem(pInventory, 0, FormSlot);
	
	if (pItemFormSlot != 0)
	{
		pItemToSlot = GetItem(pInventory, ToInventory, ToSlot);
		if (pItemToSlot == 0)
		{
			if ((FormSlot == 15)||(FormSlot == 16)||(FormSlot == 17)||(FormSlot == 29))
			{
				FormInventory = FormSlot - 13;
				if (FormInventory > 4 ) FormInventory = 5;

				TargetInvCount = GetCurCount(pInventory, FormInventory);
				if (TargetInvCount > 0)
				{
					return 0;
				}
				else
				{
					CheckUnEquip = ResetInventory(pInventory, FormInventory);
					if (CheckUnEquip == 0) return 0;
				}
			}

			SetTarget = SetItem(pInventory, ToInventory, ToSlot, pItemFormSlot);
			if (SetTarget != 0)
			{
				ClearItem(pInventory, 0, FormSlot);
				Result = 1;
			}
		}
	}

	return Result;
}

/*** Replace Equip ****/
int ReplaceEquipItem(int EquipSlot, int BagInventory, int BagSlot)
{
	int Result = 0;
	int addrs = 0;
	int pInventory;
	int pItemEquip = 0;
	int pItemUnEquip = 0;
	int CheckEquip = 0;
	int Equiped = 0;
	int UnEquiped = 0;
	
	__asm mov pInventory,ecx
	
	if ((EquipSlot == 15)||(EquipSlot == 16)||(EquipSlot == 17)||(EquipSlot == 29)) return 0;
	
	pItemUnEquip = GetItem(pInventory, 0, EquipSlot);
	if (pItemUnEquip != 0)
	{
		pItemEquip = GetItem(pInventory, BagInventory, BagSlot);
		if (pItemEquip != 0)
		{
			CheckEquip = EquipAllow(pInventory, EquipSlot, pItemEquip);
			if (CheckEquip != 0)
			{
				ClearItem(pInventory, 0, EquipSlot);
				ClearItem(pInventory, BagInventory, BagSlot);
				Equiped = SetItem(pInventory, 0, EquipSlot, pItemEquip);
				UnEquiped = SetItem(pInventory, BagInventory, BagSlot, pItemUnEquip);
				if ((Equiped == 1) && (UnEquiped == 1))
				{
					Result = 1;
				}
				else
				{
					ClearItem(pInventory, 0, EquipSlot);
					ClearItem(pInventory, BagInventory, BagSlot);
					SetItem(pInventory, 0, EquipSlot, pItemUnEquip);
					SetItem(pInventory, BagInventory, BagSlot, pItemEquip);
				}
			}
		}
	}
	return Result;
}

int EquipAllow(int pInventory, int Slot, int pItem)
{
	int Result = 0;
	int addrs = 0;
	int pPlayer;
	int CType = 0;
	int Race = 0;
	int CheckMallItem = 0;
	int MallItemDisable = 0;
	int ItemType = 0;
	int pItemScript = 0;
	int pItemWeaponScript = 0;
	int OptionGroup = 0;
	int ItemIDH = 0;
	int pItemShield = 0;
	int ItemShieldType = 0;
	int pItemWeapon = 0;
	int ItemWeaponType = 0;

	if (pItem != 0)
	{
		if (Slot > 29) return 0;
		
		addrs = (DWORD)pInventory + 0x68;
		CheckMallItem = *(reinterpret_cast<int*>(addrs));
		if (CheckMallItem != 0)
		{
			MallItemDisable = ItemOptionGetType(pItem, 0x40);
			if (MallItemDisable != 0) return 0;
		}
		ItemType = GetAttribute(pItem, 0);

		addrs = (DWORD)pItem + 0x1C;
		pItemScript = *(reinterpret_cast<int*>(addrs));

		addrs = (DWORD)pItemScript + 0xE8;
		OptionGroup = *(reinterpret_cast<int*>(addrs));
		
		switch(Slot)
		{
			// Slot 0 Battle: Helmet
			case 0:
			{
				if ((ItemType == 15)||(ItemType == 230)) Result = 1;
			}
			break;
			// Slot 1 Battle: Chestpiece
			case 1:
			{
				if ((ItemType == 13)||(ItemType == 228)) Result = 1;
			}
			break;
			// Slot 2 Battle: Bottom
			case 2:
			{
				if ((ItemType == 14)||(ItemType == 229)) Result = 1;
			}
			break;
			// Slot 3 Battle: Hand
			case 3:
			{
				if ((ItemType == 16)||(ItemType == 231)) Result = 1;
			}
			break;
			// Slot 4 Battle: Leggings
			case 4:
			{
				if ((ItemType == 17)||(ItemType == 232)) Result = 1;
			}
			break;
			// Slot 5 Battle: Weapon
			case 5:
			{
				addrs = (DWORD)pItem + 0x22;
				ItemIDH = *(reinterpret_cast<unsigned short*>(addrs));
				if (ItemIDH == 0x28)
				{
					pItemShield = GetItem(pInventory, 0, 6);
					if (pItemShield == 0)
					{
						Result = 1;
					}
					else
					{
						ItemShieldType = GetAttribute(pItemShield, 0);
						// Dagger
						if (ItemShieldType == 1)
						{
							// Slot5 Sword/Club/Axe
							if ((ItemType == 2)||(ItemType == 3)||(ItemType == 4)) Result = 1;
						}
						// Axe
						if (ItemShieldType == 4)
						{
							// Slot5 Dagger/Club/Axe
							if ((ItemType == 1)||(ItemType == 3)||(ItemType == 4)) Result = 1;
						}
						// Shield
						if (ItemShieldType == 18)
						{
							if (OptionGroup == 1) Result = 1;
						}
						// Guarder
						if (ItemShieldType == 253) Result = 1;
					}
				}
			}
			break;
			// Slot 6 Battle: Shield
			case 6:
			{
				// Dagger / Axe / Shield / Guarder
				if ((ItemType == 1)||(ItemType == 4)||(ItemType == 18)||(ItemType == 253))
				{
					pItemWeapon = GetItem(pInventory, 0, 5);
					if (pItemWeapon == 0)
					{
						Result = 1;
					}
					else
					{
						// Dagger
						if (ItemType == 1)
						{
							addrs = (DWORD)pInventory + 0x24;
							pPlayer = *(reinterpret_cast<int*>(addrs));
							addrs = (DWORD)pPlayer + 0x2C;
							CType = *(reinterpret_cast<int*>(addrs));
							Race = CType & 0xFF00;
							// Human
							if (Race = 0x100)
							{
								ItemWeaponType = GetAttribute(pItemWeapon, 0);
								// Slot5 Weapon Sword / Club / Axe
								if ((ItemWeaponType == 2)||(ItemWeaponType == 3)||(ItemWeaponType == 4)) Result = 1;
							}
						}
						// Axe
						if (ItemType == 4)
						{
							addrs = (DWORD)pInventory + 0x24;
							pPlayer = *(reinterpret_cast<int*>(addrs));
							addrs = (DWORD)pPlayer + 0x2C;
							CType = *(reinterpret_cast<int*>(addrs));
							Race = CType & 0xFF00;
							// Aesir
							if (Race = 0x9000)
							{
								ItemWeaponType = GetAttribute(pItemWeapon, 0);
								// Slot5 Weapon Dagger / Club / Axe
								if ((ItemWeaponType == 1)||(ItemWeaponType == 3)||(ItemWeaponType == 4)) Result = 1;
							}
						}
						// Shield
						if (ItemType == 18)
						{
							addrs = (DWORD)pItemWeapon + 0x1C;
							pItemWeaponScript = *(reinterpret_cast<int*>(addrs));
							addrs = (DWORD)pItemWeaponScript + 0xE8;
							OptionGroup = *(reinterpret_cast<int*>(addrs));
							if (OptionGroup == 1) Result = 1;
						}
						// Guarder
						if (ItemType == 253) Result = 1;
					}
				}
			}
			break;
			// Slot 7 Costume: Glasses
			case 7:
			{
				if ((ItemType == 22)||(ItemType == 97)) Result = 1;
			}
			break;
			// Slot 8 Costume: Earrings
			case 8:
			{
				if (ItemType == 23) Result = 1;
			}
			break;
			// Slot 9 Battle: Accessories
			case 9:
			{
				if ((ItemType == 19)||(ItemType == 20)||(ItemType == 21)||(ItemType == 95)||(ItemType == 215)) Result = 1;
			}
			break;
			// Slot 10 Battle: Accessories
			case 10:
			{
				if ((ItemType == 19)||(ItemType == 20)||(ItemType == 21)||(ItemType == 95)||(ItemType == 215)) Result = 1;
			}
			break;
			// Slot 11 Battle: Accessories
			case 11:
			{
				if ((ItemType == 19)||(ItemType == 20)||(ItemType == 21)||(ItemType == 95)||(ItemType == 215)) Result = 1;
			}
			break;
			// Slot 12 Battle: Accessories
			case 12:
			{
				if ((ItemType == 19)||(ItemType == 20)||(ItemType == 21)||(ItemType == 95)||(ItemType == 215)) Result = 1;
			}
			break;
			// Slot 13 Battle: Arrow / Axe / Dart
			case 13:
			{
				if ((ItemType == 29)||(ItemType == 30)||(ItemType == 34)||(ItemType == 167)||(ItemType == 219)||(ItemType == 220)) Result = 1;
			}
			break;
			// Slot 14 Costume: Costume
			case 14:
			{
				addrs = (DWORD)pItem + 0x22;
				ItemIDH = *(reinterpret_cast<unsigned short*>(addrs));
				if (ItemIDH == 0x43) Result = 1;
			}
			break;
			// Slot 15 Bag2
			case 15:
			{
				if (ItemType == 28) Result = 1;
			}
			break;
			// Slot 16 Bag3
			case 16:
			{
				if (ItemType == 28) Result = 1;
			}
			break;
			// Slot 17 Bag4
			case 17:
			{
				if (ItemType == 28) Result = 1;
			}
			break;
			// Slot 18 Gathering: Helmet
			case 18:
			{
				if ((ItemType == 135)||(ItemType == 136)||(ItemType == 137)||(ItemType == 138)||(ItemType == 139)) Result = 1;
			}
			break;
			// Slot 19 Gathering: Costume
			case 19:
			{
				if ((ItemType == 135)||(ItemType == 136)||(ItemType == 137)||(ItemType == 138)||(ItemType == 139)) Result = 1;
			}
			break;
			// Slot 20 Gathering: Boots
			case 20:
			{
				if ((ItemType == 135)||(ItemType == 136)||(ItemType == 137)||(ItemType == 138)||(ItemType == 139)) Result = 1;
			}
			break;
			// Slot 21 Gathering: Tools
			case 21:
			{
				if ((ItemType == 135)||(ItemType == 136)||(ItemType == 137)||(ItemType == 138)||(ItemType == 139)) Result = 1;
			}
			break;
			// Slot 22 Gathering: Gloves
			case 22:
			{
				if ((ItemType == 135)||(ItemType == 136)||(ItemType == 137)||(ItemType == 138)||(ItemType == 139)) Result = 1;
			}
			break;
			// Slot 23 Produce: Helmet
			case 23:
			{
				if ((ItemType == 140)||(ItemType == 141)||(ItemType == 142)||(ItemType == 143)||(ItemType == 144)) Result = 1;
			}
			break;
			// Slot 24 Produce: Costume
			case 24:
			{
				if ((ItemType == 140)||(ItemType == 141)||(ItemType == 142)||(ItemType == 143)||(ItemType == 144)) Result = 1;
			}
			break;
			// Slot 25 Produce: Boots
			case 25:
			{
				if ((ItemType == 140)||(ItemType == 141)||(ItemType == 142)||(ItemType == 143)||(ItemType == 144)) Result = 1;
			}
			break;
			// Slot 26 Produce: Tools
			case 26:
			{
				if ((ItemType == 140)||(ItemType == 141)||(ItemType == 142)||(ItemType == 143)||(ItemType == 144)) Result = 1;
			}
			break;
			// Slot 27 Produce: Gloves
			case 27:
			{
				if ((ItemType == 140)||(ItemType == 141)||(ItemType == 142)||(ItemType == 143)||(ItemType == 144)) Result = 1;
			}
			break;
			// Slot 28 Costume: Helmet
			case 28:
			{
				if (ItemType == 109) Result = 1;
			}
			break;
			// Slot 29 Bag5
			case 29:
			{
				if (ItemType == 28) Result = 1;
			}
			break;
		}
	}

	return Result;
}

// Cal Equip Property
void CalEquipProperty(int Slot, int pItem, int Active)
{
	int addrs;
	int pInventory;
	int pPlayer = 0;
	int ItemType = 0;
	int ItemID = 0;
	int Value = 0;
	int pValue = 0;
	int CalValue = 0;
	int OptionType = 0;
	int nAttributeTyp = 0;
	int pEquipInfo = 0;
	int ReinforceType = 0;
	int Reinforce = 0;
	float CalValueFp = 0.0;
	float ClcFp = 0.0;

	__asm mov pInventory,ecx
	
	ItemType = GetAttribute(pItem, 0x0);
	ReinforceType = GetReinforceType(pItem);

	if (Slot < 30)
	{
		switch(Slot)
		{
			// Slot 0 Battle: Helmet
			case 0:
			// Slot 1 Battle: Chestpiece
			case 1:
			// Slot 2 Battle: Bottom
			case 2:
			// Slot 3 Battle: Hand
			case 3:
			// Slot 4 Battle: Leggings
			case 4:
			{
				addrs = (DWORD)pInventory + 0x24;
				pPlayer = *(reinterpret_cast<int*>(addrs));

				// IAT_ATTACK_RANGE
				CalValue = GetAttribute(pItem, 0x10);
				CalItemOption(pInventory, 0x8, CalValue, Active);
				// IAT_MISS
				CalValue = GetAttribute(pItem, 0x11);
				CalItemOption(pInventory, 0x9, CalValue, Active);
				// IAT_INVENTORY
				CalValue = GetAttribute(pItem, 0x12);
				CalItemOption(pInventory, 0xA, CalValue, Active);
				// IAT_SLOT
				CalValue = GetAttribute(pItem, 0x13);
				CalItemOption(pInventory, 0xB, CalValue, Active);

				// Cal Option Value
				for(int i = 1; i < 124; i++ )
				{
					CalValue = ItemOptionGetType(pItem, i);
					if (CalValue > 0)
					{
						ItemCalQualities(pInventory, i, CalValue, Active);
					}
				}

				// IAT_DEFENCE
				Value = GetAttribute(pItem, 0x14);
				CalValue = GetPlayerCalValue(pPlayer, Value);
				CalItemOption(pInventory, 0x1, CalValue, Active);

				CalValue = GetCTypeCalValue(pPlayer, Value);
				CalItemOption(pInventory, 0x2, CalValue, Active);

				addrs = (DWORD)pItem + 0x20;
				ItemID = *(reinterpret_cast<unsigned int*>(addrs));
				pEquipInfo = GetEquipInfo(ItemID);
				if (pEquipInfo != 0)
				{
					// IOT_ALL_DEFENCE_REINFORCED
					Reinforce = ItemOptionGetType(pItem, ReinforceType);
					if (Reinforce != 0)
					{
						addrs = (DWORD)pEquipInfo + 0x18 + (Reinforce * 4);
						CalValue = *(reinterpret_cast<int*>(addrs));
						addrs = (DWORD)pEquipInfo + 0x18;
						nAttributeTyp = *(reinterpret_cast<int*>(addrs));
						OptionType = GetItemOptionType(nAttributeTyp, 0);
						CalItemOption(pInventory, OptionType, CalValue, Active);
					}
				}

				CalEquipOption(pInventory, pItem, Slot, Active, 6);
			}
			break;
			// Slot 5 Battle: Weapon
			case 5:
			{
				// IAT_ATTACK_RANGE
				CalValue = GetAttribute(pItem, 0x10);
				CalItemOption(pInventory, 0x8, CalValue, Active);
				// IAT_MISS
				CalValue = GetAttribute(pItem, 0x11);
				CalItemOption(pInventory, 0x9, CalValue, Active);
				// IAT_INVENTORY
				CalValue = GetAttribute(pItem, 0x12);
				CalItemOption(pInventory, 0xA, CalValue, Active);
				// IAT_SLOT
				CalValue = GetAttribute(pItem, 0x13);
				CalItemOption(pInventory, 0xB, CalValue, Active);

				// Cal Option Value
				for(int i = 1; i < 124; i++ )
				{
					CalValue = ItemOptionGetType(pItem, i);
					if (CalValue > 0)
					{
						ItemCalQualities(pInventory, i, CalValue, Active);
					}
				}

				// IAT_DAMAGE
				CalValue = GetAttribute(pItem, 0xE);
				CalItemOption(pInventory, 0x0, CalValue, Active);
				// IAT_ATTACK_SPEED
				CalValue = GetAttribute(pItem, 0xF);
				CalItemOption(pInventory, 0x5, CalValue, Active);

				addrs = (DWORD)pItem + 0x20;
				ItemID = *(reinterpret_cast<unsigned int*>(addrs));
				pEquipInfo = GetEquipInfo(ItemID);
				if (pEquipInfo != 0)
				{
					// IOT_ALL_ATTACK_REINFORCED
					Reinforce = ItemOptionGetType(pItem, ReinforceType);
					if (Reinforce != 0)
					{
						addrs = (DWORD)pEquipInfo + 0x18 + (Reinforce * 4);
						CalValue = *(reinterpret_cast<int*>(addrs));
						addrs = (DWORD)pEquipInfo + 0x18;
						nAttributeTyp = *(reinterpret_cast<int*>(addrs));
						OptionType = GetItemOptionType(nAttributeTyp, 0);
						CalItemOption(pInventory, OptionType, CalValue, Active);
					}
				}

				CalEquipOption(pInventory, pItem, Slot, Active, 6);
			}
			break;
			// Slot 6 Battle: Shield
			case 6:
			{
				addrs = (DWORD)pInventory + 0x24;
				pPlayer = *(reinterpret_cast<int*>(addrs));

				// Dagger
				if (ItemType == 1)
				{
					// IAT_DAMAGE
					CalValue = GetAttribute(pItem, 0xE);
					ClcFp = (float)CalValue;
					CalValueFp = ClcFp * 0.2;
					CalValue = (int)CalValueFp;
					CalItemOption(pInventory, 0x0, CalValue, Active);

					addrs = (DWORD)pItem + 0x20;
					ItemID = *(reinterpret_cast<unsigned int*>(addrs));
					pEquipInfo = GetEquipInfo(ItemID);
					if (pEquipInfo != 0)
					{
						// IOT_ALL_ATTACK_REINFORCED
						Reinforce = ItemOptionGetType(pItem, ReinforceType);
						if (Reinforce != 0)
						{
							addrs = (DWORD)pEquipInfo + 0x18 + (Reinforce * 4);
							CalValue = *(reinterpret_cast<int*>(addrs));
							addrs = (DWORD)pEquipInfo + 0x18;
							nAttributeTyp = *(reinterpret_cast<int*>(addrs));
							OptionType = GetItemOptionType(nAttributeTyp, 0);
							CalItemOption(pInventory, OptionType, CalValue, Active);
						}
					}

					for(int j = 1; j < 124; j++ )
					{
						CalValue = ItemOptionGetType(pItem, j);
						ClcFp = (float)CalValue;
						CalValueFp = ClcFp * 0.5;
						if (CalValueFp > 0.0)
						{
							if (CalValueFp < 1.0) CalValueFp = 1.0;
							CalValue = (int)CalValueFp;

							ItemCalQualities(pInventory, j, CalValue, Active);
						}
					}

					addrs = 0x7F1CAC;
					pValue = *(reinterpret_cast<int*>(addrs));
					addrs = pValue + 0x9C;
					CalValue = *(reinterpret_cast<int*>(addrs));
					CalItemOption(pInventory, 0x17, CalValue, Active);

					CalEquipOption(pInventory, pItem, Slot, Active, 6);
				}

				// Axe
				if (ItemType == 4)
				{
					// IAT_DAMAGE
					CalValue = GetAttribute(pItem, 0xE);
					ClcFp = (float)CalValue;
					CalValueFp = ClcFp * 0.5;
					CalValue = (int)CalValueFp;
					CalItemOption(pInventory, 0x0, CalValue, Active);

					addrs = (DWORD)pItem + 0x20;
					ItemID = *(reinterpret_cast<unsigned int*>(addrs));
					pEquipInfo = GetEquipInfo(ItemID);
					if (pEquipInfo != 0)
					{
						// IOT_ALL_ATTACK_REINFORCED
						Reinforce = ItemOptionGetType(pItem, ReinforceType);
						if (Reinforce != 0)
						{
							addrs = (DWORD)pEquipInfo + 0x18 + (Reinforce * 4);
							CalValue = *(reinterpret_cast<int*>(addrs));
							addrs = (DWORD)pEquipInfo + 0x18;
							nAttributeTyp = *(reinterpret_cast<int*>(addrs));
							OptionType = GetItemOptionType(nAttributeTyp, 0);
							CalItemOption(pInventory, OptionType, CalValue, Active);
						}
					}

					for(int j = 1; j < 124; j++ )
					{
						CalValue = ItemOptionGetType(pItem, j);
						ClcFp = (float)CalValue;
						CalValueFp = ClcFp * 0.5;
						if (CalValueFp > 0.0)
						{
							if (CalValueFp < 1.0) CalValueFp = 1.0;
							CalValue = (int)CalValueFp;

							ItemCalQualities(pInventory, j, CalValue, Active);
						}
					}

					addrs = 0x7F1CAC;
					pValue = *(reinterpret_cast<int*>(addrs));
					addrs = pValue + 0x9C;
					CalValue = *(reinterpret_cast<int*>(addrs));
					CalItemOption(pInventory, 0x17, CalValue, Active);

					CalEquipOption(pInventory, pItem, Slot, Active, 6);
				}

				// Shield / Guarder
				if ((ItemType == 18)||(ItemType == 253))
				{
					// IAT_ATTACK_RANGE
					CalValue = GetAttribute(pItem, 0x10);
					CalItemOption(pInventory, 0x8, CalValue, Active);
					// IAT_MISS
					CalValue = GetAttribute(pItem, 0x11);
					CalItemOption(pInventory, 0x9, CalValue, Active);
					// IAT_INVENTORY
					CalValue = GetAttribute(pItem, 0x12);
					CalItemOption(pInventory, 0xA, CalValue, Active);
					// IAT_SLOT
					CalValue = GetAttribute(pItem, 0x13);
					CalItemOption(pInventory, 0xB, CalValue, Active);

					// Cal Option Value
					for(int i = 1; i < 124; i++ )
					{
						CalValue = ItemOptionGetType(pItem, i);
						if (CalValue > 0)
						{
							ItemCalQualities(pInventory, i, CalValue, Active);
						}
					}

					// IAT_DEFENCE
					Value = GetAttribute(pItem, 0x14);
					CalValue = GetPlayerCalValue(pPlayer, Value);
					CalItemOption(pInventory, 0x3, CalValue, Active);

					CalValue = GetCTypeCalValue(pPlayer, Value);
					CalItemOption(pInventory, 0x4, CalValue, Active);

					addrs = (DWORD)pItem + 0x20;
					ItemID = *(reinterpret_cast<unsigned int*>(addrs));
					pEquipInfo = GetEquipInfo(ItemID);
					if (pEquipInfo != 0)
					{
						// IOT_ALL_DEFENCE_REINFORCED
						Reinforce = ItemOptionGetType(pItem, ReinforceType);

						if (Reinforce != 0)
						{
							addrs = (DWORD)pEquipInfo + 0x18 + (Reinforce * 4);
							CalValue = *(reinterpret_cast<int*>(addrs));
							addrs = (DWORD)pEquipInfo + 0x18;
							nAttributeTyp = *(reinterpret_cast<int*>(addrs));
							OptionType = GetItemOptionType(nAttributeTyp, 0);
							CalItemOption(pInventory, OptionType, CalValue, Active);
						}
					}

					CalEquipOption(pInventory, pItem, Slot, Active, 6);
				}
			}
			break;

			// Slot 7 Costume: Glasses
			case 7:
			// Slot 8 Costume: Earrings
			case 8:
			// Slot 9 Battle: Accessories
			case 9:
			// Slot 10 Battle: Accessories
			case 10:
			// Slot 11 Battle: Accessories
			case 11:
			// Slot 12 Battle: Accessories
			case 12:
			{
				// IAT_ATTACK_RANGE
				CalValue = GetAttribute(pItem, 0x10);
				CalItemOption(pInventory, 0x8, CalValue, Active);
				// IAT_MISS
				CalValue = GetAttribute(pItem, 0x11);
				CalItemOption(pInventory, 0x9, CalValue, Active);
				// IAT_INVENTORY
				CalValue = GetAttribute(pItem, 0x12);
				CalItemOption(pInventory, 0xA, CalValue, Active);
				// IAT_SLOT
				CalValue = GetAttribute(pItem, 0x13);
				CalItemOption(pInventory, 0xB, CalValue, Active);

				// Cal Option Value
				for(int i = 1; i < 124; i++ )
				{
					CalValue = ItemOptionGetType(pItem, i);
					if (CalValue > 0)
					{
						ItemCalQualities(pInventory, i, CalValue, Active);
					}
				}

				CalEquipOption(pInventory, pItem, Slot, Active, 4);
			}
			break;

			// Slot 13 Battle: Arrow / Axe / Dart
			case 13:
			{
				// IAT_ATTACK_RANGE
				CalValue = GetAttribute(pItem, 0x10);
				CalItemOption(pInventory, 0x8, CalValue, Active);
				// IAT_MISS
				CalValue = GetAttribute(pItem, 0x11);
				CalItemOption(pInventory, 0x9, CalValue, Active);
				// IAT_INVENTORY
				CalValue = GetAttribute(pItem, 0x12);
				CalItemOption(pInventory, 0xA, CalValue, Active);
				// IAT_SLOT
				CalValue = GetAttribute(pItem, 0x13);
				CalItemOption(pInventory, 0xB, CalValue, Active);

				// Cal Option Value
				for(int i = 1; i < 124; i++ )
				{
					CalValue = ItemOptionGetType(pItem, i);
					if (CalValue > 0)
					{
						ItemCalQualities(pInventory, i, CalValue, Active);
					}
				}

				// IAT_DAMAGE
				CalValue = GetAttribute(pItem, 0xE);
				CalItemOption(pInventory, 0x6, CalValue, Active);
				//CalItemOption(pInventory, 0x14, CalValue, Active);
				//CalItemOption(pInventory, 0x15, CalValue, Active);

			}
			break;

			// Slot 14 Costume: Costume
			case 14:
			// Slot 28 Costume: Helmet
			case 28:
			{
				// IAT_ATTACK_RANGE
				CalValue = GetAttribute(pItem, 0x10);
				CalItemOption(pInventory, 0x8, CalValue, Active);
				// IAT_MISS
				CalValue = GetAttribute(pItem, 0x11);
				CalItemOption(pInventory, 0x9, CalValue, Active);
				// IAT_INVENTORY
				CalValue = GetAttribute(pItem, 0x12);
				CalItemOption(pInventory, 0xA, CalValue, Active);
				// IAT_SLOT
				CalValue = GetAttribute(pItem, 0x13);
				CalItemOption(pInventory, 0xB, CalValue, Active);

				// Cal Option Value
				for(int i = 1; i < 124; i++ )
				{
					CalValue = ItemOptionGetType(pItem, i);
					if (CalValue > 0)
					{
						ItemCalQualities(pInventory, i, CalValue, Active);
					}
				}

				// IAT_FISHTOOL_PROBVALUE
				CalValue = GetAttribute(pItem, 0x3D);
				CalItemOption(pInventory, 0x26, CalValue, Active);
				// IAT_ARMOR_DEFENCE_UNAVAILABLE
				CalValue = GetAttribute(pItem, 0x4C);
				CalItemOption(pInventory, 0x23, CalValue, Active);
				if (CalValue == 0)
				{
					CalEquipOption(pInventory, pItem, Slot, Active, 5);
				}
			}
			break;

			// Slot 15 Bag2
			case 15:
			// Slot 16 Bag3
			case 16:
			// Slot 17 Bag4
			case 17:
			// Slot 29 Bag5
			case 29:
			{
				// IAT_ATTACK_RANGE
				CalValue = GetAttribute(pItem, 0x10);
				CalItemOption(pInventory, 0x8, CalValue, Active);
				// IAT_MISS
				CalValue = GetAttribute(pItem, 0x11);
				CalItemOption(pInventory, 0x9, CalValue, Active);
				// IAT_INVENTORY
				CalValue = GetAttribute(pItem, 0x12);
				CalItemOption(pInventory, 0xA, CalValue, Active);
				// IAT_SLOT
				CalValue = GetAttribute(pItem, 0x13);
				CalItemOption(pInventory, 0xB, CalValue, Active);

				// Cal Option Value
				for(int i = 1; i < 124; i++ )
				{
					CalValue = ItemOptionGetType(pItem, i);
					if (CalValue > 0)
					{
						ItemCalQualities(pInventory, i, CalValue, Active);
					}
				}

				// IAT_MAX_WEIGHT
				CalValue = GetAttribute(pItem, 0x33);
				CalItemOption(pInventory, 0x16, CalValue, Active);

			}
			break;
		}
	}
}

// Cal Equip Option
void CalEquipOption(int pInventory, int pItem, int Slot, int Active, int MaxAttribute)
{
	int addrs;
	int ItemType = 0;
	int pItemScript = 0;
	int nAttributeType = 0;
	int Value = 0;
	int CalValue = 0;
	int AddValue = 0;
	int OptionType = 0;
	float CalValueFp = 0.0;
	float ClcFp = 0.0;
	int ItemID;
	int pEquipInfo;
	int ReinforceType = 0;
	int Reinforce = 0;
	//int pInventory;

	//__asm mov pInventory,ecx

	ItemType = GetAttribute(pItem, 0);
	ReinforceType = GetReinforceType(pItem);

	if ((ItemType > 0) && (ItemType < 19)||(ItemType > 227) && (ItemType < 236)||(ItemType == 22)||(ItemType == 23)|| \
		(ItemType == 85)||(ItemType == 88)||(ItemType == 95)||(ItemType == 96)||(ItemType == 97)||(ItemType == 109)|| \
		(ItemType == 117)||(ItemType == 253))
	{
		for(int i = 0; i < MaxAttribute; i++ )
		{
			addrs = (DWORD)pItem + 0x1C;
			pItemScript = *(reinterpret_cast<int*>(addrs));

			addrs = (DWORD)pItemScript + 0x264 + (i * 2);
			nAttributeType = *(reinterpret_cast<unsigned short*>(addrs));
			if (nAttributeType != 0xFFFF)
			{
				CalValue = GetAttribute(pItem, nAttributeType);
				if (CalValue > 0)
				{
					OptionType = GetItemOptionType(nAttributeType, 0);
					if (OptionType != -1)
					{
						if (Slot == 6)
						{
							ItemType = GetAttribute(pItem, 0);
							if ((ItemType == 1)||(ItemType == 4))
							{
								ClcFp = (float)CalValue;
								CalValueFp = ClcFp * 0.5;
								if (CalValueFp < 1.0) CalValueFp = 1.0;
								CalValue = (int)CalValueFp;
							}
						}

						// Bin Attribute Vaule Addon
						addrs = (DWORD)pItem + 0x20;
						ItemID = *(reinterpret_cast<unsigned int*>(addrs));
						pEquipInfo = GetEquipInfo(ItemID);
						if (pEquipInfo != 0)
						{
							Reinforce = ItemOptionGetType(pItem, ReinforceType);
							if (Reinforce != 0)
							{
								addrs = (DWORD)pEquipInfo + 0x18 + (Reinforce * 4);
								AddValue = *(reinterpret_cast<int*>(addrs));
								CalValue += AddValue;
							}
						}

						CalItemOption(pInventory, OptionType, CalValue, Active);
					}
				}
			}
		}
	}
}

// Aesir Race Equip Patch
void PlayerEquipItemCheck()
{
	__asm or eax,dword ptr ss:[ebp-0xA8]
	__asm cmp eax,0x179000
	__asm jb RET_TARGET
	__asm sub eax,0x8F00

RET_TARGET:
	__asm mov dword ptr ss:[ebp-0x10],eax
	__asm mov ecx,0x00713AB8
	__asm jmp ecx
}

void RaceEquipItemCheck()
{
	__asm mov eax,dword ptr ss:[ebp-0xC]
	__asm cmp eax,0x39044
	__asm jb OLD_CLASS
	__asm mov eax,0x005682BA
	__asm jmp eax

OLD_CLASS:
	__asm and eax,0xFFFF0000
	__asm mov edx,0x00568278
	__asm jmp edx
}
