#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

unsigned char ARRENDAL_EVOLUTION[76] = {0};
unsigned char ITEMGR_ARRENDAL_EVOLUTION[65] = {0};

extern int WEAPONEVOLUTION_ADDRS;
extern int WEAPONEVOLUTION_SIZE;

// Packet 0x3003 Size 0x4C
void ArrendalEvolution(int pDynamic, int pSendPacket)
{
	int result;
	int addrs;
	int pSendData;
	pSendData = pSendPacket + 4;

	result = GetArrendalEvolution(pDynamic, pSendData);
	if (result != 0)
	{
		addrs = (int)ARRENDAL_EVOLUTION;
		*(reinterpret_cast<char*>(addrs)) = (char)result;
		SendPacket(pDynamic, 0x3003, (int)ARRENDAL_EVOLUTION, 0x1);
	}
}

int GetArrendalEvolution(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int pThis;
	int CharID = 0;

	unsigned int ItemID;
	unsigned int nID;
	int Inventory;
	int Slot;

	unsigned int ItemIDMeteria;
	unsigned int nIDMeteria;
	int InventoryMeteria;
	int SlotMeteria;

	int pItem;
	int pItemMeteria;
	int pNewItem;

	int pWeaponInfo = 0;
	float ArendaExpRate = 0.0;
	int IsEvolution = 0;

	int Level = 0;
	int UpLevel = 0;
	unsigned int UpItemID = 0;

	int pAttribute;
	int AttributeType;
	int AttributeValue;

	int MeteriaCheck = 0;
	int SuccessRate = 0;
	int NeedReinforce = 0;
	int CurReinforce = 0;
	int Chance;

	unsigned char NEWITEM[8] = {0};
	unsigned char STAMP[8] = {0};

	addrs = pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 1;

	addrs = pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));

	addrs = pSendData;
	ItemIDMeteria = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pSendData + 0x4;
	nIDMeteria = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pSendData + 0x8;
	InventoryMeteria = *(reinterpret_cast<char*>(addrs));
	addrs = pSendData + 0x9;
	SlotMeteria = *(reinterpret_cast<char*>(addrs));

	addrs = pSendData + 0xA;
	ItemID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pSendData + 0xE;
	nID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pSendData + 0x12;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = pSendData + 0x13;
	Slot = *(reinterpret_cast<char*>(addrs));

	pThis = pPlayer;
	ArendaExpRate = GetArrendalExpRate(pThis, ItemID);
	if (ArendaExpRate < 100.0) return 2;

	pWeaponInfo = GetItemBinScriptInfo(ItemID);
	addrs = pWeaponInfo + 0x27C;
	Level = *(reinterpret_cast<int*>(addrs));
	addrs = pWeaponInfo + 0x290;
	UpItemID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pWeaponInfo + 0x280;
	IsEvolution = *(reinterpret_cast<int*>(addrs));
	if (IsEvolution == 0) return 3;

	ItemWeaponEvolution(ItemID, ItemIDMeteria, MeteriaCheck, SuccessRate, NeedReinforce);
	if (MeteriaCheck == 0) return 4;

	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);

	pThis = pPlayer + 0xCC8;
	pItemMeteria = GetItem(pThis, InventoryMeteria, SlotMeteria);

	CurReinforce = ItemOptionGetType(pItem, 0x55);
	if (CurReinforce < NeedReinforce) return 5;

	// Clean Meteria
	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemMeteria);

	// GetItemGR
	addrs = (int)ARRENDAL_EVOLUTION + 0xA;
	tagItemInit(addrs);
	addrs = (int)ARRENDAL_EVOLUTION + 0xA;
	EpochItemBaseGetItemGR(pItem, addrs);

	// Create Packet
	addrs = (int)ARRENDAL_EVOLUTION;
	*(reinterpret_cast<unsigned int*>(addrs)) = ItemIDMeteria;
	addrs = (int)ARRENDAL_EVOLUTION + 0x4;
	*(reinterpret_cast<unsigned int*>(addrs)) = nIDMeteria;
	addrs = (int)ARRENDAL_EVOLUTION + 0x8;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryMeteria;
	addrs = (int)ARRENDAL_EVOLUTION + 0x9;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotMeteria;

	// Success 1 / Fail 0
	addrs = (int)ARRENDAL_EVOLUTION + 0x47;
	*(reinterpret_cast<char*>(addrs)) = 0;

	addrs = (int)ARRENDAL_EVOLUTION + 0x48;
	//ArendaExpRate = 0.0;
	*(reinterpret_cast<int*>(addrs)) = 0;

	pThis = pPlayer;
	Chance = BioticBaseGetRandom(pThis, 1000000);
	if (SuccessRate > Chance)
	{
		/************** Success **************/
		/*** Evolution Arrendal ***/
		addrs = (int)ITEMGR_ARRENDAL_EVOLUTION + 0x4;
		tagItemInit(addrs);
		addrs = (int)ITEMGR_ARRENDAL_EVOLUTION + 0x4;
		EpochItemBaseGetItemGR(pItem, addrs);

		pThis = pPlayer + 0xCC8;
		RemoveItem(pThis, pItem);

		UpLevel = Level + 1;

		pThis = pPlayer;
		UpgradeTrinityWeaponInfo(pThis, nID, ItemID, 0);

		addrs = (int)NEWITEM;
		*(reinterpret_cast<unsigned int*>(addrs)) = UpItemID;
		addrs = (int)NEWITEM + 0x4;
		*(reinterpret_cast<unsigned int*>(addrs)) = nID;

		pNewItem = CreateItem((int)NEWITEM, 1);

		GetItemStamp(pNewItem, (int)STAMP);

		pThis = pPlayer + 0xCC8;
		AddItem(pThis, pNewItem, Inventory, Slot, 0);

		pThis = pPlayer;
		TimerItemManager(pThis, pNewItem, (int)STAMP);

		// Setting Item Attribute
		pAttribute = (int)ITEMGR_ARRENDAL_EVOLUTION + 0xC;
		for(int i = 0; i < 14; i++ )
		{
			addrs = pAttribute + (i * 3);
			AttributeType = *(reinterpret_cast<char*>(addrs));
			if (AttributeType != 0)
			{
				addrs = pAttribute + (i * 3) + 1;
				AttributeValue = *(reinterpret_cast<unsigned short*>(addrs));

				ItemOptionSetType(pNewItem, AttributeType, AttributeValue);
			}
		}

		// DBTask Packet
		addrs = (int)ITEMGR_ARRENDAL_EVOLUTION;
		*(reinterpret_cast<unsigned int*>(addrs)) = CharID;
		addrs = (int)ITEMGR_ARRENDAL_EVOLUTION + 0x4;
		tagItemInit(addrs);
		addrs = (int)ITEMGR_ARRENDAL_EVOLUTION + 0x4;
		EpochItemBaseGetItemGR(pNewItem, addrs);

		// Send DB Packet
		SendPacketEX(0x7F23A0, 0x4A09, (int)ITEMGR_ARRENDAL_EVOLUTION, 0x41);

		// GetItemGR
		addrs = (int)ARRENDAL_EVOLUTION + 0xA;
		tagItemInit(addrs);
		addrs = (int)ARRENDAL_EVOLUTION + 0xA;
		EpochItemBaseGetItemGR(pNewItem, addrs);

		// Success 1 / Fail 0
		addrs = (int)ARRENDAL_EVOLUTION + 0x47;
		*(reinterpret_cast<char*>(addrs)) = 1;

		addrs = (int)ARRENDAL_EVOLUTION + 0x48;
		//ArendaExpRate = 0.0;
		*(reinterpret_cast<int*>(addrs)) = 0x0;

		pThis = pDynamic;
		SendPacket(pThis, 0x3003, (int)ARRENDAL_EVOLUTION, 0x4C);
		return 0;
	}
	else
	{
		/**************** Fail ***************/
		// Success 1 / Fail 0
		addrs = (int)ARRENDAL_EVOLUTION + 0x47;
		*(reinterpret_cast<char*>(addrs)) = 0;

		pThis = pDynamic;
		SendPacket(pThis, 0x3003, (int)ARRENDAL_EVOLUTION, 0x4C);
		return 0;
	}

	return 6;
}

void ItemWeaponEvolution(unsigned int ItemID, unsigned int MeteriaID, int &MeteriaCheck, int &SuccessRate, int &NeedReinforce)
{
	int addrs;
	int MaxCount;
	int LineSize = 0x18;
	int Offset = 0;
	int Spirit_Weapon;
	int Meterial_Weapon;
	
	MaxCount = WEAPONEVOLUTION_SIZE / LineSize;
	
	Offset = WEAPONEVOLUTION_ADDRS;

	for( int i=0; i < MaxCount; i++ )
	{
		//Offset += (i * LineSize);
		addrs = Offset + 0x8;
		Spirit_Weapon = *(reinterpret_cast<unsigned int*>(addrs));
		addrs = Offset + 0xC;
		Meterial_Weapon = *(reinterpret_cast<unsigned int*>(addrs));

		if (Spirit_Weapon == 0) break;

		if (Spirit_Weapon == ItemID)
		{
			if (Meterial_Weapon == MeteriaID)
			{
				MeteriaCheck = 1;
				addrs = Offset + 0x10;
				SuccessRate = *(reinterpret_cast<unsigned int*>(addrs));
				addrs = Offset + 0x14;
				NeedReinforce = *(reinterpret_cast<int*>(addrs));
				break;
			}
		}
		Offset += LineSize;
	}
}