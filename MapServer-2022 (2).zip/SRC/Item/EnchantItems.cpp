/*******************************************
 2021 RCM_MAP_ENCHANTITEM_LEVEL 0x1403 Packet Struct
 SEND:
 0D 00 05 00 +0 NpcCType (NpcID)
 AB 00 00 40 +4 NpcCharID
 83 00 28 00 +8 ItemID
 69 00 00 00 +C nID
 01          +10 Bag
 03          +11 Slot
 FF FF       +12 (0xFFFF = 1 / 0xFFFE = 2 / 0xFFFD = 3)
 
 RECV:
 00          +0
 27 00 29 00 +1 ItemID (SendData+0x8)
 EC AF 64 00 +5 nID (SendData+0xC)
 00          +9  (00 fail 01 success)
 01          +A  Bag (SendData+0x10)
 00          +B  Slot (SendData+0x11)
 32 00 00 00 +C  IAT_EQUIP_LEVEL (SetLV)
 EE 44 05 00 +10 CurMoneyL (Player+0x1958)
 00 00 00 00 +14 CurMoneyH (Player+0x195C)
 00          +18 (00 KeepItem 01 DeleteItem)

 2021 RCM_MAP_ENCHANTITEM_X 0x1404 - 0x1407 Packet Struct
 00          +0
 01          +1
 01 00 28 00 +2 ItemID
 DE E7 F7 00 +6
 01          +A
 08          +B
 06 00       +C SetVAR (Old Byte, New Short)
 AA 16 02 00 +E
 00 00 00 00 +12
 00 00 00 00 +16
 00 00 00 00 +1A
 00          +1E
 00          +1F
 04 14       +20 PacketType
 *******************************************/

#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

unsigned char ENCHANT_ITEM[25] = {0};
unsigned char DBTASK_INSITEMA[65] = {0};
unsigned char ENHANCEMET_ITEM[23] = {0};
unsigned char DBTASK_INSITEMB[65] = {0};

int PK1403_RET_SUCCESS = 0x0042B5EF;
int PK1403_RET_FAIL = 0x0042B64B;
int ENCHANTITEM_PLAYER;

int PK140X_RET = 0x004636DA;

int REINFORCE_LOOP = 0x0046037E;
int REINFORCE_END = 0x0046045B;

// **** 2021 RCM_MAP_ENCHANTITEM_LEVEL 0x1403 *******************************************
void EnchantItemLevel(int pSendData)
{
	// 0 Success / 1 Fails
	__asm cmp byte ptr ss:[ebp-0x28],0x0
	__asm je RET_ORIG

	__asm mov byte ptr ss:[ebp-0x28],0x0

	__asm mov ecx,dword ptr ss:[ebp-0x30]
	__asm mov ENCHANTITEM_PLAYER,ecx

	EnchantItemLevelDown(ENCHANTITEM_PLAYER, pSendData);

	__asm jmp PK1403_RET_FAIL

RET_ORIG:
	__asm jmp PK1403_RET_SUCCESS

}

void EnchantItemLevelDown(int pPlayer, int pSendData)
{
	int addrs = 0;
	int pItem = 0;
	int pThis = 0;
	int DLV = 0;
	int DownLevel = 0;
	int EquipLevel = 0;
	int CurLevel = 0;
	int ItemID = 0;
	int nID = 0;
	int Inventory = 0;
	int Slot = 0;
	int CharID = 0;
	int pItemInfo = 0;
	__int64 CurMoney = 0;

	addrs = (DWORD)pSendData + 0x8;
	ItemID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = (DWORD)pSendData + 0xC;
	nID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = (DWORD)pSendData + 0x10;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x11;
	Slot = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x12;
	DLV = *(reinterpret_cast<unsigned short*>(addrs));
	DownLevel = (0 - DLV) & 3;

	addrs = (DWORD)pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)pPlayer + 0x1958;
	CurMoney = *(reinterpret_cast<__int64*>(addrs));

	pThis = (DWORD)pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);

	pThis = (DWORD)pItem;
	CurLevel = GetAttribute(pThis, 5);

	pItemInfo = GetItemBinScriptInfo(ItemID);
	EquipLevel = GetItemBinAttribute(pItemInfo, 5);

	CurLevel += DownLevel;
	if (CurLevel > EquipLevel) CurLevel = EquipLevel;

	pThis = (DWORD)pItem;
	SetAttribute(pThis, 5, CurLevel);

	// Send DB Packet
	addrs = (int)DBTASK_INSITEMA;
	*(reinterpret_cast<int*>(addrs)) = CharID;
	addrs = (int)DBTASK_INSITEMA + 0x4;
	tagItemInit(addrs);
	addrs = (int)DBTASK_INSITEMA + 0x4;
	pThis = (DWORD)pItem;
	EpochItemBaseGetItemGR(pThis, addrs);

	SendPacketEX(0x7F23A0, 0x4A09, (int)DBTASK_INSITEMA, 0x41);

	// Send Clinet Packet
	addrs = (int)ENCHANT_ITEM;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = (int)ENCHANT_ITEM + 0x1;
	*(reinterpret_cast<unsigned int*>(addrs)) = ItemID;
	addrs = (int)ENCHANT_ITEM + 0x5;
	*(reinterpret_cast<unsigned int*>(addrs)) = nID;
	addrs = (int)ENCHANT_ITEM + 0x9;
	*(reinterpret_cast<char*>(addrs)) = 0; // (00 fail 01 success)
	addrs = (int)ENCHANT_ITEM + 0xA;
	*(reinterpret_cast<char*>(addrs)) = (char)Inventory;
	addrs = (int)ENCHANT_ITEM + 0xB;
	*(reinterpret_cast<char*>(addrs)) = (char)Slot;
	addrs = (int)ENCHANT_ITEM + 0xC;
	*(reinterpret_cast<int*>(addrs)) = CurLevel;
	addrs = (int)ENCHANT_ITEM + 0x10;
	*(reinterpret_cast<__int64*>(addrs)) = CurMoney;
	addrs = (int)ENCHANT_ITEM + 0x18;
	*(reinterpret_cast<char*>(addrs)) = 0; // (00 KeepItem 01 DeleteItem)

	addrs = (DWORD)pPlayer + 0x1098;
	pThis = *(reinterpret_cast<int*>(addrs));
	if (pThis != 0)
	{
		SendPacketEX(pThis, 0x1403, (int)ENCHANT_ITEM, 0x19);
	}
}

// **** 2021 RCM_MAP_ENCHANTITEM_X 0x1404 - 0x1407 *******************************************
void EnchantSetVar()
{
	__asm mov word ptr ss:[ebp-0x48],ax
	__asm mov eax,dword ptr ss:[ebp-0x1C]

	__asm jmp PK140X_RET
}

// **** 2021 RCM_MAP_ENHANCEMET_TICKET 0x1472 *******************************************
void EnhancementTicket(int pDynamic, int pSendPacket)
{
	int Result;
	int addrs;
	int pSendData;
	unsigned char ENHANCEMET_RESULT[1] = {0};

	pSendData = pSendPacket + 4;
	Result = GetEnhancementItem(pDynamic, pSendData);
	if (Result != 0)
	{
		addrs = (int)ENHANCEMET_RESULT;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;
		SendPacketEX(pDynamic, 0x1472, (int)ENHANCEMET_RESULT, 0x1);
	}
}

int GetEnhancementItem(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int pThis;
	int CharID;

	int ItemID;
	int nID;	
	int Inventory;
	int Slot;

	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;
	
	int CheckID;

	int pItem;
	int pItemUse;

	//int ItemType;
	int ItemTypeUse;
	int ReinforceType;
	int BootsLevel = 0;
	int Rate = 0;
	//int AddRate = 0;
	int Chance = 0;
	int MaxLevel = 0;

	// Check
	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 0x19;

	addrs = (DWORD)pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));

	// Send Packet
	addrs = (DWORD)pSendData + 0x0;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x4;
	nID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x9;
	Slot = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)pSendData + 0xA;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xE;
	nIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x12;
	InventoryUse = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x13;
	SlotUse = *(reinterpret_cast<char*>(addrs));

	// Check Item
	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);
	if (pItem == 0) return 0x37;
	addrs = (DWORD)pItem + 0x20;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != ItemID) return 0x37;
	addrs = (DWORD)pItem + 0x24;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != nID) return 0x37;

	// Check ItemUse
	pThis = pPlayer + 0xCC8;
	pItemUse = GetItem(pThis, InventoryUse, SlotUse);
	if (pItemUse == 0) return 0x37;
	addrs = (DWORD)pItemUse + 0x20;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != ItemIDUse) return 0x37;
	addrs = (DWORD)pItemUse + 0x24;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != nIDUse) return 0x37;

	ItemTypeUse = GetAttribute(pItemUse, 0);
	if (ItemTypeUse != 244) return 0x37;

	// Attribute 170 0xAA MaxLevel
	MaxLevel = GetAttribute(pItemUse, 0xAA);

	// Get Boots Level
	ReinforceType = GetReinforceType(pItem);
	BootsLevel = ItemOptionGetType(pItem, ReinforceType);

	if (MaxLevel == 0)
	{
		// Safe Enhancement Stone
		if (BootsLevel > 29) return 0x37;

		// Attribute 171 0xAB Rate
		//Rate = GetAttribute(pItemUse, 0xAB);
		//if (Rate == 0) Rate = 500000;
		// Attribute 36 0x24 AddRate
		Rate = GetAttribute(pItemUse, 0x24);
		Rate += 500000;

		Chance = BioticBaseGetRandom(pPlayer, 1000000);
		if (Rate >= Chance)
		{
			/************** Success **************/
			// Packet 0x1472
			addrs = (int)ENHANCEMET_ITEM;
			*(reinterpret_cast<char*>(addrs)) = 0;
			// 1:Success 0:Fail
			addrs = (int)ENHANCEMET_ITEM + 0x1;
			*(reinterpret_cast<char*>(addrs)) = 1;

			//Set Boost Level
			BootsLevel += 1;
			if (BootsLevel > 30) BootsLevel = 30;
			ItemOptionSetType(pItem, ReinforceType, BootsLevel);

			// Create DB Packet 0x4A09
			addrs = (int)DBTASK_INSITEMB;
			*(reinterpret_cast<int*>(addrs)) = CharID;

			addrs = (int)DBTASK_INSITEMB + 0x4;
			tagItemInit(addrs);
			addrs = (int)DBTASK_INSITEMB + 0x4;
			EpochItemBaseGetItemGR(pItem, addrs);

			// Send DB Packet
			SendPacketEX(0x7F23A0, 0x4A09, (int)DBTASK_INSITEMB, 0x41);
		}
		else
		{
			/**************** Fail ***************/
			// Packet 0x1472
			addrs = (int)ENHANCEMET_ITEM;
			*(reinterpret_cast<char*>(addrs)) = 0;
			// 1:Success 0:fails
			addrs = (int)ENHANCEMET_ITEM + 0x1;
			*(reinterpret_cast<char*>(addrs)) = 0;
		}
	}
	else
	{
		// +1 Enhancement Ticket
		if (BootsLevel >= MaxLevel) return 0x37;

		// Packet 0x1472
		addrs = (int)ENHANCEMET_ITEM;
		*(reinterpret_cast<char*>(addrs)) = 0;
		// 1:Success 0:Fail
		addrs = (int)ENHANCEMET_ITEM + 0x1;
		*(reinterpret_cast<char*>(addrs)) = 1;

		//Set Boost Level
		BootsLevel += 1;
		if (BootsLevel > MaxLevel) BootsLevel = MaxLevel;
		ItemOptionSetType(pItem, ReinforceType, BootsLevel);

		// Create DB Packet 0x4A09
		addrs = (int)DBTASK_INSITEMB;
		*(reinterpret_cast<int*>(addrs)) = CharID;
		addrs = (int)DBTASK_INSITEMB + 0x4;
		tagItemInit(addrs);
		addrs = (int)DBTASK_INSITEMB + 0x4;
		EpochItemBaseGetItemGR(pItem, addrs);

		// Send DB Packet
		SendPacketEX(0x7F23A0, 0x4A09, (int)DBTASK_INSITEMB, 0x41);
	}

	// Clinet Packet
	// ItemID
	addrs = (int)ENHANCEMET_ITEM + 0x2;
	*(reinterpret_cast<int*>(addrs)) = ItemID;
	// nID
	addrs = (int)ENHANCEMET_ITEM + 0x6;
	*(reinterpret_cast<int*>(addrs)) = nID;
	// Inventory
	addrs = (int)ENHANCEMET_ITEM + 0xA;
	*(reinterpret_cast<char*>(addrs)) = (char)Inventory;
	// Inventory
	addrs = (int)ENHANCEMET_ITEM + 0xB;
	*(reinterpret_cast<char*>(addrs)) = (char)Slot;
	// ItemIDUse
	addrs = (int)ENHANCEMET_ITEM + 0xC;
	*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
	// nIDUse
	addrs = (int)ENHANCEMET_ITEM + 0x10;
	*(reinterpret_cast<int*>(addrs)) = nIDUse;
	// InventoryUse
	addrs = (int)ENHANCEMET_ITEM + 0x14;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryUse;
	// InventoryUse
	addrs = (int)ENHANCEMET_ITEM + 0x15;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotUse;
	// Set Boost Level
	addrs = (int)ENHANCEMET_ITEM + 0x16;
	*(reinterpret_cast<char*>(addrs)) = (char)BootsLevel;

	// Remove Item
	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemUse);

	pThis = pDynamic;
	SendPacket(pThis, 0x1472, (int)ENHANCEMET_ITEM, 0x17);

	return 0;
}

// RCM_MAP_REINFORCE_ANCIENT_ITEM 0x1453
void ReinforceAnvientItem()
{
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov edx,dword ptr ds:[eax+0xA]
	__asm cmp edx,0x2C7538
	__asm je CASE3
// CASE1
	__asm cmp dword ptr ss:[ebp-0xB0],0x1
	__asm jge LOOPEND
	__asm jmp REINFORCE_LOOP

CASE3:
	__asm cmp dword ptr ss:[ebp-0xB0],0x3
	__asm jge LOOPEND
	__asm jmp REINFORCE_LOOP

LOOPEND:
	__asm jmp REINFORCE_END

}
