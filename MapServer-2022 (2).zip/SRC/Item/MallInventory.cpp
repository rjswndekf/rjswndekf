#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

int GETMALLITEMSEND_RET = 0x00562094;
int GETMALLITEMRECV_RET = 0x0040E1CC;
int GETMALL_PLAYER;
int GETMALL_PDATA;
int GETMALL_PITEM;

// Check Item Timer
unsigned char GETMALLITEM_LOCALTIME[16] = {0};
int GETMALLITEM_LOCALTIME_ADDRS = (DWORD)GETMALLITEM_LOCALTIME;

unsigned char GETMALLITEM_TIMER[8] = {0};
int GETMALLITEM_TIMER_ADDRS = (DWORD)GETMALLITEM_TIMER;

unsigned char MALLMOVEDBSK[65] = {0};
int MALLMOVEDBSK_ADDRS = (DWORD)MALLMOVEDBSK;

/******* ASM Funs *******/
extern int GETFREEINVSLOT;
extern int SETITEMPTR;
extern int GETITEMPTR;
extern int CALITEMTIMER;

int GETITEMGRDATAPTR = 0x0055B660;

// RCM_MAP_GETMALLITEM 0x1426
void GetMallItemSend()
{
	// Check Timer
	__asm push 0x4E
	__asm mov ecx,dword ptr ss:[ebp-0x8]
	__asm mov edx,dword ptr ds:[ecx]
	__asm mov ecx,dword ptr ss:[ebp-0x8]
	__asm call dword ptr ds:[edx+0x4]
	__asm test eax,eax
	__asm je SET_SLOT
	__asm cmp eax,0xF4240
	__asm jge SET_SLOT
	
	// GetLocalTime
	__asm mov eax,GETMALLITEM_LOCALTIME_ADDRS
	__asm push eax
	__asm call dword ptr ds:[0x79523C]
	
	// CalItemTimer
	__asm push 0xFFFFFFFF
	__asm mov ecx,GETMALLITEM_LOCALTIME_ADDRS
	__asm push ecx
	__asm mov ecx,GETMALLITEM_TIMER_ADDRS
	__asm call CALITEMTIMER

	// Settings ItemGR Attr
	__asm mov ecx,GETMALLITEM_TIMER_ADDRS
	__asm movzx eax,word ptr ds:[ecx]
	__asm movzx edx,word ptr ds:[ecx+0x2]
	__asm mov byte ptr ss:[ebp-0x4F], 0x42
	__asm mov word ptr ss:[ebp-0x4E],ax
	__asm mov byte ptr ss:[ebp-0x4C], 0x43
	__asm mov word ptr ss:[ebp-0x4B],dx

SET_SLOT:
	__asm mov dword ptr ss:[ebp-0x10],0xFF
	__asm mov dword ptr ss:[ebp-0x8],0xFF
	__asm lea eax,dword ptr ss:[ebp-0x8]
	__asm push eax
	__asm lea edx,dword ptr ss:[ebp-0x10]
	__asm push edx
	// PlayerPTR
	__asm mov edx,dword ptr ss:[ebp-0xC0]
	__asm mov ecx,dword ptr ds:[edx+0x744]
	__asm add ecx,0xCC8
	__asm call GETFREEINVSLOT

	// Inventory
	__asm mov edx, dword ptr ss:[ebp-0x10]
	__asm mov byte ptr ss:[ebp-0x25],dl
	// Slot
	__asm mov edx, dword ptr ss:[ebp-0x8]
	__asm mov byte ptr ss:[ebp-0x24],dl

	__asm jmp GETMALLITEMSEND_RET
}


void GetMallItemRecv()
{
	// pPlayer
	__asm lea edx,dword ptr ss:[ebp+0xFFFF5F74]
	__asm mov ecx,dword ptr ds:[edx]
	__asm mov GETMALL_PLAYER,ecx

	// pData
	__asm lea esi,dword ptr ss:[ebp+0xFFFF5F78]
	__asm mov GETMALL_PDATA,esi

	// ItemGRPTR
	__asm lea eax,dword ptr es:[esi+0x5]
	__asm push 0x0
	__asm push eax
	__asm mov ecx,dword ptr ds:[0x7F1CA4]
	__asm call GETITEMGRDATAPTR
	__asm mov GETMALL_PITEM,eax

	SetMallItem(GETMALL_PLAYER, GETMALL_PITEM, GETMALL_PDATA);

	__asm jmp GETMALLITEMRECV_RET
}

void SetMallItem(int pPlayer, int pItem, int pData)
{
	int addrs;
	int pThis;
	int CharID;
	int pItemGR;
	int Slot;
	int Inventory;

	// Set OwnerID
	addrs = pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));
	addrs = pItem + 0x9C;
	*(reinterpret_cast<int*>(addrs)) = CharID;

	// Set Option Value
	SetItemBinOptionValue(pItem);

	// SetItem
	addrs = pData + 0x37;
	Inventory = *(reinterpret_cast<char*>(addrs));
	Inventory &= 0xFF;

	addrs = pData + 0x38;
	Slot = *(reinterpret_cast<char*>(addrs));
	Slot &= 0xFF;

	pThis = pPlayer + 0xCC8;
	SetItem(pThis, Inventory, Slot, pItem);

	// Send DB Packet
	addrs = MALLMOVEDBSK_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = CharID;
	addrs = MALLMOVEDBSK_ADDRS + 4;
	tagItemInit(addrs);
	addrs = MALLMOVEDBSK_ADDRS + 4;
	EpochItemBaseGetItemGR(pItem, addrs);

	SendPacketEX(0x7F23A0, 0x4A09, MALLMOVEDBSK_ADDRS, 0x41);

	// Client Packet
	pItemGR = pData + 5;
	tagItemInit(pItemGR);
	pItemGR = pData + 5;
	EpochItemBaseGetItemGR(pItem, pItemGR);
}
