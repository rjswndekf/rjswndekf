#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

extern int ITEMDISLEVEL_ADDRS;
extern int ITEMDISLEVEL_SIZE;
extern int ITEMDISREIF_ADDRS;
extern int ITEMDISREIF_SIZE;

unsigned char EQUIPDISMANTLE[59] = {0};
int EQUIPDISMANTLE_ADDRS = (DWORD)EQUIPDISMANTLE;

void EquipDismantle(int pDynamic, int pSendPacket)
{
	int Result;
	int pSendData;
	pSendData = pSendPacket + 4;
	Result = GetEquipDismantle(pDynamic, pSendData);
	if (Result != 0)
	{
		*(reinterpret_cast<char*>(EQUIPDISMANTLE_ADDRS)) = (char)Result;
		SendPacketEX(pDynamic, 0x1476, EQUIPDISMANTLE_ADDRS, 0x1);
	}
}

int GetEquipDismantle(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int pThis;
	int pItem;
	int pItemUse;
	int Result;
	int ReinforceLevel;

	int NpcID;
	int NpcnID;
	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;

	int ItemID;
	int nID;
	int pNID;
	int Inventory;
	int Slot;
	int pInventory;
	int pSlot;
	int GroupID;
	int RewardCount = 0;
	int RewardRate = 0;

	unsigned char REWARDDATA[60] = {0};
	int REWARDDATA_ADDRS = (DWORD)REWARDDATA;
	
	unsigned char RACIPITEMID[8] = {0};
	int RACIPITEMID_ADDRS = (DWORD)RACIPITEMID;

	unsigned char FREESPACE[8] = {0};
	int FREESPACE_ADDRS = (DWORD)FREESPACE;
	
	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 2;

	// Send Packet
	addrs = (DWORD)pSendData;
	NpcID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x4;
	NpcnID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xC;
	nIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x10;
	InventoryUse = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x11;
	SlotUse = *(reinterpret_cast<char*>(addrs));

	GroupID = GetEquipDisGroupID(ItemIDUse);
	if (GroupID == -1) return 0x37;

	pThis = pPlayer + 0xCC8;
	pItemUse = GetItem(pThis, InventoryUse, SlotUse);
	if (pItemUse == 0) return 5;

	addrs = pItemUse + 0x24;
	Result = *(reinterpret_cast<int*>(addrs));
	if (Result != nIDUse) return 0x37;
	
	ReinforceLevel = ItemOptionGetType(pItemUse, 0x4F);
	if (ReinforceLevel == 0)
	{
		ReinforceLevel = ItemOptionGetType(pItemUse, 0x55);
		if (ReinforceLevel == 0)
		{
			ReinforceLevel = ItemOptionGetType(pItemUse, 0x56);
			if (ReinforceLevel == 0) return 0x37;
		}
	}

	Result = GetRewardItem(GroupID, ReinforceLevel, REWARDDATA_ADDRS);
	if (Result == 0) return 0x37;

	addrs = REWARDDATA_ADDRS;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = REWARDDATA_ADDRS + 0x4;
	RewardCount = *(reinterpret_cast<int*>(addrs));
	addrs = REWARDDATA_ADDRS + 0x8;
	RewardRate = *(reinterpret_cast<int*>(addrs));

	// Cerate Item
	AllocItem(RACIPITEMID_ADDRS, ItemID);
	pNID = RACIPITEMID_ADDRS + 4;
	nID = *(reinterpret_cast<int*>(pNID));
	if (nID < 1) return 0x8E;

	pItem = CreateItem(RACIPITEMID_ADDRS, 1);

	addrs = (DWORD)FREESPACE_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;
	addrs = (DWORD)FREESPACE_ADDRS + 4;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;

	pInventory = FREESPACE_ADDRS;
	pSlot = FREESPACE_ADDRS + 4;

	pThis = pPlayer + 0xCC8;
	Result = GetFreeInventorySlot(pThis, pInventory, pSlot);
	if (Result == 0) return 0x37;

	addrs = FREESPACE_ADDRS;
	Inventory = *(reinterpret_cast<int*>(addrs));
	addrs = FREESPACE_ADDRS + 4;
	Slot = *(reinterpret_cast<int*>(addrs));

	pThis = pPlayer + 0xCC8;
	Result = AddItem(pThis, pItem, Inventory, Slot, 0);
	if (Result == 0) return 0x37;

	// Client Packet
	addrs = (DWORD)EQUIPDISMANTLE_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0;
	// Item 1 (Size 0xB)
	addrs = (DWORD)EQUIPDISMANTLE_ADDRS + 0x4;
	*(reinterpret_cast<int*>(addrs)) = ItemID;
	addrs = (DWORD)EQUIPDISMANTLE_ADDRS + 0x8;
	*(reinterpret_cast<int*>(addrs)) = nID;
	addrs = (DWORD)EQUIPDISMANTLE_ADDRS + 0xC;
	*(reinterpret_cast<char*>(addrs)) = (char)Inventory;
	addrs = (DWORD)EQUIPDISMANTLE_ADDRS + 0xD;
	*(reinterpret_cast<char*>(addrs)) = (char)Slot;
	addrs = (DWORD)EQUIPDISMANTLE_ADDRS + 0xE;
	*(reinterpret_cast<char*>(addrs)) = (char)RewardCount;

	// Remove Item
	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemUse);

	pThis = pDynamic;
	SendPacketEX(pThis, 0x1476, EQUIPDISMANTLE_ADDRS, 0x3B);

	return 0;
}

int GetEquipDisGroupID(int ItemID)
{
	int GroupID = -1;
	int addrs;
	int BinItemID = 0;
	int MaxCount = 0;
	int Offset = 0;
	
	MaxCount = ITEMDISLEVEL_SIZE / 0xC;

	Offset = (DWORD)ITEMDISLEVEL_ADDRS;

	for( int i=0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x8;
		BinItemID = *(reinterpret_cast<int*>(addrs));
		if (BinItemID == ItemID)
		{
			addrs = Offset + 0x4;
			GroupID = *(reinterpret_cast<int*>(addrs));
			break;
		}
		Offset += 0xC;
	}
	return GroupID;
}

int GetRewardItem(int GroupID, int ReinforceLevel, int pRewardData)
{
	int Result = 0;
	int addrs;
	int BinGroupID = 0;
	int BinReinforceLevel = 0;
	int BinRewardItem = 0;
	int RewardAddrs = 0;
	int RewardItem = 0;
	int RewardCount = 0;
	int RewardRate = 0;

	int MaxCount = 0;
	int Offset = 0;

	MaxCount = ITEMDISREIF_SIZE / 0x48;

	Offset = (DWORD)ITEMDISREIF_ADDRS;

	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x4;
		BinGroupID = *(reinterpret_cast<int*>(addrs));
		if (BinGroupID == GroupID)
		{
			addrs = Offset + 0x8;
			BinReinforceLevel = *(reinterpret_cast<int*>(addrs));
			if (BinReinforceLevel == ReinforceLevel)
			{
				RewardAddrs = Offset + 0xC;
				for( int j = 0; j < 5; j++ )
				{
					addrs = RewardAddrs + (j * 12);
					RewardItem = *(reinterpret_cast<int*>(addrs));
					addrs = RewardAddrs + (j * 12) + 0x4;
					RewardCount = *(reinterpret_cast<int*>(addrs));
					addrs = RewardAddrs + (j * 12) + 0x8;
					RewardRate = *(reinterpret_cast<int*>(addrs));

					addrs = pRewardData + (j * 12);
					*(reinterpret_cast<int*>(addrs)) = RewardItem;
					addrs = pRewardData + (j * 12) + 0x4;
					*(reinterpret_cast<int*>(addrs)) = RewardCount;
					addrs = pRewardData + (j * 12) + 0x8;
					*(reinterpret_cast<int*>(addrs)) = RewardRate;

					Result = 1;
				}
			}
		}
		if (Result == 1) break;
		else Offset += 0x48;
	}
	return Result;
}
