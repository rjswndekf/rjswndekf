#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

#include <ctime>

using namespace std;

unsigned char RECIPEDATA[12] = {0};
int RECIPEDATA_ADDRS = (DWORD)RECIPEDATA;

unsigned char RESLIST[124] = {0};
int RESLIST_ADDRS = (DWORD)RESLIST;

unsigned char NOTICE_F00D[526] = {0};
int NOTICE_F00D_ADDRS = (DWORD)NOTICE_F00D;

unsigned char BAP2316[8] = {0};
int BAP2316_ADDRS = (DWORD)BAP2316;

unsigned char SOCKET_REPAIRB[80] = {0};
int SOCKET_REPAIRB_ADDRS = (DWORD)SOCKET_REPAIRB;

// *** 0x231C RCM_MAP_SOCKET_REPAIR *******************************/
void ItemRecipe(int pDynamic, int pSendPacket)
{
	int addrs;
	int Result;
	int pSendData;

	memset(NOTICE_F00D,0,sizeof(char)*526);

	pSendData = pSendPacket + 4;

	Result = GetRecipeItem(pDynamic, pSendData);
	if (Result != 0)
	{
		addrs = (DWORD)SOCKET_REPAIRB_ADDRS;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;

		SendPacketEX(pDynamic, 0x231C, SOCKET_REPAIRB_ADDRS, 0x1);
	}
}

int GetRecipeItem(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int pThis;
	int gRecip;
	int RecipeID;
	int Result;
	int pRecipeInfo;
	int pItemTools;
	int Timestamp;
	int ItemTimestamp;
	int AddTimestamp;
	int pRecipeResourceList;
	int i;
	int MaxCount;
	int ItemID;
	int nID;
	int Inventory;
	int Slot;
	int pInventory;
	int pSlot;
	int Stack;
	int ItemIDMaterial;
	int InventoryMaterial;
	int StackMaterial;
	int SlotMaterial;
	int pItem;
	int pItemMaterial;
	int CraftType;
	int CraftPoint;
	int pCraftWork;
	int offset;
	int CType;
	int CharID;
	int PlayerState;

	unsigned char SLOTTMP[8] = {0};
	int SLOTTMP_ADDRS = (DWORD)SLOTTMP;

	unsigned char RACIPITEMID[8] = {0};
	int RACIPITEMID_ADDRS = (DWORD)RACIPITEMID;

	unsigned char CURSTACK[4] = {0};
	int CURSTACK_ADDRS = (DWORD)CURSTACK;

	addrs = pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 4;
	
	addrs = pSendData;
	RecipeID = *(reinterpret_cast<int*>(addrs));
	if (RecipeID == 0) return 3;
	
	pThis = pPlayer + 0x1E20;
	Result = GetRecipeData(pThis, RecipeID, RECIPEDATA_ADDRS);
	if (Result != 0) return 7;

	addrs = 0x4BEF074;
	gRecip = *(reinterpret_cast<int*>(addrs));
	addrs = gRecip + 0x8;
	pThis = *(reinterpret_cast<int*>(addrs));
	pRecipeInfo = GetRecipeInfo(pThis, RecipeID);
	if (pRecipeInfo == 0) return 2;

	// Check Slot Tools
	pThis = pPlayer + 0xCC8;
	pItemTools = GetItem(pThis, 0x0, 0x1A);
	if (pItemTools == 0) return 42;

	// Check Free Slot Count
	pThis = pPlayer + 0xCC8;
	Result = GetFreeSlotCount(pThis);
	if (Result < 1) return 13;

	// Check Timestamp
	time_t seconds = time(NULL);
	Timestamp = (int)seconds;
	addrs = RECIPEDATA_ADDRS + 0x4;
	AddTimestamp = *(reinterpret_cast<int*>(addrs));
	addrs = pRecipeInfo + 0x28;
	ItemTimestamp = *(reinterpret_cast<int*>(addrs));
	ItemTimestamp += AddTimestamp;
	if (ItemTimestamp > Timestamp) return 18;

	// Get Resource List
	pThis = pPlayer + 0xCC8;
	pRecipeResourceList = GetRecipeResourceList(pThis, pRecipeInfo, RESLIST_ADDRS);
	if (pRecipeResourceList == 0) return 19;

	// Check Playe SelfItemWork
	Result = PlayerCheckSelfItemWork(pPlayer, 1);
	if (Result == 0) return 12;
	
	// Check Res List Material nID
	addrs = RESLIST_ADDRS;
	MaxCount = *(reinterpret_cast<int*>(addrs));
	
	for(i = 0; i < MaxCount; i++ )
	{
		addrs = RESLIST_ADDRS + 8 + (i * 12);
		nID = *(reinterpret_cast<int*>(addrs));
		Result = PlayerCheckWorkItem(pPlayer, nID);
		if (Result == 0) return 12;
	}

	// Cerate Item
	addrs = pRecipeInfo + 0x4;
	ItemID = *(reinterpret_cast<int*>(addrs));
	AllocItem(RACIPITEMID_ADDRS, ItemID);
	addrs = RACIPITEMID_ADDRS + 4;
	nID = *(reinterpret_cast<int*>(addrs));
	if (nID < 1) return 3;

	addrs = pRecipeInfo + 0x8;
	Stack = *(reinterpret_cast<int*>(addrs));
	pItem = CreateItem(RACIPITEMID_ADDRS, Stack);
	if (pItem == 0) return 14;

	Result = AddTimerItem(pPlayer, pItem, pRecipeInfo, Timestamp);
	if (Result != 0)
	{
		CIOItemRelease(pItem);
		return Result;
	}
	
	// Check Craft Type
	addrs = pPlayer + 0x1E0C;
	CraftType = *(reinterpret_cast<char*>(addrs));
	CraftType &= 0xFF;
	if ((CraftType != 7) && (CraftType != 8))
	{
		// Settings Item Socket
		ItemOptionSetValue(pItem, 0x4B, 0x1);
	}

	// Check Res List Material pItem
	addrs = RESLIST_ADDRS;
	MaxCount = *(reinterpret_cast<int*>(addrs));

	for(i = 0; i < MaxCount; i++ )
	{
		addrs = RESLIST_ADDRS + 12 + (i * 12);
		InventoryMaterial = *(reinterpret_cast<char*>(addrs));
		InventoryMaterial &= 0xFF;
		addrs = RESLIST_ADDRS + 13 + (i * 12);
		SlotMaterial = *(reinterpret_cast<char*>(addrs));
		SlotMaterial &= 0xFF;
		addrs = RESLIST_ADDRS + 14 + (i * 12);
		StackMaterial = *(reinterpret_cast<char*>(addrs));
		StackMaterial &= 0xFF;

		pThis = pPlayer + 0xCC8;
		pItemMaterial = GetItem(pThis, InventoryMaterial, SlotMaterial);

		Result = RTDynamicCast(pItemMaterial, 0, 0x7E9778, 0x7E9794, 0);
		if (Result != 0)
		{
			pThis = pPlayer + 0xCC8;
			UseItemMaterial(pThis, pItemMaterial, StackMaterial, CURSTACK_ADDRS);
		}
	}

	addrs = (DWORD)SLOTTMP_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;
	addrs = (DWORD)SLOTTMP_ADDRS + 4;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;

	pInventory = (DWORD)SLOTTMP_ADDRS;
	pSlot = (DWORD)SLOTTMP_ADDRS + 4;

	pThis = pPlayer + 0xCC8;
	Result = GetFreeInventorySlot(pThis, pInventory, pSlot);
	if (Result == 0)
	{
		CIOItemRelease(pItem);
		CIOCraftRelease(pPlayer);
		return 14;
	}

	addrs = SLOTTMP_ADDRS;
	Inventory = *(reinterpret_cast<int*>(addrs));
	addrs = SLOTTMP_ADDRS + 4;
	Slot = *(reinterpret_cast<int*>(addrs));

	pThis = pPlayer + 0xCC8;
	Result = AddItem(pThis, pItem, Inventory, Slot, 0);
	if (Result == 0)
	{
		CIOItemRelease(pItem);
		CIOCraftRelease(pPlayer);
		return 14;
	}

	SetCraftItem(pPlayer, pItem);
	pThis = pPlayer + 0x1E20;
	UpdateRecipe(pThis, RecipeID, Timestamp);
	UpdateRecipeInfo(pPlayer);

	// Create Packet
	addrs = pRecipeInfo + 0x8;
	Stack = *(reinterpret_cast<int*>(addrs));

	addrs = pPlayer + 0x1EA8;
	pCraftWork = *(reinterpret_cast<int*>(addrs));
	addrs = pCraftWork + 0x68;
	CraftPoint = *(reinterpret_cast<int*>(addrs));

	// +0 Result
	addrs = SOCKET_REPAIRB_ADDRS;
	*(reinterpret_cast<char*>(addrs)) = 0;
	// +1 CraftPoint
	addrs = SOCKET_REPAIRB_ADDRS + 0x1;
	*(reinterpret_cast<int*>(addrs)) = CraftPoint;
	// +5 Stack
	addrs = SOCKET_REPAIRB_ADDRS + 0x5;
	*(reinterpret_cast<int*>(addrs)) = Stack;
	// +9 ItemGR
	addrs = SOCKET_REPAIRB_ADDRS + 0x9;
	tagItemInit(addrs);
	addrs = SOCKET_REPAIRB_ADDRS + 0x9;
	EpochItemBaseGetItemGR(pItem, addrs);
	// +46 N/A ItemID
	addrs = SOCKET_REPAIRB_ADDRS + 0x46;
	*(reinterpret_cast<int*>(addrs)) = 0;
	// +4A N/A nID
	addrs = SOCKET_REPAIRB_ADDRS + 0x4A;
	*(reinterpret_cast<int*>(addrs)) = 0;
	// +4E N/A Inv & Slot / Stack
	addrs = SOCKET_REPAIRB_ADDRS + 0x4E;
	*(reinterpret_cast<short*>(addrs)) = 0;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x231C, SOCKET_REPAIRB_ADDRS, 0x50);

	// SendNotice 0xF00D
	addrs = RESLIST_ADDRS;
	MaxCount = *(reinterpret_cast<int*>(addrs));

	addrs = NOTICE_F00D_ADDRS + 0x15;
	*(reinterpret_cast<int*>(addrs)) = RecipeID;
	addrs = NOTICE_F00D_ADDRS + 0x19;
	*(reinterpret_cast<char*>(addrs)) = (char)MaxCount;

	offset = NOTICE_F00D_ADDRS + 0x1A;

	for(i = 0; i < MaxCount; i++ )
	{
		addrs = RESLIST_ADDRS + 8 + (i * 12);
		nID = *(reinterpret_cast<int*>(addrs));

		addrs = RESLIST_ADDRS + 4 + (i * 12);
		ItemIDMaterial = *(reinterpret_cast<int*>(addrs));

		addrs = RESLIST_ADDRS + 14 + (i * 12);
		Stack = *(reinterpret_cast<char*>(addrs));
		Stack &= 0xFF;

		addrs = offset + (i * 10);
		*(reinterpret_cast<int*>(addrs)) = nID;
		addrs = offset + 4 + (i * 10);
		*(reinterpret_cast<int*>(addrs)) = ItemIDMaterial;
		addrs = offset + 8 + (i * 10);
		*(reinterpret_cast<short*>(addrs)) = (short)Stack;
	}

	pThis = pPlayer;
	PlayerSendNotice(pThis, 0xF00D, NOTICE_F00D_ADDRS, 0x20E, 0x15);

	addrs = pPlayer + 0x8C;
	PlayerState = *(reinterpret_cast<int*>(addrs));
	if (PlayerState == 0x60014)
	{
		CIOItemRelease(pItem);
		CIOCraftRelease(pPlayer);
		return 14;
	}
	else
	{
		if (PlayerState != 0x00150005)
		{
			addrs = pPlayer + 0x8C;
			*(reinterpret_cast<int*>(addrs)) = 0x00150005;
		}

		// BroadCast Around Players
		addrs = pPlayer + 0x2C;
		CType = *(reinterpret_cast<int*>(addrs));
		addrs = pPlayer + 0x30;
		CharID = *(reinterpret_cast<int*>(addrs));
		addrs = BAP2316_ADDRS;
		*(reinterpret_cast<int*>(addrs)) = CType;
		addrs = BAP2316_ADDRS + 0x4;
		*(reinterpret_cast<int*>(addrs)) = CharID;

		BioticBroadCastAroundPlayers(pPlayer, 0x2316, BAP2316_ADDRS, 8, 0, 2);
	}

	return 0;
}
