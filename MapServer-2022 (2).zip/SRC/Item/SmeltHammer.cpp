#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

extern int ITEMADDSOCKETDS_ADDRS;
extern int ITEMADDSOCKETDSSIZE;

unsigned char SMELTHAMMER[76] = {0};
int SMELTHAMMER_ADDRS = (DWORD)SMELTHAMMER;

unsigned char ADDSOCKET_DBSK[65] = {0};
int ADDSOCKET_DBSK_ADDRS = (DWORD)ADDSOCKET_DBSK;

void ChakraSmelt(int pDynamic, int pSendPacket)
{
	int Result;
	int pSendData;
	pSendData = pSendPacket + 4;
	Result = GetAddChakraSocket(pDynamic, pSendData);
	if (Result != 0)
	{
		*(reinterpret_cast<char*>(SMELTHAMMER_ADDRS)) = (char)Result;
		SendPacketEX(pDynamic, 0x2329, SMELTHAMMER_ADDRS, 0x1);
	}
}

int GetAddChakraSocket(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int pThis;
	int CharID;

	int ItemID;
	int nID;
	int Inventory;
	int Slot;

	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;

	int pItem;
	int pItemUse;
	
	int SocketNumber = 0;
	int AddSocket = 0;
	int ReinforceRate = 0;
	int Chance = 0;

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 2;

	// Send Packet
	addrs = (DWORD)pSendData;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x4;
	nID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x9;
	Slot = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0xA;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xE;
	nIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x12;
	InventoryUse = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x13;
	SlotUse = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)SMELTHAMMER_ADDRS;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = (DWORD)SMELTHAMMER_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)SMELTHAMMER_ADDRS + 0x42;
	*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
	addrs = (DWORD)SMELTHAMMER_ADDRS + 0x46;
	*(reinterpret_cast<int*>(addrs)) = nIDUse;
	addrs = (DWORD)SMELTHAMMER_ADDRS + 0x4A;
	*(reinterpret_cast<char*>(addrs)) = InventoryUse;
	addrs = (DWORD)SMELTHAMMER_ADDRS + 0x4B;
	*(reinterpret_cast<char*>(addrs)) = SlotUse;

	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);

	pThis = pPlayer + 0xCC8;
	pItemUse = GetItem(pThis, InventoryUse, SlotUse);

	addrs = SMELTHAMMER_ADDRS + 0x5;
	tagItemInit(addrs);

	addrs = ADDSOCKET_DBSK_ADDRS + 4;
	tagItemInit(addrs);

	GetItemAddSocketDetails(ItemIDUse, ItemID, AddSocket, ReinforceRate);

	addrs = pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));

	SocketNumber = ItemOptionGetType(pItem, 0x4B);
	SocketNumber += AddSocket;
	if (SocketNumber > 2) return 0x37;

	if (ReinforceRate == 1000000)
	{
		// Success 1 / Fail 0
		addrs = (DWORD)SMELTHAMMER_ADDRS + 0x1;
		*(reinterpret_cast<int*>(addrs)) = 1;

		// Set Socket
		ItemOptionSetType(pItem, 0x4B, SocketNumber);

		addrs = ADDSOCKET_DBSK_ADDRS;
		*(reinterpret_cast<int*>(addrs)) = CharID;

		addrs = ADDSOCKET_DBSK_ADDRS + 4;
		EpochItemBaseGetItemGR(pItem, addrs);

		// Send DB Packet
		SendPacketEX(0x7F23A0, 0x4A09, ADDSOCKET_DBSK_ADDRS, 0x41);
	}
	else
	{
		Chance = BioticBaseGetRandom(pPlayer, 1000000);
		if (ReinforceRate > Chance)
		{
			// Success 1 / Fail 0
			addrs = (DWORD)SMELTHAMMER_ADDRS + 0x1;
			*(reinterpret_cast<int*>(addrs)) = 1;
			// Add Socket
			ItemOptionSetType(pItem, 0x4B, SocketNumber);

			addrs = ADDSOCKET_DBSK_ADDRS;
			*(reinterpret_cast<int*>(addrs)) = CharID;

			addrs = ADDSOCKET_DBSK_ADDRS + 4;
			EpochItemBaseGetItemGR(pItem, addrs);

			// Send DB Packet
			SendPacketEX(0x7F23A0, 0x4A09, ADDSOCKET_DBSK_ADDRS, 0x41);
		}
		else
		{
			// Success 1 / Fail 0
			addrs = (DWORD)SMELTHAMMER_ADDRS + 0x1;
			*(reinterpret_cast<int*>(addrs)) = 0;
		}
	}

	addrs = SMELTHAMMER_ADDRS + 0x5;
	EpochItemBaseGetItemGR(pItem, addrs);

	// Remove Item
	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemUse);

	pThis = pDynamic;
	SendPacketEX(pThis, 0x2329, SMELTHAMMER_ADDRS, 0x4C);

	return 0;
}

void GetItemAddSocketDetails(int UseItem, int ItemID, int &AddSocket, int &ReinforceRate)
{
	int addrs;
	int BinItemID = 0;
	int BinUseItem = 0;
	int MaxCount = 0;
	int Offset = 0;

	MaxCount = ITEMADDSOCKETDSSIZE / 0x24;
	Offset = (DWORD)ITEMADDSOCKETDS_ADDRS;
	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x8;
		BinUseItem = *(reinterpret_cast<int*>(addrs));
		if (BinUseItem == UseItem)
		{
			for( int j = 0; j < 4; j++ )
			{
				addrs = Offset + 0x14 + (j * 4);
				BinItemID = *(reinterpret_cast<int*>(addrs));
				if (BinItemID == ItemID)
				{
					addrs = Offset + 0xC;
					AddSocket = *(reinterpret_cast<int*>(addrs));
					addrs = Offset + 0x10;
					ReinforceRate = *(reinterpret_cast<int*>(addrs));
					break;
				}
			}
		}
		if (AddSocket == 0) Offset += 0x24;
		else break;
	}
}
