#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

unsigned char WISH_ITEM_EXCH[72] = {0};

extern int WISHITEMEXCHBIN_ADDRS;
extern int WISHITEMEXCHBIN_SIZE;

void WishItemExchange(int pDynamic, int pSendPacket)
{
	int Result;
	int addrs;
	int pSendData;
	int PacketType;
	unsigned char WISH_RESULT[1] = {0};

	addrs = (DWORD)pSendPacket;
	PacketType = *(reinterpret_cast<int*>(addrs));
	PacketType &= 0xFFFF;

	pSendData = pSendPacket + 4;
	Result = GetWishItemExchange(pDynamic, pSendData, PacketType);
	if (Result != 0)
	{
		addrs = (int)WISH_RESULT;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;
		SendPacketEX(pDynamic, PacketType, (int)WISH_RESULT, 0x1);
	}
}

int GetWishItemExchange(int pDynamic, int pSendData, int PacketType)
{
	int Result = 0;
	int addrs;
	int pPlayer;
	int pThis;

	int Status;
	int NpcID;
	int pNpc;
	int pScript;
	int GroupID;
	int pGroupScript;
	int CheckID;

	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;
	int ItemUseCount;

	int ItemIDMaterial;
	int nIDMaterial;
	int InventoryMaterial;
	int SlotMaterial;

	int ItemID;
	int nID;
	int Inventory = 0xFF;
	int Slot = 0xFF;

	int pItem;
	int pItemUse;
	int pItemMaterial;

	unsigned char NEWNID[8] = {0};
	unsigned char REMOVEITEM[12] = {0};

	// Check
	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 0x19;

	pThis = (DWORD)pPlayer;
	Status = PlayerCheckTradeItemWork(pThis, 0x0);
	if (Status == 0) return 0x55;

	addrs = (DWORD)pSendData + 0x4;
	NpcID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	ItemIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xC;
	nIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x10;
	InventoryMaterial = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x11;
	SlotMaterial = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x12;
	ItemID = *(reinterpret_cast<int*>(addrs));

	if (NpcID == 0) return 0x1;
	pNpc = GetNpc(NpcID);
	if (pNpc == 0) return 0x1;

	// Check ItemID
	pScript = GetWishItemExchangeScript(ItemIDMaterial);
	if (pScript == 0) return 0x5;

	addrs = (DWORD)pScript +0x20;
	GroupID = *(reinterpret_cast<int*>(addrs));

	pGroupScript = GetWishGroupIDScript(GroupID);
	if (pGroupScript == 0) return 0x5;

	Result = CheckGroupID(pGroupScript, ItemID);
	if (Result == 0) return 0x5;

	// Check WishTicket
	addrs = (DWORD)pScript + 0x10;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pScript + 0x14;
	ItemUseCount = *(reinterpret_cast<int*>(addrs));
	if (ItemIDUse == 0) return 0x89;

	for( int i = 0; i < ItemUseCount; i++ )
	{
		pThis = (DWORD)pPlayer + 0xCC8;
		pItemUse = FindItem(pThis, ItemIDUse);
		if (pItemUse == 0) return 0x89;

		addrs = (DWORD)pItemUse + 0x20;
		ItemIDUse = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)pItemUse + 0x24;
		nIDUse = *(reinterpret_cast<int*>(addrs));;
		InventoryUse = GetAttribute(pItemUse, 0xC);
		SlotUse = GetAttribute(pItemUse, 0xD);

		// Remove WishTicket
		addrs = (int)REMOVEITEM;
		*(reinterpret_cast<char*>(addrs)) = 0;
		addrs = (int)REMOVEITEM + 0x1;
		*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
		addrs = (int)REMOVEITEM + 0x5;
		*(reinterpret_cast<int*>(addrs)) = nIDUse;
		addrs = (int)REMOVEITEM + 0x9;
		*(reinterpret_cast<char*>(addrs)) = (char)InventoryUse;
		addrs = (int)REMOVEITEM + 0xA;
		*(reinterpret_cast<char*>(addrs)) = (char)SlotUse;
		addrs = (int)REMOVEITEM + 0xB;
		*(reinterpret_cast<char*>(addrs)) = 0;

		pThis = (DWORD)pDynamic;
		SendPacketEX(pThis, 0x1512, (int)REMOVEITEM, 0xC);

		pThis = pPlayer + 0xCC8;
		RemoveItemsInInventory(pThis, pItemUse, 1);
	}

	// Check Material
	pThis = pPlayer + 0xCC8;
	pItemMaterial = GetItem(pThis, InventoryMaterial, SlotMaterial);
	if (pItemMaterial == 0) return 5;

	addrs = pItemMaterial + 0x20;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != ItemIDMaterial) return 0x37;

	addrs = pItemMaterial + 0x24;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != nIDMaterial) return 0x37;

	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemMaterial);

	// Cerate Item
	AllocItem((int)NEWNID, ItemID);
	addrs = (int)NEWNID + 0x4;
	nID = *(reinterpret_cast<int*>(addrs));
	if (nID < 1) return 0x8E;

	pItem = CreateItem((int)NEWNID, 1);

	pThis = (DWORD)pPlayer + 0xCC8;
	Result = GetFreeInventorySlot(pThis, (int)&Inventory, (int)&Slot);
	if (Result == 0) return 0x37;

	pThis = (DWORD)pPlayer + 0xCC8;
	Result = AddItem(pThis, pItem, Inventory, Slot, 0);
	if (Result == 0) return 0x37;

	// Client Packet
	addrs = (int)WISH_ITEM_EXCH + 0x1;
	*(reinterpret_cast<int*>(addrs)) = ItemIDMaterial;
	addrs = (int)WISH_ITEM_EXCH + 0x5;
	*(reinterpret_cast<int*>(addrs)) = nIDMaterial;
	addrs = (int)WISH_ITEM_EXCH + 0x9;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryMaterial;
	addrs = (int)WISH_ITEM_EXCH + 0xA;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotMaterial;

	addrs = (int)WISH_ITEM_EXCH + 0xB;
	tagItemInit(addrs);

	addrs = (int)WISH_ITEM_EXCH;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = (int)WISH_ITEM_EXCH + 0xB;
	EpochItemBaseGetItemGR(pItem, addrs);

	pThis = (DWORD)pDynamic;
	SendPacketEX(pThis, PacketType, (int)WISH_ITEM_EXCH, 0x48);

	return 0;
}

int GetWishItemExchangeScript(int ItemID)
{
	int pScript = 0;
	int addrs;
	int BinItemID;
	int MaxCount = 0;
	int Offset = 0;

	MaxCount = WISHITEMEXCHBIN_SIZE / 0x24;
	Offset = (DWORD)WISHITEMEXCHBIN_ADDRS;
	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x18;
		BinItemID = *(reinterpret_cast<int*>(addrs));
		if (BinItemID == ItemID)
		{
			pScript = Offset;
			break;
		}
		Offset += 0x24;
	}

	return pScript;
}
