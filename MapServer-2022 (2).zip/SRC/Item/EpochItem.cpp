#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

int EQITEMP1_RET = 0x004262D7;
int EQITEMP3_RET = 0x0057553F;

int UNEQUIPITEM1_RET = 0x004266D2;
int UNEQUIPITEM2_RET = 0x0050FA4D;
int UNEQUIPITEM4_RET = 0x00573F9A;

int EXCHANGEEQUIPITEM_RET = 0x00426F0F;

unsigned char EQUIPITEM_BUFFER[191] = {0};
int EQUIPITEM_ADDRS = (DWORD)EQUIPITEM_BUFFER;

unsigned char UNEQUIPITEM_BUFFER[191] = {0};
int UNEQUIPITEM_ADDRS = (DWORD)UNEQUIPITEM_BUFFER;

unsigned char EXCHANGEEQUIPITEM_BUFFER[201] = {0};
int EXCHANGEEQUIPITEM_ADDRS = (DWORD)EXCHANGEEQUIPITEM_BUFFER;

extern int CHARSTATUS_SIZE;
int EQUIP_PKSIZE = 0xB + CHARSTATUS_SIZE;
int EXCHANGE_PKSIZE = 0x15 + CHARSTATUS_SIZE;

/******* ASM Funs *******/
extern int GETSTATUS;
extern int SENDPACKET_FUN;

// **** 2018 RCM_MAP_EQUIPITEM 0x150B ************************************************
void EquipItemP1(int SendPacketPTR)
{
	__asm mov edi, EQUIPITEM_ADDRS
	// +0
	__asm mov byte ptr ss:[edi],0x0
	// SendPacket
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov ecx,dword ptr ds:[eax]
	__asm mov edx,dword ptr ds:[eax+0x4]
	// +1 ItemID
	__asm mov dword ptr ss:[edi+0x01],ecx
	// +5 Type
	__asm mov dword ptr ss:[edi+0x05],edx
	// +9 ToInventory
	__asm mov byte ptr ss:[edi+0x09],0
	// SendPacket
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov cl,byte ptr ds:[eax+0xA]
	// +A ToSlot
	__asm mov byte ptr ss:[edi+0x0A],dl
	// +B CharStatus
	__asm add edi, 0x0B
	__asm push edi
	// PlayerPTR
	__asm mov ecx,dword ptr ss:[ebp-0x50]
	__asm push ecx
	__asm call GETSTATUS

	// Send Packet
	// 2021 PacketSize 0xBB; 2018 PacketSize 0x77;
	__asm mov edi, EQUIPITEM_ADDRS
	__asm mov eax, EQUIP_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x150B
	__asm mov ecx,dword ptr ss:[ebp-0xE8]
	__asm mov edx,dword ptr ds:[ecx]
	__asm mov ecx,dword ptr ss:[ebp-0xE8]
	__asm call dword ptr ds:[edx+0x2C]

	__asm jmp EQITEMP1_RET

}

void EquipItemP3()
{
	__asm mov edi, EQUIPITEM_ADDRS
	// +0
	__asm mov byte ptr ss:[edi],0x0
	// ItemPTR
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov ecx,dword ptr ds:[eax+0x20]
	__asm mov dword ptr ss:[ebp-0x90],ecx
	__asm mov edx,dword ptr ss:[ebp-0x90]
	// +1 ItemID
	__asm mov dword ptr ss:[edi+0x1],edx
	// ItemPTR
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov ecx,dword ptr ds:[eax+0x24]
	__asm mov dword ptr ss:[ebp-0x94],ecx
	__asm mov edx,dword ptr ss:[ebp-0x94]
	// +5 Type
	__asm mov dword ptr ss:[edi+0x5],edx
	// +9 ToInventory
	__asm mov byte ptr ss:[edi+0x9],0x0
	// +A ToSlot
	__asm mov byte ptr ss:[edi+0x0A],0x1F
	// +B CharStatus
	__asm add edi, 0x0B
	__asm push edi
	// PlayerPTR
	__asm mov ecx,dword ptr ss:[ebp-0xA4]
	__asm mov ecx,dword ptr ds:[ecx+0x24]
	__asm push ecx
	__asm call GETSTATUS
	// PlayerPTR
	__asm mov edx,dword ptr ss:[ebp-0xA4]
	__asm mov eax,dword ptr ds:[edx+0x24]
	__asm mov dword ptr ss:[ebp-0x9C],eax
	__asm mov ecx,dword ptr ss:[ebp-0x9C]
	// DynamicPTR
	__asm mov edx,dword ptr ds:[ecx+0x1098]
	__asm mov dword ptr ss:[ebp-0x98],edx
	// Check DynamicPTR
	__asm cmp dword ptr ss:[ebp-0x98],0x0
	__asm je RET_TARGET

	// Send Packet
	// 2021 PacketSize 0xBB; 2018 PacketSize 0x77;
	__asm mov edi, EQUIPITEM_ADDRS
	__asm mov eax, EQUIP_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x150B
	__asm mov ecx,dword ptr ss:[ebp-0x98]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp EQITEMP3_RET

}

// **** 2018 RCM_MAP_UNEQUIPITEM 0x150D **********************************************
void UnEquipItemP1(int SendPacketPTR)
{
	__asm mov edi, UNEQUIPITEM_ADDRS
	// +0
	__asm mov byte ptr ss:[edi],0x0
	// SendPacket
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov eax,dword ptr ds:[edx]
	__asm mov ecx,dword ptr ds:[edx+0x4]
	// +1 ItemID
	__asm mov dword ptr ss:[edi+0x01],eax
	// +5 Type
	__asm mov dword ptr ss:[edi+0x05],ecx
	// SendPacket
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov al,byte ptr ds:[edx+0xA]
	// +9 ToInventory
	__asm mov byte ptr ss:[edi+0x09],al
	// SendPacket
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm mov dl,byte ptr ds:[ecx+0xB]
	// +A ToSlot
	__asm mov byte ptr ss:[edi+0x0A],dl
	// +B CharStatus
	__asm add edi, 0x0B
	__asm push edi
	// PlayerPTR
	__asm mov ecx,dword ptr ss:[ebp-0x50]
	__asm push ecx
	__asm call GETSTATUS
	
	// Send Packet
	// 2021 PacketSize 0xBB; 2018 PacketSize 0x77;
	__asm mov edi, UNEQUIPITEM_ADDRS
	__asm mov eax, EQUIP_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x150D
	__asm mov edx,dword ptr ss:[ebp-0x78]
	__asm mov eax,dword ptr ds:[edx]
	__asm mov ecx,dword ptr ss:[ebp-0x78]
	__asm call dword ptr ds:[eax+0x2C]

	__asm jmp UNEQUIPITEM1_RET

}

void UnEquipItemP2()
{
	__asm mov edi, UNEQUIPITEM_ADDRS
	// +0
	__asm mov byte ptr ss:[edi],0x0
	// ItemPTR
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov ecx,dword ptr ds:[eax+0x24]
	__asm mov dword ptr ss:[ebp-0x9C],ecx
	__asm mov edx,dword ptr ss:[ebp-0x9C]
	// +5 Type
	__asm mov dword ptr ss:[edi+0x5],edx
	// ItemPTR
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov ecx,dword ptr ds:[eax+0x20]
	__asm mov dword ptr ss:[ebp-0xA0],ecx
	__asm mov edx,dword ptr ss:[ebp-0xA0]
	// +1 ItemID
	__asm mov dword ptr ss:[edi+0x1],edx
	// +9 ToInventory
	__asm mov byte ptr ss:[edi+0x9],0xFF
	// +A ToSlot
	__asm mov byte ptr ss:[edi+0xA],0xFF
	// +B CharStatus
	__asm add edi, 0x0B
	__asm push edi
	// PlayerPTR
	__asm mov ecx,dword ptr ss:[ebp-0xD0]
	__asm push ecx
	__asm call GETSTATUS

	// PlayerPTR
	__asm mov ecx,dword ptr ss:[ebp-0xD0]
	// DynamicPTR
	__asm mov edx,dword ptr ds:[ecx+0x1098]
	__asm mov dword ptr ss:[ebp-0xA4],edx
	// Check DynamicPTR
	__asm cmp dword ptr ss:[ebp-0xA4],0x0
	__asm je RET_TARGET

	// Send Packet
	// 2021 PacketSize 0xBB; 2018 PacketSize 0x77;
	__asm mov edi, UNEQUIPITEM_ADDRS
	__asm mov eax, EQUIP_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x150D
	__asm mov ecx,dword ptr ss:[ebp-0xA4]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp UNEQUIPITEM2_RET

}

void UnEquipItemP4()
{
	__asm mov edi, UNEQUIPITEM_ADDRS
	// +0
	__asm mov byte ptr ss:[edi],0x0
	// ItemPTR
	__asm mov edx,dword ptr ss:[ebp-0xC]
	__asm mov eax,dword ptr ds:[edx+0x24]
	__asm mov dword ptr ss:[ebp-0xA8],eax
	__asm mov ecx,dword ptr ss:[ebp-0xA8]
	// +5 Type
	__asm mov dword ptr ss:[edi+0x5],ecx
	// ItemPTR
	__asm mov edx,dword ptr ss:[ebp-0xC]
	__asm mov eax,dword ptr ds:[edx+0x20]
	__asm mov dword ptr ss:[ebp-0xAC],eax
	__asm mov ecx,dword ptr ss:[ebp-0xAC]
	// +1 ItemID
	__asm mov dword ptr ss:[edi+0x1],ecx
	// +9 ToInventory
	__asm mov byte ptr ss:[edi+0x9],0xFF
	// +A ToSlot
	__asm mov byte ptr ss:[edi+0xA],0xFF
	// +B CharStatus
	__asm add edi, 0x0B
	__asm push edi
	// PlayerPTR
	__asm mov ecx,dword ptr ss:[ebp-0x10]
	__asm push ecx
	__asm call GETSTATUS
	// PlayerPTR
	__asm mov eax,dword ptr ss:[ebp-0x10]
	// DynamicPTR
	__asm mov ecx,dword ptr ds:[eax+0x1098]
	__asm mov dword ptr ss:[ebp-0xB0],ecx
	// Check DynamicPTR
	__asm cmp dword ptr ss:[ebp-0xB0],0x0
	__asm je RET_TARGET

	// Send Packet
	// 2021 PacketSize 0xBB; 2018 PacketSize 0x77;
	__asm mov edi, UNEQUIPITEM_ADDRS
	__asm mov eax, EQUIP_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x150D
	__asm mov ecx,dword ptr ss:[ebp-0xB0]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp UNEQUIPITEM4_RET

}

// **** 2018 RCM_MAP_EXCHANGEEQUIPITEM 0x150F ****************************************
void ExchangeEquipItem(int SendPacketPTR)
{
	__asm mov edi, EXCHANGEEQUIPITEM_ADDRS
	// +0
	__asm mov byte ptr ss:[edi],0x0
	// SendPacket
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov ecx,dword ptr ds:[eax]
	__asm mov edx,dword ptr ds:[eax+0x4]
	// +B EItemID
	__asm mov dword ptr ss:[edi+0x0B],ecx
	// +F EType
	__asm mov dword ptr ss:[edi+0x0F],edx
	// SendPacket
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov cl,byte ptr ds:[eax+0x12]
	// +13 EToInventory
	__asm mov byte ptr ss:[edi+0x13],cl
	// SendPacket
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov al,byte ptr ds:[edx+0x13]
	// +14 EToSlot
	__asm mov byte ptr ss:[edi+0x14],al
	// SendPacket
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm mov edx,dword ptr ds:[ecx+0xA]
	__asm mov eax,dword ptr ds:[ecx+0xE]
	// +1 UItemID
	__asm mov dword ptr ss:[edi+0x01],edx
	// +5 UType
	__asm mov dword ptr ss:[edi+0x05],eax
	// SendPacket
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm mov dl,byte ptr ds:[ecx+0x8]
	// +9 UToInventory
	__asm mov byte ptr ss:[edi+0x09],dl
	// SendPacket
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov cl,byte ptr ds:[eax+0x9]
	// +A UToSlot
	__asm mov byte ptr ss:[edi+0x0A],cl
	// +15 CharStatus
	__asm add edi, 0x15
	__asm push edi
	// PlayerPTR
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm push ecx
	__asm call GETSTATUS

	// Send Packet
	// 2021 PacketSize 0xC5; 2018 PacketSize 0x81;
	__asm mov edi, EXCHANGEEQUIPITEM_ADDRS
	__asm mov eax, EXCHANGE_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x150F
	__asm mov ecx,dword ptr ss:[ebp-0x170]
	__asm mov edx,dword ptr ds:[ecx]
	__asm mov ecx,dword ptr ss:[ebp-0x170]
	__asm call dword ptr ds:[edx+0x2C]

	__asm jmp EXCHANGEEQUIPITEM_RET

}
