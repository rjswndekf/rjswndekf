#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

unsigned char ENCHANT_CHARM[246] = {0};

extern int CHCHARMS_ADDRS;
extern int CHCHARMSSIZE;
int CHCHARMSLINE = 0x70;

void EnchantTalisman(int pDynamic, int pSendPacket)
{
	int Result;
	int addrs;
	int pSendData;
	unsigned char CHCHARM_RESULT[1] = {0};

	pSendData = pSendPacket + 4;
	Result = GetEnchantTalisman(pDynamic, pSendData);
	if (Result != 0)
	{
		addrs = (int)CHCHARM_RESULT;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;
		SendPacketEX(pDynamic, 0x2326, (int)CHCHARM_RESULT, 0x1);
	}
}

int GetEnchantTalisman(int pDynamic, int pSendData)
{
	int Result = 0;
	int addrs = 0;
	int pPlayer = 0;
	int pThis = 0;

	int NpcID;
	int NpcNID;
	int i;

	int ItemUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;

	int ItemMaterial1;
	int nIDMaterial1;
	int InventoryMaterial1;
	int SlotMaterial1;

	int ItemMaterial2;
	int nIDMaterial2;
	int InventoryMaterial2;
	int SlotMaterial2;

	int ItemMaterial3;
	int nIDMaterial3;
	int InventoryMaterial3;
	int SlotMaterial3;

	int pScript;
	int pItem = 0;
	int pItemUse = 0;
	int pItemMaterial1 = 0;
	int pItemMaterial2 = 0;
	int pItemMaterial3 = 0;

	int Material1Count = 0;
	int Material2Count = 0;
	int Material3Count = 0;

	int Material1CurStack = 0;
	int Material2CurStack = 0;
	int Material3CurStack = 0;

	int nID;
	int Inventory;
	int Slot;

	int ItemID1 = 0;
	int Rate1 = 0;
	int Count1 = 0;
	int ItemID2 = 0;
	int Rate2 = 0;
	int Count2 = 0;
	int ItemID3 = 0;
	int Rate3 = 0;
	int Count3 = 0;

	int ItemCount = 0;
	int Success = 0;
	int Chance = 0;
	
	unsigned char NEWNID[8] = {0};
	memset(NEWNID, 0, 8);
	memset(ENCHANT_CHARM, 0, 246);

	// Check
	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 0x19;

	// Send Packet
	addrs = (DWORD)pSendData;
	NpcID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x4;
	NpcNID = *(reinterpret_cast<int*>(addrs));
	// ItemUse
	addrs = (DWORD)pSendData + 0x8;
	ItemUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xC;
	nIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x10;
	InventoryUse = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x11;
	SlotUse = *(reinterpret_cast<char*>(addrs));
	// Material1
	addrs = (DWORD)pSendData + 0x12;
	ItemMaterial1 = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x16;
	nIDMaterial1 = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x1A;
	InventoryMaterial1 = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x1B;
	SlotMaterial1 = *(reinterpret_cast<char*>(addrs));
	// Material2
	addrs = (DWORD)pSendData + 0x1C;
	ItemMaterial2 = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x20;
	nIDMaterial2 = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x24;
	InventoryMaterial2 = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x25;
	SlotMaterial2 = *(reinterpret_cast<char*>(addrs));
	// Material3
	addrs = (DWORD)pSendData + 0x26;
	ItemMaterial3 = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x2A;
	nIDMaterial3 = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x2E;
	InventoryMaterial3 = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x2F;
	SlotMaterial3 = *(reinterpret_cast<char*>(addrs));

	// Check
	pScript = GetEnchantTalismanScript(ItemUse, ItemMaterial1, ItemMaterial2, ItemMaterial3);
	if (pScript == 0) return 0x37;

	pThis = pPlayer + 0xCC8;
	pItemUse = GetItem(pThis, InventoryUse, SlotUse);
	if (pItemUse == 0) return 0x37;

	addrs = pScript + 0x44;
	Material1Count = *(reinterpret_cast<int*>(addrs));
	addrs = pScript + 0x4C;
	Material2Count = *(reinterpret_cast<int*>(addrs));
	addrs = pScript + 0x54;
	Material3Count = *(reinterpret_cast<int*>(addrs));

	// Check Current Stack
	if (ItemMaterial1 != 0)
	{
		pThis = pPlayer + 0xCC8;
		pItemMaterial1 = FindItem(pThis, ItemMaterial1);
		if (pItemMaterial1 == 0) return 0x19;
		pThis = pPlayer + 0xCC8;
		Material1CurStack = GetItemCurrentStack(pThis, ItemMaterial1);
		if (Material1CurStack < Material1Count) return 0x19;
	}

	if (ItemMaterial2 != 0)
	{
		pThis = pPlayer + 0xCC8;
		pItemMaterial2 = FindItem(pThis, ItemMaterial2);
		if (pItemMaterial2 == 0) return 0x19;
		pThis = pPlayer + 0xCC8;
		Material2CurStack = GetItemCurrentStack(pThis, ItemMaterial2);
		if (Material2CurStack < Material2Count) return 0x19;
	}

	if (ItemMaterial3 != 0)
	{
		pThis = pPlayer + 0xCC8;
		pItemMaterial3 = FindItem(pThis, ItemMaterial3);
		if (pItemMaterial3 == 0) return 0x19;
		pThis = pPlayer + 0xCC8;
		Material3CurStack = GetItemCurrentStack(pThis, ItemMaterial3);
		if (Material3CurStack < Material3Count) return 0x19;
	}

	// Remove Items
	if (pItemMaterial1 != 0)
	{
		pThis = pPlayer + 0xCC8;
		RemoveItemsInInventory(pThis, pItemMaterial1, Material1Count);
	}
	if (pItemMaterial2 != 0)
	{
		pThis = pPlayer + 0xCC8;
		RemoveItemsInInventory(pThis, pItemMaterial2, Material2Count);
	}
	if (pItemMaterial3 != 0)
	{
		pThis = pPlayer + 0xCC8;
		RemoveItemsInInventory(pThis, pItemMaterial3, Material3Count);
	}

	// Client Packet
	addrs = (int)ENCHANT_CHARM;
	*(reinterpret_cast<char*>(addrs)) = 0;

	addrs = (int)ENCHANT_CHARM + 0x2;
	for( i = 0; i < 4; i++ )
	{
		tagItemInit(addrs);
		addrs += 0x3D;
	}

	// Cerate Item
	addrs = pScript + 0x58;
	ItemID1 = *(reinterpret_cast<int*>(addrs));
	addrs = pScript + 0x5C;
	Rate1 = *(reinterpret_cast<int*>(addrs));
	Count1 = 1;

	addrs = pScript + 0x60;
	ItemID2 = *(reinterpret_cast<int*>(addrs));
	addrs = pScript + 0x64;
	Rate2 = *(reinterpret_cast<int*>(addrs));
	Count2 = 1;

	addrs = pScript + 0x68;
	ItemID3 = *(reinterpret_cast<int*>(addrs));
	addrs = pScript + 0x6C;
	Rate3 = *(reinterpret_cast<int*>(addrs));
	Count3 = 1;

	Chance = BioticBaseGetRandom(pPlayer, 1000000);
	if (Rate1 > Chance)
	{
		ItemCount = 1;

		// Success
		pThis = pPlayer + 0xCC8;
		RemoveItem(pThis, pItemUse);

		// Cerate Item
		Inventory = 0xFF;
		Slot = 0xFF;

		AllocItem((int)NEWNID, ItemID1);
		addrs = (int)NEWNID + 0x4;
		nID = *(reinterpret_cast<int*>(addrs));
		if (nID < 1) return 0x8E;

		pItem = CreateItem((int)NEWNID, Count1);

		pThis = (DWORD)pPlayer + 0xCC8;
		Result = GetFreeInventorySlot(pThis, (int)&Inventory, (int)&Slot);
		if (Result == 0) return 0x37;

		pThis = (DWORD)pPlayer + 0xCC8;
		Result = AddItem(pThis, pItem, Inventory, Slot, 0);
		if (Result == 0) return 0x37;

		// Client Packet
		addrs = (int)ENCHANT_CHARM + 0x2;
		EpochItemBaseGetItemGR(pItem, addrs);
	}
	else
	{
		// Item Count
		ItemCount = 0;

		// Client Packet
		addrs = (int)ENCHANT_CHARM + 0x2;
		EpochItemBaseGetItemGR(pItemUse, addrs);

		/***
		if (ItemID2 != 0)
		{
			Chance = BioticBaseGetRandom(pPlayer, 1000000);
			if (Rate2 > Chance)
			{
				//pThis = pPlayer + 0xCC8;
				//RemoveItem(pThis, pItemUse);

				// Cerate Item
				Inventory = 0xFF;
				Slot = 0xFF;

				AllocItem((int)NEWNID, ItemID2);
				addrs = (int)NEWNID + 0x4;
				nID = *(reinterpret_cast<int*>(addrs));
				if (nID < 1) return 0x8E;

				pItem = CreateItem((int)NEWNID, Count2);

				pThis = (DWORD)pPlayer + 0xCC8;
				Result = GetFreeInventorySlot(pThis, (int)&Inventory, (int)&Slot);
				if (Result == 0) return 0x37;

				pThis = (DWORD)pPlayer + 0xCC8;
				Result = AddItem(pThis, pItem, Inventory, Slot, 0);
				if (Result == 0) return 0x37;

				// Client Packet
				addrs = (int)ENCHANT_CHARM + 0x2;
				EpochItemBaseGetItemGR(pItem, addrs);

				if (ItemID3 != 0)
				{
					Chance = BioticBaseGetRandom(pPlayer, 1000000);
					if (Rate3 > Chance)
					{
						memset(NEWNID, 0, 8);

						// Cerate Item
						Inventory = 0xFF;
						Slot = 0xFF;

						AllocItem((int)NEWNID, ItemID3);
						addrs = (int)NEWNID + 0x4;
						nID = *(reinterpret_cast<int*>(addrs));
						if (nID < 1) return 0x8E;

						pItem = CreateItem((int)NEWNID, Count3);

						pThis = (DWORD)pPlayer + 0xCC8;
						Result = GetFreeInventorySlot(pThis, (int)&Inventory, (int)&Slot);
						if (Result == 0) return 0x37;

						pThis = (DWORD)pPlayer + 0xCC8;
						Result = AddItem(pThis, pItem, Inventory, Slot, 0);
						if (Result == 0) return 0x37;

						// Client Packet
						addrs = (int)ENCHANT_CHARM + 0x3F;
						EpochItemBaseGetItemGR(pItem, addrs);
					}
				}
			}
		}
		***/
	}

	// ItemCount 0 Fail / Other Success
	addrs = (int)ENCHANT_CHARM + 0x1;
	*(reinterpret_cast<char*>(addrs)) = (char)ItemCount;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x2326, (int)ENCHANT_CHARM, 0xF6);

	return 0;
}

int GetEnchantTalismanScript(int UseItem, int Material1, int Material2, int Material3)
{
	int pScript = 0;
	int addrs = 0;
	int BinUseItem = 0;
	int BinMaterial1 = 0;
	int BinMaterial2 = 0;
	int BinMaterial3 = 0;
	int MaxCount = 0;
	int Offset = 0;

	MaxCount = CHCHARMSSIZE / CHCHARMSLINE;

	Offset = (DWORD)CHCHARMS_ADDRS;

	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x3C;
		BinUseItem = *(reinterpret_cast<int*>(addrs));
		if (BinUseItem == UseItem)
		{
			addrs = Offset + 0x40;
			BinMaterial1 = *(reinterpret_cast<int*>(addrs));
			if (BinMaterial1 == Material1)
			{
				addrs = Offset + 0x48;
				BinMaterial2 = *(reinterpret_cast<int*>(addrs));
				if (BinMaterial2 == Material2)
				{
					addrs = Offset + 0x50;
					BinMaterial3 = *(reinterpret_cast<int*>(addrs));
					if (BinMaterial3 == Material3)
					{
						pScript = Offset;
						break;
					}
				}
			}
		}
		Offset += CHCHARMSLINE;
	}

	return pScript;
}
