#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

extern int TRANSRACIPE_ADDRS;
extern int TRANSRACIPE_SIZE;
extern int CHACCESS_ADDRS;
extern int CHACCESS_SIZE;
extern int CHWEAPON_ADDRS;
extern int CHWEAPON_SIZE;
extern int CHITEMS_ADDRS;
extern int CHITEMS_SIZE;

unsigned char TRANSEQUIPRACIP[82] = {0};
int TRANSEQUIPRACIP_ADDRS = (DWORD)TRANSEQUIPRACIP;

unsigned char TRANSACCESSORY[86] = {0};
int TRANSACCESSORY_ADDRS = (DWORD)TRANSACCESSORY;

unsigned char TRANSWEAPONS[82] = {0};
int TRANSWEAPONS_ADDRS = (DWORD)TRANSWEAPONS;

unsigned char IGNSKYITEM[86] = {0};
int IGNSKYITEM_ADDRS = (DWORD)IGNSKYITEM;

void TranscendenceEquipRacipe(int pDynamic, int pSendPacket)
{
	int Result;
	int pSendData;
	pSendData = pSendPacket + 4;
	Result = GetTranscendenceEquip(pDynamic, pSendData);
	if (Result != 0)
	{
		*(reinterpret_cast<char*>(TRANSEQUIPRACIP_ADDRS)) = (char)Result;
		SendPacketEX(pDynamic, 0x231F, TRANSEQUIPRACIP_ADDRS, 0x1);
	}
}

int GetTranscendenceEquip(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int pThis;
	int pItem;
	int pItemStore;
	int pItemMaterial;
	int CheckMaterial;
	int pMaterialAttr;
	int MaterialOption;
	int MaterialValue;
	int Result;

	int ItemID;
	int nID;
	int pNID;
	int Inventory;
	int Slot;
	int pInventory;
	int pSlot;

	int ItemIDStore;
	int nIDStore;
	int InventoryStore;
	int SlotStore;

	int ItemIDMaterial;
	int nIDMaterial;
	int InventoryMaterial;
	int SlotMaterial;

	unsigned char RACIPITEMID[8] = {0};
	int RACIPITEMID_ADDRS = (DWORD)RACIPITEMID;

	unsigned char MATERIALGR[61] = {0};
	int MATERIALGR_ADDRS = (DWORD)MATERIALGR;

	unsigned char FREESPACE[8] = {0};
	int FREESPACE_ADDRS = (DWORD)FREESPACE;

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));

	if (pPlayer == 0) return 2;
	
	// Send Packet
	addrs = (DWORD)pSendData + 0x4;
	ItemIDStore = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	nIDStore = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xC;
	InventoryStore = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0xD;
	SlotStore = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)pSendData + 0xE;
	ItemIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x12;
	nIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x16;
	InventoryMaterial = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x17;
	SlotMaterial = *(reinterpret_cast<char*>(addrs));
	
	addrs = (DWORD)TRANSEQUIPRACIP_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)TRANSEQUIPRACIP_ADDRS + 1;
	*(reinterpret_cast<int*>(addrs)) = ItemIDStore;
	addrs = (DWORD)TRANSEQUIPRACIP_ADDRS + 5;
	*(reinterpret_cast<int*>(addrs)) = nIDStore;
	addrs = (DWORD)TRANSEQUIPRACIP_ADDRS + 9;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryStore;
	addrs = (DWORD)TRANSEQUIPRACIP_ADDRS + 10;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotStore;
	addrs = (DWORD)TRANSEQUIPRACIP_ADDRS + 11;
	*(reinterpret_cast<int*>(addrs)) = ItemIDMaterial;
	addrs = (DWORD)TRANSEQUIPRACIP_ADDRS + 15;
	*(reinterpret_cast<int*>(addrs)) = nIDMaterial;
	addrs = (DWORD)TRANSEQUIPRACIP_ADDRS + 19;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryMaterial;
	addrs = (DWORD)TRANSEQUIPRACIP_ADDRS + 20;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotMaterial;

	addrs = TRANSEQUIPRACIP_ADDRS + 0x15;
	tagItemInit(addrs);

	tagItemInit(MATERIALGR_ADDRS);

	pThis = pPlayer + 0xCC8;
	pItemStore = GetItem(pThis, InventoryStore, SlotStore);
	if (pItemStore == 0) return 5;

	pThis = pPlayer + 0xCC8;
	pItemMaterial = GetItem(pThis, InventoryMaterial, SlotMaterial);
	if (pItemMaterial == 0) return 5;
	
	addrs = pItemMaterial + 0x20;
	CheckMaterial = *(reinterpret_cast<int*>(addrs));
	if (CheckMaterial != ItemIDMaterial) return 0x37;

	addrs = pItemMaterial + 0x24;
	CheckMaterial = *(reinterpret_cast<int*>(addrs));
	if (CheckMaterial != nIDMaterial) return 0x37;

	ItemID = GetRacipeEquip(ItemIDMaterial);
	if (ItemID == 0) return 0x37;

	// Cerate Item
	AllocItem(RACIPITEMID_ADDRS, ItemID);
	pNID = RACIPITEMID_ADDRS + 4;
	nID = *(reinterpret_cast<int*>(pNID));
	if (nID < 1) return 0x8E;

	pItem = CreateItem(RACIPITEMID_ADDRS, 1);

	EpochItemBaseGetItemGR(pItemMaterial, MATERIALGR_ADDRS);

	// Set Option
	pMaterialAttr = MATERIALGR_ADDRS + 8;
	for( int i=0; i < 14; i++ )
	{
		addrs = (DWORD)pMaterialAttr;
		MaterialOption = *(reinterpret_cast<char*>(addrs));
		if (MaterialOption != 0)
		{
			addrs = (DWORD)pMaterialAttr + 1;
			MaterialValue = *(reinterpret_cast<unsigned short*>(addrs));
			ItemOptionSetType(pItem, MaterialOption, MaterialValue);
		}
		pMaterialAttr += 3;
	}

	addrs = (DWORD)FREESPACE_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;
	addrs = (DWORD)FREESPACE_ADDRS + 4;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;

	pInventory = FREESPACE_ADDRS;
	pSlot = FREESPACE_ADDRS + 4;

	pThis = pPlayer + 0xCC8;
	Result = GetFreeInventorySlot(pThis, pInventory, pSlot);
	if (Result == 0) return 0x37;

	addrs = FREESPACE_ADDRS;
	Inventory = *(reinterpret_cast<int*>(addrs));
	addrs = FREESPACE_ADDRS + 4;
	Slot = *(reinterpret_cast<int*>(addrs));

	pThis = pPlayer + 0xCC8;
	Result = AddItem(pThis, pItem, Inventory, Slot, 0);
	if (Result == 0) return 0x37;

	addrs = TRANSEQUIPRACIP_ADDRS + 0x15;
	EpochItemBaseGetItemGR(pItem, addrs);

	// Remove Item
	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemStore);

	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemMaterial);

	pThis = pDynamic;
	SendPacketEX(pThis, 0x231F, TRANSEQUIPRACIP_ADDRS, 0x52);

	return 0;
}

int GetRacipeEquip(int MaterialID)
{
	int addrs;
	int ItemID = 0;
	int BinItemID = 0;
	int MaxCount = 0;
	int Offset = 0;
	
	MaxCount = TRANSRACIPE_SIZE / 0x5C;

	Offset = (DWORD)TRANSRACIPE_ADDRS;

	for( int i=0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x8;
		BinItemID = *(reinterpret_cast<int*>(addrs));
		if (BinItemID == MaterialID)
		{
			addrs = Offset + 0xC;
			ItemID = *(reinterpret_cast<int*>(addrs));
			break;
		}
		Offset += 0x5C;
	}
	return ItemID;
}


void TranscendenceAccessoryRacipe(int pDynamic, int pSendPacket)
{
	int Result;
	int pSendData;
	pSendData = pSendPacket + 4;
	Result = GetTranscendenceAccessory(pDynamic, pSendData);
	if (Result != 0)
	{
		*(reinterpret_cast<char*>(TRANSACCESSORY_ADDRS)) = (char)Result;
		SendPacketEX(pDynamic, 0x2324, TRANSACCESSORY_ADDRS, 0x1);
	}
}

int GetTranscendenceAccessory(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int pThis = 0;
	int pItem;
	int pItemStore;
	int pItemMaterial;
	int CheckMaterial;
	int pMaterialAttr;
	int MaterialOption;
	int MaterialValue;
	int Result;

	int ItemID;
	int nID;
	int pNID;
	int Inventory;
	int Slot;
	int pInventory;
	int pSlot;

	int ItemIDStore;
	int nIDStore;
	int InventoryStore;
	int SlotStore;

	int ItemIDMaterial;
	int nIDMaterial;
	int InventoryMaterial;
	int SlotMaterial;

	unsigned char RACIPITEMID[8] = {0};
	int RACIPITEMID_ADDRS = (DWORD)RACIPITEMID;

	unsigned char MATERIALGR[61] = {0};
	int MATERIALGR_ADDRS = (DWORD)MATERIALGR;

	unsigned char FREESPACE[8] = {0};
	int FREESPACE_ADDRS = (DWORD)FREESPACE;

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 2;

	// Send Packet
	addrs = (DWORD)pSendData + 0x4;
	ItemIDStore = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	nIDStore = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xC;
	InventoryStore = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0xD;
	SlotStore = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)pSendData + 0xE;
	ItemIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x12;
	nIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x16;
	InventoryMaterial = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x17;
	SlotMaterial = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)TRANSACCESSORY_ADDRS;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = (DWORD)TRANSACCESSORY_ADDRS + 0x1;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)TRANSACCESSORY_ADDRS + 0x5;
	*(reinterpret_cast<int*>(addrs)) = ItemIDStore;
	addrs = (DWORD)TRANSACCESSORY_ADDRS + 0x9;
	*(reinterpret_cast<int*>(addrs)) = nIDStore;
	addrs = (DWORD)TRANSACCESSORY_ADDRS + 0xD;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryStore;
	addrs = (DWORD)TRANSACCESSORY_ADDRS + 0xE;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotStore;
	addrs = (DWORD)TRANSACCESSORY_ADDRS + 0xF;
	*(reinterpret_cast<int*>(addrs)) = ItemIDMaterial;
	addrs = (DWORD)TRANSACCESSORY_ADDRS + 0x13;
	*(reinterpret_cast<int*>(addrs)) = nIDMaterial;
	addrs = (DWORD)TRANSACCESSORY_ADDRS + 0x17;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryMaterial;
	addrs = (DWORD)TRANSACCESSORY_ADDRS + 0x18;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotMaterial;

	ItemID = GetRacipeAccess(ItemIDStore, ItemIDMaterial);
	if (ItemID == 0) return 0x37;

	addrs = TRANSACCESSORY_ADDRS + 0x19;
	tagItemInit(addrs);

	tagItemInit(MATERIALGR_ADDRS);

	pThis = pPlayer + 0xCC8;
	pItemStore = GetItem(pThis, InventoryStore, SlotStore);
	if (pItemStore == 0) return 5;

	pThis = pPlayer + 0xCC8;
	pItemMaterial = GetItem(pThis, InventoryMaterial, SlotMaterial);
	if (pItemMaterial == 0) return 5;
	
	addrs = pItemMaterial + 0x24;
	CheckMaterial = *(reinterpret_cast<int*>(addrs));
	if (CheckMaterial != nIDMaterial) return 0x37;

	// Cerate Item
	AllocItem(RACIPITEMID_ADDRS, ItemID);
	pNID = RACIPITEMID_ADDRS + 4;
	nID = *(reinterpret_cast<int*>(pNID));
	if (nID < 1) return 0x8E;

	pItem = CreateItem(RACIPITEMID_ADDRS, 1);

	EpochItemBaseGetItemGR(pItemMaterial, MATERIALGR_ADDRS);

	// Set Option
	pMaterialAttr = MATERIALGR_ADDRS + 8;
	for( int i=0; i < 14; i++ )
	{
		addrs = (DWORD)pMaterialAttr;
		MaterialOption = *(reinterpret_cast<char*>(addrs));
		if (MaterialOption == 0x4F)
		{
			addrs = (DWORD)pMaterialAttr + 1;
			MaterialValue = *(reinterpret_cast<unsigned short*>(addrs));
			ItemOptionSetType(pItem, MaterialOption, MaterialValue);
		}
		pMaterialAttr += 3;
	}

	addrs = (DWORD)FREESPACE_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;
	addrs = (DWORD)FREESPACE_ADDRS + 4;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;

	pInventory = FREESPACE_ADDRS;
	pSlot = FREESPACE_ADDRS + 4;

	pThis = pPlayer + 0xCC8;
	Result = GetFreeInventorySlot(pThis, pInventory, pSlot);
	if (Result == 0) return 0x37;

	addrs = FREESPACE_ADDRS;
	Inventory = *(reinterpret_cast<int*>(addrs));
	addrs = FREESPACE_ADDRS + 4;
	Slot = *(reinterpret_cast<int*>(addrs));

	pThis = pPlayer + 0xCC8;
	Result = AddItem(pThis, pItem, Inventory, Slot, 0);
	if (Result == 0) return 0x37;

	addrs = TRANSACCESSORY_ADDRS + 0x19;
	EpochItemBaseGetItemGR(pItem, addrs);

	// Remove Item
	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemStore);

	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemMaterial);

	pThis = pDynamic;
	SendPacketEX(pThis, 0x2324, TRANSACCESSORY_ADDRS, 0x56);


	return 0;
}

int GetRacipeAccess(int UseItem, int MaterialItem)
{
	int addrs;
	int ItemID = 0;
	int BinUseItem = 0;
	int BinMaterial = 0;
	int MaxCount = 0;
	int Offset = 0;
	
	MaxCount = CHACCESS_SIZE / 0x18;
	Offset = (DWORD)CHACCESS_ADDRS;

	for( int i=0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x8;
		BinUseItem = *(reinterpret_cast<int*>(addrs));
		if (BinUseItem == UseItem)
		{
			addrs = Offset + 0x10;
			BinMaterial = *(reinterpret_cast<int*>(addrs));
			if (BinMaterial == MaterialItem)
			{
				addrs = Offset + 0x14;
				ItemID = *(reinterpret_cast<int*>(addrs));
				break;
			}
		}
		Offset += 0x18;
	}
	return ItemID;
}

void TranscendenceWeaponsRacipe(int pDynamic, int pSendPacket)
{
	int Result;
	int pSendData;
	pSendData = pSendPacket + 4;
	Result = GetTranscendenceWeapons(pDynamic, pSendData);
	if (Result != 0)
	{
		*(reinterpret_cast<char*>(TRANSWEAPONS_ADDRS)) = (char)Result;
		SendPacketEX(pDynamic, 0x2323, TRANSWEAPONS_ADDRS, 0x1);
	}
}

int GetTranscendenceWeapons(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int CharID;
	int pThis = 0;
	int pItem;
	int pItemTicket;
	int pItemMaterial;
	int CheckMaterial;
	int pMaterialAttr;
	int MaterialOption;
	int MaterialValue;
	int Result;

	int ItemID;
	int CheckItemID;
	int nID;
	int pNID;
	int Inventory;
	int Slot;
	int pInventory;
	int pSlot;

	int ItemIDTicket;
	int nIDTicket;
	int InventoryTicket;
	int SlotTicket;

	int ItemIDMaterial;
	int nIDMaterial;
	int InventoryMaterial;
	int SlotMaterial;

	unsigned char RACIPITEMID[8] = {0};
	int RACIPITEMID_ADDRS = (DWORD)RACIPITEMID;

	unsigned char MATERIALGR[61] = {0};
	int MATERIALGR_ADDRS = (DWORD)MATERIALGR;

	unsigned char FREESPACE[8] = {0};
	int FREESPACE_ADDRS = (DWORD)FREESPACE;

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 2;

	addrs = (DWORD)pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));

	// Send Packet
	addrs = (DWORD)pSendData;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x4;
	ItemIDTicket = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	nIDTicket = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xC;
	InventoryTicket = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0xD;
	SlotTicket = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)pSendData + 0xE;
	ItemIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x12;
	nIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x16;
	InventoryMaterial = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x17;
	SlotMaterial = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)TRANSWEAPONS_ADDRS;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = (DWORD)TRANSWEAPONS_ADDRS + 1;
	*(reinterpret_cast<int*>(addrs)) = ItemIDTicket;
	addrs = (DWORD)TRANSWEAPONS_ADDRS + 5;
	*(reinterpret_cast<int*>(addrs)) = nIDTicket;
	addrs = (DWORD)TRANSWEAPONS_ADDRS + 9;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryTicket;
	addrs = (DWORD)TRANSWEAPONS_ADDRS + 10;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotTicket;
	addrs = (DWORD)TRANSWEAPONS_ADDRS + 11;
	*(reinterpret_cast<int*>(addrs)) = ItemIDMaterial;
	addrs = (DWORD)TRANSWEAPONS_ADDRS + 15;
	*(reinterpret_cast<int*>(addrs)) = nIDMaterial;
	addrs = (DWORD)TRANSWEAPONS_ADDRS + 19;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryMaterial;
	addrs = (DWORD)TRANSWEAPONS_ADDRS + 20;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotMaterial;

	CheckItemID = CheckRacipeWeapons(ItemIDTicket, ItemIDMaterial, ItemID);
	if (CheckItemID == 0) return 0x37;

	addrs = TRANSWEAPONS_ADDRS + 0x15;
	tagItemInit(addrs);

	tagItemInit(MATERIALGR_ADDRS);

	pThis = pPlayer + 0xCC8;
	pItemTicket = GetItem(pThis, InventoryTicket, SlotTicket);
	if (pItemTicket == 0) return 5;

	pThis = pPlayer + 0xCC8;
	pItemMaterial = GetItem(pThis, InventoryMaterial, SlotMaterial);
	if (pItemMaterial == 0) return 5;

	addrs = pItemMaterial + 0x24;
	CheckMaterial = *(reinterpret_cast<int*>(addrs));
	if (CheckMaterial != nIDMaterial) return 0x37;

	// Cerate Item
	AllocItem(RACIPITEMID_ADDRS, ItemID);
	pNID = RACIPITEMID_ADDRS + 4;
	nID = *(reinterpret_cast<int*>(pNID));
	if (nID < 1) return 0x8E;

	pItem = CreateItem(RACIPITEMID_ADDRS, 1);

	EpochItemBaseGetItemGR(pItemMaterial, MATERIALGR_ADDRS);

	// Set Option
	pMaterialAttr = MATERIALGR_ADDRS + 8;
	for( int i=0; i < 14; i++ )
	{
		addrs = (DWORD)pMaterialAttr;
		MaterialOption = *(reinterpret_cast<char*>(addrs));
		if ((MaterialOption == 0x4F) || (MaterialOption == 0x55) || (MaterialOption == 0x56))
		{
			addrs = (DWORD)pMaterialAttr + 1;
			MaterialValue = *(reinterpret_cast<unsigned short*>(addrs));
			ItemOptionSetType(pItem, MaterialOption, MaterialValue);
		}
		pMaterialAttr += 3;
	}

	addrs = (DWORD)FREESPACE_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;
	addrs = (DWORD)FREESPACE_ADDRS + 4;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;

	pInventory = FREESPACE_ADDRS;
	pSlot = FREESPACE_ADDRS + 4;

	pThis = pPlayer + 0xCC8;
	Result = GetFreeInventorySlot(pThis, pInventory, pSlot);
	if (Result == 0) return 0x37;

	addrs = FREESPACE_ADDRS;
	Inventory = *(reinterpret_cast<int*>(addrs));
	addrs = FREESPACE_ADDRS + 4;
	Slot = *(reinterpret_cast<int*>(addrs));

	pThis = pPlayer + 0xCC8;
	Result = AddItem(pThis, pItem, Inventory, Slot, 0);
	if (Result == 0) return 0x37;

	addrs = TRANSWEAPONS_ADDRS + 0x15;
	EpochItemBaseGetItemGR(pItem, addrs);

	// Remove Item
	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemTicket);

	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemMaterial);

	pThis = pDynamic;
	SendPacketEX(pThis, 0x2323, TRANSWEAPONS_ADDRS, 0x52);

	return 0;
}

int CheckRacipeWeapons(int UseItem, int MaterialItem, int ItemID)
{
	int addrs;
	int pScript = 0;
	int Result = 0;
	int BinUseItem = 0;
	int BinMaterial = 0;
	int BinItemID = 0;
	int MaxCount = 0;
	int Offset = 0;
	int i;

	// 2021 0x4C
	MaxCount = CHWEAPON_SIZE / 0x4C;
	Offset = (DWORD)CHWEAPON_ADDRS;

	for( i = 0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x8;
		BinUseItem = *(reinterpret_cast<int*>(addrs));
		if (BinUseItem == UseItem)
		{
			addrs = Offset + 0xC;
			BinMaterial = *(reinterpret_cast<int*>(addrs));
			if (BinMaterial == MaterialItem)
			{
				pScript = Offset;
				break;
			}
		}
		Offset += 0x4C;
	}

	if (pScript != 0)
	{
		Offset = (DWORD)pScript + 0x10;
		for( i = 0; i < 15; i++ )
		{
			addrs = Offset + (i * 4);
			BinItemID = *(reinterpret_cast<int*>(addrs));
			if (BinItemID == ItemID)
			{
				Result = 1;
				break;
			}
		}
	}

	return Result;
}

void IgnielSkyItemRacipe(int pDynamic, int pSendPacket)
{
	int Result;
	int pSendData;
	pSendData = pSendPacket + 4;
	Result = GetIgnielSkyItem(pDynamic, pSendData);
	if (Result != 0)
	{
		*(reinterpret_cast<char*>(IGNSKYITEM_ADDRS)) = (char)Result;
		SendPacketEX(pDynamic, 0x2327, IGNSKYITEM_ADDRS, 0x1);
	}
}

int GetIgnielSkyItem(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int pThis;
	int pItem;
	int pItemUse;
	int pItemMaterial;
	int CheckMaterial;
	int pMaterialAttr;
	int MaterialOption;
	int MaterialValue;
	int Result;

	int ItemID;
	int nID;
	int pNID;
	int Inventory;
	int Slot;
	int pInventory;
	int pSlot;

	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;

	int ItemIDMaterial;
	int nIDMaterial;
	int InventoryMaterial;
	int SlotMaterial;

	unsigned char RACIPITEMID[8] = {0};
	int RACIPITEMID_ADDRS = (DWORD)RACIPITEMID;

	unsigned char MATERIALGR[61] = {0};
	int MATERIALGR_ADDRS = (DWORD)MATERIALGR;

	unsigned char FREESPACE[8] = {0};
	int FREESPACE_ADDRS = (DWORD)FREESPACE;

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 2;

	// Send Packet
	addrs = (DWORD)pSendData + 0x4;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	nIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xC;
	InventoryUse = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0xD;
	SlotUse = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)pSendData + 0xE;
	ItemIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x12;
	nIDMaterial = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x16;
	InventoryMaterial = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x17;
	SlotMaterial = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)IGNSKYITEM_ADDRS;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = (DWORD)IGNSKYITEM_ADDRS + 0x1;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)IGNSKYITEM_ADDRS + 0x5;
	*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
	addrs = (DWORD)IGNSKYITEM_ADDRS + 0x9;
	*(reinterpret_cast<int*>(addrs)) = nIDUse;
	addrs = (DWORD)IGNSKYITEM_ADDRS + 0xD;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryUse;
	addrs = (DWORD)IGNSKYITEM_ADDRS + 0xE;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotUse;
	addrs = (DWORD)IGNSKYITEM_ADDRS + 0xF;
	*(reinterpret_cast<int*>(addrs)) = ItemIDMaterial;
	addrs = (DWORD)IGNSKYITEM_ADDRS + 0x13;
	*(reinterpret_cast<int*>(addrs)) = nIDMaterial;
	addrs = (DWORD)IGNSKYITEM_ADDRS + 0x17;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryMaterial;
	addrs = (DWORD)IGNSKYITEM_ADDRS + 0x18;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotMaterial;

	ItemID = GetRacipeItem(ItemIDUse, ItemIDMaterial);
	if (ItemID == 0) return 0x37;

	addrs = IGNSKYITEM_ADDRS + 0x19;
	tagItemInit(addrs);

	tagItemInit(MATERIALGR_ADDRS);

	pThis = pPlayer + 0xCC8;
	pItemUse = GetItem(pThis, InventoryUse, SlotUse);
	if (pItemUse == 0) return 5;

	pThis = pPlayer + 0xCC8;
	pItemMaterial = GetItem(pThis, InventoryMaterial, SlotMaterial);
	if (pItemMaterial == 0) return 5;

	addrs = pItemMaterial + 0x24;
	CheckMaterial = *(reinterpret_cast<int*>(addrs));
	if (CheckMaterial != nIDMaterial) return 0x37;

	// Cerate Item
	AllocItem(RACIPITEMID_ADDRS, ItemID);
	pNID = RACIPITEMID_ADDRS + 4;
	nID = *(reinterpret_cast<int*>(pNID));
	if (nID < 1) return 0x8E;

	pItem = CreateItem(RACIPITEMID_ADDRS, 1);

	EpochItemBaseGetItemGR(pItemMaterial, MATERIALGR_ADDRS);

	// Set Option
	pMaterialAttr = MATERIALGR_ADDRS + 8;
	for( int i=0; i < 14; i++ )
	{
		addrs = (DWORD)pMaterialAttr;
		MaterialOption = *(reinterpret_cast<char*>(addrs));
		//if ((MaterialOption == 0x4F) || (MaterialOption == 0x55) || (MaterialOption == 0x56))
		if (MaterialOption != 0)
		{
			addrs = (DWORD)pMaterialAttr + 1;
			MaterialValue = *(reinterpret_cast<unsigned short*>(addrs));
			ItemOptionSetType(pItem, MaterialOption, MaterialValue);
		}
		pMaterialAttr += 3;
	}

	addrs = (DWORD)FREESPACE_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;
	addrs = (DWORD)FREESPACE_ADDRS + 4;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;

	pInventory = FREESPACE_ADDRS;
	pSlot = FREESPACE_ADDRS + 4;

	pThis = pPlayer + 0xCC8;
	Result = GetFreeInventorySlot(pThis, pInventory, pSlot);
	if (Result == 0) return 0x37;

	addrs = FREESPACE_ADDRS;
	Inventory = *(reinterpret_cast<int*>(addrs));
	addrs = FREESPACE_ADDRS + 4;
	Slot = *(reinterpret_cast<int*>(addrs));

	pThis = pPlayer + 0xCC8;
	Result = AddItem(pThis, pItem, Inventory, Slot, 0);
	if (Result == 0) return 0x37;

	addrs = IGNSKYITEM_ADDRS + 0x19;
	EpochItemBaseGetItemGR(pItem, addrs);

	// Remove Item
	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemUse);

	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemMaterial);

	pThis = pDynamic;
	SendPacketEX(pThis, 0x2327, IGNSKYITEM_ADDRS, 0x56);

	return 0;
}

int GetRacipeItem(int UseItem, int Material)
{
	int addrs;
	int ItemID = 0;
	int BinUseItem = 0;
	int BinMaterial = 0;
	int IsOption = 0;
	int RequiredLevel = 0;
	int MaxCount = 0;
	int Offset = 0;

	MaxCount = CHITEMS_SIZE / 0x20;

	Offset = (DWORD)CHITEMS_ADDRS;

	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x8;
		BinUseItem = *(reinterpret_cast<int*>(addrs));
		if (BinUseItem == UseItem)
		{
			addrs = Offset + 0x10;
			BinMaterial = *(reinterpret_cast<int*>(addrs));
			if (BinMaterial == Material)
			{
				addrs = Offset + 0x14;
				ItemID = *(reinterpret_cast<int*>(addrs));
				addrs = Offset + 0x18;
				IsOption = *(reinterpret_cast<int*>(addrs));
				if (IsOption == 1)
				{
					addrs = Offset + 0x1C;
					RequiredLevel = *(reinterpret_cast<int*>(addrs));
				}
				break;
			}
		}
		Offset += 0x20;
	}
	return ItemID;
}
