#include <RHItem.h>
#include <MapFunctions.h>
#include <ctime>

using namespace std;

unsigned char USE_DCITEM[132] = {0};
int USE_DCITEM_ADDRS = (DWORD)USE_DCITEM;

unsigned char OPENITEMUSE[132] = {0};
unsigned char OPENITEMUSE_EX[23] = {0};
unsigned char NOTICE_F044[59] = {0};
unsigned char NOTICE_2038[47] = {0};
unsigned char DBTASK_INSITEMC[65] = {0};

int USE_DCITEM_PLAYER;
int USE_DCITEM_SCRIPT;
int USE_DCITEM_RET = 0x0046161A;

int USE_DCITEM_SCRDATA;
int USE_DCITEM_THIS;
int USE_DCITEM_SEND_RET = 0x00461E1D;

unsigned char EXP64[8] = {0};
int EXP64_ADDRS = (DWORD)EXP64;

// **** RCM_MAP_USE_DC_ITEM 0x1459 *******************************
void CheckItemExp()
{

	// EXP Init
	__asm mov edi,USE_DCITEM_ADDRS
	__asm mov dword ptr es:[edi+0x23],0x0
	__asm mov dword ptr es:[edi+0x27],0x0

	// PlayerPTR
	__asm mov ecx,dword ptr ss:[ebp-0xE4]
	__asm mov USE_DCITEM_PLAYER,ecx
	// pScript
	__asm mov ecx,dword ptr ss:[ebp-0xFC]
	__asm mov USE_DCITEM_SCRIPT,ecx
	__asm cmp dword ptr ds:[ecx+0x24],0x0
	__asm je RETORIG

	CheckExp64(USE_DCITEM_PLAYER, USE_DCITEM_SCRIPT);

	__asm mov byte ptr ss:[ebp-0xD9],0x1

RETORIG:
	__asm jmp USE_DCITEM_RET
}

void CheckExp64(int pPlayer, int pScript)
{
	int addrs;
	int pThis;
	int ItemID;
	int IsExp64;
	unsigned int ExpL = 0;
	unsigned int ExpH = 0;

	addrs = pScript + 0x20;
	ItemID = *(reinterpret_cast<int*>(addrs));
	IsExp64 = GetExp64(ItemID);
	
	if (IsExp64 == 0)
	{
		addrs = pScript + 0x24;
		ExpL = *(reinterpret_cast<unsigned int*>(addrs));
	}
	else
	{
		addrs = EXP64_ADDRS;
		ExpL = *(reinterpret_cast<unsigned int*>(addrs));
		addrs = EXP64_ADDRS + 4;
		ExpH = *(reinterpret_cast<unsigned int*>(addrs));
	}

	addrs = (int)USE_DCITEM + 0x23;
	*(reinterpret_cast<unsigned int*>(addrs)) = ExpL;
	addrs = (int)USE_DCITEM + 0x27;
	*(reinterpret_cast<unsigned int*>(addrs)) = ExpH;

	pThis = pPlayer;
	OpenItemAddExp(pThis, ExpL, ExpH);
}

void UseDCItemPacket()
{
	__asm lea eax,dword ptr ss:[ebp-0xD8]
	__asm mov USE_DCITEM_SCRDATA,eax
	__asm mov ecx,dword ptr ss:[ebp-0x2D4]
	__asm mov USE_DCITEM_THIS,ecx

	UseDCItemPacketSend(USE_DCITEM_THIS, USE_DCITEM_SCRDATA);

	__asm jmp USE_DCITEM_SEND_RET
}

void UseDCItemPacketSend(int pDynamic, int pSrcData)
{
	int addrs;
	int pThis;

	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;

	int ItemIDKey1 = 0;
	int nIDKey1 = 0;
	int InventoryKey1 = 0;
	int SlotKey1 = 0;

	int ItemIDKey2 = 0;
	int nIDKey2 = 0;
	int InventoryKey2 = 0;
	int SlotKey2 = 0;
	
	int Money;

	int ItemMaxCount;
	int ItemID;
	int Count;

	addrs = (DWORD)pSrcData + 0x1;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSrcData + 0x5;
	nIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSrcData + 0x9;
	InventoryUse = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSrcData + 0xA;
	SlotUse = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)pSrcData + 0xB;
	ItemIDKey1 = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSrcData + 0xF;
	nIDKey1 = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSrcData + 0x13;
	InventoryKey1 = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSrcData + 0x14;
	SlotKey1 = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)pSrcData + 0x15;
	ItemIDKey2 = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSrcData + 0x19;
	nIDKey2 = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSrcData + 0x1D;
	InventoryKey2 = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSrcData + 0x1E;
	SlotKey2 = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)pSrcData + 0x1F;
	Money = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)pSrcData + 0x2F;
	ItemMaxCount = *(reinterpret_cast<char*>(addrs));

	addrs = (int)USE_DCITEM;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = (int)USE_DCITEM + 0x1;
	*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
	addrs = (int)USE_DCITEM + 0x5;
	*(reinterpret_cast<int*>(addrs)) = nIDUse;
	addrs = (int)USE_DCITEM + 0x9;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryUse;
	addrs = (int)USE_DCITEM + 0xA;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotUse;

	addrs = (int)USE_DCITEM + 0xB;
	*(reinterpret_cast<int*>(addrs)) = ItemIDKey1;
	addrs = (int)USE_DCITEM + 0xF;
	*(reinterpret_cast<int*>(addrs)) = nIDKey1;
	addrs = (int)USE_DCITEM + 0x13;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryKey1;
	addrs = (int)USE_DCITEM + 0x14;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotKey1;

	addrs = (int)USE_DCITEM + 0x15;
	*(reinterpret_cast<int*>(addrs)) = ItemIDKey2;
	addrs = (int)USE_DCITEM + 0x19;
	*(reinterpret_cast<int*>(addrs)) = nIDKey2;
	addrs = (int)USE_DCITEM + 0x1D;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryKey2;
	addrs = (int)USE_DCITEM + 0x1E;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotKey2;

	addrs = (int)USE_DCITEM + 0x1F;
	*(reinterpret_cast<int*>(addrs)) = Money;

	addrs = (int)USE_DCITEM + 0x33;
	*(reinterpret_cast<char*>(addrs)) = (char)ItemMaxCount;

	for(int i = 0; i < 16; i++ )
	{
		addrs = (DWORD)pSrcData + 0x30 + (i * 5);
		ItemID = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)pSrcData + 0x34 + (i * 5);
		Count = *(reinterpret_cast<char*>(addrs));

		addrs = (int)USE_DCITEM + 0x34 + (i * 5);
		*(reinterpret_cast<int*>(addrs)) = ItemID;
		addrs = (int)USE_DCITEM + 0x38 + (i * 5);
		*(reinterpret_cast<char*>(addrs)) = (char)Count;
	}

	pThis = pDynamic;
	SendPacketEX(pThis, 0x1459, (int)USE_DCITEM, 0x84);
}

// **** RCM_MAP_USE_DC_ITEM 0x1477 *******************************
void OpenUseItem(int pDynamic, int pSendPacket)
{
	int Result;
	int addrs;
	int pSendData;
	int PacketType;
	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;

	unsigned char OPENITEM_RESULT[11] = {0};

	addrs = (DWORD)pSendPacket;
	PacketType = *(reinterpret_cast<int*>(addrs));
	PacketType &= 0xFFFF;

	pSendData = pSendPacket + 4;

	addrs = (DWORD)pSendData;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x4;
	nIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	InventoryUse = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x9;
	SlotUse = *(reinterpret_cast<char*>(addrs));

	addrs = (int)OPENITEM_RESULT + 0x1;
	*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
	addrs = (int)OPENITEM_RESULT + 0x5;
	*(reinterpret_cast<int*>(addrs)) = nIDUse;
	addrs = (int)OPENITEM_RESULT + 0x9;
	*(reinterpret_cast<char*>(addrs)) = InventoryUse;
	addrs = (int)OPENITEM_RESULT + 0xA;
	*(reinterpret_cast<char*>(addrs)) = SlotUse;

	Result = GetOpenUseItem(pDynamic, pSendData, PacketType);
	if (Result != 0)
	{
		addrs = (int)OPENITEM_RESULT;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;

		SendPacketEX(pDynamic, PacketType, (int)OPENITEM_RESULT, 0xB);
	}
}

int GetOpenUseItem(int pDynamic, int pSendData, int PacketType)
{
	int addrs;
	int pPlayer;
	int pThis;
	int CharID;
	int Status;
	char OPList;
	int OpenMode = 0;

	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;

	int ItemIDKey1 = 0;
	int nIDKey1 = 0;
	int InventoryKey1 = 0;
	int SlotKey1 = 0;

	int ItemIDKey2 = 0;
	int nIDKey2 = 0;
	int InventoryKey2 = 0;
	int SlotKey2 = 0;

	int Check;
	//int ItemType;
	int pItemUse;
	int pItemKey1;
	int pItemKey2;

	int ItemTimer;
	unsigned int Timestamp;
	int pScript;
	int GetItemCountMax;
	unsigned int GetEXP;
	unsigned int GetMoney;
	unsigned int MoneyType;
	int ItemMaxUseCount;
	int ItemReuseTime;
	//int Value;
	int TimeL;
	int TimeH;
	unsigned int LastTimestamp;
	int RunQuestID;
	int QusetStatus;

	int i;
	int pGetItem;
	int pGetItemCount;
	int pGetItemRate;
	int GetItemID;
	int GetItemRate;
	int GetItemCount;
	int Chance;
	int ItemCount = 0;
	int ItemNum = 0;
	int pItemScript;
	int MaxCount;

	int IsExp64;
	unsigned int ExpH;
	unsigned int ExpL;

	unsigned int IpL = 0;
	unsigned int IpH = 0;

	unsigned int MoneyL = 0;
	unsigned int MoneyH = 0;
	float PosX;
	float PosY;
	float PosZ;
	__int64 CurMoney = 0;

	int CurUseCount;
	int ItemEtcKeyItem1;
	int ItemEtcKeyItem2;

	memset(OPENITEMUSE, 0, 132);

	// Check
	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 0x19;

	addrs = (DWORD)pPlayer + 0x8C;
	Status = *(reinterpret_cast<int*>(addrs));
	if (Status == 0x60014) return 0x58;

	addrs = (DWORD)pSendData;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x4;
	nIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	InventoryUse = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x9;
	SlotUse = *(reinterpret_cast<char*>(addrs));

	if (PacketType == 0x1459)
	{
		addrs = (DWORD)pSendData + 0xA;
		ItemIDKey1 = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)pSendData + 0xE;
		nIDKey1 = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)pSendData + 0x12;
		InventoryKey1 = *(reinterpret_cast<char*>(addrs));
		addrs = (DWORD)pSendData + 0x13;
		SlotKey1 = *(reinterpret_cast<char*>(addrs));

		addrs = (DWORD)pSendData + 0x14;
		ItemIDKey2 = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)pSendData + 0x18;
		nIDKey2 = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)pSendData + 0x1C;
		InventoryKey2 = *(reinterpret_cast<char*>(addrs));
		addrs = (DWORD)pSendData + 0x1D;
		SlotKey2 = *(reinterpret_cast<char*>(addrs));
	}

	// Packet 0x1459
	addrs = (int)OPENITEMUSE;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = (int)OPENITEMUSE + 0x1;
	*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
	addrs = (int)OPENITEMUSE + 0x5;
	*(reinterpret_cast<int*>(addrs)) = nIDUse;
	addrs = (int)OPENITEMUSE + 0x9;
	*(reinterpret_cast<char*>(addrs)) = InventoryUse;
	addrs = (int)OPENITEMUSE + 0xA;
	*(reinterpret_cast<char*>(addrs)) = SlotUse;

	if (PacketType == 0x1459)
	{
		if (ItemIDKey1 != 0)
		{
			addrs = (int)OPENITEMUSE + 0xB;
			*(reinterpret_cast<int*>(addrs)) = ItemIDKey1;
			addrs = (int)OPENITEMUSE + 0xF;
			*(reinterpret_cast<int*>(addrs)) = nIDKey1;
			addrs = (int)OPENITEMUSE + 0x13;
			*(reinterpret_cast<char*>(addrs)) = InventoryKey1;
			addrs = (int)OPENITEMUSE + 0x14;
			*(reinterpret_cast<char*>(addrs)) = SlotKey1;
		}
		if (ItemIDKey2 != 0)
		{
			addrs = (int)OPENITEMUSE + 0x15;
			*(reinterpret_cast<int*>(addrs)) = ItemIDKey2;
			addrs = (int)OPENITEMUSE + 0x19;
			*(reinterpret_cast<int*>(addrs)) = nIDKey2;
			addrs = (int)OPENITEMUSE + 0x1D;
			*(reinterpret_cast<char*>(addrs)) = InventoryKey2;
			addrs = (int)OPENITEMUSE + 0x1E;
			*(reinterpret_cast<char*>(addrs)) = SlotKey2;
		}
	}

	// Check Item Use
	pThis = pPlayer + 0xCC8;
	pItemUse = GetItem(pThis, InventoryUse, SlotUse);
	Check = RTDynamicCast(pItemUse, 0, 0x7E9778, 0x7E9794, 0);
	if (Check == 0) return 0x29;

	addrs = (DWORD)pItemUse + 0x20;
	Check = *(reinterpret_cast<int*>(addrs));
	if (Check != ItemIDUse) return 0x3;
	addrs = (DWORD)pItemUse+ 0x24;
	Check = *(reinterpret_cast<int*>(addrs));
	if (Check != nIDUse) return 0x3A;
	
	//ItemType = GetAttribute(pItemUse, 0x0);
	//if (ItemType != 209) return 0xCE;

	// Check KeyItem
	if (ItemIDKey1 != 0)
	{
		pThis = pPlayer + 0xCC8;
		pItemKey1 = GetItem(pThis, InventoryKey1, SlotKey1);		
		Check = RTDynamicCast(pItemKey1, 0, 0x7E9778, 0x7E9794, 0);
		if (Check == 0) return 0xE3;
	}
	if (ItemIDKey2 != 0)
	{
		pThis = pPlayer + 0xCC8;
		pItemKey2 = GetItem(pThis, InventoryKey2, SlotKey2);		
		Check = RTDynamicCast(pItemKey2, 0, 0x7E9778, 0x7E9794, 0);
		if (Check == 0) return 0xE3;
	}

	pThis = pPlayer;
	ItemTimer = GetItemTimer(pThis, pItemUse);

	addrs = (DWORD)pItemUse + 0x20;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));

	pScript = GetOpenUseItemScript(ItemIDUse);
	if (pScript == 0)
	{
		addrs = (DWORD)pItemUse + 0x24;
		nIDUse = *(reinterpret_cast<int*>(addrs));
		pThis = pPlayer;
		if (ItemTimer != 0)
		{
			if (nIDUse != 0)
			{
				if (pThis != 0)
				{
					ReleaseItemTimer(pThis, nIDUse);
				}
			}
		}
		return 0x19;
	}

	addrs = pScript + 0x30;
	GetItemCountMax = *(reinterpret_cast<int*>(addrs));
	if (GetItemCountMax > 16) GetItemCountMax = 16;

	if (GetItemCountMax >= 0)
	{
		addrs = pPlayer + 0x1F04;
		OPList = *(reinterpret_cast<char*>(addrs));
		if (OPList != 0)
		{
			addrs = (DWORD)pItemUse + 0x24;
			nIDUse = *(reinterpret_cast<int*>(addrs));
			pThis = pPlayer;
			if (ItemTimer != 0)
			{
				if (nIDUse != 0)
				{
					if (pThis != 0)
					{
						ReleaseItemTimer(pThis, nIDUse);
					}
				}
			}
			return 0xD0;
		}
	}

	time_t now = time(0);
	Timestamp  = (unsigned int)now;

	addrs = pScript + 0x8C;
	ItemMaxUseCount = *(reinterpret_cast<int*>(addrs));
	addrs = pScript + 0x90;
	ItemReuseTime = *(reinterpret_cast<int*>(addrs));

	if (ItemMaxUseCount > 1)
	{
		TimeL = ItemOptionGetType(pItemUse, 0x3E);
		TimeL &= 0xFFFF;
		TimeH = ItemOptionGetType(pItemUse, 0x3F);
		TimeH <<= 16;
		LastTimestamp = TimeL | TimeH;
		if (LastTimestamp != 0)
		{
			LastTimestamp += ItemReuseTime;

			if (LastTimestamp > Timestamp)
			{
				addrs = (DWORD)pItemUse + 0x24;
				nIDUse = *(reinterpret_cast<int*>(addrs));
				pThis = pPlayer;
				if (ItemTimer != 0)
				{
					if (nIDUse != 0)
					{
						if (pThis != 0)
						{
							ReleaseItemTimer(pThis, nIDUse);
						}
					}
				}
				return 0xA;
			}
		}
	}

	addrs = pScript + 0x88;
	RunQuestID = *(reinterpret_cast<int*>(addrs));
	if (RunQuestID > 0)
	{
		addrs = pPlayer + 0x1160;
		Status = *(reinterpret_cast<int*>(addrs));
		if (Status != 0)
		{
			QusetStatus = GetQusetIDStatus(Status, RunQuestID);
			if (QusetStatus == 1)
			{
				addrs = pPlayer + 0x1F00;
				*(reinterpret_cast<int*>(addrs)) = RunQuestID;
			}
		}
	}
	
	// Check Open Mode
	// 0 Item
	// 1 Experience
	// 2 IP
	// 3 Money
	addrs = pScript + 0x24;
	GetEXP = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pScript + 0x2C;
	GetMoney = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pScript + 0x28;
	MoneyType = *(reinterpret_cast<unsigned int*>(addrs));

	if (GetItemCountMax > 0)
	{
		// Item
		OpenMode = 0;
	}
	else
	{
		if (GetEXP > 0)
		{
			// Experience
			OpenMode = 1;
		}
		else
		{
			if (GetMoney > 0)
			{
				if (MoneyType == 149)
				{
					// IP
					OpenMode = 2;
				}
				else
				{
					// Money
					OpenMode = 3;
				}
			}
		}
	}
	
	if ((OpenMode == 0) && (PacketType == 0x1477)) return 0x3;

	if (OpenMode == 0)
	{
		// Item
		addrs = pScript + 0x38;
		pGetItem = *(reinterpret_cast<int*>(addrs));

		addrs = pScript + 0x48;
		pGetItemCount = *(reinterpret_cast<int*>(addrs));

		addrs = pScript + 0x58;
		pGetItemRate = *(reinterpret_cast<int*>(addrs));

		for(i = 0; i < GetItemCountMax; i++ )
		{
			addrs = pGetItemRate + (i * 4);
			GetItemRate = *(reinterpret_cast<int*>(addrs));

			pThis = pPlayer;
			Chance = BioticBaseGetRandom(pThis, 1000000);
			if (GetItemRate > Chance)
			{
				addrs = pGetItem + (i * 4);
				GetItemID = *(reinterpret_cast<int*>(addrs));

				addrs = pGetItemCount + (i * 4);
				GetItemCount = *(reinterpret_cast<int*>(addrs));

				pItemScript = GetItemBinScriptInfo(GetItemID);
				MaxCount = GetItemScriptAttrbute(pItemScript, 0xA);
				if (GetItemCount > MaxCount) GetItemCount = MaxCount;

				addrs = (int)OPENITEMUSE + 0x34 + (ItemNum * 5);
				*(reinterpret_cast<int*>(addrs)) = GetItemID;

				addrs = (int)OPENITEMUSE + 0x38 + (ItemNum * 5);
				*(reinterpret_cast<char*>(addrs)) = (char)GetItemCount;

				ItemCount ++;
				ItemNum ++;
			}
		}

		if (ItemCount == 0)
		{
			addrs = pGetItem;
			GetItemID = *(reinterpret_cast<int*>(addrs));

			addrs = pGetItemCount;
			GetItemCount = *(reinterpret_cast<int*>(addrs));

			pItemScript = GetItemBinScriptInfo(GetItemID);
			MaxCount = GetItemScriptAttrbute(pItemScript, 0xA);
			if (GetItemCount > MaxCount) GetItemCount = MaxCount;

			addrs = (int)OPENITEMUSE + 0x34;
			*(reinterpret_cast<int*>(addrs)) = GetItemID;

			addrs = (int)OPENITEMUSE + 0x38;
			*(reinterpret_cast<char*>(addrs)) = (char)GetItemCount;

			ItemCount = 1;
		}

		for(i = 0; i < 16; i++ )
		{
			addrs = (int)OPENITEMUSE + 0x34 + (i * 5);
			GetItemID = *(reinterpret_cast<int*>(addrs));
			addrs = (int)OPENITEMUSE + 0x38 + (i * 5);
			GetItemCount = *(reinterpret_cast<char*>(addrs));
		
			addrs = pPlayer + 0x1F09 + (i * 5);
			*(reinterpret_cast<int*>(addrs)) = GetItemID;
			if (GetItemID != 0)
			{
				addrs = pPlayer + 0x1F0D + (i * 5);
				*(reinterpret_cast<char*>(addrs)) = (char)GetItemCount;
			}
		}

		addrs = (int)OPENITEMUSE + 0x33;
		*(reinterpret_cast<char*>(addrs)) = (char)ItemCount;
		// Item End
	}
	else if (OpenMode == 1)
	{
		// Experience
		ExpL = 0;
		ExpH = 0;

		IsExp64 = GetExp64(ItemIDUse);
		if (IsExp64 == 0)
		{
			addrs = pScript + 0x24;
			ExpL = *(reinterpret_cast<unsigned int*>(addrs));
		}
		else
		{
			addrs = EXP64_ADDRS;
			ExpL = *(reinterpret_cast<unsigned int*>(addrs));
			addrs = EXP64_ADDRS + 4;
			ExpH = *(reinterpret_cast<unsigned int*>(addrs));
		}

		if (PacketType == 0x1459)
		{
			addrs = (int)OPENITEMUSE + 0x23;
			*(reinterpret_cast<unsigned int*>(addrs)) = ExpL;
			addrs = (int)OPENITEMUSE + 0x27;
			*(reinterpret_cast<unsigned int*>(addrs)) = ExpH;
		}
		else
		{
			// Client Packet 0x1477
			addrs = (int)OPENITEMUSE_EX;
			*(reinterpret_cast<char*>(addrs)) = 0;
			addrs = (int)OPENITEMUSE_EX + 0x1;
			*(reinterpret_cast<int*>(addrs)) = 0;
			addrs = (int)OPENITEMUSE_EX + 0x5;
			*(reinterpret_cast<unsigned int*>(addrs)) = ExpL;
			addrs = (int)OPENITEMUSE_EX + 0x9;
			*(reinterpret_cast<unsigned int*>(addrs)) = ExpH;
			addrs = (int)OPENITEMUSE_EX + 0xD;
			*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
			addrs = (int)OPENITEMUSE_EX + 0x11;
			*(reinterpret_cast<int*>(addrs)) = nIDUse;
			addrs = (int)OPENITEMUSE_EX + 0x15;
			*(reinterpret_cast<char*>(addrs)) = InventoryUse;
			addrs = (int)OPENITEMUSE_EX + 0x16;
			*(reinterpret_cast<char*>(addrs)) = SlotUse;
		}
	
		pThis = pPlayer;
		OpenItemAddExp(pThis, ExpL, ExpH);
		// Experience End
	}
	else if (OpenMode == 2)
	{
		// IP
		addrs = pScript + 0x2C;
		IpL = *(reinterpret_cast<unsigned int*>(addrs));

		addrs = (int)OPENITEMUSE + 0x1F;
		*(reinterpret_cast<unsigned int*>(addrs)) = IpL;

		pThis = pPlayer;
		OpenItemAddIP(pThis, IpL, IpH);
		// IP End
	}
	else if (OpenMode == 3)
	{
		// Money	
		addrs = pScript + 0x2C;
		MoneyL = *(reinterpret_cast<unsigned int*>(addrs));

		addrs = (int)OPENITEMUSE + 0x1F;
		*(reinterpret_cast<unsigned int*>(addrs)) = MoneyL;

		pThis = pPlayer;
		OpenItemAddMoney(pThis, MoneyL, MoneyH);
		// Send Notice 0xF044

		addrs = pPlayer + 0x34;
		PosX = *(reinterpret_cast<float*>(addrs));
		addrs = pPlayer + 0x38;
		PosY = *(reinterpret_cast<float*>(addrs));
		addrs = pPlayer + 0x3C;
		PosZ = *(reinterpret_cast<float*>(addrs));
		addrs = pPlayer + 0x1958;
		CurMoney = *(reinterpret_cast<__int64*>(addrs));

		addrs = (int)NOTICE_F044 + 0x15;
		*(reinterpret_cast<int*>(addrs)) = nIDUse;
		addrs = (int)NOTICE_F044 + 0x19;
		*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
		addrs = (int)NOTICE_F044 + 0x1D;
		*(reinterpret_cast<short*>(addrs)) = 0;
		addrs = (int)NOTICE_F044 + 0x1F;
		*(reinterpret_cast<int*>(addrs)) = MoneyL;
		addrs = (int)NOTICE_F044 + 0x23;
		*(reinterpret_cast<int*>(addrs)) = MoneyH;
		addrs = (int)NOTICE_F044 + 0x27;
		*(reinterpret_cast<__int64*>(addrs)) = CurMoney;
		addrs = (int)NOTICE_F044 + 0x2F;
		*(reinterpret_cast<float*>(addrs)) = PosX;
		addrs = (int)NOTICE_F044 + 0x33;
		*(reinterpret_cast<float*>(addrs)) = PosY;
		addrs = (int)NOTICE_F044 + 0x37;
		*(reinterpret_cast<float*>(addrs)) = PosZ;

		pThis = pPlayer;
		PlayerSendNotice(pThis, 0xF044, (int)NOTICE_F044, 0x3B, 0x15);
		// Money End
	}

	addrs = pPlayer + 0x1F04;
	*(reinterpret_cast<char*>(addrs)) = ItemCount;
	addrs = pPlayer + 0x1F05;
	*(reinterpret_cast<int*>(addrs)) = Timestamp;

	// Send Notice 0x2038
	addrs = pPlayer + 0x34;
	PosX = *(reinterpret_cast<float*>(addrs));
	addrs = pPlayer + 0x38;
	PosY = *(reinterpret_cast<float*>(addrs));
	addrs = pPlayer + 0x3C;
	PosZ = *(reinterpret_cast<float*>(addrs));

	addrs = (int)NOTICE_2038 + 0x15;
	*(reinterpret_cast<int*>(addrs)) = ItemCount;
	addrs = (int)NOTICE_2038 + 0x19;
	*(reinterpret_cast<int*>(addrs)) = nIDUse;
	addrs = (int)NOTICE_2038 + 0x1D;
	*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
	addrs = (int)NOTICE_2038 + 0x21;
	*(reinterpret_cast<short*>(addrs)) = 0;

	addrs = (int)NOTICE_2038 + 0x23;
	*(reinterpret_cast<float*>(addrs)) = PosX;
	addrs = (int)NOTICE_2038 + 0x27;
	*(reinterpret_cast<float*>(addrs)) = PosY;
	addrs = (int)NOTICE_2038 + 0x2B;
	*(reinterpret_cast<float*>(addrs)) = PosZ;

	pThis = pPlayer;
	PlayerSendNotice(pThis, 0x2038, (int)NOTICE_2038, 0x2F, 0x15);

	// Send Client Packet
	if (PacketType == 0x1477)
	{
		pThis = pDynamic;
		SendPacket(pThis, 0x1477, (int)OPENITEMUSE_EX, 0x17);
	}
	else
	{
		pThis = pDynamic;
		SendPacket(pThis, 0x1459, (int)OPENITEMUSE, 0x84);
	}

	// ItemUse Status
	CurUseCount = ItemOptionGetType(pItemUse, 0x54);
	CurUseCount += 1;

	if (CurUseCount >= ItemMaxUseCount)
	{
		//pThis = pPlayer;
		//RemoveItemTimer(pThis, nIDUse);

		pThis = pPlayer + 0xCC8;
		RemoveItem(pThis, pItemUse);
	}
	else
	{
		ItemOptionSetValue(pItemUse, 0x54, CurUseCount);

		TimeL = Timestamp & 0xFFFF;
		ItemOptionSetValue(pItemUse, 0x3E, TimeL);

		TimeH = Timestamp >> 16;
		TimeH &= 0xFFFF;
		ItemOptionSetValue(pItemUse, 0x3F, TimeH);

		// Send DBTask Packet
		addrs = pPlayer + 0x30;
		CharID = *(reinterpret_cast<short*>(addrs));

		addrs = (int)DBTASK_INSITEMC;
		*(reinterpret_cast<short*>(addrs)) = CharID;
		addrs = (int)DBTASK_INSITEMC + 0x4;
		tagItemInit(addrs);
		addrs = (int)DBTASK_INSITEMC + 0x4;
		EpochItemBaseGetItemGR(pItemUse, addrs);

		SendPacketEX(0x7F23A0, 0x4A09, (int)DBTASK_INSITEMC, 0x41);		
	}

	// Use ItemKey's
	if (ItemIDKey1 != 0)
	{
		addrs = pScript + 0x94;
		ItemEtcKeyItem1 = *(reinterpret_cast<short*>(addrs));
		pThis = pPlayer + 0xCC8;
		Check = UseItem(pThis, pItemKey1, 1);
		if (Check == 0)
		{
			if (ItemTimer != 0)
			{
				if (nIDUse != 0)
				{
					if (pThis != 0)
					{
						ReleaseItemTimer(pThis, nIDUse);
					}
				}
			}
			return 0xE4;
		}
	}
	if (ItemIDKey2 != 0)
	{
		addrs = pScript + 0x98;
		ItemEtcKeyItem2 = *(reinterpret_cast<short*>(addrs));
		pThis = pPlayer + 0xCC8;
		Check = UseItem(pThis, pItemKey2, 1);
		if (Check == 0)
		{
			if (ItemTimer != 0)
			{
				if (nIDUse != 0)
				{
					if (pThis != 0)
					{
						ReleaseItemTimer(pThis, nIDUse);
					}
				}
			}
			return 0xE4;
		}
	}

	return 0;
}



int GetExp64(int ItemID)
{
	int IsExp64 = 0;
	int addrs;
	__int64 GetEXP = 0;

	switch(ItemID)
	{
		case 2895584: GetEXP = 200000000000; break;
		case 2895585: GetEXP = 400000000000; break;
		case 2895586: GetEXP = 600000000000; break;
		case 2895587: GetEXP = 800000000000; break;
		case 2895588: GetEXP = 1000000000000; break;
		case 2895589: GetEXP = 1200000000000; break;
		case 2895590: GetEXP = 1400000000000; break;
		case 2895591: GetEXP = 1800000000000; break;
		case 2895592: GetEXP = 2200000000000; break;
		case 2895593: GetEXP = 2600000000000; break;
		case 2895594: GetEXP = 3000000000000; break;
		case 2895595: GetEXP = 3400000000000; break;
		case 2895596: GetEXP = 4000000000000; break;
		case 2895597: GetEXP = 5000000000000; break;
		case 2887162: GetEXP = 200000000000; break;
		case 2909647: GetEXP = 100000000000; break;
		case 2896616: GetEXP = 500000000000; break;
		case 2896620: GetEXP = 300000000000; break;
		case 2896621: GetEXP = 120000000000; break;
		case 2896622: GetEXP = 18000000000; break;
		case 2909731: GetEXP = 10000000000; break;
		case 2909821: GetEXP = 500000000000; break;
		case 2909822: GetEXP = 250000000000; break;
		case 2909823: GetEXP = 50000000000; break;

		case 2948691: GetEXP = 500000000000; break;
		case 2948692: GetEXP = 250000000000; break;
		case 2948693: GetEXP = 50000000000; break;
		case 2948696: GetEXP = 64685710676918; break;
	}

	addrs = EXP64_ADDRS;
	*(reinterpret_cast<__int64*>(addrs)) = GetEXP;

	if (GetEXP > 0) IsExp64 = 1;

	return IsExp64;
}