#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

extern int TRANSITEMS_ADDRS;
extern int TRANSITEM_SIZE;

int UPGRADE_RETORIG = 0x00467AB9;
int UPGRADE_RETEND = 0x00467AAF;

int UPGRADE_PLAYER;
int UPGRADE_SENDDATA;
int UPGRADE_UPITEMIDPTR;

// RCM_MAP_UPGRADE_ITEM 0x151A
void UpgradeItem()
{
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov UPGRADE_SENDDATA,eax

	__asm mov ecx,dword ptr ss:[ebp-0x60]
	__asm mov UPGRADE_PLAYER,ecx
	
	__asm lea edx,dword ptr ss:[ebp-0x64]
	__asm mov UPGRADE_UPITEMIDPTR,edx

	GetUpgradeItemID(UPGRADE_PLAYER, UPGRADE_SENDDATA, UPGRADE_UPITEMIDPTR);

	__asm jmp eax

}

int GetUpgradeItemID(int pPlayer, int pSendData, int pUpgradeItemID)
{
	int addrs;
	int RetAddrs;
	int pThis;
	int ItemID = 0;
	int Inventory = 0;
	int Slot = 0;
	int pItem = 0;
	int BinItemID = 0;
	int UpItemID = 0;
	int MaxCount = 0;
	int Offset = 0;
	int EnhLevel = 0;
	int CurBootsLevel = 0;
	
	addrs = pSendData;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = pSendData + 8;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = pSendData + 9;
	Slot = *(reinterpret_cast<char*>(addrs));

	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);
	CurBootsLevel = ItemOptionGetType(pItem, 0x4F);

	// 2018 Line 0xC / 2021 Line 0x10
	MaxCount = TRANSITEM_SIZE / 0x10;
	Offset = (DWORD)TRANSITEMS_ADDRS;

	for( int i=0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x4;
		BinItemID = *(reinterpret_cast<int*>(addrs));
		if (BinItemID == ItemID)
		{
			addrs = Offset + 0x8;
			UpItemID = *(reinterpret_cast<int*>(addrs));
			addrs = Offset + 0xC;
			EnhLevel = *(reinterpret_cast<int*>(addrs));
			break;
		}
		Offset += 0x10;
	}
	
	if (UpItemID == 0) RetAddrs = UPGRADE_RETEND;
	
	if (CurBootsLevel >= EnhLevel)
	{
		addrs = pUpgradeItemID;
		*(reinterpret_cast<int*>(addrs)) = UpItemID;
		RetAddrs = UPGRADE_RETORIG;
	}
	else
	{
		RetAddrs = UPGRADE_RETEND;
	}

	return RetAddrs;
}
