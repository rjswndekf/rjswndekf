/*******************************************
 2021 RCM_MAP_EXTEND_BANKTAB_INFO 0x1D2E = 0x1D34
 Hero4 Packet Recv
 34 1D 07 00 00 00 00 00 00 00 36
 2021 Packet Recv
 2E 1D 07 00 00 00 00 00 00 00 36 
 
 2021 RCM_MAP_BANK_GET_INFO 0x1D2A = 0x1D2B
 Hero4 Packet Recv
 2B 1D 13 00 00 00 00 00 00 00 00 00 00 36 00 00 00 00 00 00 00 00 00 
 2021 Packet Recv
 2A 1D 0B 00 00 00 00 00 00 00 00 00 00 36 00

 2021 RCM_MAP_BANK_GET_INFO 0x1D2A Packet Struct
 00           +0
 08 00 00 00  +1 Crons
 00 00 00 00  +5
 36           +9 ALL 
 02           +A Count

 size 0x3D
 1A 00 2C 00 ItemID
 A0 79 35 00 
 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 64 02 01 00 00 00 00 00 00 00 00 

 *******************************************/

#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

int BANKINFO_RET = 0x0044F4AE;
int EXTBANKINFO_RET = 0x0046A343;
int UPBANKMAXSLOT_RET = 0x00553A3B;
int GETBANKEXTDAY_RET = 0x0045D479;

/******* ASM Funs *******/
extern int GETATTRIBUTE;

// **** 2021 RCM_MAP_BANK_GET_INFO 0x1D2A Patch *******************************
void BankGetInfo(int DynamicPTR, int SendPacketPTR)
{
	int result;
	int pData;
	unsigned char Packet_1D2A[1] = {0};
	int BANKINFO = 0x0044F060;

	// Bank Get Info
	__asm mov eax, SendPacketPTR
	__asm add eax,0x4
	__asm push eax
	__asm mov ecx, DynamicPTR
	__asm call BANKINFO
	__asm mov result, eax

	if (result !=0)
	{
		pData = (DWORD)Packet_1D2A;
		*(reinterpret_cast<unsigned char*>(pData)) = (unsigned char)result;
		SendPacketEX(DynamicPTR, 0x1D2A, pData, 0x1);
	}
}

void BankGetInfoPacket()
{
	// Check PackType
	__asm mov esi,dword ptr ss:[ebp+0x8]
	__asm sub esi,0x4
	__asm movzx edi, word ptr es:[esi]
	__asm cmp edi,0x1D2A
	__asm je BANKINFOA
	// 0x1D2B
	__asm push edx
	__asm lea eax,dword ptr ss:[ebp-0x19D8]
	__asm push eax
	__asm push edi
	__asm mov ecx,dword ptr ss:[ebp-0x1A48]
	__asm mov edx,dword ptr ds:[ecx]
	__asm mov ecx,dword ptr ss:[ebp-0x1A48]
	__asm call dword ptr ds:[edx+0x2C]
	__asm jmp RET_TARGET

BANKINFOA:
	// 0x1D2A
	__asm mov al,byte ptr ss:[ebp-0x19CF]
	__asm mov byte ptr ss:[ebp-0x19C7],al
	__asm mov al,byte ptr ss:[ebp-0x19D8]
	__asm mov byte ptr ss:[ebp-0x19D0],al
	__asm mov eax,dword ptr ss:[ebp-0x19D7]
	__asm mov dword ptr ss:[ebp-0x19CF],eax
	__asm mov eax,dword ptr ss:[ebp-0x19D3]
	__asm mov dword ptr ss:[ebp-0x19CB],eax

	__asm sub edx,0x8
	__asm push edx
	__asm lea eax,dword ptr ss:[ebp-0x19D0]
	__asm push eax
	__asm push edi
	__asm mov ecx,dword ptr ss:[ebp-0x1A48]
	__asm mov edx,dword ptr ds:[ecx]
	__asm mov ecx,dword ptr ss:[ebp-0x1A48]
	__asm call dword ptr ds:[edx+0x2C]

RET_TARGET:
	// RET ADDR
	__asm jmp BANKINFO_RET
}

// RCM_MAP_EXTEND_BANKTAB_INFO 0x1D2E
void ExtendBanktabInfo(int DynamicPTR, int SendPacketPTR)
{
	int result;
	int pData;
	int pThis;
	unsigned char Packet_1D2E[1] = {0};

	// Extend Banktab Info
	pThis = DynamicPTR;
	result = GetExtendBanktabInfo(pThis);

	if (result !=0)
	{
		pData = (DWORD)Packet_1D2E;
		*(reinterpret_cast<unsigned char*>(pData)) = (unsigned char)result;
		SendPacketEX(DynamicPTR, 0x1D2E, pData, 0x1);
	}
}


int GetExtendBanktabInfo(int DynamicPTR)
{
	int addrs;
	int pThis;
	int PlayerPTR;
	unsigned int UserID;
	unsigned int CharID;
	int pBank;
	int IsLoad;
	int IsOwner;
	int MaxSlot = 0;
	unsigned int ExpireTime = 0;
	int IsExpire;
	int ExtBankLoad = 0;
	unsigned char EXTBANKINFO[7] = {0};

	int EXTBANKINFO_ADDRS = (DWORD)EXTBANKINFO;

	addrs = (DWORD)DynamicPTR + 0x534;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));	
	if (PlayerPTR == 0x0) return 0xB;
	
	addrs = (DWORD)PlayerPTR + 0x1A0C;
	UserID = *(reinterpret_cast<unsigned int*>(addrs));

	pBank = GetBank(UserID);
	if (pBank == 0x0) return 0x16;
	
	addrs = (DWORD)pBank + 0x19E0;
	IsLoad = *(reinterpret_cast<unsigned int*>(addrs));
	if (IsLoad == 0x0)
	{
		if (pBank != 0)
		{
			pThis = pBank;
			CIOObjectRelease(pThis);
		}
		return 0x1A;
	}
	
	addrs = (DWORD)pBank + 0x19DC;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = (DWORD)pBank + 0x19D8;
	UserID = *(reinterpret_cast<unsigned int*>(addrs));
	pThis = PlayerPTR;
	IsOwner = IsBankOwner(pThis, UserID, CharID);
	if (IsOwner == 0x0)
	{
		if (pBank != 0)
		{
			pThis = pBank;
			CIOObjectRelease(pThis);
		}
		return 0x18;
	}
	pThis = pBank;
	MaxSlot = GetBankMaxSlot(pThis, UserID);
	if (MaxSlot > 54)
	{
		addrs = (DWORD)pBank + 0x19D8;
		UserID = *(reinterpret_cast<unsigned int*>(addrs));
		ExpireTime = GetDBBankExpireTime(UserID);
		
		addrs = (DWORD)pBank + 0x19F0;
		*(reinterpret_cast<unsigned int*>(addrs)) = ExpireTime;

		pThis = pBank;
		IsExpire = CheckExpireTime(pThis);
		if (IsExpire == 0) ExtBankLoad = 1;
		else ExtBankLoad = 0;
	}

	addrs = EXTBANKINFO_ADDRS;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = EXTBANKINFO_ADDRS + 0x1;
	*(reinterpret_cast<char*>(addrs)) = (char)ExtBankLoad;
	addrs = EXTBANKINFO_ADDRS + 0x2;
	*(reinterpret_cast<unsigned int*>(addrs)) = ExpireTime;
	addrs = EXTBANKINFO_ADDRS + 0x6;
	*(reinterpret_cast<char*>(addrs)) = (char)MaxSlot;
	
	pThis = DynamicPTR;
	SendPacketEX(pThis, 0x1D2E, EXTBANKINFO_ADDRS, 0x7);

	if (pBank != 0)
	{
		pThis = pBank;
		CIOObjectRelease(pThis);
	}

	return 0;
}

/**** 2021 Add ExtendBank Patch ***/
// Get Bank ExtendDay
void GetBankExtendDay()
{
	__asm push 0x90
	__asm mov ecx,dword ptr ss:[ebp-0x20]
	__asm call GETATTRIBUTE
	__asm mov dword ptr ss:[ebp-0x2C],eax
	__asm jmp GETBANKEXTDAY_RET
}

// Bank UpdateMaxSlot Patch
void BankUpdateMaxSlot()
{
	// ExtendDay
	__asm mov edx,dword ptr ss:[ebp+0xC]
	// ExtendDay * 86400 Second
	__asm imul edx,edx,0x15180
	__asm mov dword ptr ss:[ebp+0xC],edx
	// CurTime + Second
	__asm mov eax,dword ptr ss:[ebp-0x8]
	__asm add eax,dword ptr ss:[ebp+0xC]
	// ExpireTime = pBank + 0x19F0
	__asm mov ecx,dword ptr ss:[ebp-0x30]
	__asm mov dword ptr ds:[ecx+0x19F0],eax
	__asm mov edx,dword ptr ss:[ebp-0x30]
	__asm mov eax,dword ptr ds:[edx+0x19F0]
	__asm mov dword ptr ss:[ebp-0x13],eax

	__asm jmp UPBANKMAXSLOT_RET
}

/*** 2021 Update Bank ExpireTime 0x145B ***/
void BankExpansionTicket(int DynamicPTR, int SendPacketPTR)
{
	int result;
	int pData;
	int pThis;
	unsigned char Packet_145B[1] = {0x00};

	// Update Bank ExpireTime
	pThis = DynamicPTR;
	pData = (DWORD)SendPacketPTR + 0x4;
	result = UpdateBankExpireTime(pThis, pData);

	if (result !=0)
	{
		pData = (DWORD)Packet_145B;
		*(reinterpret_cast<unsigned char*>(pData)) = (unsigned char)result;
		SendPacketEX(DynamicPTR, 0x145B, pData, 0x1);
	}
}

int UpdateBankExpireTime(int DynamicPTR, int SendPacketData)
{
	int addrs;
	int pThis;
	int PlayerPTR;
	int InventoryPTR;
	int Status;
	unsigned int ItemID;
	unsigned int EpochID;
	unsigned int CheckID;
	int Inventory;
	int Slot;
	int pItem;
	int Desc;
	int CouponTime;
	unsigned int UserID;
	unsigned int CharID;
	int pBank;
	int IsLoad;
	int IsOwner;
	int MaxSlot = 0;
	unsigned int ExpireTime = 0;
	unsigned int AddTime;
	int pData;
	unsigned char MOVEITEM[12] = {0};
	unsigned char UPDATEEXTBANKTIME[19] = {0};
	unsigned char PLAYERADDBANKTIME[47] = {0};

	memset(PLAYERADDBANKTIME,0,sizeof(char)*47);

	addrs = (DWORD)DynamicPTR + 0x534;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	if (PlayerPTR == 0x0) return 0x19;
	
	pThis = PlayerPTR;
	Status = PlayerCheckSelfItemWork(pThis, 0x1);
	if (Status == 0x0) return 0x55;

	addrs = (DWORD)SendPacketData;
	ItemID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = (DWORD)SendPacketData + 0x4;
	EpochID = *(reinterpret_cast<unsigned int*>(addrs));
	pThis = PlayerPTR;
	Status = PlayerCheckWorkItem(pThis, EpochID);
	if (Status == 0x0) return 0x22;

	pThis = PlayerPTR;
	Status = PlayerCheckTradeItemWork(pThis, 0x0);
	if (Status == 0x0) return 0x22;
	
	addrs = (DWORD)SendPacketData + 0x8;
	Inventory = *(reinterpret_cast<char*>(addrs));
	if (Inventory < 1) return 0x43;
	if (Inventory > 5) return 0x43;
	
	addrs = (DWORD)SendPacketData + 0x9;
	Slot = *(reinterpret_cast<char*>(addrs));
	InventoryPTR = (DWORD)PlayerPTR + 0xCC8;
	pItem = GetItem(InventoryPTR, Inventory, Slot);
	if (pItem == 0) return 0x29;
	
	addrs = (DWORD)pItem + 0x20;
	CheckID = *(reinterpret_cast<unsigned int*>(addrs));
	if (CheckID != ItemID) return 0x29;

	addrs = (DWORD)pItem + 0x24;
	CheckID = *(reinterpret_cast<unsigned int*>(addrs));
	if (CheckID != EpochID) return 0x29;
	
	pThis = pItem;
	Desc = GetAttribute(pThis, 0x1);
	if (Desc != 0x0)
	{
		if (Desc != 0xD)
			return 0x4C;
	}

	pThis = pItem;
	CouponTime = GetAttribute(pThis, 0x90);
	if (CouponTime == 0x0) return 0xD6;

	addrs = (DWORD)PlayerPTR + 0x1A0C;
	UserID = *(reinterpret_cast<unsigned int*>(addrs));
	pBank = GetBank(UserID);
	if (pBank == 0x0) return 0x91;

	addrs = (DWORD)pBank + 0x19E0;
	IsLoad = *(reinterpret_cast<unsigned int*>(addrs));
	if (IsLoad == 0x0)
	{
		if (pBank != 0)
		{
			pThis = pBank;
			CIOObjectRelease(pThis);
		}
		return 0x92;
	}

	addrs = (DWORD)pBank + 0x19DC;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = (DWORD)pBank + 0x19D8;
	UserID = *(reinterpret_cast<unsigned int*>(addrs));
	pThis = PlayerPTR;
	IsOwner = IsBankOwner(pThis, UserID, CharID);
	if (IsOwner == 0x0)
	{
		if (pBank != 0)
		{
			pThis = pBank;
			CIOObjectRelease(pThis);
		}
		return 0x93;
	}

	pThis = pBank;
	MaxSlot = GetBankMaxSlot(pThis, UserID);
	if (MaxSlot < 55)
	{
		if (pBank != 0)
		{
			pThis = pBank;
			CIOObjectRelease(pThis);
		}
		return 0x96;
	}
	
	CouponTime = GetAttribute(pItem, 0x90);
	pThis = pBank;
	UpdateBankTabTime(pThis, CouponTime);
	
	// RemoveItem
	addrs = (DWORD)pItem + 0x20;
	ItemID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = (DWORD)pItem + 0x24;
	EpochID = *(reinterpret_cast<unsigned int*>(addrs));
	pThis = pItem;
	Inventory = GetAttribute(pThis, 0xC);
	pThis = pItem;
	Slot = GetAttribute(pThis, 0xD);

	addrs = (DWORD)MOVEITEM;
	*(reinterpret_cast<char*>(addrs)) = 0x0;
	addrs = (DWORD)MOVEITEM + 0x1;
	*(reinterpret_cast<unsigned int*>(addrs)) = ItemID;
	addrs = (DWORD)MOVEITEM + 0x5;
	*(reinterpret_cast<unsigned int*>(addrs)) = EpochID;
	addrs = (DWORD)MOVEITEM + 0x9;
	*(reinterpret_cast<char*>(addrs)) = Inventory;
	addrs = (DWORD)MOVEITEM + 0xA;
	*(reinterpret_cast<char*>(addrs)) = Slot;
	addrs = (DWORD)MOVEITEM + 0xB;
	*(reinterpret_cast<char*>(addrs)) = 0x0;

	pThis = pItem;
	InventoryPTR = (DWORD)PlayerPTR + 0xCC8;
	Status = RemoveItem(InventoryPTR, pThis);
	if (Status == 0)
	{
		if (pBank != 0)
		{
			pThis = pBank;
			CIOObjectRelease(pThis);
		}
		return 0x8C;
	}
	
	pThis = DynamicPTR;
	pData = (DWORD)MOVEITEM;
	SendPacketEX(pThis, 0x1512, pData, 0xC);
	
	// Update Bank Expire Time
	addrs = (DWORD)SendPacketData;
	ItemID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = (DWORD)SendPacketData + 0x4;
	EpochID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = (DWORD)SendPacketData + 0x8;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)SendPacketData + 0x9;
	Slot = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)pBank + 0x19F0;
	ExpireTime =  *(reinterpret_cast<unsigned int*>(addrs));
	
	AddTime = CouponTime * 86400;

	addrs = (DWORD)UPDATEEXTBANKTIME;
	*(reinterpret_cast<char*>(addrs)) = 0x0;
	addrs = (DWORD)UPDATEEXTBANKTIME + 0x1;
	*(reinterpret_cast<unsigned int*>(addrs)) = ItemID;
	addrs = (DWORD)UPDATEEXTBANKTIME + 0x5;
	*(reinterpret_cast<unsigned int*>(addrs)) = EpochID;
	addrs = (DWORD)UPDATEEXTBANKTIME + 0x9;
	*(reinterpret_cast<char*>(addrs)) = Inventory;
	addrs = (DWORD)UPDATEEXTBANKTIME + 0xA;
	*(reinterpret_cast<char*>(addrs)) = Slot;
	addrs = (DWORD)UPDATEEXTBANKTIME + 0xB;
	*(reinterpret_cast<unsigned int*>(addrs)) = ExpireTime;
	addrs = (DWORD)UPDATEEXTBANKTIME + 0xF;
	*(reinterpret_cast<unsigned int*>(addrs)) = AddTime;

	pThis = DynamicPTR;
	pData = (DWORD)UPDATEEXTBANKTIME;
	SendPacketEX(pThis, 0x145B, pData, 0x13);

	/***
	addrs = (DWORD)PLAYERADDBANKTIME + 0x19;
	*(reinterpret_cast<unsigned int*>(addrs)) = EpochID;
	addrs = (DWORD)PLAYERADDBANKTIME + 0x1D;
	*(reinterpret_cast<unsigned int*>(addrs)) = ItemID;
	addrs = (DWORD)PLAYERADDBANKTIME + 0x21;
	*(reinterpret_cast<short*>(addrs)) = 0;
	addrs = (DWORD)PLAYERADDBANKTIME + 0x23;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)PLAYERADDBANKTIME + 0x27;
	*(reinterpret_cast<unsigned int*>(addrs)) = CouponTime;
	addrs = (DWORD)PLAYERADDBANKTIME + 0x27;
	*(reinterpret_cast<unsigned int*>(addrs)) = ExpireTime;

	pThis = DynamicPTR;
	pData = (DWORD)PLAYERADDBANKTIME;
	SendOptPacket(pThis, 0x400B, pData, 0x2F, 0x19);
	***/

	if (pBank != 0)
	{
		pThis = pBank;
		CIOObjectRelease(pThis);
	}

	return 0;

}

void UpdateBankTabTime(int BankPTR, int CouponTime)
{
	int addrs;
	int pThis;
	int UserID;
	unsigned int ExpireTime = 0;
	int AddTime;

	if (BankPTR != 0)
	{
		AddTime = CouponTime * 86400;

		addrs = (DWORD)BankPTR + 0x19D8;
		UserID = *(reinterpret_cast<unsigned int*>(addrs));
		pThis = BankPTR;
		ExpireTime = GetBankExpireTime(pThis, UserID);
		if (ExpireTime == 0)
		{
			ExpireTime = GetDBBankExpireTime(UserID);
		}
	
		ExpireTime += AddTime;
		SetDBBankExpireTime(UserID, ExpireTime);
		addrs = (DWORD)BankPTR + 0x19F0;
		*(reinterpret_cast<unsigned int*>(addrs)) = ExpireTime;
	}
}

// RCM_MAP_BANK_SECRETINFO 0x1D18
void BankSecretInfo(int DynamicPTR, int SendPacketPTR)
{
	int addrs;
	int pData;
	unsigned char BANK_SECRETINFO[4] = {0};

	addrs = (DWORD)BANK_SECRETINFO;
	*(reinterpret_cast<int*>(addrs)) = 0;
	
	pData = (DWORD)BANK_SECRETINFO;
	SendPacketEX(DynamicPTR, 0x1D18, pData, 0x3);
}
