#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

unsigned char DBSK_ITEMGR_WO[65] = {0};
unsigned char WISH_OPTIONCHANGE[62] = {0};

extern int WISHOPTCHBIN_ADDRS;
extern int WISHOPTCHBIN_SIZE;

// RCM_MAP_WISH_TICKET_WEAPON_OPTION_CHANGE 0x147F
// RCM_MAP_WISH_TICKET_ARMOR_OPTION_CHANGE 0x1480
void WishEquipOptionChange(int pDynamic, int pSendPacket)
{
	int Result;
	int addrs;
	int pSendData;
	int PacketType;
	unsigned char WISH_RESULT[1] = {0};
	addrs = (DWORD)pSendPacket;
	PacketType = *(reinterpret_cast<int*>(addrs));
	PacketType &= 0xFFFF;

	pSendData = pSendPacket + 4;
	Result = GetWishEquipOptionChange(pDynamic, pSendData, PacketType);
	if (Result != 0)
	{
		addrs = (int)WISH_RESULT;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;
		SendPacketEX(pDynamic, PacketType, (int)WISH_RESULT, 0x1);
	}
}

int GetWishEquipOptionChange(int pDynamic, int pSendData, int PacketType)
{

	int Result = 0;
	int addrs;
	int pPlayer;
	int CharID;
	int pThis;

	int Status;
	int NpcID;
	int pNpc;
	int pScript;

	int ItemID;
	int nID;
	int Inventory;
	int Slot;

	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;
	int ItemUseCount;

	int pItem;
	int pItemUse;
	//int pOption;
	int CheckID;

	int TypeSrc1 = 0;
	int TypeSrc2 = 0;
	int TypeDst1 = 0;
	int TypeDst2 = 0;
	int Value1 = 0;
	int Value2 = 0;

	int i = 0;
	int CalType = 0;
	int CalValue = 0;
	int ValueAdd = 0;
	int TypeDst = 0;
	int ValueDst = 0;

	unsigned char REMOVEITEM[12] = {0};

	// Check
	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 0x19;

	addrs = (DWORD)pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));
	addrs = (int)DBSK_ITEMGR_WO;
	*(reinterpret_cast<int*>(addrs)) = CharID;

	pThis = (DWORD)pPlayer;
	Status = PlayerCheckTradeItemWork(pThis, 0x0);
	if (Status == 0) return 0x55;

	addrs = (DWORD)pSendData + 0x4;
	NpcID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xC;
	nID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x10;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x11;
	Slot = *(reinterpret_cast<char*>(addrs));
	
	if (PacketType == 0x147F)
	{
		addrs = (DWORD)pSendData + 0x12;
		TypeSrc1 = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)pSendData + 0x16;
		TypeSrc2 = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)pSendData + 0x1A;
		TypeDst1 = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)pSendData + 0x1E;
		TypeDst2 = *(reinterpret_cast<int*>(addrs));
	}
	else
	{
		addrs = (DWORD)pSendData + 0x12;
		TypeDst = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)pSendData + 0x16;
		ValueDst = *(reinterpret_cast<int*>(addrs));		
	}

	// Check NPC
	if (NpcID == 0) return 0x1;
	pNpc = GetNpc(NpcID);
	if (pNpc == 0) return 0x1;

	// Check ItemID
	pScript = GetOptionChangeScript(ItemID);
	if (pScript == 0) return 0x5;

	// Check Item
	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);
	if (pItem == 0) return 5;
	addrs = pItem + 0x20;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != ItemID) return 5;
	addrs = pItem + 0x24;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != nID) return 5;

	// Check WishTicket
	addrs = (DWORD)pScript + 0x10;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pScript + 0x14;
	ItemUseCount = *(reinterpret_cast<int*>(addrs));
	if (ItemIDUse == 0) return 0x89;

	for( i = 0; i < ItemUseCount; i++ )
	{
		pThis = (DWORD)pPlayer + 0xCC8;
		pItemUse = FindItem(pThis, ItemIDUse);
		if (pItemUse == 0) return 0x89;

		addrs = (DWORD)pItemUse + 0x20;
		ItemIDUse = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)pItemUse + 0x24;
		nIDUse = *(reinterpret_cast<int*>(addrs));;
		InventoryUse = GetAttribute(pItemUse, 0xC);
		SlotUse = GetAttribute(pItemUse, 0xD);

		// Remove WishTicket
		addrs = (int)REMOVEITEM;
		*(reinterpret_cast<char*>(addrs)) = 0;
		addrs = (int)REMOVEITEM + 0x1;
		*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
		addrs = (int)REMOVEITEM + 0x5;
		*(reinterpret_cast<int*>(addrs)) = nIDUse;
		addrs = (int)REMOVEITEM + 0x9;
		*(reinterpret_cast<char*>(addrs)) = (char)InventoryUse;
		addrs = (int)REMOVEITEM + 0xA;
		*(reinterpret_cast<char*>(addrs)) = (char)SlotUse;
		addrs = (int)REMOVEITEM + 0xB;
		*(reinterpret_cast<char*>(addrs)) = 0;

		pThis = (DWORD)pDynamic;
		SendPacketEX(pThis, 0x1512, (int)REMOVEITEM, 0xC);

		pThis = pPlayer + 0xCC8;
		RemoveItemsInInventory(pThis, pItemUse, 1);		
	}

	//pOption = (DWORD)pScript + 0x20;

	if (PacketType == 0x147F)
	{
		// Weapon Option Change
		// Get SRC AttrbuteValue
		Value1 = ItemOptionGetType(pItem, TypeSrc1);
		Value2 = ItemOptionGetType(pItem, TypeSrc2);
		// Clean SRC AttrbuteValue
		ItemOptionSetType(pItem, TypeSrc1, 0);
		ItemOptionSetType(pItem, TypeSrc2, 0);
		// Set DST AttrbuteValue
		ItemOptionSetType(pItem, TypeDst1, Value1);
		ItemOptionSetType(pItem, TypeDst2, Value2);	
	}
	else
	{
		// Armor Option Change
		// Cal SRC AttrbuteValue
		for( i = 0; i < 6; i++ )
		{
			CalType = i + 1;
			ValueAdd = ItemOptionGetType(pItem, CalType);
			CalValue += ValueAdd;
		}
		// Clean SRC AttrbuteValue
		for( i = 0; i < 6; i++ )
		{
			CalType = i + 1;
			ItemOptionSetType(pItem, CalType, 0);
		}
		// Set DST AttrbuteValue
		ItemOptionSetType(pItem, TypeDst, CalValue);
	}

	// DBTask Packet
	addrs = (int)DBSK_ITEMGR_WO + 0x4;
	tagItemInit(addrs);
	addrs = (int)DBSK_ITEMGR_WO + 0x4;
	EpochItemBaseGetItemGR(pItem, addrs);

	SendPacketEX(0x7F23A0, 0x4A09, (int)DBSK_ITEMGR_WO, 0x41);

	// Client Packet
	addrs = (int)WISH_OPTIONCHANGE;
	*(reinterpret_cast<char*>(addrs)) = 0;

	addrs = (int)WISH_OPTIONCHANGE + 0x1;
	tagItemInit(addrs);
	addrs = (int)WISH_OPTIONCHANGE + 0x1;
	EpochItemBaseGetItemGR(pItem, addrs);

	pThis = pDynamic;
	SendPacketEX(pThis, PacketType, (int)WISH_OPTIONCHANGE, 0x3E);

	return 0;
}

int GetOptionChangeScript(int ItemID)
{
	int pScript = 0;
	int addrs;
	int BinItemID;
	int MaxCount = 0;
	int Offset = 0;

	MaxCount = WISHOPTCHBIN_SIZE / 0x40;
	Offset = (DWORD)WISHOPTCHBIN_ADDRS;
	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x18;
		BinItemID = *(reinterpret_cast<int*>(addrs));
		if (BinItemID == ItemID)
		{
			pScript = Offset;
			break;
		}
		Offset += 0x40;
	}

	return pScript;
}