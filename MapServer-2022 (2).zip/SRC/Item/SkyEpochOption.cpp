/*******************************************
 RCM_MAP_ADD_SPECIAL_OPTION 0x232A
 Send Size 0x14
 14 9D 28 00 +0  Item
 21 00 00 00 +4  nID
 01          +8  Inventory
 0F          +9  Slot
 
 88 94 2C 00 +A  ItemUse (2921608 Celestial Crystal)
 2E 00 00 00 +E  nIDUse
 01          +12 InventoryUse
 09          +13 SlotUse
 
 Recv Size 0x25
 *******************************************/
#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;


unsigned char ADD_SPECIAL_OPTION[37] = {0};
unsigned char SPECIAL_OPTION_GRANTCONFIRM[19] = {0};
unsigned char SPECIAL_OPTION_RESET[76] = {0};
unsigned char SPECIAL_OPTION_RESDDIGN[13] = {0};

unsigned char DBTASK_INSITEM_232A[65] = {0};
unsigned char DBTASK_INSITEM_232B[65] = {0};
unsigned char DBTASK_INSITEM_232C[65] = {0};

extern int SPECIALOPTIONTYPEBIN_ADDRS;
extern int SPECIALOPTIONTYPEBIN_SIZE;
extern int SPECIALOPTIONTYPEVALUEBIN_ADDRS;
extern int SPECIALOPTIONTYPEVALUEBIN_SIZE;
extern int SPECIALOPTIONCOSTBIN_ADDRS;
extern int SPECIALOPTIONCOSTBIN_SIZE;


// RCM_MAP_ADD_SPECIAL_OPTION 0x232A
void SkyItemAddSpecialOption(int pDynamic, int pSendPacket)
{
	int Result;
	int addrs;
	int pSendData;
	
	memset(ADD_SPECIAL_OPTION, 0, 37);

	pSendData = pSendPacket + 4;
	Result = GetItemAddSpecialOption(pDynamic, pSendData);
	if (Result != 0)
	{
		addrs = (int)ADD_SPECIAL_OPTION;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;
		SendPacketEX(pDynamic, 0x232A, (int)ADD_SPECIAL_OPTION, 0x1);
	}
}

int GetItemAddSpecialOption(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int pThis;
	unsigned int CharID;
	int i;
	int p = 0;

	int ItemID;
	int nID;
	int Inventory;
	int Slot;

	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;
	
	int pItem;
	int pItemUse;
	int ItemType;
	int CheckID;

	int Rate = 0;
	int RateMedium = 0;
	int RateAdd = 0;
	int RateSub= 0;
	int Chance = 0;

	int pAttrbuteTypeScript;
	int pAttrbuteValueScript;

	int AttrbuteType = 0;
	int AttrbuteValue = 0;
	int UseCount = 0;
	
	int Success = 0;

	unsigned char REMOVEITEM[12] = {0};

	// Check
	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 0x1;
	
	addrs = (DWORD)pPlayer + 0x30;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));

	addrs = (DWORD)pSendData;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x4;
	nID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x9;
	Slot = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)pSendData + 0xA;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xE;
	nIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x12;
	InventoryUse = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x13;
	SlotUse = *(reinterpret_cast<char*>(addrs));

	// Check Item
	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);
	if (pItem == 0) return 5;

	addrs = pItem + 0x20;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != ItemID) return 5;
	addrs = pItem + 0x24;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != nID) return 5;

	pThis = pPlayer + 0xCC8;
	pItemUse = GetItem(pThis, InventoryUse, SlotUse);
	if (pItemUse == 0) return 5;

	addrs = pItemUse + 0x20;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != ItemIDUse) return 5;
	addrs = pItemUse + 0x24;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != nIDUse) return 5;

	// Check UseCount
	UseCount = ItemOptionGetType(pItem, 0x6B);
	if (UseCount != 0) return 5;

	Chance = BioticBaseGetRandom(pPlayer, 1000000);
	if (Chance < 900000) Success = 1;

	if (Success == 1)
	{
		// Get AttributeType
		ItemType = GetAttribute(pItem, 0);
		pAttrbuteTypeScript = GetSpecialOptionTypeScript(ItemType);
		if (pAttrbuteTypeScript == 0) return 5;
		p = 0;
		for( i = 0; i < 7; i++ )
		{
			addrs = pAttrbuteTypeScript + (i * 8) + 4;
			RateAdd = *(reinterpret_cast<int*>(addrs));
			Rate += RateAdd;
			if (Rate > Chance) break;
			p++;
		}
		p -= 1;
		if (p < 0) p = 0;

		addrs = pAttrbuteTypeScript + (p * 8);
		AttrbuteType = *(reinterpret_cast<int*>(addrs));

		// Get AttrbuteValue
		pAttrbuteValueScript = GetSpecialOptionValueScript(ItemType, AttrbuteType);
		if (pAttrbuteValueScript == 0) return 5;
		Chance = BioticBaseGetRandom(pPlayer, 1000000);
		Rate = 1000000;
		p = 0;
		for( i = 0; i < 3; i++ )
		{
			addrs = pAttrbuteValueScript + (i * 0xC);
			RateSub = *(reinterpret_cast<int*>(addrs));
			if (Rate < Chance) break;
			p++;
			Rate -= RateSub;
		}
		p -= 1;
		if (p < 0) p = 0;

		RateMedium = Rate / 2;
		if (RateMedium > Chance)
		{
			// ValueMax
			addrs = pAttrbuteValueScript + (p * 0xC) + 0x8;
			AttrbuteValue = *(reinterpret_cast<int*>(addrs));
		}
		else
		{
			// ValueMin
			addrs = pAttrbuteValueScript + (p * 0xC) + 0x4;
			AttrbuteValue = *(reinterpret_cast<int*>(addrs));
		}
		
		ItemOptionSetType(pItem, AttrbuteType, AttrbuteValue);

		UseCount = 1;
		ItemOptionSetType(pItem, 0x6B, UseCount);

		// Create DB Packet 0x4A09
		addrs = (int)DBTASK_INSITEM_232A;
		*(reinterpret_cast<int*>(addrs)) = CharID;

		addrs = (int)DBTASK_INSITEM_232A + 0x4;
		tagItemInit(addrs);
		addrs = (int)DBTASK_INSITEM_232A + 0x4;
		EpochItemBaseGetItemGR(pItem, addrs);

		// Send DB Packet
		SendPacketEX(0x7F23A0, 0x4A09, (int)DBTASK_INSITEM_232A, 0x41);
	}

	// Client Packet
	// 1 Success / 0 Fail
	addrs = (int)ADD_SPECIAL_OPTION + 0x1;
	*(reinterpret_cast<int*>(addrs)) = Success;

	addrs = (int)ADD_SPECIAL_OPTION + 0x5;
	*(reinterpret_cast<int*>(addrs)) = ItemID;
	addrs = (int)ADD_SPECIAL_OPTION + 0x9;
	*(reinterpret_cast<int*>(addrs)) = nID;
	addrs = (int)ADD_SPECIAL_OPTION + 0xD;
	*(reinterpret_cast<char*>(addrs)) = (char)Inventory;
	addrs = (int)ADD_SPECIAL_OPTION + 0xE;
	*(reinterpret_cast<char*>(addrs)) = (char)Slot;

	addrs = (int)ADD_SPECIAL_OPTION + 0xF;
	*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
	addrs = (int)ADD_SPECIAL_OPTION + 0x13;
	*(reinterpret_cast<int*>(addrs)) = nIDUse;
	addrs = (int)ADD_SPECIAL_OPTION + 0x17;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryUse;
	addrs = (int)ADD_SPECIAL_OPTION + 0x18;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotUse;

	addrs = (int)ADD_SPECIAL_OPTION + 0x19;
	*(reinterpret_cast<int*>(addrs)) = AttrbuteType;

	addrs = (int)ADD_SPECIAL_OPTION + 0x1D;
	*(reinterpret_cast<int*>(addrs)) = AttrbuteValue;

	addrs = (int)ADD_SPECIAL_OPTION + 0x21;
	*(reinterpret_cast<int*>(addrs)) = UseCount;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x232A, (int)ADD_SPECIAL_OPTION, 0x25);

	// Remove Item
	addrs = (int)REMOVEITEM;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = (int)REMOVEITEM + 0x1;
	*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
	addrs = (int)REMOVEITEM + 0x5;
	*(reinterpret_cast<int*>(addrs)) = nIDUse;
	addrs = (int)REMOVEITEM + 0x9;
	*(reinterpret_cast<char*>(addrs)) = (char)InventoryUse;
	addrs = (int)REMOVEITEM + 0xA;
	*(reinterpret_cast<char*>(addrs)) = (char)SlotUse;
	addrs = (int)REMOVEITEM + 0xB;
	*(reinterpret_cast<char*>(addrs)) = 0;

	pThis = (DWORD)pDynamic;
	SendPacketEX(pThis, 0x1512, (int)REMOVEITEM, 0xC);

	pThis = pPlayer + 0xCC8;
	RemoveItemsInInventory(pThis, pItemUse, 1);

	return 0;
}

// RCM_MAP_SPECIAL_OPTION_GRANTCONFIRM 0x232B
void SkyItemSpecialOptionGrantConfirm(int pDynamic, int pSendPacket)
{
	int Result;
	int addrs;
	int pSendData;

	memset(SPECIAL_OPTION_GRANTCONFIRM, 0, 19);

	pSendData = pSendPacket + 4;
	Result = GetItemSpecialOptionGrantConfirm(pDynamic, pSendData);
	if (Result != 0)
	{
		addrs = (int)SPECIAL_OPTION_GRANTCONFIRM;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;
		SendPacketEX(pDynamic, 0x232B, (int)SPECIAL_OPTION_GRANTCONFIRM, 0x1);
	}
}

int GetItemSpecialOptionGrantConfirm(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int pThis;
	unsigned int CharID;

	int NpcType;
	int NpcID;
	int pNpc;

	int ItemID;
	int nID;
	int Inventory;
	int Slot;
	
	int pItem;
	int CheckID;
	int pCost;
	__int64 Cost = 0;
	unsigned int PriceL;
	unsigned int PriceH;
	__int64 CurMoney = 0;

	int AttrbuteType = 0;
	int AttrbuteValue = 0;
	int UseCount;

	// Check
	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 0x19;

	addrs = (DWORD)pPlayer + 0x30;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));

	addrs = (DWORD)pSendData + 0x4;
	NpcType = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	NpcID = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)pSendData + 0xC;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x10;
	nID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x3E;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x3F;
	Slot = *(reinterpret_cast<char*>(addrs));

	// Check NPC
	if (NpcID == 0) return 0x1;
	pNpc = GetNpc(NpcID);
	if (pNpc == 0) return 0x1;

	// Check Item
	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);
	if (pItem == 0) return 5;

	addrs = pItem + 0x20;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != ItemID) return 5;
	addrs = pItem + 0x24;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != nID) return 5;

	// Check Money
	UseCount = ItemOptionGetType(pItem, 0x6B);
	if (UseCount > 11) return 6;

	pCost = GetSpecialOptionCostScript(UseCount);
	Cost = *(reinterpret_cast<__int64*>(pCost));

	addrs = pPlayer + 0x1958;
	CurMoney = *(reinterpret_cast<__int64*>(addrs));
	if (CurMoney < Cost) return 5;

	// Sky Equip Special Option
	addrs = pPlayer + 0x20A0;
	AttrbuteType = *(reinterpret_cast<int*>(addrs));
	addrs = pPlayer + 0x20A4;
	AttrbuteValue = *(reinterpret_cast<int*>(addrs));
	if (AttrbuteType == 0) return 5;

	// Clean Special OptionAttrbuteType
	for( int i = 108; i < 124; i++ )
	{
		ItemOptionSetType(pItem, i, 0);
	}

	ItemOptionSetType(pItem, AttrbuteType, AttrbuteValue);

	UseCount += 1;
	ItemOptionSetType(pItem, 0x6B, UseCount);

	// Create DB Packet 0x4A09
	addrs = (int)DBTASK_INSITEM_232B;
	*(reinterpret_cast<int*>(addrs)) = CharID;

	addrs = (int)DBTASK_INSITEM_232B + 0x4;
	tagItemInit(addrs);
	addrs = (int)DBTASK_INSITEM_232B + 0x4;
	EpochItemBaseGetItemGR(pItem, addrs);

	// Send DB Packet
	SendPacketEX(0x7F23A0, 0x4A09, (int)DBTASK_INSITEM_232B, 0x41);

	// Client Packet
	addrs = (int)SPECIAL_OPTION_GRANTCONFIRM;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = (int)SPECIAL_OPTION_GRANTCONFIRM + 0x1;
	*(reinterpret_cast<int*>(addrs)) = UseCount;
	addrs = (int)SPECIAL_OPTION_GRANTCONFIRM + 0x5;
	*(reinterpret_cast<int*>(addrs)) = nID;
	addrs = (int)SPECIAL_OPTION_GRANTCONFIRM + 0xB;
	*(reinterpret_cast<int*>(addrs)) = AttrbuteType;
	addrs = (int)SPECIAL_OPTION_GRANTCONFIRM + 0xF;
	*(reinterpret_cast<int*>(addrs)) = AttrbuteValue;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x232B, (int)SPECIAL_OPTION_GRANTCONFIRM, 0x13);
	
	// Sub Money
	PriceH = Cost >> 32;
	PriceL = (unsigned int)Cost;
	pThis = pPlayer;
	PlayerSubMoney(pThis, PriceL, PriceH, 0x4D, 1);

	return 0;
}
// RCM_MAP_SPECIAL_OPTION_RESET 0x232C
void SkyItemSpecialOptionReset(int pDynamic, int pSendPacket)
{
	int Result;
	int addrs;
	int pSendData;
	
	memset(SPECIAL_OPTION_RESET, 0, 13);

	pSendData = pSendPacket + 4;
	Result = GetItemSpecialOptionReset(pDynamic, pSendData);
	if (Result != 0)
	{
		addrs = (int)SPECIAL_OPTION_RESET;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;
		SendPacketEX(pDynamic, 0x232C, (int)SPECIAL_OPTION_RESET, 0x1);
	}
}

int GetItemSpecialOptionReset(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int pThis;
	unsigned int CharID;

	int NpcType;
	int NpcID;
	int pNpc;

	int ItemID;
	int nID;
	int Inventory;
	int Slot;
	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;
	
	int pItem;
	int pItemUse;
	int UseCount;
	int CheckID;
	int pCost;

	__int64 Cost = 0;
	unsigned int PriceL;
	unsigned int PriceH;
	__int64 CurMoney = 0;

	int AttrbuteType = 0;
	int AttrbuteValue = 0;

	// Check
	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 0x1;
	
	addrs = (DWORD)pPlayer + 0x30;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));

	addrs = (DWORD)pSendData;
	NpcType = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x4;
	NpcID = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)pSendData + 0x8;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xC;
	nID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x10;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x11;
	Slot = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)pSendData + 0x12;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x16;
	nIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x1A;
	InventoryUse = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x1B;
	SlotUse = *(reinterpret_cast<char*>(addrs));

	// Check NPC
	if (NpcID == 0) return 0x1;
	pNpc = GetNpc(NpcID);
	if (pNpc == 0) return 0x1;

	// Check Item
	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);
	if (pItem == 0) return 5;

	addrs = pItem + 0x20;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != ItemID) return 5;
	addrs = pItem + 0x24;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != nID) return 5;

	pThis = pPlayer + 0xCC8;
	pItemUse = GetItem(pThis, InventoryUse, SlotUse);
	if (pItemUse == 0) return 5;

	addrs = pItemUse + 0x20;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != ItemIDUse) return 5;
	addrs = pItemUse + 0x24;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != nIDUse) return 5;

	// Check UseCount
	UseCount = ItemOptionGetType(pItem, 0x6B);
	if (UseCount < 2) return 5;

	// Check Money
	pCost = GetSpecialOptionCostScript(1);
	Cost = *(reinterpret_cast<__int64*>(pCost));

	addrs = pPlayer + 0x1958;
	CurMoney = *(reinterpret_cast<__int64*>(addrs));
	if (CurMoney < Cost) return 5;

	ItemOptionSetType(pItem, 0x6B, 1);

	// Create DB Packet 0x4A09
	addrs = (int)DBTASK_INSITEM_232C;
	*(reinterpret_cast<int*>(addrs)) = CharID;

	addrs = (int)DBTASK_INSITEM_232C + 0x4;
	tagItemInit(addrs);
	addrs = (int)DBTASK_INSITEM_232C + 0x4;
	EpochItemBaseGetItemGR(pItem, addrs);

	// Send DB Packet
	SendPacketEX(0x7F23A0, 0x4A09, (int)DBTASK_INSITEM_232C, 0x41);

	// Client Packet
	for( int i = 108; i < 124; i++ )
	{
		AttrbuteValue = ItemOptionGetType(pItem, i);
		if (AttrbuteValue != 0)
		{
			AttrbuteType = i;
			break;
		}
	}

	addrs = (int)SPECIAL_OPTION_RESET;
	*(reinterpret_cast<char*>(addrs)) = 0;

	addrs = (int)SPECIAL_OPTION_RESET + 0x1;
	*(reinterpret_cast<int*>(addrs)) = ItemID;
	addrs = (int)SPECIAL_OPTION_RESET + 0x5;
	*(reinterpret_cast<int*>(addrs)) = nID;
	addrs = (int)SPECIAL_OPTION_RESET + 0x9;
	*(reinterpret_cast<char*>(addrs)) = (char)Inventory;
	addrs = (int)SPECIAL_OPTION_RESET + 0xA;
	*(reinterpret_cast<char*>(addrs)) = (char)Slot;

	addrs = (int)SPECIAL_OPTION_RESET + 0xB;
	*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
	addrs = (int)SPECIAL_OPTION_RESET + 0xF;
	*(reinterpret_cast<int*>(addrs)) = nIDUse;
	addrs = (int)SPECIAL_OPTION_RESET + 0x13;
	*(reinterpret_cast<char*>(addrs)) = (char)Inventory;
	addrs = (int)SPECIAL_OPTION_RESET + 0x14;
	*(reinterpret_cast<char*>(addrs)) = (char)Slot;

	// AttrbuteType
	addrs = (int)SPECIAL_OPTION_RESET + 0x40;
	*(reinterpret_cast<int*>(addrs)) = AttrbuteType;
	// AttrbuteValue
	addrs = (int)SPECIAL_OPTION_RESET + 0x44;
	*(reinterpret_cast<int*>(addrs)) = AttrbuteValue;
	// Reset UseCount
	addrs = (int)SPECIAL_OPTION_RESET + 0x48;
	*(reinterpret_cast<int*>(addrs)) = 1;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x232C, (int)SPECIAL_OPTION_RESET, 0x4C);

	// Sub Money
	PriceH = Cost >> 32;
	PriceL = (unsigned int)Cost;
	pThis = pPlayer;
	PlayerSubMoney(pThis, PriceL, PriceH, 0x4D, 1);

	// Remove Item
	pThis = pPlayer + 0xCC8;
	RemoveItem(pThis, pItemUse);

	return 0;

}

// RCM_MAP_SPECIAL_OPTION_REASSIGNMENT 0x232D
void SkyItemSpecialOptionReassignment(int pDynamic, int pSendPacket)
{
	int Result;
	int addrs;
	int pSendData;
	
	memset(SPECIAL_OPTION_RESDDIGN, 0, 13);

	pSendData = pSendPacket + 4;
	Result = GetItemSpecialOptionReassignment(pDynamic, pSendData);
	if (Result != 0)
	{
		addrs = (int)SPECIAL_OPTION_RESDDIGN;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;
		SendPacketEX(pDynamic, 0x232D, (int)SPECIAL_OPTION_RESDDIGN, 0x1);
	}
}

int GetItemSpecialOptionReassignment(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int pThis;
	int i;
	int p = 0;

	int NpcType;
	int NpcID;

	int ItemID;
	int nID;
	int Inventory;
	int Slot;

	int pItem;
	int ItemType;
	int pNpc;
	int CheckID;

	int Rate = 0;
	int RateMedium = 0;
	int RateAdd = 0;
	int RateSub= 0;
	int Chance = 0;

	int pAttrbuteTypeScript;
	int pAttrbuteValueScript;

	int AttrbuteType = 0;
	int AttrbuteValue = 0;
	int UseCount = 0;

	// Check
	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 0x19;

	addrs = (DWORD)pSendData;
	NpcType = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x4;
	NpcID = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)pSendData + 0x8;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0xC;
	nID = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)pSendData + 0x3A;
	Inventory = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pSendData + 0x3B;
	Slot = *(reinterpret_cast<char*>(addrs));

	// Check NPC
	if (NpcID == 0) return 0x1;
	pNpc = GetNpc(NpcID);
	if (pNpc == 0) return 0x1;

	// Check Item
	pThis = pPlayer + 0xCC8;
	pItem = GetItem(pThis, Inventory, Slot);
	if (pItem == 0) return 5;

	addrs = pItem + 0x20;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != ItemID) return 5;
	addrs = pItem + 0x24;
	CheckID = *(reinterpret_cast<int*>(addrs));
	if (CheckID != nID) return 5;

	// Check UseCount
	UseCount = ItemOptionGetType(pItem, 0x6B);

	// Get AttributeType
	ItemType = GetAttribute(pItem, 0);
	pAttrbuteTypeScript = GetSpecialOptionTypeScript(ItemType);
	if (pAttrbuteTypeScript == 0) return 5;

	Chance = BioticBaseGetRandom(pPlayer, 1000000);
	p = 0;
	for( i = 0; i < 7; i++ )
	{
		addrs = pAttrbuteTypeScript + (i * 8) + 4;
		RateAdd = *(reinterpret_cast<int*>(addrs));
		Rate += RateAdd;
		if (Rate > Chance) break;
		p++;
	}
	p -= 1;
	if (p < 0) p = 0;

	addrs = pAttrbuteTypeScript + (p * 8);
	AttrbuteType = *(reinterpret_cast<int*>(addrs));

	// Get AttrbuteValue
	pAttrbuteValueScript = GetSpecialOptionValueScript(ItemType, AttrbuteType);
	if (pAttrbuteValueScript == 0) return 5;

	Chance = BioticBaseGetRandom(pPlayer, 1000000);
	Rate = 1000000;
	p = 0;
	for( i = 0; i < 3; i++ )
	{
		addrs = pAttrbuteValueScript + (i * 0xC);
		RateSub = *(reinterpret_cast<int*>(addrs));
		if (Rate < Chance) break;
		p++;
		Rate -= RateSub;
	}
	p -= 1;
	if (p < 0) p = 0;

	RateMedium = Rate / 2;
	if (RateMedium > Chance)
	{
		// ValueMax
		addrs = pAttrbuteValueScript + (p * 0xC) + 0x8;
		AttrbuteValue = *(reinterpret_cast<int*>(addrs));
	}
	else
	{
		// ValueMin
		addrs = pAttrbuteValueScript + (p * 0xC) + 0x4;
		AttrbuteValue = *(reinterpret_cast<int*>(addrs));
	}


	// Sky Equip Special Option
	addrs = pPlayer + 0x20A0;
	*(reinterpret_cast<int*>(addrs)) = AttrbuteType;
	addrs = pPlayer + 0x20A4;
	*(reinterpret_cast<int*>(addrs)) = AttrbuteValue;

	// Client Packet
	addrs = (int)SPECIAL_OPTION_RESDDIGN;
	*(reinterpret_cast<char*>(addrs)) = 0;

	addrs = (int)SPECIAL_OPTION_RESDDIGN + 1;
	*(reinterpret_cast<int*>(addrs)) = AttrbuteType;

	addrs = (int)SPECIAL_OPTION_RESDDIGN + 5;
	*(reinterpret_cast<int*>(addrs)) = AttrbuteValue;

	addrs = (int)SPECIAL_OPTION_RESDDIGN + 9;
	*(reinterpret_cast<int*>(addrs)) = UseCount;

	pThis = pDynamic;
	SendPacketEX(pThis, 0x232D, (int)SPECIAL_OPTION_RESDDIGN, 0xD);

	return 0;
}

/*************** Funs ***************/
int GetSpecialOptionTypeScript(int ItemType)
{
	int pScript = 0;
	int addrs;
	int BinItemType = 0;
	int MaxCount = 0;
	int Offset = 0;

	MaxCount = SPECIALOPTIONTYPEBIN_SIZE / 0x54;
	Offset = (DWORD)SPECIALOPTIONTYPEBIN_ADDRS;

	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset;
		BinItemType = *(reinterpret_cast<int*>(addrs));
		if (BinItemType == ItemType)
		{
			pScript = Offset + 0x4;
			break;
		}
		Offset += 0x54;
	}

	return pScript;
}

int GetSpecialOptionValueScript(int ItemType, int AttrbuteType)
{
	int pScript = 0;
	int addrs;
	int BinItemType = 0;
	int BinAttrbuteType = 0;
	int MaxCount = 0;
	int Offset = 0;

	MaxCount = SPECIALOPTIONTYPEVALUEBIN_SIZE / 0x2C;
	Offset = (DWORD)SPECIALOPTIONTYPEVALUEBIN_ADDRS;

	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset;
		BinItemType = *(reinterpret_cast<int*>(addrs));
		if (BinItemType == ItemType)
		{
			addrs = Offset + 0x4;
			BinAttrbuteType = *(reinterpret_cast<int*>(addrs));
			if (BinAttrbuteType == AttrbuteType)
			{
				pScript = Offset + 0x8;
				break;
			}
		}
		Offset += 0x2C;
	}

	return pScript;
}


int GetSpecialOptionCostScript(int UseCount)
{
	int pScript = 0;
	int addrs;
	int BinUseCount = 0;

	int MaxCount = 0;
	int Offset = 0;

	MaxCount = SPECIALOPTIONCOSTBIN_SIZE / 0x10;
	Offset = (DWORD)SPECIALOPTIONCOSTBIN_ADDRS;

	if (UseCount > 10) UseCount = 10;

	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset;
		BinUseCount = *(reinterpret_cast<int*>(addrs));
		if (BinUseCount == UseCount)
		{
			pScript = Offset + 0x8;
			break;
		}
		Offset += 0x10;
	}

	return pScript;
}