/*******************************************
 RCM_MAP_WISH_TICKET_GETITEM 0x1483
 Send Size 0x12
 BE FA 05 00 +0  NPCType
 60 03 00 40 +4  NPCID
 E2 26 2C 00 +8  ItemID
 00 00 00 00 +C  nID
 00          +10 Inventory
 00          +11 Slot

 Recv Size 0x3E
 *******************************************/
#include <RHItem.h>
#include <MapFunctions.h>

using namespace std;

unsigned char WISH_GETITEM[62] = {0};

extern int WISHGETITEMBIN_ADDRS;
extern int WISHGETITEMBIN_SIZE;

// RCM_MAP_WISH_TICKET_GETITEM 0x1483
void WishGetItem(int pDynamic, int pSendPacket)
{
	int Result;
	int addrs;
	int pSendData;
	unsigned char WISH_RESULT[1] = {0};

	pSendData = pSendPacket + 4;
	Result = WishGetItemEtc(pDynamic, pSendData);
	if (Result != 0)
	{
		addrs = (int)WISH_RESULT;
		*(reinterpret_cast<char*>(addrs)) = (char)Result;
		SendPacketEX(pDynamic, 0x1483, (int)WISH_RESULT, 0x1);
	}
}

int WishGetItemEtc(int pDynamic, int pSendData)
{
	int Result = 0;
	int addrs;
	int pPlayer;
	int pThis;

	int Status;
	int NpcID;
	int pNpc;
	int pScript;
	int pGroupScript;

	int ItemIDUse;
	int nIDUse;
	int InventoryUse;
	int SlotUse;
	int ItemUseCount;

	int ItemID;
	int nID;
	int Inventory = 0xFF;
	int Slot = 0xFF;

	int pItem;
	int pItemUse;

	unsigned char NEWNID[8] = {0};
	unsigned char REMOVEITEM[12] = {0};

	// Check
	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 0x19;

	pThis = (DWORD)pPlayer;
	Status = PlayerCheckTradeItemWork(pThis, 0x0);
	if (Status == 0x0) return 0x55;

	addrs = (DWORD)pSendData + 0x4;
	NpcID = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pSendData + 0x8;
	ItemID = *(reinterpret_cast<int*>(addrs));

	if (NpcID == 0) return 0x1;
	pNpc = GetNpc(NpcID);
	if (pNpc == 0) return 0x1;

	// Check WishTicket / ItemID
	pScript = GetWishGetItemScript(ItemID);
	if (pScript == 0) return 0x5;

	pGroupScript = GetWishGroupIDScript(1);
	if (pGroupScript == 0) return 0x5;

	Result = CheckGroupID(pGroupScript, ItemID);
	if (Result == 0) return 0x5;

	addrs = (DWORD)pScript + 0x10;
	ItemIDUse = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pScript + 0x14;
	ItemUseCount = *(reinterpret_cast<int*>(addrs));
	if (ItemIDUse == 0) return 0x89;

	for( int i = 0; i < ItemUseCount; i++ )
	{
		pThis = (DWORD)pPlayer + 0xCC8;
		pItemUse = FindItem(pThis, ItemIDUse);
		if (pItemUse == 0) return 0x89;

		addrs = (DWORD)pItemUse + 0x20;
		ItemIDUse = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)pItemUse + 0x24;
		nIDUse = *(reinterpret_cast<int*>(addrs));;
		InventoryUse = GetAttribute(pItemUse, 0xC);
		SlotUse = GetAttribute(pItemUse, 0xD);

		// Remove WishTicket
		addrs = (int)REMOVEITEM;
		*(reinterpret_cast<char*>(addrs)) = 0;
		addrs = (int)REMOVEITEM + 0x1;
		*(reinterpret_cast<int*>(addrs)) = ItemIDUse;
		addrs = (int)REMOVEITEM + 0x5;
		*(reinterpret_cast<int*>(addrs)) = nIDUse;
		addrs = (int)REMOVEITEM + 0x9;
		*(reinterpret_cast<char*>(addrs)) = (char)InventoryUse;
		addrs = (int)REMOVEITEM + 0xA;
		*(reinterpret_cast<char*>(addrs)) = (char)SlotUse;
		addrs = (int)REMOVEITEM + 0xB;
		*(reinterpret_cast<char*>(addrs)) = 0;

		pThis = (DWORD)pDynamic;
		SendPacketEX(pThis, 0x1512, (int)REMOVEITEM, 0xC);

		pThis = pPlayer + 0xCC8;
		RemoveItemsInInventory(pThis, pItemUse, 1);		
	}

	// Cerate Item
	AllocItem((int)NEWNID, ItemID);
	addrs = (int)NEWNID + 0x4;
	nID = *(reinterpret_cast<int*>(addrs));
	if (nID < 1) return 0x8E;

	pItem = CreateItem((int)NEWNID, 1);

	pThis = (DWORD)pPlayer + 0xCC8;
	Result = GetFreeInventorySlot(pThis, (int)&Inventory, (int)&Slot);
	if (Result == 0) return 0x37;

	pThis = (DWORD)pPlayer + 0xCC8;
	Result = AddItem(pThis, pItem, Inventory, Slot, 0);
	if (Result == 0) return 0x37;

	// Client Packet
	addrs = (int)WISH_GETITEM + 1;
	tagItemInit(addrs);

	addrs = (int)WISH_GETITEM;
	*(reinterpret_cast<char*>(addrs)) = 0;
	addrs = (int)WISH_GETITEM + 1;
	EpochItemBaseGetItemGR(pItem, addrs);

	pThis = (DWORD)pDynamic;
	SendPacketEX(pThis, 0x1483, (int)WISH_GETITEM, 0x3E);

	return 0;
}

int GetWishGetItemScript(int ItemID)
{
	int pScript = 0;
	int addrs;
	int BinItemID;
	int MaxCount = 0;
	int Offset = 0;

	MaxCount = WISHGETITEMBIN_SIZE / 0x1C;
	Offset = (DWORD)WISHGETITEMBIN_ADDRS;
	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset + 0x18;
		BinItemID = *(reinterpret_cast<int*>(addrs));
		if (BinItemID == ItemID)
		{
			pScript = Offset;
			break;
		}
		Offset += 0x1C;
	}

	return pScript;
}