#include <Party.h>
#include <MapFunctions.h>
#include <RHItem.h>

using namespace std;

int CREATEPARTYRUNE_PARTY;
int CREATEPARTYRUNE_RET = 0x00543F94;
int CREATEPARTYRUNE_EXIT = 0x00543F8D;

int ADDMEMBERRUNE_PARTY;
int ADDMEMBERRUNE_RET = 0x005446BA;
int ADDMEMBERRUNE_EXIT = 0x00544690;

int CHANGELEADERRUNE_PARTY;
int CHANGELEADERRUNE_FUN = 0x00556060;
int CHANGELEADERRUNE_RET = 0x005498C9;

int WITHDRAWID;
int WITHDRAWPARTYRUNE_PARTY;
int WITHDRAWPARTYRUNE_FUN = 0x00649A10;
int WITHDRAWPARTYRUNE_RET = 0x00544909;

int DESTROYPARTYRUNE_PARTY;
int DESTROYPARTYRUNE_RET = 0x0054A3C1;

void CreatePartyRuneProc()
{
	// OrigCode
	__asm test eax,eax
	__asm je EXIT

	__asm mov ecx,dword ptr ss:[ebp-0x3C]
	__asm mov CREATEPARTYRUNE_PARTY,ecx

	RuneAttrButeSetting(CREATEPARTYRUNE_PARTY);
	RuneAttrButeLoad(CREATEPARTYRUNE_PARTY);

	__asm jmp CREATEPARTYRUNE_RET
EXIT:
	__asm jmp CREATEPARTYRUNE_EXIT
}

void AddMemberRuneProc()
{
	// OrigCode
	__asm test eax,eax
	__asm je EXIT

	__asm mov ecx,dword ptr ss:[ebp-0x6C]
	__asm mov ADDMEMBERRUNE_PARTY,ecx

	RuneAttrButeUnload(ADDMEMBERRUNE_PARTY);
	RuneAttrButeSetting(ADDMEMBERRUNE_PARTY);
	RuneAttrButeLoad(ADDMEMBERRUNE_PARTY);

	__asm jmp ADDMEMBERRUNE_RET
EXIT:
	__asm jmp ADDMEMBERRUNE_EXIT

}

void ChangeLeaderRuneProc()
{
	__asm mov ecx,dword ptr ss:[ebp-0x4]
	__asm mov CHANGELEADERRUNE_PARTY,ecx

	RuneAttrButeUnload(CHANGELEADERRUNE_PARTY);
	RuneAttrButeSetting(CHANGELEADERRUNE_PARTY);
	RuneAttrButeLoad(CHANGELEADERRUNE_PARTY);

	// OrigCode
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm push eax
	__asm mov ecx,dword ptr ss:[ebp-0x150]
	__asm add ecx,0x4
	__asm call CHANGELEADERRUNE_FUN
	__asm jmp CHANGELEADERRUNE_RET
}

void WithdrawPartyRuneProc()
{
	__asm mov ecx,dword ptr ss:[ebp-0x48]
	__asm mov WITHDRAWPARTYRUNE_PARTY,ecx

	RuneAttrButeUnload(WITHDRAWPARTYRUNE_PARTY);

	// OrigCode
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm push edx
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm push eax
	__asm mov ecx,dword ptr ss:[ebp-0x48]
	__asm call WITHDRAWPARTYRUNE_FUN

	// Resetting Rune
	RuneAttrButeSetting(WITHDRAWPARTYRUNE_PARTY);
	RuneAttrButeLoad(WITHDRAWPARTYRUNE_PARTY);

	__asm jmp WITHDRAWPARTYRUNE_RET
}

void DestroyPartyRuneProc()
{
	__asm mov ecx,dword ptr ss:[ebp-0x88]
	__asm mov DESTROYPARTYRUNE_PARTY,ecx

	RuneAttrButeUnload(DESTROYPARTYRUNE_PARTY);

	// OrigCode
	__asm push 0x1
	__asm mov eax,dword ptr ss:[ebp-0x88]
	__asm mov edx,dword ptr ds:[eax]
	__asm mov ecx,dword ptr ss:[ebp-0x88]
	__asm call dword ptr ds:[edx]

	__asm jmp DESTROYPARTYRUNE_RET

}

void RuneAttrButeSetting(int pParty)
{
	int addrs;
	int pPlayer;
	int pThis;
	unsigned int CharID = 0;
	int pItemRune = 0;
	int ItemID;
	int pitemScript;
	int pReinfScript;
	int AttrButeType;
	int AttrButeValue;
	int BootsLevel;

	for(int i = 0; i < 6; i++)
	{
		addrs = (DWORD)pParty + 0xA40 + (i * 4);
		*(reinterpret_cast<int*>(addrs)) = 0;
		addrs = (DWORD)pParty + 0xA60 + (i * 4);
		*(reinterpret_cast<int*>(addrs)) = 0;
		addrs = (DWORD)pParty + 0xA80 + (i * 4);
		*(reinterpret_cast<int*>(addrs)) = 0;
		addrs = (DWORD)pParty + 0xAA0 + (i * 4);
		*(reinterpret_cast<int*>(addrs)) = 0;

		addrs = (DWORD)pParty + 0x4 + (i * 4);
		CharID = *(reinterpret_cast<unsigned int*>(addrs));

		if (CharID != 0)
		{
			pPlayer = EntityManagerGetPlayer(CharID);
			if (pPlayer != 0)
			{
				ItemID = 0;
				AttrButeType = 0;
				AttrButeValue = 0;
				BootsLevel = 0;

				pThis = pPlayer;
				pItemRune = GetItemRune(pThis);
				if (pItemRune != 0)
				{
					addrs = (DWORD)pItemRune + 0x20;
					ItemID = *(reinterpret_cast<int*>(addrs));

					addrs = (DWORD)pItemRune + 0x1C;
					pitemScript = *(reinterpret_cast<int*>(addrs));

					addrs = (DWORD)pitemScript + 0x264;
					AttrButeType = *(reinterpret_cast<unsigned short*>(addrs));
					AttrButeType &= 0xFFFF;

					AttrButeValue = GetAttribute(pItemRune, AttrButeType);

					BootsLevel = ItemOptionGetType(pItemRune, 0x4F);
					if (BootsLevel > 0)
					{
						pReinfScript = GetRuneScript(ItemID);
						addrs = (DWORD)pReinfScript + 0x14 + (BootsLevel * 4);
						AttrButeValue = *(reinterpret_cast<unsigned short*>(addrs));
					}
				}

				addrs = (DWORD)pParty + 0xA40 + (i * 4);
				*(reinterpret_cast<int*>(addrs)) = ItemID;

				addrs = (DWORD)pParty + 0xA60 + (i * 4);
				*(reinterpret_cast<int*>(addrs)) = AttrButeType;

				addrs = (DWORD)pParty + 0xA80 + (i * 4);
				*(reinterpret_cast<int*>(addrs)) = AttrButeValue;

				addrs = (DWORD)pParty + 0xAA0 + (i * 4);
				*(reinterpret_cast<int*>(addrs)) = BootsLevel;

				// Release pPlayer
				pThis = pPlayer;
				CIOObjectRelease(pThis);
			}
		}
	}
}

void RuneAttrButeLoad(int pParty)
{
	int addrs;
	int pPlayer;
	int pThis;
	int pPartyID;
	unsigned int CharID = 0;
	int pAttrButeType;
	int pAttrButeValue;
	int AttrButeType = 0;
	int AttrButeValue = 0;
	int Value = 0;

	pPartyID = (DWORD)pParty + 4;
	pAttrButeType = (DWORD)pParty + 0xA60;
	pAttrButeValue = (DWORD)pParty + 0xA80;

	for(int i = 0; i < 6; i++)
	{
		addrs = (DWORD)pPartyID + (i * 4);
		CharID = *(reinterpret_cast<unsigned int*>(addrs));
		if (CharID != 0)
		{
			pPlayer = EntityManagerGetPlayer(CharID);
			if (pPlayer != 0)
			{
				for(int j = 0; j < 6; j++)
				{
					addrs = (DWORD)pAttrButeType + (j * 4);
					AttrButeType = *(reinterpret_cast<int*>(addrs));
					if (AttrButeType != 0)
					{
						addrs = (DWORD)pAttrButeValue + (j * 4);
						AttrButeValue = *(reinterpret_cast<int*>(addrs));

						// MK EXP Bonus
						if (AttrButeType == 191)
						{
							// EXP Bonus Rate (pPlater + 0x1AA4)
							addrs = pPlayer + 0x1AA4;
							Value = *(reinterpret_cast<int*>(addrs));
							if (Value < 0) Value = 0;
							Value += AttrButeValue;
							*(reinterpret_cast<int*>(addrs)) = Value;
						}
						else
						{
							pThis = pPlayer + 0xCC8;
							CalItemOption(pThis, AttrButeType, AttrButeValue, 1);
						}
					}
				}

				// CalAllAbility
				pThis = pPlayer;
				PlayerCalAllAbility(pThis);

				// Send CharStatus
				pThis = pPlayer;
				PlayerSendStatus(pThis);

				// Release pPlayer
				pThis = pPlayer;
				CIOObjectRelease(pThis);
			}
		}
	}
}

void RuneAttrButeUnload(int pParty)
{
	int addrs;
	int pPlayer;
	int pThis;
	int pPartyID;
	unsigned int CharID = 0;
	int pAttrButeType;
	int pAttrButeValue;
	int AttrButeType = 0;
	int AttrButeValue = 0;
	int Value = 0;

	pPartyID = (DWORD)pParty + 4;
	pAttrButeType = (DWORD)pParty + 0xA60;
	pAttrButeValue = (DWORD)pParty + 0xA80;

	for(int i = 0; i < 6; i++)
	{
		addrs = (DWORD)pPartyID + (i * 4);
		CharID = *(reinterpret_cast<unsigned int*>(addrs));
		if (CharID != 0)
		{
			pPlayer = EntityManagerGetPlayer(CharID);
			if (pPlayer != 0)
			{
				for(int j = 0; j < 6; j++)
				{
					addrs = (DWORD)pAttrButeType + (j * 4);
					AttrButeType = *(reinterpret_cast<int*>(addrs));
					if (AttrButeType != 0)
					{
						addrs = (DWORD)pAttrButeValue + (j * 4);
						AttrButeValue = *(reinterpret_cast<int*>(addrs));

						// MK EXP Bonus
						if (AttrButeType == 191)
						{
							// EXP Bonus Rate (pPlater + 0x1AA4)
							addrs = pPlayer + 0x1AA4;
							Value = *(reinterpret_cast<int*>(addrs));
							Value -= AttrButeValue;
							if (Value < 0) Value = 0;
							*(reinterpret_cast<int*>(addrs)) = Value;
						}
						else
						{
							pThis = pPlayer + 0xCC8;
							CalItemOption(pThis, AttrButeType, AttrButeValue, 0);
						}
					}
				}

				// CalAllAbility
				pThis = pPlayer;
				PlayerCalAllAbility(pThis);

				// Send CharStatus
				pThis = pPlayer;
				PlayerSendStatus(pThis);

				// Release pPlayer
				pThis = pPlayer;
				CIOObjectRelease(pThis);
			}
		}
	}
}

int GetItemRune(int pPlayer)
{
	int pItem = 0;
	int pThis;

	pThis = pPlayer + 0xCC8;
	pItem = FindItem(pThis, 5505025);
	if (pItem != 0) return pItem;

	pThis = pPlayer + 0xCC8;
	pItem = FindItem(pThis, 5505026);
	if (pItem != 0) return pItem;

	pThis = pPlayer + 0xCC8;
	pItem = FindItem(pThis, 5505027);
	if (pItem != 0) return pItem;

	pThis = pPlayer + 0xCC8;
	pItem = FindItem(pThis, 5505028);
	if (pItem != 0) return pItem;

	pThis = pPlayer + 0xCC8;
	pItem = FindItem(pThis, 5505029);
	if (pItem != 0) return pItem;

	pThis = pPlayer + 0xCC8;
	pItem = FindItem(pThis, 5505030);
	if (pItem != 0) return pItem;

	return 0;
}
