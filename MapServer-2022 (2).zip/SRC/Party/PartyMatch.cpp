#include <Party.h>
#include <MapFunctions.h>

using namespace std;

unsigned char PARTYMATCH_MAIN[36] = {0};
int PARTYMATCH_MAIN_ADDRS = (DWORD)PARTYMATCH_MAIN;

int PARTYMATCHREG_PLAYER;
int PARTYMATCHREG_RET = 0x00488D4F;
int PARTYMATCHREGLV_PLAYER;
int PARTYMATCHREGLV_RET = 0x0054D175;

int PARTYMATCHUNREG_PLAYER;
int PARTYMATCHUNREG_RET = 0x0048A7E1;
int PARTYMATCHUNREGLV_PLAYER;
int PARTYMATCHUNREGLV_RET = 0x005041B3;

int PARTYMATCH_CREATE_RET = 0x0054E7CB;
int PARTYMATCH_CLEAN_RET = 0x0054E858;
int PARTYMATCH_CLEAN_LOOP = 0x0054E832;
int PARTYMATCH_FIND_RET = 0x0054EA38;
int PARTYMATCH_ADD_RET = 0x0054EB7A;
int PARTYMATCH_GET_RET = 0x0054EF15;

extern int NationVersion;;

// RCM_MAP_PARTYMATCHINGLIST 0x1710
void PartyMatchListReg()
{
	// pPlayer
	__asm mov ecx,dword ptr ss:[ebp-0x10]
	__asm mov PARTYMATCHREG_PLAYER,ecx
	
	GetPartyMatchGate(PARTYMATCHREG_PLAYER);

	__asm mov byte ptr ss:[ebp-0x5],al
	__asm jmp PARTYMATCHREG_RET
}

void PartyMatchListRegLevel()
{
	__asm mov ecx,dword ptr ss:[ebp-0x10]
	__asm mov PARTYMATCHREGLV_PLAYER,ecx

	GetCharAllLevel(PARTYMATCHREGLV_PLAYER);

	__asm jmp PARTYMATCHREGLV_RET
}

void PartyMatchListUnReg()
{
	// pPlayer
	__asm mov ecx,dword ptr ss:[ebp-0xC]
	__asm mov PARTYMATCHUNREG_PLAYER,ecx
	
	GetPartyMatchGate(PARTYMATCHUNREG_PLAYER);

	__asm jmp PARTYMATCHUNREG_RET
}

void PartyMatchListUnRegLevel()
{
	__asm mov ecx,dword ptr ss:[ebp-0x58]
	__asm mov PARTYMATCHUNREGLV_PLAYER,ecx

	GetCharAllLevel(PARTYMATCHUNREGLV_PLAYER);

	__asm jmp PARTYMATCHUNREGLV_RET
}

int GetPartyMatchGate(int pPlayer)
{
	int Gate = 0;
	int Level;

	Level = GetCharAllLevel(pPlayer);
	if (Level > 165) Level = 165;

	// NationVersion KR
	if (NationVersion == 0x524B)
	{
		if (Level < 91) Gate = 0;
		if ((Level > 90) && (Level < 115)) Gate = 1;
		if ((Level > 114) && (Level < 165)) Gate = 2;
		if (Level > 164) Gate = 3;
	}
	else
	{
		Gate = (Level - 1) / 25;
		if (Gate > 6) Gate = 6;
	}

	return Gate;
}

/***** Party Match Memory *****/
void CreatePartyMatch()
{
	__asm mov ecx,PARTYMATCH_MAIN_ADDRS
	__asm mov dword ptr ds:[ecx+eax*4],edx
	
	__asm jmp PARTYMATCH_CREATE_RET
}

void CleanPartyMatch()
{
	__asm mov edx,PARTYMATCH_MAIN_ADDRS
	__asm cmp dword ptr ds:[edx+ecx*4],0x0
	__asm je EXIT

	__asm mov eax,dword ptr ss:[ebp-0x4]
	__asm mov ecx,PARTYMATCH_MAIN_ADDRS
	__asm mov edx,dword ptr ds:[ecx+eax*4]
	__asm jmp PARTYMATCH_CLEAN_RET

EXIT:
	__asm jmp PARTYMATCH_CLEAN_LOOP
}

void FindPartyMatch()
{
	__asm mov eax,PARTYMATCH_MAIN_ADDRS
	__asm mov ecx,dword ptr ds:[eax+edx*4]
	__asm mov dword ptr ss:[ebp-0xC],ecx

	__asm jmp PARTYMATCH_FIND_RET
}

void AddPartyMatch()
{
	__asm mov ecx,PARTYMATCH_MAIN_ADDRS
	__asm mov edx,dword ptr ds:[ecx+eax*4]
	__asm mov dword ptr ss:[ebp-0xC],edx

	__asm jmp PARTYMATCH_ADD_RET
}

void GetPartyMatch()
{
	__asm mov eax,PARTYMATCH_MAIN_ADDRS
	__asm mov ecx,dword ptr ds:[eax+edx*4]
	__asm mov dword ptr ss:[ebp-0x10],ecx

	__asm jmp PARTYMATCH_GET_RET
}


