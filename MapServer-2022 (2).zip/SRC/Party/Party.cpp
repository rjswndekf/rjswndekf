/*******************************************
 2021+ RCM_MAP_CREATEPARTY 0x1703 Packet Struct
 void CreateParty(ecx PartyPTR, int EntityID, byte bAdd)
 i = 0-5
 83 01 03 00 Ctype (i * 0x38) +0
 EB 03 00 00 CharID (i * 0x38) +4 
 AC F5 C0 74 A3 AE 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 CharName (i * 0x38) +8
 73 19 00 00 CurLife (i * 0x38) +1D
 73 19 00 00 MaxLife (i * 0x38) +21
 2F 08 00 00 CurMana (i * 0x38) +25
 2F 08 00 00 MaxMana (i * 0x38) +29
 73 00       LV      (i * 0x38) +2D
 00          ULV 1=ULV (i * 0x38) +2F
 00 00 00 00 HLV (i * 0x38) +30 //Taiwan Vers. 104.935+
 00 00 00 00 StatCount (i * 0x38) +34 // StatCount

 08 00 00 00 PartyNum = word ptr ds:[0xB3581C] +150

2021+ RCM_MAP_CHANGEPARTYLEADER_BROADCAST 0x1715 Packet Struct
void ChangePartyLeader(ecx PartyPTR)
 i = 0-5
 83 01 03 00 Ctype (i * 0x38) +0
 EB 03 00 00 CharID (i * 0x38) +4 
 AC F5 C0 74 A3 AE 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 CharName (i * 0x38) +8
 73 19 00 00 CurLife (i * 0x38) +1D
 73 19 00 00 MaxLife (i * 0x38) +21
 2F 08 00 00 CurMana (i * 0x38) +25
 2F 08 00 00 MaxMana (i * 0x38) +29
 73 00       LV      (i * 0x38) +2D
 00          ULV 1=ULV (i * 0x38) +2F
 02 00 00 00 HLV (i * 0x38) +30 Level Var
 00 00 00 00 StatCount (i * 0x38) +34 StatCount

 08 00 00 00 PartyNum = word ptr ds:[0xB3581C] +150
 00 00 00 00 PartyPTR+0x9FC +154
 00          PartyPTR+0x20  +158
 
 *******************************************/

#include <Party.h>
#include <MapFunctions.h>

using namespace std;

unsigned char CREATEPARTY_BUFFER[340] = {0};
int CREATEPARTY_ADDRS = (DWORD)CREATEPARTY_BUFFER;
int CREATEPARTY_RET = 0x00545E8A;

unsigned char CHANGEPARTYLEADER_BUFFER[345] = {0};
int CHANGEPARTYLEADER_ADDRS = (DWORD)CHANGEPARTYLEADER_BUFFER;
int CHANGEPARTYLEADER_RET = 0x00544558;

int CHANGEPARTYLEADER_FUN = 0x00545780;

int PartyDynamicPTR;
int PartyAddrs;
int PartyPTR;
int CurPlayerPTR;
int PartyNUM;
int PartyIndex;
int PartyEntityID;
int PartyPlayerPTR;
int PartyCType;
int PartyCharID;
int CharNameSRCPTR;
int CharNameDSTPTR;
int CurLife;
int MaxLife;
int CurMana;
int MaxMana;
int PartyPlayerLevel;
int PartyPlayerHLV;
int PartyPlayerTrans;
int PartyPlayerStatCount;

int ChangeAddrs;
int ChangePTR;
int ChangeNUM;
int ChangeIndex;
int ChangeEntityID;
int ChangePlayerPTR;
int ChangeCType;
int ChangeCharID;
int NameSRCPTR;
int NameDSTPTR;
int ChangeCurLife;
int ChangeMaxLife;
int ChangeCurMana;
int ChangeMaxMana;
int ChangePlayerLevel;
int ChangePlayerHLV;
int ChangePlayerTrans;
int ChangePlayerStatCount;
int OrderID;
int OrderOption;

// **** 2021 RCM_MAP_CREATEPARTY 0x1703 **********************************************
void CreateParty()
{
	
	memset(CREATEPARTY_BUFFER,0,sizeof(char)*340);

	__asm mov eax,dword ptr ds:[0xB3581C]
	__asm mov PartyNUM, eax

	__asm mov edx,dword ptr ss:[ebp-0x134]
	__asm mov CurPlayerPTR, edx
	
	__asm mov eax,dword ptr ss:[ebp-0x190]
	__asm mov PartyPTR, eax

	for(PartyIndex=0; PartyIndex < 6; PartyIndex++ )
	{
		PartyAddrs = (DWORD)PartyPTR + (PartyIndex * 4) + 4;
		PartyEntityID = *(reinterpret_cast<unsigned int*>(PartyAddrs));
		if (PartyEntityID)
		{
			PartyPlayerPTR = EntityManagerGetPlayer(PartyEntityID);
			if (PartyPlayerPTR)
			{
				// PartyPlayer CType
				PartyAddrs = (DWORD)PartyPlayerPTR + 0x2C;
				PartyCType = *(reinterpret_cast<unsigned int*>(PartyAddrs));
				PartyAddrs = (DWORD)CREATEPARTY_BUFFER + (PartyIndex * 0x38);
				*(reinterpret_cast<unsigned int*>(PartyAddrs)) = PartyCType;

				// PartyPlayer EntityID
				PartyAddrs = (DWORD)PartyPlayerPTR + 0x30;
				PartyCharID = *(reinterpret_cast<unsigned int*>(PartyAddrs));
				PartyAddrs = (DWORD)CREATEPARTY_BUFFER + (PartyIndex * 0x38) + 0x4;
				*(reinterpret_cast<unsigned int*>(PartyAddrs)) = PartyCharID;

				// PartyPlayer Name
				CharNameSRCPTR = PlayerGetName(PartyPlayerPTR);
				CharNameDSTPTR = (DWORD)CREATEPARTY_BUFFER + (PartyIndex * 0x38) + 0x8;
				StringsCopy(CharNameDSTPTR, CharNameSRCPTR, 0x15);

				// PartyPlayer CurLife
				PartyAddrs = (DWORD)PartyPlayerPTR + 0xAC;
				CurLife = *(reinterpret_cast<unsigned int*>(PartyAddrs));
				PartyAddrs = (DWORD)CREATEPARTY_BUFFER + (PartyIndex * 0x38) + 0x1D;
				*(reinterpret_cast<unsigned int*>(PartyAddrs)) = CurLife;

				// PartyPlayer MaxLife
				MaxLife = BioticBaseGetAbility(PartyPlayerPTR, 0xD);
				PartyAddrs = (DWORD)CREATEPARTY_BUFFER + (PartyIndex * 0x38) + 0x21;
				*(reinterpret_cast<unsigned int*>(PartyAddrs)) = MaxLife;
				
				// PartyPlayer CurMana
				PartyAddrs = (DWORD)PartyPlayerPTR + 0xB0;
				CurMana = *(reinterpret_cast<unsigned int*>(PartyAddrs));
				PartyAddrs = (DWORD)CREATEPARTY_BUFFER + (PartyIndex * 0x38) + 0x25;
				*(reinterpret_cast<unsigned int*>(PartyAddrs)) = CurMana;
				
				// PartyPlayer MaxMana
				MaxMana = BioticBaseGetAbility(PartyPlayerPTR, 0xF);
				PartyAddrs = (DWORD)CREATEPARTY_BUFFER + (PartyIndex * 0x38) + 0x29;
				*(reinterpret_cast<unsigned int*>(PartyAddrs)) = MaxMana;

				// PartyPlayer Level
				PartyPlayerLevel = BioticBaseGetAbility(PartyPlayerPTR, 0x15);
				if (PartyPlayerLevel > 115) PartyPlayerLevel = 115;
				PartyAddrs = (DWORD)CREATEPARTY_BUFFER + (PartyIndex * 0x38) + 0x2D;
				*(reinterpret_cast<unsigned int*>(PartyAddrs)) = PartyPlayerLevel;

				// PartyPlayer HLV Show
				PartyPlayerHLV = BioticBaseGetAbility(PartyPlayerPTR, 0x65);
				PartyAddrs = (DWORD)CREATEPARTY_BUFFER + (PartyIndex * 0x38) + 0x30;
				*(reinterpret_cast<char*>(PartyAddrs)) = PartyPlayerHLV;

				// PartyPlayer Trans
				PartyPlayerTrans = BioticBaseGetAbility(PartyPlayerPTR, 0x76);
				PartyAddrs = (DWORD)CREATEPARTY_BUFFER + (PartyIndex * 0x38) + 0x2F;
				*(reinterpret_cast<char*>(PartyAddrs)) = (char)PartyPlayerTrans;

				// PartyPlayer StatCount
				PartyPlayerStatCount = BioticBaseGetAbility(PartyPlayerPTR, 0x77);
				PartyAddrs = (DWORD)CREATEPARTY_BUFFER + (PartyIndex * 0x38) + 0x34;
				*(reinterpret_cast<int*>(PartyAddrs)) = PartyPlayerStatCount;

				// Release PartyPlayer
				CIOObjectRelease(PartyPlayerPTR);
			}
		}
	}

	// Party Num
	PartyAddrs = (DWORD)CREATEPARTY_BUFFER + 0x150;
	*(reinterpret_cast<int*>(PartyAddrs)) = PartyNUM;
	
	PartyAddrs = (DWORD)CurPlayerPTR + 0x1098;
	PartyDynamicPTR = *(reinterpret_cast<unsigned int*>(PartyAddrs));
	
	if (PartyDynamicPTR != 0)
	{
		SendPacket(PartyDynamicPTR, 0x1703, CREATEPARTY_ADDRS, 0x154);
	}

	__asm jmp CREATEPARTY_RET

}

// **** 2021 RCM_MAP_PARTY_RUNE_INFO 0x171E ******************************************************
void PartyRuneInfo(int pDynamic, int pSendPacket)
{
	int addrs;
	int pPlayer;
	int pThis;
	int PartyID;
	int pParty;
	int PacketAddrs;

	int CharID;
	int AttrButeType;
	int AttrButeValue;
	char Activat;
	int ItemID;
	int BootsLevel;

	unsigned char PARTYRUNEINFO[127] = {0};
	int PARTYRUNEINFO_ADDRS = (DWORD)PARTYRUNEINFO;

	memset(PARTYRUNEINFO,0,sizeof(char)*127);

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer != 0)
	{
		addrs = (DWORD)pPlayer + 0x1108;
		PartyID = *(reinterpret_cast<int*>(addrs));
		if (PartyID != 0)
		{
			pParty = GetParty(PartyID);

			if (pParty != 0)
			{
				PacketAddrs = (DWORD)PARTYRUNEINFO + 1;
				for(int i=0; i < 6; i++ )
				{
					addrs = (DWORD)pParty + 0x4 + (i * 0x4);
					CharID = *(reinterpret_cast<int*>(addrs));

					// pParty + 0xA40 ItemID
					addrs = (DWORD)pParty + 0xA40 + (i * 0x4);
					ItemID = *(reinterpret_cast<int*>(addrs));

					// pParty + 0xA60 AttrButeTypes
					addrs = (DWORD)pParty + 0xA60 + (i * 0x4);
					AttrButeType = *(reinterpret_cast<int*>(addrs));
					if (AttrButeType == 0) Activat = 0;
					else Activat = 1;

					// pParty + 0xA80 AttrButeValues
					addrs = (DWORD)pParty + 0xA80 + (i * 0x4);
					AttrButeValue = *(reinterpret_cast<int*>(addrs));

					// pParty + 0xAA0 BootsLevel
					addrs = (DWORD)pParty + 0xAA0 + (i * 0x4);
					BootsLevel = *(reinterpret_cast<int*>(addrs));

					addrs = (DWORD)PacketAddrs + (i * 0x15);
					*(reinterpret_cast<int*>(addrs)) = CharID;
					addrs = (DWORD)PacketAddrs + 0x4 + (i * 0x15);
					*(reinterpret_cast<int*>(addrs)) = AttrButeType;
					addrs = (DWORD)PacketAddrs + 0x8 + (i * 0x15);
					*(reinterpret_cast<int*>(addrs)) = AttrButeValue;
					addrs = (DWORD)PacketAddrs + 0xC + (i * 0x15);
					*(reinterpret_cast<char*>(addrs)) = Activat;
					addrs = (DWORD)PacketAddrs + 0xD + (i * 0x15);
					*(reinterpret_cast<int*>(addrs)) = ItemID;
					addrs = (DWORD)PacketAddrs + 0x11 + (i * 0x15);
					*(reinterpret_cast<int*>(addrs)) = 0;
				}

				addrs = (DWORD)pPlayer + 0x1098;
				pThis = *(reinterpret_cast<int*>(addrs));
				SendPacketEX(pThis, 0x171E, PARTYRUNEINFO_ADDRS, 0x7F);
			}
		}
	}
}

// **** 2021 RCM_MAP_CHANGEPARTYLEADER_BROADCAST 0x1715 **********************************************
void ChangePartyLeader()
{
	memset(CHANGEPARTYLEADER_BUFFER,0,sizeof(char)*345);

	__asm mov eax,dword ptr ss:[ebp-0x168]
	__asm mov ChangePTR, eax

	__asm mov eax,dword ptr ds:[0xB3581C]
	__asm mov ChangeNUM, eax

	__asm mov eax,dword ptr ss:[ebp-0x168]
	__asm mov ecx,dword ptr ds:[eax+0x9FC]
	__asm mov OrderID, ecx

	__asm mov eax,dword ptr ss:[ebp-0x168]
	__asm mov ecx,dword ptr ds:[eax+0x20]
	__asm mov OrderOption, ecx

	for(ChangeIndex=0; ChangeIndex < 6; ChangeIndex++ )
	{
		ChangeAddrs = (DWORD)ChangePTR + (ChangeIndex * 4) + 4;
		ChangeEntityID = *(reinterpret_cast<unsigned int*>(ChangeAddrs));
		if (ChangeEntityID)
		{
			ChangePlayerPTR = EntityManagerGetPlayer(ChangeEntityID);
			if (ChangePlayerPTR)
			{
				// PartyPlayer CType
				ChangeAddrs = (DWORD)ChangePlayerPTR + 0x2C;
				ChangeCType = *(reinterpret_cast<unsigned int*>(ChangeAddrs));
				ChangeAddrs = (DWORD)CHANGEPARTYLEADER_BUFFER + (ChangeIndex * 0x38);
				*(reinterpret_cast<unsigned int*>(ChangeAddrs)) = ChangeCType;

				// PartyPlayer EntityID
				ChangeAddrs = (DWORD)ChangePlayerPTR + 0x30;
				ChangeCharID = *(reinterpret_cast<unsigned int*>(ChangeAddrs));
				ChangeAddrs = (DWORD)CHANGEPARTYLEADER_BUFFER + (ChangeIndex * 0x38) + 0x4;
				*(reinterpret_cast<unsigned int*>(ChangeAddrs)) = ChangeCharID;

				// PartyPlayer Name
				NameSRCPTR = PlayerGetName(ChangePlayerPTR);
				NameDSTPTR = (DWORD)CHANGEPARTYLEADER_BUFFER + (ChangeIndex * 0x38) + 0x8;
				StringsCopy(NameDSTPTR, NameSRCPTR, 0x15);

				// PartyPlayer CurLife
				ChangeAddrs = (DWORD)ChangePlayerPTR + 0xAC;
				ChangeCurLife = *(reinterpret_cast<unsigned int*>(ChangeAddrs));
				ChangeAddrs = (DWORD)CHANGEPARTYLEADER_BUFFER + (ChangeIndex * 0x38) + 0x1D;
				*(reinterpret_cast<unsigned int*>(ChangeAddrs)) = ChangeCurLife;

				// PartyPlayer MaxLife
				ChangeMaxLife = BioticBaseGetAbility(ChangePlayerPTR, 0xD);
				ChangeAddrs = (DWORD)CHANGEPARTYLEADER_BUFFER + (ChangeIndex * 0x38) + 0x21;
				*(reinterpret_cast<unsigned int*>(ChangeAddrs)) = ChangeMaxLife;
				
				// PartyPlayer CurMana
				ChangeAddrs = (DWORD)ChangePlayerPTR + 0xB0;
				ChangeCurMana = *(reinterpret_cast<unsigned int*>(ChangeAddrs));
				ChangeAddrs = (DWORD)CHANGEPARTYLEADER_BUFFER + (ChangeIndex * 0x38) + 0x25;
				*(reinterpret_cast<unsigned int*>(ChangeAddrs)) = ChangeCurMana;
				
				// PartyPlayer MaxMana
				ChangeMaxMana = BioticBaseGetAbility(ChangePlayerPTR, 0xF);
				ChangeAddrs = (DWORD)CHANGEPARTYLEADER_BUFFER + (ChangeIndex * 0x38) + 0x29;
				*(reinterpret_cast<unsigned int*>(ChangeAddrs)) = ChangeMaxMana;

				// PartyPlayer Level
				ChangePlayerLevel = BioticBaseGetAbility(ChangePlayerPTR, 0x15);
				if (ChangePlayerLevel > 115) ChangePlayerLevel = 115;
				ChangeAddrs = (DWORD)CHANGEPARTYLEADER_BUFFER + (ChangeIndex * 0x38) + 0x2D;
				*(reinterpret_cast<unsigned int*>(ChangeAddrs)) = ChangePlayerLevel;
				
				// PartyPlayer HLV Show
				ChangePlayerHLV = BioticBaseGetAbility(ChangePlayerPTR, 0x65);
				ChangeAddrs = (DWORD)CHANGEPARTYLEADER_BUFFER + (ChangeIndex * 0x38) + 0x30;
				*(reinterpret_cast<char*>(ChangeAddrs)) = ChangePlayerHLV;

				// PartyPlayer Trans
				ChangePlayerTrans = BioticBaseGetAbility(ChangePlayerPTR, 0x76);
				ChangeAddrs = (DWORD)CHANGEPARTYLEADER_BUFFER + (ChangeIndex * 0x38) + 0x2F;
				*(reinterpret_cast<char*>(ChangeAddrs)) = (char)ChangePlayerTrans;

				// PartyPlayer StatCount
				ChangePlayerStatCount = BioticBaseGetAbility(ChangePlayerPTR, 0x77);
				ChangeAddrs = (DWORD)CHANGEPARTYLEADER_BUFFER + (ChangeIndex * 0x38) + 0x34;
				*(reinterpret_cast<int*>(ChangeAddrs)) = ChangePlayerStatCount;

				// Release PartyPlayer
				CIOObjectRelease(ChangePlayerPTR);
			}
		}
	}

	// Party Num
	ChangeAddrs = (DWORD)CHANGEPARTYLEADER_BUFFER + 0x150;
	*(reinterpret_cast<int*>(ChangeAddrs)) = ChangeNUM;

	// Party OrderID
	ChangeAddrs = (DWORD)CHANGEPARTYLEADER_BUFFER + 0x154;
	*(reinterpret_cast<unsigned int*>(ChangeAddrs)) = OrderID;

	// Party OrderID
	ChangeAddrs = (DWORD)CHANGEPARTYLEADER_BUFFER + 0x158;
	*(reinterpret_cast<unsigned char*>(ChangeAddrs)) = OrderOption;

	// Send Packet
	__asm mov edi,CHANGEPARTYLEADER_ADDRS
	// PartyLeader EntityID
	__asm mov ecx,dword ptr ss:[ebp-0x168]
	__asm mov edx,dword ptr ds:[ecx+0x4]
	__asm push edx
	__asm push 0x0
	__asm push 0x159
	__asm push edi
	__asm push 0x1715
	__asm mov ecx,dword ptr ss:[ebp-0x168]
	__asm call CHANGEPARTYLEADER_FUN

	__asm jmp CHANGEPARTYLEADER_RET

}
