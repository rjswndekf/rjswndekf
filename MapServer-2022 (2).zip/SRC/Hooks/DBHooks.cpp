#include <MapHooks.h>
#include <RHDB.h>

using namespace std; 

void DBHooks()
{
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	int ByteLen;
	
	// Recv DB Packet
	ByteLen = 5;
	Target_Addrs = 0x00408326;
	Proc_Addrs = (DWORD)DBPacketRecv + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// DB Packet 0x4A0F Patch
	ByteLen = 5;
	Target_Addrs = 0x0047B679;
	Proc_Addrs = (DWORD)DBPacketLimit+ 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// WSARecv Size Limit Slot 330
	ByteLen = 5;
	Target_Addrs = 0x005E5B91;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x4EB3; //20147
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x004188D9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x4EB3; //20147
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);


/***
	// WSASend Size Limit
	ByteLen = 5;
	Target_Addrs = 0x005E5DC9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x4EB3;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 6;
	Target_Addrs = 0x005E5EC4;
	Addrs = Target_Addrs + 2 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x4EB3;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x00418647;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x4EB3;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x004010A8;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x4EB3;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 6;
	Target_Addrs = 0x0066E451;
	Addrs = Target_Addrs + 2 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x4EB3;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
***/
}
