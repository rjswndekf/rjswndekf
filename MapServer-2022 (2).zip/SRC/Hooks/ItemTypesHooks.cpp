#include <MapHooks.h>
#include <RHItem.h>

using namespace std; 

void ItemTypeHooks()
{
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	int ByteLen;

	// Cal State Guarder Type
	ByteLen = 5;
	Target_Addrs = 0x00569013;
	Proc_Addrs = (DWORD)CalStateGuarderType + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Arrendal ItemType Patch
	ByteLen = 7;
	Target_Addrs = 0x0045FFE7;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x0045FFF0;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	
	ByteLen = 7;
	Target_Addrs = 0x00463E38;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x00463E41;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x00470D2C;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x00470D35;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x004717DC;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x004717E9;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x0053A879;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x0053A882;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x00561706;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 5;
	Target_Addrs = 0x0056171A;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x00565D5F;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x00565D68;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x00565D89;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x005660B7;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x005660C0;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x005661FA;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x00566203;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x00566224;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x00566871;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x0056687A;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x00566A07;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x00566A10;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x00566A31;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x00574391;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x0057439A;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x005F04E3;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x005F04EC;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x00711413;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x0071141C;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x00712A6A;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x00712A73;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Trinity Armor Patch
	ByteLen = 7;
	Target_Addrs = 0x0046000E;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE4;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x00460017;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE8;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	
	ByteLen = 7;
	Target_Addrs = 0x00463E56;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE4;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x00463E5F;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE8;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x00470D8B;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE4;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x00470D94;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE8;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x00471A0D;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE4;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x00471A1A;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE8;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x0053A89B;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE4;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x0053A8A4;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE8;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x00561684;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE4;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 5;
	Target_Addrs = 0x00561698;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE8;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x0056FE00;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE6;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x0056FE27;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE4;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x0056FE4E;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE5;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x0056FE75;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE7;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x0056FE9C;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE8;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x00571B80;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE4;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 5;
	Target_Addrs = 0x00571B94;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE8;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x00571D1B;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE4;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 5;
	Target_Addrs = 0x00571D2F;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE8;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x00574373;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE4;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x0057437C;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE8;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x005F050B;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE4;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x005F0514;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE8;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x006CCFB5;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE6;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x006CCFDC;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE4;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x006CD003;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE5;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x006CD02A;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE7;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x006CD051;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE8;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x00713590;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE4;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 5;
	Target_Addrs = 0x007135AA;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE5;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 5;
	Target_Addrs = 0x007135C4;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE6;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 5;
	Target_Addrs = 0x007135DE;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE7;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 5;
	Target_Addrs = 0x007135F8;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE8;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 5;
	Target_Addrs = 0x0071360D;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 5;
	Target_Addrs = 0x00713622;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xEA;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Arrow & Bolt ItemType Patch
	ByteLen = 7;
	Target_Addrs = 0x004FC5BA;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xDB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x004FC5C3;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xDC;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	
	ByteLen = 7;
	Target_Addrs = 0x005700D0;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xDB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x005700D9;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xDC;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x006CD253;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xDB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 7;
	Target_Addrs = 0x006CD25C;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xDC;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// SocketType 1 Patch
	ByteLen = 5;
	Target_Addrs = 0x0055A2B9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xB6;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x0047184D;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xB6;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x00471A7E;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xB6;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x00471CC0;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xB6;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x0055A2CD;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE1;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x0047359C;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE1;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x0046886F;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE1;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x00473710;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE1;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x0050FF3E;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE1;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x0056B87A;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE1;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x0047308F;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xE1;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Mail System ItemType 215 Patch
	ByteLen = 2;
	Target_Addrs = 0x00465AE7;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Closet Extension ItemType 226 Patch
	ByteLen = 2;
	Target_Addrs = 0x0046A73D;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// Closet Extension ItemType 227 Patch
	ByteLen = 2;
	Target_Addrs = 0x0046B126;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// BankBag ItemType 211 Patch
	ByteLen = 2;
	Target_Addrs = 0x0045D4EE;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// DCItem ItemType 209 Patch
	ByteLen = 2;
	Target_Addrs = 0x00461088;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Guard Armor Enhancement Packet 0x230F
	ByteLen = 2;
	Target_Addrs = 0x00470DCE;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Power Badge Type 223 Patch
	ByteLen = 5;
	Target_Addrs = 0x0057760E;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xDF;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Indun ItemType
	ByteLen = 10;
	Target_Addrs = 0x0047A321;
	Addrs = Target_Addrs + 6;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xD8;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 10;
	Target_Addrs = 0x0047A32D;
	Addrs = Target_Addrs + 6;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xD9;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Pet ItemType 184 Patch
	ByteLen = 2;
	Target_Addrs = 0x0045FD0A;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

}
