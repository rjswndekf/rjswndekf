#include <MapHooks.h>
#include <Scenegraph.h>

using namespace std; 


void ScenegraphHooks()
{
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	int ByteLen;

	/*** RCM_MAP_NEWENTITY_PLAYER 0x1209 Patch ***/
	// Packet Base Size
	ByteLen = 10;
	Target_Addrs = 0x005248F6;
	Addrs = Target_Addrs + 6 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xED;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Slot 6 Reinforce Patch
	ByteLen = 2;
	Target_Addrs = 0x00524CE5;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x00;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	/*** 2018+ tagAffect Size 0x24 ***/
	// tagAffectSkill Packet Size Patch 1 
	ByteLen = 5;
	Target_Addrs = 0x004A9853;
	Proc_Addrs = (DWORD)TagAffectSkillP1 + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// tagAffectSkill Packet Size Patch 2 
	ByteLen = 5;
	Target_Addrs = 0x004A986C;
	Proc_Addrs = (DWORD)TagAffectSkillP2 + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// tagAffectSkill Packet Size Patch 3 
	ByteLen = 5;
	Target_Addrs = 0x004A9890;
	Proc_Addrs = (DWORD)TagAffectSkillP3 + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// TagAffectSkill Size Patch
	ByteLen = 5;
	Target_Addrs = 0x005249C9;
	Proc_Addrs = (DWORD)TagAffectSkillSize + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	/*** Char Level Info ***/
	ByteLen = 5;
	Target_Addrs = 0x00524D51;
	Proc_Addrs = (DWORD)GetCharLevelInfo + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

}
