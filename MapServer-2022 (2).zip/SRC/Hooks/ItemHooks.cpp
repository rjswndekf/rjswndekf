#include <MapHooks.h>
#include <RHItem.h>

using namespace std; 


void ItemHooks()
{
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	int ByteLen;

	// 2018 RCM_MAP_GETITEMOFCHARACTER 0xD102 Patch
	// Get DB ItemOfCharData For Bag5 330 Slot
	ByteLen = 5;
	Target_Addrs = 0x004093CC;
	Proc_Addrs = (DWORD)DBGetItem + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	
	//ASM + C
	ByteLen = 5;
	Target_Addrs = 0x0041EFD0;
	Proc_Addrs = (DWORD)GetCharItemProc;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned int*>(Addrs)) = 0x90909090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2021 Inventory Fix
	// InitStaticInventory
	// No.0 Bag - EquipBag 0x1E(30) slot
	ByteLen = 7;
	Target_Addrs = 0x0047BAEC;
	Addrs = Target_Addrs + 6;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x1E;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// ALL Inventory cont
	ByteLen = 2;
	Target_Addrs = 0x006CCEC8;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x06; // Inventory cont
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// No.0 Bag - EquipBag 0x1E(30) slot
	ByteLen = 2;
	Target_Addrs = 0x006CCED2;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x1E;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// No.1 Bag slot 60
	ByteLen = 2;
	Target_Addrs = 0x006CCEDE;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x3C;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	//ByteLen = 10;
	//Target_Addrs = 0x00456C7F;
	//Addrs = Target_Addrs + 6;
	//*(reinterpret_cast<unsigned char*>(Addrs)) = 0x3C;
	//VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Init Inventory Item Packet
	ByteLen = 5;
	Target_Addrs = 0x00664180;
	Proc_Addrs = (DWORD)InitItemPacket;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Check nInventory
	ByteLen = 3;
	Target_Addrs = 0x00456BC3;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x06;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00423382;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004229EF;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004239B9;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00426482;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00425EE1;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x005663DF;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x00565EA5;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x005666A6;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004268E6;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00427793;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0042B40C;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0042BA8C;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0043177E;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0043204E;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0043EE45;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0043F585;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0043FCC5;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00440405;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044441E;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044D4F0;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0045028A;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004524FA;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00458CE2;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0045D366;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00464B46;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00468518;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0046A53D;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0046AF2D;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0047A1CE;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00509403;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0056CCDB;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00423DBD;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004259C9;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004270E8;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00428269;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0042A356;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0042A3D2;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0042ACAB;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00437C5B;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00439346;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004393C2;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044149B;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044452C;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044ADE0;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044B248;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044CA3C;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044CAB8;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044E83D;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004501F1;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00452461;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00457FBB;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0045917F;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004592B6;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004599B0;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0045ABB8;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0045B637;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0045B6B3;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0045C280;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0045CD5B;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0045DC0A;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0045F08C;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00467518;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0046E175;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0047F0BF;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0047F546;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00491582;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00425A1B;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00429251;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0042AC12;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0042F58A;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00431817;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004320E7;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004408B9;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044193E;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00444298;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044500F;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044549B;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044579C;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00445BFC;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004462A1;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004469FE;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00447510;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044A8FD;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044C1EB;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044F905;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0044F981;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00450B65;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00450BE1;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0045129B;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00451317;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00451B7B;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00451BF7;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00452DD5;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00452E51;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00453521;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0045359D;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00454152;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00454BC1;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00454EE4;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00455441;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004584E3;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00458897;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0045C2C5;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00463192;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004632E8;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00465A46;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0048F1EC;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00490FDC;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0049124C;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x005101C9;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	//Check GetCurCount for nInventory
	ByteLen = 4;
	Target_Addrs = 0x0053B7C4;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x00568440;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x005684C6;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x06;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x00568596;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x06;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0056927B;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x0056935F;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x0056942F;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x005694FF;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x0056BE6F;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x06;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x0056D444;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x06;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x0056D535;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x06;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x00571E8D;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x00572004;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x00572123;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x00572852;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x00572FAB;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x0057346B;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x00574062;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x0057759B;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x00592257;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x06;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x006CD732;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x006CD812;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x006CD890;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x006CD9E2;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x05;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	/*** ItemGR Attribute Patch ***/
	ByteLen = 7;
	Target_Addrs = 0x0068B774;
	Addrs = Target_Addrs + 6;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x7C;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
}

void EquipHooks()
{
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	int ByteLen;

	// 2018 RCM_MAP_EQUIPITEM 0x150B Patch
	ByteLen = 5;
	Target_Addrs = 0x00426290;
	Proc_Addrs = (DWORD)EquipItemP1 + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x005754B7;
	Proc_Addrs = (DWORD)EquipItemP3 + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2018 RCM_MAP_UNEQUIPITEM 0x150D Patch
	ByteLen = 5;
	Target_Addrs = 0x0042668C;
	Proc_Addrs = (DWORD)UnEquipItemP1 + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x0050F9D7;
	Proc_Addrs = (DWORD)UnEquipItemP2 + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x00573F2A;
	Proc_Addrs = (DWORD)UnEquipItemP4 + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2018 RCM_MAP_EXCHANGEEQUIPITEM 0x150F Patch
	ByteLen = 5;
	Target_Addrs = 0x00426EA2;
	Proc_Addrs = (DWORD)ExchangeEquipItem + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Equip
	ByteLen = 5;
	Target_Addrs = 0x006CD3A0;
	Proc_Addrs = (DWORD)EquipItem;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// UnEquip
	ByteLen = 5;
	Target_Addrs = 0x006CD640;
	Proc_Addrs = (DWORD)UnEquipItem;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	
	// Replace Equip
	ByteLen = 5;
	Target_Addrs = 0x006CD510;
	Proc_Addrs = (DWORD)ReplaceEquipItem;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Cal Equip Property
	ByteLen = 5;
	Target_Addrs = 0x00576250;
	Proc_Addrs = (DWORD)CalEquipProperty;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Item Option Attribute Type Ext
	ByteLen = 5;
	Target_Addrs = 0x00688346;
	Proc_Addrs = (DWORD)ItemAttr + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Aesir Race Equip Patch
	ByteLen = 5;
	Target_Addrs = 0x00713AAF;
	Proc_Addrs = (DWORD)PlayerEquipItemCheck + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x00568273;
	Proc_Addrs = (DWORD)RaceEquipItemCheck + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
}

void TalismanHooks()
{
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	int ByteLen;

	// Eguip & UnEguip Talisman
	ByteLen = 5;
	Target_Addrs = 0x00572A30;
	Proc_Addrs = (DWORD)EguipTalisman;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	//Addrs = Target_Addrs + 5 ;
	//*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Eguip Talisman Type
	ByteLen = 5;
	Target_Addrs = 0x00573520;
	Proc_Addrs = (DWORD)EquipTalismanType;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// UnEguip Talisman Type
	ByteLen = 5;
	Target_Addrs = 0x005738B0;
	Proc_Addrs = (DWORD)UnEquipTalismanType;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
}

void EnchantItemHooks()
{
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	int ByteLen;

	// 2021 RCM_MAP_ENCHANTITEM_LEVEL 0x1403 Patch
	// After the item fails to enchant, Level limit increased.
	ByteLen = 5;
	Target_Addrs = 0x0042B5E0;
	Proc_Addrs = (DWORD)EnchantItemLevel + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	
	// 2021 RCM_MAP_ENCHANTITEM_LEVEL 0x1403 Patch
	// 2021 RCM_MAP_ENCHANTITEM_RANK 0x1404 Patch
	// 2021 RCM_MAP_ENCHANTITEM_STRENGTH 0x1405 Patch
	// 2021 RCM_MAP_ENCHANTITEM_DEXTERITY 0x1406 Patch
	// 2021 RCM_MAP_ENCHANTITEM_INTELLIGENCE 0x1407 Patch
	// + 16
	ByteLen = 3;
	Target_Addrs = 0x004636B0;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xC2;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// + 1A
	ByteLen = 3;
	Target_Addrs = 0x004636B3;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xC6;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// + 1E
	ByteLen = 3;
	Target_Addrs = 0x004636BC;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xCA;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// + 1F
	ByteLen = 3;
	Target_Addrs = 0x004636C5;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xCB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// + 0E
	ByteLen = 3;
	Target_Addrs = 0x004636F8;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xBA;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// + 12
	ByteLen = 3;
	Target_Addrs = 0x00463701;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xBE;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// + 20 PacketType
	ByteLen = 4;
	Target_Addrs = 0x0046370A;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xCC;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// Packet Size
	ByteLen = 2;
	Target_Addrs = 0x0046370E;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x22;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// EnchantSetVar
	ByteLen = 5;
	Target_Addrs = 0x004636D4;
	Proc_Addrs = (DWORD)EnchantSetVar + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	
	// 2021 RCM_MAP_REINFORCE_ANCIENT_ITEM 0x1453 Patch
	ByteLen = 2;
	Target_Addrs = 0x004600F0;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 2;
	Target_Addrs = 0x004600B3;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x00460371;
	Proc_Addrs = (DWORD)ReinforceAnvientItem + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// RCM_MAP_UPGRADE_ITEM 0x151A Patch
	ByteLen = 5;
	Target_Addrs = 0x00467A79;
	Proc_Addrs = (DWORD)UpgradeItem + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Skill Point Recovery Stone Level Patch
	ByteLen = 2;
	Target_Addrs = 0x006946CA;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x00;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// ItemCombinationEX 2022
	ByteLen = 5;
	Target_Addrs = 0x00451D88;
	Proc_Addrs = (DWORD)CombinationEXSend43;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x00451DC8;
	Proc_Addrs = (DWORD)CombinationEXSend6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
}

void BankInventoryHooks()
{
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	int ByteLen;

	// RCM_MAP_BANK_GET_INFO 0x1D2A Patch
	ByteLen = 5;
	Target_Addrs = 0x0044F490;
	Proc_Addrs = (DWORD)BankGetInfoPacket + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	/**** 2021 Add ExtendBank Patch ***/
	// BANK ExtendDay Patch
	ByteLen = 5;
	Target_Addrs = 0x0045D472;
	Proc_Addrs = (DWORD)GetBankExtendDay + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x00553A34;
	Proc_Addrs = (DWORD)BankUpdateMaxSlot + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
}

void UseDCItemHooks()
{
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	int ByteLen;

	// RCM_MAP_USE_DC_ITEM 0x1459
	ByteLen = 5;
	Target_Addrs = 0x004615CE;
	Proc_Addrs = (DWORD)CheckItemExp + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x00461DFB;
	Proc_Addrs = (DWORD)UseDCItemPacket + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// GetEXP Fun Patch
	ByteLen = 2;
	Target_Addrs = 0x004FABF7;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x43EB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// GetMoney Fun Patch
	ByteLen = 2;
	Target_Addrs = 0x004FB15A;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 2;
	Target_Addrs = 0x004FB236;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x18EB;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned int*>(Addrs)) = 0x90909090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// CheckPotionUseLevelLimit
	ByteLen = 2;
	Target_Addrs = 0x004FA36D;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

}

void ItemBuffScrollHooks()
{
	DWORD Target_Addrs;
	//DWORD Proc_Addrs;
	DWORD Addrs;
	//DWORD JMPADDR;
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	int ByteLen;

	// RCM_MAP_USE_SKILLSCROLL 0x1438 Patch
	ByteLen = 6;
	Target_Addrs = 0x004A9172;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x9E;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// DBTASK_SAVEAFFECTSKILL Patch
	// Click Save
	ByteLen = 5;
	Target_Addrs = 0x004A41B6;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0xA001;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 6;
	Target_Addrs = 0x004A85A2;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0xA100;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 6;
	Target_Addrs = 0x004A85B4;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0xA100;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// RCM_SKILL_GETAFFECTSKILLLIST Patch
	ByteLen = 6;
	Target_Addrs = 0x0047C578;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0xA100;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	
	// DBTASK_DELAFFECTSKILL Patch
	ByteLen = 5;
	Target_Addrs = 0x004A426F;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0xA100;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

}

void MallItemHooks()
{
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	int ByteLen;

	// RCM_MAP_GETMALLITEM 0x1426
	ByteLen = 5;
	Target_Addrs = 0x0056208C;
	Proc_Addrs = (DWORD)GetMallItemSend + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	Addrs = Target_Addrs + 7 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x0040E1C5;
	Proc_Addrs = (DWORD)GetMallItemRecv + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Event Item Set OptionValue
	ByteLen = 5;
	Target_Addrs = 0x0056DBAF;
	Proc_Addrs = (DWORD)EventItemSetOptionValue + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
}

void MailHooks()
{
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	int ByteLen;

	ByteLen = 5;
	Target_Addrs = 0x0041364D;
	Proc_Addrs = (DWORD)GetMailList + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
}
