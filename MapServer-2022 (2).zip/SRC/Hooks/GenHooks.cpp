#include <MapHooks.h>
#include <GenFunctions.h>

using namespace std; 


void GenHooks()
{
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	int ByteLen;
	
	// BinReader 2021+
	ByteLen = 5;
	Target_Addrs = 0x0067D2C1;
	Proc_Addrs = (DWORD)ItemBinRead + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// pThis Size Ext 0x2600 to 0x2700
	ByteLen = 5;
	Target_Addrs = 0x00418C56;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = 0x2700;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// pPlayer Size Ext 0x2058 to 0x2200
	ByteLen = 5;
	Target_Addrs = 0x004DCB53;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = 0x2200;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// pParty Size Ext 0xA38 to 0xB00
	ByteLen = 5;
	Target_Addrs = 0x0054883C;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = 0xB00;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2016 SPEED HACK Patch
	//ByteLen = 2;
	//Target_Addrs = 0x00504A6C;
	//*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	//VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2018 LoginIndex FIX
	ByteLen = 2;
	Target_Addrs = 0x004569D3;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2018 indunmonster.bin Invalied LevelType fix
	//Target_Addrs = 0x006088C9;
	//*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	//VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2018 ALIVE HACK FIX
	Target_Addrs = 0x00504902;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// INVALID_TELEPORT_TYPE
	Target_Addrs = 0x0043E794;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// INVALID_REGION
	Target_Addrs = 0x004FA693;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// INVALID_BIND_INDEX
	Target_Addrs = 0x00429EC8;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	Target_Addrs = 0x0043D486;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// TempIndex
	Target_Addrs = 0x00502DEC;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// WRONG_DESCRIPTION_C
	Target_Addrs = 0x00471803;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	Target_Addrs = 0x00471C76;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	Target_Addrs = 0x00471A34;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	
	// INVALID TELEPORT POSITION
	ByteLen = 5;
	Target_Addrs = 0x0043DA4D;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = 0x00000086;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// INVALID TELEPORT POSITION
	Target_Addrs = 0x0043E61A;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = 0x00000086;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Coliseum Level limit Patch
	ByteLen = 2;
	Target_Addrs = 0x0043BD16;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Power Arena Level limit Patch
	ByteLen = 2;
	Target_Addrs = 0x0062DD25;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2021 Character ReLogin Patch
	/***
	ByteLen = 5;
	Target_Addrs = 0x004207BE;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned int*>(Addrs)) = 0x90909087;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	***/

	ByteLen = 2;
	Target_Addrs = 0x00420764;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 2;
	Target_Addrs = 0x004CE357;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x0041F980;
	*(reinterpret_cast<unsigned int*>(Target_Addrs)) = 0x90909090;
	Target_Addrs = 0x0041F984;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0x90;

	// 2021 Load GuildWar Npc (Room.bin) Patch for Taiwan Version
	ByteLen = 5;
	Target_Addrs = 0x005CB212;
	Proc_Addrs = (DWORD)GuildWarNPC + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Ashkeena Monster Grade Settings
	ByteLen = 2;
	Target_Addrs = 0x00608841;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x0CEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x006087E2;
	Proc_Addrs = (DWORD)AshkeenaMonGroup + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Lindun Monster EXP Patch
	ByteLen = 5;
	Target_Addrs = 0x00535448;
	Proc_Addrs = (DWORD)IndunMonsterExp + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2018+ Lindun Level Limit Patch
	ByteLen = 3;
	Target_Addrs = 0x004781A1;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x02;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 6;
	Target_Addrs = 0x004781A4;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x87;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// reserveddef.bin Syntax Error Patch
	ByteLen = 2;
	Target_Addrs = 0x0068E54E;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 2;
	Target_Addrs = 0x0068E643;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 2;
	Target_Addrs = 0x0068E668;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 2;
	Target_Addrs = 0x0068E690;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 2;
	Target_Addrs = 0x0068E73D;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 2;
	Target_Addrs = 0x0068E7D4;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// ItemMall Type / Price Patch
	ByteLen = 7;
	Target_Addrs = 0x006DFF49;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<int*>(Addrs)) = 0xFFFFFFFF;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 2;
	Target_Addrs = 0x006DFF50;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x28;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 7;
	Target_Addrs = 0x006DFF55;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<int*>(Addrs)) = 0xB2;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 2;
	Target_Addrs = 0x006DFF5C;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0x74;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Cal Monster Stat
	ByteLen = 5;
	Target_Addrs = 0x006FAF53;
	Proc_Addrs = (DWORD)MonStatProc + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	
	// Crash Patch
	ByteLen = 1;
	Target_Addrs = 0x005E2920;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xC3;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Township Battle 1 Player Test
	ByteLen = 2;
	Target_Addrs = 0x004841CE;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 2;
	Target_Addrs = 0x005CF5DC;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

}

