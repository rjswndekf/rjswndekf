#include <MapHooks.h>
#include <Party.h>

using namespace std; 

void PartyHooks()
{
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	int ByteLen;

	// 2021 RCM_MAP_CREATEPARTY 0x1703 Patch
	ByteLen = 5;
	Target_Addrs = 0x00545C5A;
	Proc_Addrs = (DWORD)CreateParty + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned int*>(Addrs)) = 0x90909090;
	Addrs = Target_Addrs + 9 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2021 RCM_MAP_CHANGEPARTYLEADER_BROADCAST 0x1715 Patch
	ByteLen = 5;
	Target_Addrs = 0x00544530;
	Proc_Addrs = (DWORD)ChangePartyLeader + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// RCM_MAP_PARTYMATCHINGLIST 0x1710
	// Create PartyMatch Memory
	ByteLen = 5;
	Target_Addrs = 0x0054E80E;
	Proc_Addrs = (DWORD)CreatePartyMatch + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// Clean PartyMatch Memory
	ByteLen = 5;
	Target_Addrs = 0x0054E847;
	Proc_Addrs = (DWORD)CleanPartyMatch + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// Find Party Match
	ByteLen = 5;
	Target_Addrs = 0x0054EA2E;
	Proc_Addrs = (DWORD)FindPartyMatch + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// Add Party Match
	ByteLen = 5;
	Target_Addrs = 0x0054EB6D;
	Proc_Addrs = (DWORD)AddPartyMatch + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// Get Party Match
	ByteLen = 5;
	Target_Addrs = 0x0054EF08;
	Proc_Addrs = (DWORD)GetPartyMatch + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// PartyMatch Tab Max Index
	ByteLen = 4;
	Target_Addrs = 0x0054E7D4;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x7;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 4;
	Target_Addrs = 0x0054E83B;
	Addrs = Target_Addrs + 3;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x7;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// Open Find
	ByteLen = 3;
	Target_Addrs = 0x0054E9B5;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x7;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// Reg Party
	ByteLen = 3;
	Target_Addrs = 0x00488D46;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x7;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0054EB1F;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x7;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x004889D5;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x7;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 3;
	Target_Addrs = 0x0054EEB7;
	Addrs = Target_Addrs + 2;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x7;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Tab Level
	ByteLen = 5;
	Target_Addrs = 0x00488D38;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x19;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x0048A7DA;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x19;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Reg
	ByteLen = 5;
	Target_Addrs = 0x00488D2A;
	Proc_Addrs = (DWORD)PartyMatchListReg + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 5;
	Target_Addrs = 0x0054D16B;
	Proc_Addrs = (DWORD)PartyMatchListRegLevel + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	//UnReg
	ByteLen = 5;
	Target_Addrs = 0x0048A7CC;
	Proc_Addrs = (DWORD)PartyMatchListUnReg + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 5;
	Target_Addrs = 0x005041A9;
	Proc_Addrs = (DWORD)PartyMatchListUnRegLevel + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	/**** Rune System ****/
	// Create Party
	ByteLen = 5;
	Target_Addrs = 0x00543F69;
	Proc_Addrs = (DWORD)CreatePartyRuneProc + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// Add Member
	ByteLen = 5;
	Target_Addrs = 0x00544669;
	Proc_Addrs = (DWORD)AddMemberRuneProc + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned int*>(Addrs)) = 0x90909090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// Change Leader
	ByteLen = 5;
	Target_Addrs = 0x005498BA;
	Proc_Addrs = (DWORD)ChangeLeaderRuneProc + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// Withdraw Party
	ByteLen = 5;
	Target_Addrs = 0x005448F9;
	Proc_Addrs = (DWORD)WithdrawPartyRuneProc + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	// Destroy Party
	ByteLen = 5;
	Target_Addrs = 0x0054A3AF;
	Proc_Addrs = (DWORD)DestroyPartyRuneProc + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
}
