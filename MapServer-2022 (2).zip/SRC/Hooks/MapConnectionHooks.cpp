#include <MapHooks.h>
#include <MapConnection.h>

using namespace std; 

void MapConnectionHooks()
{
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	int ByteLen;

	// 2018 RCM_MAP_GETSTATUS 0x1801 Patch
	ByteLen = 5;
	Target_Addrs = 0x004F2860;
	Proc_Addrs = (DWORD)GetStatus;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2018 RCM_MAP_INCABILITY_BROADCAST 0x1808 Patch
	ByteLen = 5;
	Target_Addrs = 0x004F86B0;
	Proc_Addrs = (DWORD)IncabilityBroadcast;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x0042864B;
	Proc_Addrs = (DWORD)IncabilityDBTask + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x0046793B;
	Proc_Addrs = (DWORD)IncabilityDBTaskMore + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// for HLV Incability Broadcast
	ByteLen = 5;
	Target_Addrs = 0x00516480;
	Proc_Addrs = (DWORD)IncabilityBroadcast;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2018 RCM_MAP_CHANGEJOB 0x180B Patch
	ByteLen = 5;
	Target_Addrs = 0x004FBA71;
	Proc_Addrs = (DWORD)ChangeJob + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2018 RCM_MAP_USETRANSJOB 0x141C Patch
	ByteLen = 5;
	Target_Addrs = 0x0044AAAF;
	Proc_Addrs = (DWORD)UseTransJob + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Quest Check
	ByteLen = 5;
	Target_Addrs = 0x00429A76;
	Proc_Addrs = (DWORD)QuestStateCheckProc + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Trinity Quest Arrendal Init
	ByteLen = 5;
	Target_Addrs = 0x004FABC7;
	Proc_Addrs = (DWORD)ArrendalQuestItemCheck + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
}

void CharInitHooks()
{
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	int ByteLen;

	// 2018 RCM_MAP_USEINITSKILL 0x1418 Patch
	ByteLen = 5;
	Target_Addrs = 0x005095AD;
	Proc_Addrs = (DWORD)UseInitSkill + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	
	// 2018 RCM_SKILL_INITSKILL 0x1610 Patch
	ByteLen = 5;
	Target_Addrs = 0x0050B892;
	Proc_Addrs = (DWORD)MapInitSkill + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2018 RCM_MAP_USEINITSTATUS 0x1417 Patch
	ByteLen = 5;
	Target_Addrs = 0x00441637;
	Proc_Addrs = (DWORD)UseInitStatus + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2018 RCM_MAP_MALL_USE_INITSTATUS 0x1433 Patch
	ByteLen = 5;
	Target_Addrs = 0x004581B9;
	Proc_Addrs = (DWORD)MallUseInitStatus + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2018 RCM_MAP_INIT_STATUS 0x181C Patch
	Target_Addrs = 0x00443955;
	Proc_Addrs = (DWORD)InitStatus + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2018 RCM_MAP_QUEST_INITSTATUS 0x1A0B Patch
	ByteLen = 5;
	Target_Addrs = 0x0059C17E;
	Proc_Addrs = (DWORD)QuestInitStatus + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned short*>(Addrs)) = 0x9090;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// CharBaseStatus add Aesir
	ByteLen = 5;
	Target_Addrs = 0x004D528D;
	Proc_Addrs = (DWORD)CharBaseStatus + 3;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	
	// New Race Init Patch
	ByteLen = 2;
	Target_Addrs = 0x00508775;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	ByteLen = 2;
	Target_Addrs = 0x0050F10B;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

}

void PortalHooks()
{
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	int ByteLen;

	// Portal
	ByteLen = 5;
	Target_Addrs = 0x006A1AE0;
	Proc_Addrs = (DWORD)Portal;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Portal Teleport FIX
	ByteLen = 2;
	Target_Addrs = 0x43B790;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	Target_Addrs = 0x43B851;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	Target_Addrs = 0x43B977;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	Target_Addrs = 0x43D971;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2021 Map Teleport
	ByteLen = 5;
	Target_Addrs = 0x0043EA37;
	Proc_Addrs = (DWORD)MapTeleport + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

}
