#include <MapHooks.h>
#include <GateChar.h>

using namespace std; 

void GateCharHooks()
{
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	int ByteLen;

	// 2019 RCM_GATE_ALLCHARACTER_1 0xE002 Patch
	ByteLen = 6;
	Target_Addrs = 0x005FB2A4;
	*(reinterpret_cast<int*>(Target_Addrs)) = 0x0150C969;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 6;
	Target_Addrs = 0x0047AAD6;
	*(reinterpret_cast<int*>(Target_Addrs)) = 0x0150C969;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x0047AADC;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x4CBA;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 6;
	Target_Addrs = 0x0041F8E5;
	*(reinterpret_cast<int*>(Target_Addrs)) = 0x0150C969;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 5;
	Target_Addrs = 0x0041F8EB;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x4CBA;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	/***
	ByteLen = 5;
	Target_Addrs = 0x0047AA93;
	Proc_Addrs = (DWORD)GetCharList + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	***/

	ByteLen = 5;
	Target_Addrs = 0x005FAE59;
	Proc_Addrs = (DWORD)GetCharList + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	
	// 2019 RCM_MAP_GETCHARACTER 0xD101 Patch
	ByteLen = 5;
	Target_Addrs = 0x0047B3DD;
	Proc_Addrs = (DWORD)GetCharacter + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 2;
	Target_Addrs = 0x0047B028;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// 2021 RCM_GATE_CREATECHARACTER 0xA001 Patch
	ByteLen = 5;
	Target_Addrs = 0x00408D1F;
	Proc_Addrs = (DWORD)CreateCharacterProc + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

}
