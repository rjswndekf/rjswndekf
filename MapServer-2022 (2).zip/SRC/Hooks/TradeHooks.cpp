#include <MapHooks.h>
#include <Trade.h>

using namespace std; 

void TradeHooks()
{
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	int ByteLen;

	// 2018 RCM_MAP_BUYITEMFROMNPC_2 0x1515 Patch
	ByteLen = 4;
	Target_Addrs = 0x00422002;
	Addrs = Target_Addrs + 3 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x14;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 4;
	Target_Addrs = 0x0042206D;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xB6;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 4;
	Target_Addrs = 0x0042212B;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0xB6;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 4;
	Target_Addrs = 0x004221C7;
	Addrs = Target_Addrs + 3 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x12;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 4;
	Target_Addrs = 0x004221D2;
	Addrs = Target_Addrs + 3 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x12;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 4;
	Target_Addrs = 0x004221FA;
	Addrs = Target_Addrs + 3 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x12;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 3;
	Target_Addrs = 0x004222A8;
	Addrs = Target_Addrs + 2 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x12;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 4;
	Target_Addrs = 0x004222D2;
	Addrs = Target_Addrs + 3 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x14;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 4;
	Target_Addrs = 0x00422306;
	Addrs = Target_Addrs + 3 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x12;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 4;
	Target_Addrs = 0x00422323;
	Addrs = Target_Addrs + 3 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x12;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 4;
	Target_Addrs = 0x00422497;
	Addrs = Target_Addrs + 3 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x13;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	ByteLen = 4;
	Target_Addrs = 0x004224A3;
	Addrs = Target_Addrs + 3 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x12;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// RCM_MAP_INDUN_BUY_ITEM 0x251C Patch
	ByteLen = 5;
	Target_Addrs = 0x004798C9;
	Proc_Addrs = (DWORD)IndunBuyItem + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Power Badge Mall 0x280A Patch
	ByteLen = 5;
	Target_Addrs = 0x0048BD15;
	Proc_Addrs = (DWORD)PowerBadgeMall + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Trade Item List Fix
	ByteLen = 5;
	Target_Addrs = 0x0074E03D;
	Proc_Addrs = (DWORD)SetTradeItemProc + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
}