#include <MapHooks.h>
#include <RHPet.h>

using namespace std; 

void PetCheckHooks()
{
	DWORD Target_Addrs;
	//DWORD Proc_Addrs;
	//DWORD Addrs;
	//DWORD JMPADDR;
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	int ByteLen;
	
	// Pet Check Patch
	Target_Addrs = 0x00445149;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x0044515A;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x00445572;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x0044557B;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x0044436F;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x00444378;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x00454FBB;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x00454FC4;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x004446A3;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x004446AF;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x00445CD3;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x00445CDC;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x0044637E;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x00446387;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x00446AD5;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x00446ADE;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x0044B3C2;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x0044B3CB;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x0045479B;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x004547A4;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x00454A7C;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x00454A85;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x00454C98;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x00454CA1;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x00455518;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x00455521;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x00459419;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x00459422;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x0045FC96;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x0045FCA7;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x006C1A27;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x006C1A30;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x006C1F19;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	ByteLen = 2;
	Target_Addrs = 0x006C1F22;
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xEB;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	Target_Addrs = 0x0053B8D1;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	Target_Addrs = 0x0053B8DA;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	Target_Addrs = 0x005598A4;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	Target_Addrs = 0x005598C0;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	Target_Addrs = 0x00559C79;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	Target_Addrs = 0x00559C95;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	Target_Addrs = 0x0056D397;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	Target_Addrs = 0x0056D3A0;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	Target_Addrs = 0x00437E70;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

	Target_Addrs = 0x00437E79;
	*(reinterpret_cast<unsigned short*>(Target_Addrs)) = 0x9090;

}

void PetHooks()
{
	DWORD Target_Addrs;
	DWORD Proc_Addrs;
	DWORD Addrs;
	DWORD JMPADDR;
	DWORD ProtectPTR = PAGE_EXECUTE_READWRITE;
	int ByteLen;

	// Pet Data Initialization
	ByteLen = 5;
	Target_Addrs = 0x0050C8E9;
	Proc_Addrs = (DWORD)PetDataInit + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

	// Pet Data Settings
	ByteLen = 5;
	Target_Addrs = 0x005EDDB0;
	Proc_Addrs = (DWORD)PetDataSet + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);
	
	// Pet Affect
	ByteLen = 5;
	Target_Addrs = 0x005EF3B0;
	Proc_Addrs = (DWORD)PetAffectProc + 6;
	JMPADDR = ((DWORD)Proc_Addrs - (DWORD)Target_Addrs - ByteLen);
	*(reinterpret_cast<unsigned char*>(Target_Addrs)) = 0xE9;
	Addrs = Target_Addrs + 1 ;
	*(reinterpret_cast<int*>(Addrs)) = JMPADDR;
	Addrs = Target_Addrs + 5 ;
	*(reinterpret_cast<unsigned char*>(Addrs)) = 0x90;
	VirtualProtect((LPVOID)Target_Addrs, ByteLen, PAGE_EXECUTE_READWRITE, &ProtectPTR);

}