#include <MapHooks.h>
#include <GenFunctions.h>

using namespace std;

int CUILDWARNPC_RET_ORIG = 0x005CB218;
int CUILDWARNPC_RET_END = 0x005CB298;

int LNDUNMONSTER;
int ASHKEENA_GRADE_RET = 0x006087E8;

int MONDATA;
int MONSTAT_RET = 0x006FAF59;

int LME_RETORG = 0x0053544F;
int LME_RETEXP = 0x00535463;
int LNDUN_MONSTER_TYPE;

extern int MON_DEF_RATE;

// 2021 Load GuildWar Npc (Room.bin) Patch
void GuildWarNPC()
{
	__asm mov eax,dword ptr ss:[ebp-0x94]
	__asm mov dword ptr ss:[ebp-0x10],eax
	__asm cmp dword ptr ss:[ebp-0x10],0x0
	__asm je RET_GWN0

	__asm jmp CUILDWARNPC_RET_ORIG

RET_GWN0:
	__asm jmp CUILDWARNPC_RET_END

}

/*** pIndunMonster ***
 + 0x8 MonsterType
 + 0xE2 Grade
 + 0xE4 Level
 *********************/
void AshkeenaMonGroup()
{
	__asm cmp ecx,0x9
	__asm jne RET_ORIG
	__asm mov ecx,0x4

RET_ORIG:
	__asm mov dword ptr ss:[ebp-0xF4],ecx

	__asm mov eax,dword ptr ss:[ebp-0x38]
	__asm mov LNDUNMONSTER, eax

	SetLmonGroup(LNDUNMONSTER);

	__asm mov dword ptr ss:[ebp-0x4C],eax
	__asm jmp ASHKEENA_GRADE_RET
}

int SetLmonGroup(int pIndunMonster)
{
	int SetGroup;
	int addrs;
	int MonsterLevel;
	int MonsterGrade;
	int MonsterType;
	
	addrs = pIndunMonster + 0x8;
	MonsterType = *(reinterpret_cast<int*>(addrs));
	addrs = pIndunMonster + 0xE2;
	MonsterGrade = *(reinterpret_cast<unsigned short*>(addrs));
	MonsterGrade &= 0xFFFF;
	addrs = pIndunMonster + 0xE4;
	MonsterLevel = *(reinterpret_cast<unsigned short*>(addrs));
	MonsterLevel &= 0xFFFF;
	
	if (MonsterGrade == 4)
	{
		// Ashkeena 31-90
		if (MonsterLevel == 45) SetGroup = 0;
		if (MonsterLevel == 55) SetGroup = 1;
		if (MonsterLevel == 65) SetGroup = 2;
		// Ashkeena 91-164
		if (MonsterLevel == 75) SetGroup = 3;
		if (MonsterLevel == 85) SetGroup = 4;
		if (MonsterLevel == 95) SetGroup = 5;
		// Ashkeena 165+
		if (MonsterLevel == 105) SetGroup = 6;
		if (MonsterLevel == 115) SetGroup = 7;
		if (MonsterLevel == 125) SetGroup = 8;
	}
	else
	{
		// ElementIndun 90+ SetGroup 0
		if (MonsterLevel == 105) SetGroup = 0;
		// ElementIndun 115+ SetGroup 3 4
		if (MonsterLevel == 115) SetGroup = 3;
		if (MonsterLevel == 135) SetGroup = 4;
		// ElementIndun Trans+ SetGroup 6 7 8
		if (MonsterLevel == 145) SetGroup = 6;
		if (MonsterLevel == 165) SetGroup = 7;
		if (MonsterLevel == 185) SetGroup = 8;

		// Ashkeena
		if (MonsterType == 310171) SetGroup = 0;
		if (MonsterType == 310172) SetGroup = 1;
		if (MonsterType == 310173) SetGroup = 2;
		if (MonsterType == 310174) SetGroup = 3;
		if (MonsterType == 310175) SetGroup = 4;
		if (MonsterType == 310176) SetGroup = 5;
		if (MonsterType == 310177) SetGroup = 6;
		if (MonsterType == 310178) SetGroup = 7;
		if (MonsterType == 310179) SetGroup = 8;

		// Grade 9
		if (MonsterType == 310147) SetGroup = 3;
		if (MonsterType == 310148) SetGroup = 4;
		if (MonsterType == 310149) SetGroup = 5;
		if (MonsterType == 310156) SetGroup = 3;
		if (MonsterType == 310157) SetGroup = 4;
		if (MonsterType == 310158) SetGroup = 5;
		if (MonsterType == 310165) SetGroup = 3;
		if (MonsterType == 310166) SetGroup = 4;
		if (MonsterType == 310167) SetGroup = 5;
	}

	return SetGroup;
}

void IndunMonsterExp()
{
	// Orig Code
	__asm mov dword ptr ss:[ebp-0x4],0x0

	// Target Monster Type
	__asm mov ecx, dword ptr ss:[ebp-0xC]
	__asm mov eax, dword ptr ds:[ecx+0x74]
	__asm mov edx, dword ptr ds:[eax+0x2C]
	__asm mov LNDUN_MONSTER_TYPE,edx

	CheckIndunMonsterType(LNDUN_MONSTER_TYPE);

	__asm test eax,eax
	__asm je RETORG
	__asm jmp LME_RETEXP

RETORG:
	__asm jmp LME_RETORG
}

int CheckIndunMonsterType(int MonsterType)
{
	int Result = 0;

	if ((MonsterType > 305143) && (MonsterType < 310180)) Result = 1;
		
	return Result;
}

/***********************
 Cal Monster Stat
 MonsterLevel + 0xE0
 MonsterSTR +0xF0
 MonsterDEX +0xF4
 MonsterVIT +0xF8
 MonsterINT +0xFC
 MonsterPSY +0x100
 MonsterAGI +0x104
 ***********************/
void MonStatProc()
{
	//pBinData
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov MONDATA,edx

	CalMonStat(MONDATA);

	// Orig Code
	__asm mov ecx,dword ptr ss:[ebp-0x8]
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm jmp MONSTAT_RET
}

void CalMonStat(int pBinData)
{
	int addrs;
	int Value = 0;
	int CalValue = 0;

	addrs = pBinData + 0xF8;
	Value = *(reinterpret_cast<int*>(addrs));
	CalValue = (Value * MON_DEF_RATE) / 100;
	Value += CalValue;
	addrs = pBinData + 0xF8;
	*(reinterpret_cast<int*>(addrs)) = Value;

	addrs = pBinData + 0x100;
	Value = *(reinterpret_cast<int*>(addrs));
	CalValue = (Value * MON_DEF_RATE) / 100;
	Value += CalValue;
	addrs = pBinData + 0x100;
	*(reinterpret_cast<int*>(addrs)) = Value;
}