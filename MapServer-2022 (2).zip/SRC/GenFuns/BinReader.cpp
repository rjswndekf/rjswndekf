#include <MapHooks.h>
#include <GenFunctions.h>
#include <MapFunctions.h>

using namespace std;

int BINREAD_THIS;

int BINREAD_RET = 0x0067D2C7;

extern int ITEMRANDOBOX_ADDRS;
extern int ITEMRANDOBOX_SIZE;

extern int ITEMRUNE_ADDRS;
extern int ITEMRUNE_SIZE;

char StrText[256];
char StrBuff[256];
string Text = "";


void ItemBinRead()
{
	// Original Code
	__asm mov dword ptr ss:[ebp-0x1B8],eax

	// pBin This
	__asm mov ecx,dword ptr ss:[ebp-0x578]
	__asm mov BINREAD_THIS, ecx

	// Read ItemRandomBox
	ItemRandomBoxRead(BINREAD_THIS, ITEMRANDOBOX_ADDRS);

	// Read ItemRune
	ItemRuneRead(BINREAD_THIS, ITEMRUNE_ADDRS);

	__asm jmp BINREAD_RET
}

// ItemRandomBox LineSize 0x1BC
void ItemRandomBoxRead(int pScriptThis, int pBinData)
{
	int addrs;
	int pThis;
	int pItemData;
	int i;
	int Disable;
	int MaxCount;

	if (ITEMRANDOBOX_SIZE != 0)
	{
		MaxCount = ITEMRANDOBOX_SIZE / 0x1BC;
		for( i = 0; i < MaxCount; i++ )
		{
			addrs = pBinData + (i * 0x1BC);
			Disable = *(reinterpret_cast<int*>(addrs));
			if (Disable == 0)
			{	pThis = pScriptThis;
				pItemData = pBinData + (i * 0x1BC);
				SetRandomBoxScript(pThis, pItemData);
			}
		}
	}
}

void SetRandomBoxScript(int pScriptThis, int pItemData)
{
	int addrs;
	int pThis;
	char * ItemScript;
	int pItemScript;

	int StrSize;
	int SRC;
	int DST;
	int Value;
	int ItemID;

	ItemScript = (char*) malloc(624 * sizeof(char));
	memset(ItemScript, 0xFC, 624);

	pItemScript = (int)ItemScript;
	ItemScriptInit(pItemScript);

	// ID
	addrs = pItemData + 0x4;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = pItemScript + 0x4;
	*(reinterpret_cast<int*>(addrs)) = ItemID;

	// Name
	SRC = pItemData + 0x8;
	StrSize = GetStringSize(SRC);
	DST = pItemScript + 0x8;
	SetScriptStrings(DST, SRC, StrSize);

	// KoreanName
	SRC = pItemData + 0x3A;
	StrSize = GetStringSize(SRC);
	DST = pItemScript + 0x24;
	SetScriptStrings(DST, SRC, StrSize);

	// Weight;
	addrs = pItemData + 0x6C;
	Value = *(reinterpret_cast<int*>(addrs));
	pThis = pItemScript + 0x228;
	SetItemScriptAttrbute(pThis, 0x2, Value);

	// Price;
	addrs = pItemData + 0x70;
	Value = *(reinterpret_cast<int*>(addrs));
	pThis = pItemScript + 0x228;
	SetItemScriptAttrbute(pThis, 0x3, Value);

	// SellPrice;
	addrs = pItemData + 0x74;
	Value = *(reinterpret_cast<int*>(addrs));
	pThis = pItemScript + 0x228;
	SetItemScriptAttrbute(pThis, 0x4, Value);

	// ItemType
	addrs = pItemData + 0x78;
	Value = *(reinterpret_cast<int*>(addrs));
	pThis = pItemScript + 0x228;
	SetItemScriptAttrbute(pThis, 0x0, Value);

	// ItemEntity;
	addrs = pItemData + 0x7C;
	Value = *(reinterpret_cast<int*>(addrs));
	addrs = pItemScript + 0x104;
	*(reinterpret_cast<int*>(addrs)) = Value;

	// Description
	addrs = pItemData + 0x80;
	Value = *(reinterpret_cast<int*>(addrs));
	pThis = pItemScript + 0x228;
	SetItemScriptAttrbute(pThis, 0x1, Value);
	SetItemScriptAttrbute(pThis, 0xA, 0x1);

	// RewardGrade
	addrs = pItemData + 0x84;
	Value = *(reinterpret_cast<int*>(addrs));
	pThis = pItemScript + 0x228;
	SetItemScriptAttrbute(pThis, 0x3A, Value);

	// ImageName;
	SRC = pItemData + 0x88;
	StrSize = GetStringSize(SRC);
	DST = pItemScript + 0x40;
	SetScriptStrings(DST, SRC, StrSize);

	// ItemExplain;
	SRC = pItemData + 0xBA;
	StrSize = GetStringSize(SRC);
	DST = pItemScript + 0x1D4;
	SetScriptStrings(DST, SRC, StrSize);

	// Setting Item Script
	pThis = pScriptThis;
	SetItemScript(pThis, ItemID, pItemScript);
}

// ItemRune LineSize 0x2B0
void ItemRuneRead(int pScriptThis, int pBinData)
{
	int addrs;
	int pThis;
	int pItemData;
	int i;
	int Disable;
	int MaxCount;

	if (ITEMRUNE_SIZE != 0)
	{
		MaxCount = ITEMRUNE_SIZE / 0x2B0;
		for( i = 0; i < MaxCount; i++ )
		{
			addrs = pBinData + (i * 0x2B0);
			Disable = *(reinterpret_cast<int*>(addrs));
			if (Disable == 0)
			{	pThis = pScriptThis;
				pItemData = pBinData + (i * 0x2B0);
				SetRuneScript(pThis, pItemData);
			}
		}
	}
}

void SetRuneScript(int pScriptThis, int pItemData)
{
	int addrs;
	int pThis;
	char * ItemScript;
	int pItemScript;
	int i;

	int StrSize;
	int SRC;
	int DST;
	int Value;
	int ItemID;

	int pAttributeType;
	int pAttributeValue;
	int AttributeType;
	int AttributeValue;

	ItemScript = (char*) malloc(624 * sizeof(char));
	memset(ItemScript, 0xFC, 624);

	pItemScript = (int)ItemScript;
	ItemScriptInit(pItemScript);

	// ID
	addrs = pItemData + 0x4;
	ItemID = *(reinterpret_cast<int*>(addrs));
	addrs = pItemScript + 0x4;
	*(reinterpret_cast<int*>(addrs)) = ItemID;

	// Name
	SRC = pItemData + 0x8;
	StrSize = GetStringSize(SRC);
	DST = pItemScript + 0x8;
	SetScriptStrings(DST, SRC, StrSize);

	// KoreanName
	SRC = pItemData + 0x3A;
	StrSize = GetStringSize(SRC);
	DST = pItemScript + 0x24;
	SetScriptStrings(DST, SRC, StrSize);

	// Description
	addrs = pItemData + 0x6C;
	Value = *(reinterpret_cast<int*>(addrs));
	pThis = pItemScript + 0x228;
	SetItemScriptAttrbute(pThis, 0x1, Value);

	// ItemType
	addrs = pItemData + 0x70;
	Value = *(reinterpret_cast<int*>(addrs));
	pThis = pItemScript + 0x228;
	SetItemScriptAttrbute(pThis, 0x0, Value);

	// ItemSubType
	addrs = pItemData + 0x74;
	Value = *(reinterpret_cast<int*>(addrs));
	pThis = pItemScript + 0x228;
	SetItemScriptAttrbute(pThis, 0x58, Value);

	// Weight;
	addrs = pItemData + 0x78;
	Value = *(reinterpret_cast<int*>(addrs));
	pThis = pItemScript + 0x228;
	SetItemScriptAttrbute(pThis, 0x2, Value);

	// Price;
	addrs = pItemData + 0x7C;
	Value = *(reinterpret_cast<int*>(addrs));
	pThis = pItemScript + 0x228;
	SetItemScriptAttrbute(pThis, 0x3, Value);

	// SellPrice;
	addrs = pItemData + 0x80;
	Value = *(reinterpret_cast<int*>(addrs));
	pThis = pItemScript + 0x228;
	SetItemScriptAttrbute(pThis, 0x4, Value);

	// MaxStack;
	addrs = pItemData + 0x84;
	Value = *(reinterpret_cast<int*>(addrs));
	pThis = pItemScript + 0x228;
	SetItemScriptAttrbute(pThis, 0xA, Value);

	// pImageName;
	SRC = pItemData + 0x88;
	StrSize = GetStringSize(SRC);
	DST = pItemScript + 0x40;
	SetScriptStrings(DST, SRC, StrSize);

	// ItemEntity;
	addrs = pItemData + 0xBC;
	Value = *(reinterpret_cast<int*>(addrs));
	addrs = pItemScript + 0x104;
	*(reinterpret_cast<int*>(addrs)) = Value;

	// AttributeType;
	pAttributeType = pItemData + 0xC0;
	// AttributeValue;
	pAttributeValue = pItemData + 0xD0;
	for( i = 0; i < 4; i++ )
	{
		addrs = pAttributeType + (i * 4);
		AttributeType = *(reinterpret_cast<int*>(addrs));
		addrs = pItemScript + 0x264 + (i * 2);
		*(reinterpret_cast<short*>(addrs)) = (short)AttributeType;
		if (AttributeType >= 0)
		{
			addrs = pAttributeValue + (i * 4);
			AttributeValue = *(reinterpret_cast<int*>(addrs));
			pThis = pItemScript + 0x228;
			SetItemScriptAttrbute(pThis, AttributeType, AttributeValue);
		}
	}

	// UseMinLevel;
	addrs = pItemData + 0xE0;
	Value = *(reinterpret_cast<int*>(addrs));
	addrs = pItemScript + 0x1D0;
	*(reinterpret_cast<int*>(addrs)) = Value;
	// UseMaxLevel;
	addrs = pItemData + 0xE4;
	Value = *(reinterpret_cast<int*>(addrs));
	addrs = pItemScript + 0x1CC;
	*(reinterpret_cast<int*>(addrs)) = Value;

	// pEquipSound;
	SRC = pItemData + 0xE8;
	StrSize = GetStringSize(SRC);
	DST = pItemScript + 0x140;
	SetScriptStrings(DST, SRC, StrSize);

	// pDropSound;
	SRC = pItemData + 0x11A;
	StrSize = GetStringSize(SRC);
	DST = pItemScript + 0x15C;
	SetScriptStrings(DST, SRC, StrSize);

	// pItemLargeImage;
	SRC = pItemData + 0x14C;
	StrSize = GetStringSize(SRC);
	DST = pItemScript + 0x5C;
	SetScriptStrings(DST, SRC, StrSize);

	// pExplainFileName;
	SRC = pItemData + 0x17E;
	StrSize = GetStringSize(SRC);
	DST = pItemScript + 0x1F0;
	SetScriptStrings(DST, SRC, StrSize);

	// pItemExplain;
	SRC = pItemData + 0x1B0;
	StrSize = GetStringSize(SRC);
	DST = pItemScript + 0x1D4;
	SetScriptStrings(DST, SRC, StrSize);

	// Setting Item Script
	pThis = pScriptThis;
	SetItemScript(pThis, ItemID, pItemScript);
}
