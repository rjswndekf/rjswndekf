#include <MapServer.h>
#include <winreg.h>
//#include <cstdlib>
#include <RHDB.h>
#include <sqlext.h>
#include <fstream>

using namespace std;

// SQLConnect Strings
unsigned char SQLCONNSTRS [512] = {0};

// ServerDir & attendance Path
char ServerDirPath [100] = {0};
unsigned char Nation [4] = {0};
int NationVersion;

int MON_DEF_RATE = 0;
int CRON_DROP_RATE = 0;

// PC-Bang
int PCMALL_WAIT_TIME = 0;

// Lucky Number Time
int LUCKYNUM_WAIT_TIME = 0;
int LUCKY_NUMBER_EXPIRE_TIME = 0;
int LUCKY_NUMBER_USER_EXPIRE_TIME = 0;

// Assassin Rank
unsigned char ASSRANK[36] = {0};
int ASSRANK_ADDRS = (DWORD)ASSRANK;

/********* MapServer Initialization *********/
void SrvInit()
{
    //SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
    //SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
    //SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	// Get SQLConnect Strings 
	GetSQLConnStrs();

	// Get ServerDir & attendance Path
	long RetCode;
    HKEY KeyHandle;
	const char* REG_PATH = "SOFTWARE\\Wow6432Node\\Geomind\\Gamenet";
	const char* ValueName = "ServerDir";
	const char* NationName = "Nation";
    DWORD ValueSize;
	DWORD NationValueSize;
    DWORD Type;

	int addrs;

	RetCode = RegOpenKeyEx(HKEY_LOCAL_MACHINE, REG_PATH,0, KEY_QUERY_VALUE, &KeyHandle);
    if( RetCode == ERROR_SUCCESS)
	{
		ValueSize = 99;
		NationValueSize = 4;
		RegQueryValueEx(KeyHandle, ValueName, NULL, &Type, (LPBYTE)ServerDirPath, &ValueSize);
		RegQueryValueEx(KeyHandle, NationName, NULL, &Type, (LPBYTE)Nation, &NationValueSize);

		RegCloseKey(KeyHandle);
	}

	addrs = (DWORD)Nation;;
	NationVersion = *(reinterpret_cast<int*>(addrs));

	/**** Load Bin ****/
	AttendanceBin();
	ChangeAccessoryBin();
	ChangeCharmBin();
	ChangeItemBin();
	ChangeWeaponBin();
	ItemAddSocketDetailsBin();
	ItemDismantleLevelBin();
	ItemDismantleReinforceBin();
	ItemRandomBoxBin();
	ItemRandomBoxRewardBin();
	ItemRuneBin();
	ItemWeaponEvolutionBin();
	ItemWeaponTransitionBin();
	LuckynumberBin();
	RuneReinforceBin();
	SpecialOptionCostBin();
	SpecialOptionTypeBin();
	SpecialOptionTypeValueBin();
	TranscendenceRacipeBin();
	TransItemBin();
	UltimateLevelStatBin();
	VipBossBin();
	WishGroupRecipeBin();
	WishTicketGetItemBin();
	WishTicketItemExchangeBin();
	WishTicketLevelEnchantBin();
	WishTicketOptionChangeBin();
	WishTicketReinforceBin();
	WishTicketTransitionBin();
	WishTransitionGroupBin();

	/**** VIP Room Init ****/
	VIPRoomInit();
	/**** Load Rate Sttings ****/
	LoadMapSetting();
	/**** Load AssassinRank ****/
	AssassinRankLoad();
}

/********* SQLConnect Strings *********/
void GetSQLConnStrs()
{
	long RetCode;
    HKEY KeyHandle;
	const char* REG_DBPATH = "SOFTWARE\\Wow6432Node\\Geomind\\Gamenet\\DB";
	const char* DBNAME = "GameDB";
    DWORD ValueSize;
    DWORD Type;

	RetCode = RegOpenKeyEx(HKEY_LOCAL_MACHINE, REG_DBPATH,0, KEY_QUERY_VALUE, &KeyHandle);
    if(RetCode == ERROR_SUCCESS)
	{
		ValueSize = 511;
		RegQueryValueEx(KeyHandle, DBNAME, NULL, &Type, (LPBYTE)SQLCONNSTRS, &ValueSize);
		RegCloseKey(KeyHandle);
	}
}

void LoadMapSetting()
{
	//define handles and variables
	SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
	SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
	SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	unsigned char cmdstr0[] = "SELECT LuckyNum_Wait_Time, PCBang_Wait_Time, CronDropRate, MonDefenseRate FROM RohanGame.dbo.TGameConfig";

	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr0, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {
			SQLGetData(SHSTMT, 1, SQL_C_ULONG, &LUCKYNUM_WAIT_TIME, 0, NULL);
			SQLGetData(SHSTMT, 2, SQL_C_ULONG, &PCMALL_WAIT_TIME, 0, NULL);
			SQLGetData(SHSTMT, 3, SQL_C_ULONG, &CRON_DROP_RATE, 0, NULL);
			SQLGetData(SHSTMT, 4, SQL_C_ULONG, &MON_DEF_RATE, 0, NULL);
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
}

void AssassinRankLoad()
{
	//define handles and variables
	SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
	SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
	SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	int offset = 0;
	int addrs = 0;

	unsigned char cmdstr0[] = "select top 3 char_id, accumulated_killcount, accumulated_killpoint from RohanGame.dbo.TAssassinInfo order by accumulated_killpoint desc";

	if (SQL_SUCCESS != SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr0, SQL_NTS))
	{
		SQLFreeStmt(SHSTMT, SQL_CLOSE);
	}
	else
	{
		while (SQLFetch(SHSTMT) == SQL_SUCCESS) {

			// CharID
			SQLGetData(SHSTMT, 1, SQL_C_BINARY, &ASSRANK[offset], 4, NULL);
			offset += 4;
			// Kill Count
			SQLGetData(SHSTMT, 2, SQL_C_BINARY, &ASSRANK[offset], 4, NULL);
			offset += 4;
			// Kill Point
			SQLGetData(SHSTMT, 3, SQL_C_BINARY, &ASSRANK[offset], 4, NULL);
			offset += 4;
		}
	}
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);
}
