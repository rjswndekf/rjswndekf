#include <GateChar.h>
#include <MapFunctions.h>

using namespace std; 

int GETCHARLIST_RET = 0x005FAE6C;
int GETCHARACTER_RET = 0x0047B3F9;

int GATE_CHARID;
int GATE_LEVEL;
int GATE_TRANS;
int GETCHAR_CHARID;
int GETCHAR_LEVEL;
int GETCHAR_TRANS;

int GETALLCHARACTER = 0x0041F840;
int CREATECHARACTER_RET = 0x00415AD6;

/******* ASM Funs *******/
extern int SENDPACKET_FUN;

// 2019 RCM_GATE_ALLCHARACTER_1 0xE002
void GetCharList()
{
	// +2C Write 1-Byte
	// [ebp-0x4] CharDataPTR (SRC) Size 0x152
	__asm mov esi,dword ptr ss:[ebp-0x4]
	__asm add esi,0x4
	__asm mov ecx,0x0B
	// [ebp+0x8] CopyTargetPTR (DST)
	__asm mov edi,dword ptr ss:[ebp+0x8]
	__asm rep movs dword ptr es:[edi],dword ptr ds:[esi]

	// ULV byte
	__asm mov byte ptr ds:[edi],0x0
	__asm add edi,0x1

	__asm mov ecx,0x48
	__asm rep movs dword ptr es:[edi],dword ptr ds:[esi]
	__asm movs word ptr es:[edi],word ptr ds:[esi]
	__asm movs byte ptr es:[edi],byte ptr ds:[esi]
	
	// Check Level
	__asm mov edi,dword ptr ss:[ebp+0x8]
	__asm movzx eax,word ptr es:[edi+0x2A]
	__asm cmp eax,0x1
	__asm je CLASS_CHECK

	// Check Trans
	__asm mov edi,dword ptr ss:[ebp+0x8]

	__asm mov ecx,dword ptr es:[edi]
	__asm mov GATE_CHARID,ecx

	__asm lea eax,dword ptr es:[edi+0x2A]
	__asm mov GATE_LEVEL,eax

	__asm lea edx,dword ptr es:[edi+0x2C]
	__asm mov GATE_TRANS,edx

	ShowTransMode(GATE_CHARID, GATE_LEVEL, GATE_TRANS);
	__asm jmp RET_TARGET

CLASS_CHECK:
	__asm mov edx,dword ptr es:[edi+0x19]
	__asm cmp edx, 0x000390C0
	__asm je SETAESIR_LEVEL
	__asm cmp edx, 0x00039044
	__asm jnz RET_TARGET

SETAESIR_LEVEL:
	__asm mov byte ptr es:[edi+0x2A],0x46
	

RET_TARGET:
	__asm jmp GETCHARLIST_RET
}

// 2019 RCM_MAP_GETCHARACTER 0xD101
void GetCharacter()
{
	// pData
	__asm lea edi,dword ptr ss:[ebp-0xD0]
	// CharID
	__asm mov ecx,dword ptr es:[edi+0x2]
	__asm mov GETCHAR_CHARID, ecx
	// pLevel
	__asm lea eax,dword ptr es:[edi+0x3C]
	__asm mov GETCHAR_LEVEL, eax
	// pTrans
	__asm lea edx,dword ptr es:[edi+0xC0]
	__asm mov GETCHAR_TRANS, edx

	ShowTransMode(GETCHAR_CHARID, GETCHAR_LEVEL, GETCHAR_TRANS);

	__asm push 0xC1
	__asm lea edx,dword ptr ss:[ebp-0xD0]
	__asm push edx
	__asm push 0xD101
	__asm mov ecx,dword ptr ss:[ebp-0x178]
	__asm call SENDPACKET_FUN

	__asm jmp GETCHARACTER_RET
	
}

// 2021 RCM_GATE_CREATECHARACTER 0xA001 Patch
void CreateCharacterProc()
{
	__asm mov ecx,dword ptr ss:[ebp-0xAE4]
	__asm call GETALLCHARACTER
	__asm jmp CREATECHARACTER_RET
}

/***
void SendGateCharPacket()
{
	__asm mov edi, BUFFER
	__asm mov eax, edi
	__asm add eax, 0xC
	__asm push eax
	__asm mov ecx, edi
	__asm add ecx, 0x4
	__asm push ecx
	__asm mov ecx,dword ptr ss:[ebp-0x56C]
	__asm add ecx,0x25A8
	CALL_ADDR = 0x005FB210;
	__asm call CALL_ADDR

	// +0
	__asm mov dword ptr ss:[edi],eax

	// +8
	__asm mov edx,dword ptr ss:[ebp-0x56C]
	__asm movzx eax,byte ptr ds:[edx+0x55C]
	__asm mov dword ptr ss:[edi+0x8],eax

	__asm mov ecx,0x4
	__asm sub ecx,dword ptr ss:[edi+0x4]
	__asm imul ecx,ecx,0x150
	__asm mov edx,0x54C
	__asm sub edx,ecx
	__asm mov dword ptr ss:[ebp-0x4],edx
	__asm mov eax,dword ptr ss:[ebp-0x4]

	// Send Packet
	__asm mov PacketSize, eax
	PacketPTR = (DWORD)BUFFER;
	PacketType = 0xE002;
	SendPacket(Dynamic_Pointer, PacketType, PacketPTR, PacketSize);

	RET_ADDR = 0x0047AB01;
	__asm jmp RET_ADDR
}
***/

