#include <BattleManager.h>
#include <MapFunctions.h>

using namespace std;

unsigned char SENDHUNTINGBONUS[65] = {0};
int SENDHUNTINGBONUS_ADDRS = (DWORD)SENDHUNTINGBONUS;

void HuntingBonus(int pDynamic, int pSendPacket)
{
	int Result;
	int pSendData;
	
	memset(SENDHUNTINGBONUS,0,sizeof(char)*65);

	pSendData = pSendPacket + 4;
	Result = GetHuntingBonus(pDynamic, pSendData);
	if (Result != 0)
	{
		*(reinterpret_cast<char*>(SENDHUNTINGBONUS_ADDRS)) = (char)Result;
		SendPacketEX(pDynamic, 0x1851, SENDHUNTINGBONUS_ADDRS, 0x41);
	}
}

int GetHuntingBonus(int pDynamic, int pSendData)
{
	int addrs;
	int pPlayer;
	int pThis;
	int ItemID;
	int nID;
	int Inventory;
	int Slot;
	int pItem;
	int pInventory;
	int pSlot;
	int Result;

	unsigned char RACIPITEMID[8] = {0};
	int RACIPITEMID_ADDRS = (DWORD)RACIPITEMID;

	unsigned char FREESPACE[8] = {0};
	int FREESPACE_ADDRS = (DWORD)FREESPACE;

	pThis = pDynamic;
	ResetHuntingBonus(pThis);

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer == 0) return 2;

	addrs = pSendData;
	ItemID = *(reinterpret_cast<int*>(addrs));
	if (ItemID == 0) return 1;

	addrs = SENDHUNTINGBONUS_ADDRS + 0x4;
	tagItemInit(addrs);

	// Cerate Item
	AllocItem(RACIPITEMID_ADDRS, ItemID);
	addrs = RACIPITEMID_ADDRS + 4;
	nID = *(reinterpret_cast<int*>(addrs));
	if (nID == 0) return 1;

	pItem = CreateItem(RACIPITEMID_ADDRS, 1);

	addrs = (DWORD)FREESPACE_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;
	addrs = (DWORD)FREESPACE_ADDRS + 4;
	*(reinterpret_cast<int*>(addrs)) = 0xFF;

	pInventory = FREESPACE_ADDRS;
	pSlot = FREESPACE_ADDRS + 4;

	pThis = pPlayer + 0xCC8;
	Result = GetFreeInventorySlot(pThis, pInventory, pSlot);
	if (Result == 0) return 1;

	addrs = FREESPACE_ADDRS;
	Inventory = *(reinterpret_cast<int*>(addrs));
	addrs = FREESPACE_ADDRS + 4;
	Slot = *(reinterpret_cast<int*>(addrs));

	pThis = pPlayer + 0xCC8;
	Result = AddItem(pThis, pItem, Inventory, Slot, 0);
	if (Result == 0) return 1;

	// Client Packet
	addrs = (DWORD)SENDHUNTINGBONUS_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0;
	addrs = (DWORD)SENDHUNTINGBONUS_ADDRS + 0x4;
	EpochItemBaseGetItemGR(pItem, addrs);

	pThis = pDynamic;
	SendPacketEX(pThis, 0x1851, SENDHUNTINGBONUS_ADDRS, 0x41);

	return 0;
}

void ResetHuntingBonus(int pDynamic)
{
	int addrs;
	int pThis;
	int pPlayer;
	unsigned char HUNTINGINIT[4] = {0};
	int HUNTINGINIT_ADDRS = (DWORD)HUNTINGINIT;

	// HuntingBonusInit
	addrs = (DWORD)HUNTINGINIT_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = 0;

	pThis = pDynamic;
	SendPacket(pThis, 0x1A4C, HUNTINGINIT_ADDRS, 0x4);

	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	if (pPlayer != 0)
	{
		pThis = (DWORD)pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0xF5, 0);
	}
}
