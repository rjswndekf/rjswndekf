#include <BattleManager.h>
#include <MapFunctions.h>
#include <RHDB.h>
#include <sqlext.h>

using namespace std;

unsigned char ASSASSIN_INFO[20] = {0};

int ASSASSIN_BATTLEPK_ATKER;
int ASSASSIN_BATTLEPK_ATKEE;
int ASSASSIN_BATTLEPK_RET = 0x00539471;

int ASSASSIN_BATTLEMK_PLAYER;
int ASSASSIN_BATTLEMK_RET = 0x00535E37;

int MKLIMIT_RETORIG = 0x00420C9E;
int MKLIMIT_RETEXIT = 0x00420CAD;
int MKLIMIT_ATTACKER;
int MKLIMIT_ATTACKEE;

/************ Assassin Info PK ************/
void AssassinBattlePK()
{
	// Orig Code
	__asm mov dword ptr ss:[ebp-0x4],0x0

	// Attacker
	__asm mov eax,dword ptr ss:[ebp-0x15C]
	__asm mov ecx,dword ptr ds:[eax+0x20C]
	__asm mov ASSASSIN_BATTLEPK_ATKER,ecx
	// Attacker Mode
	__asm cmp dword ptr ds:[ecx+0x1980],0x0
	__asm je RETEND
	// Attacker PL/MK Type
	__asm cmp dword ptr ds:[ecx+0x2094],0x1
	__asm jne RETEND

	// Attackee
	__asm mov edx,dword ptr ss:[ebp-0x88]
	__asm mov ASSASSIN_BATTLEPK_ATKEE,edx
	// Attackee Mode
	__asm cmp dword ptr ds:[edx+0x1980],0x1
	__asm je RETEND

	AssassinInfoPK(ASSASSIN_BATTLEPK_ATKER, ASSASSIN_BATTLEPK_ATKEE);

RETEND:
	__asm jmp ASSASSIN_BATTLEPK_RET
}

void AssassinInfoPK(int Attacker, int Attackee)
{
	int addrs;
	int pThis;
	int AttackerLevel = 0;
	int AttackeeLevel = 0;
	int AccumulatedKillCount = 0;
	int WeeklyKillCount = 0;
	int AccumulatedKillPoint = 0;
	int WeeklyKillPoint = 0;
	int KillPoint = 0;
	int ChangeTime = 0;
	int AssType = 0;
	int AssPK = 0;

	unsigned char ASSASSIN_LIMIT_PK[1] = {0};
	unsigned char ASSASSIN_LIMIT_TYPE[4] = {0};

	pThis = Attacker;
	AttackerLevel = GetCharAllLevel(pThis);

	pThis = Attackee;
	AttackeeLevel = GetCharAllLevel(pThis);

	KillPoint = GetKillPoint(AttackerLevel, AttackeeLevel);

	// AssassinInfo KillCount
	addrs = Attacker + 0x2080;
	AccumulatedKillCount = *(reinterpret_cast<int*>(addrs));
	AccumulatedKillCount += 1;
	addrs = Attacker + 0x2080;
	*(reinterpret_cast<int*>(addrs)) = AccumulatedKillCount;

	addrs = Attacker + 0x2088;
	WeeklyKillCount = *(reinterpret_cast<int*>(addrs));
	WeeklyKillCount += 1;
	addrs = Attacker + 0x2088;
	*(reinterpret_cast<int*>(addrs)) = WeeklyKillCount;

	// AssassinInfo KillPoint
	addrs = Attacker + 0x2084;
	AccumulatedKillPoint = *(reinterpret_cast<int*>(addrs));
	AccumulatedKillPoint += KillPoint;
	addrs = Attacker + 0x2084;
	*(reinterpret_cast<int*>(addrs)) = AccumulatedKillPoint;

	addrs = Attacker + 0x208C;
	WeeklyKillPoint = *(reinterpret_cast<int*>(addrs));
	WeeklyKillPoint += KillPoint;
	addrs = Attacker + 0x208C;
	*(reinterpret_cast<int*>(addrs)) = WeeklyKillPoint;

	// Change Timestamp
	addrs = Attacker + 0x2090;
	ChangeTime = *(reinterpret_cast<int*>(addrs));

	// Client Packet
	addrs = (int)ASSASSIN_INFO;
	*(reinterpret_cast<int*>(addrs)) = ChangeTime;
	addrs = (int)ASSASSIN_INFO + 0x4;
	*(reinterpret_cast<int*>(addrs)) = AccumulatedKillCount;
	addrs = (int)ASSASSIN_INFO + 0x8;
	*(reinterpret_cast<int*>(addrs)) = AccumulatedKillPoint;
	addrs = (int)ASSASSIN_INFO + 0xC;
	*(reinterpret_cast<int*>(addrs)) = WeeklyKillCount;
	addrs = (int)ASSASSIN_INFO + 0x10;
	*(reinterpret_cast<int*>(addrs)) = WeeklyKillPoint;

	addrs = (DWORD)Attacker + 0x1098;
	pThis = *(reinterpret_cast<int*>(addrs));
	if (pThis != 0)
	{
		SendPacketEX(pThis, 0x1311, (int)ASSASSIN_INFO, 0x14);
	}

	// Assassin Limit PK
	addrs = (DWORD)Attacker + 0x2094;
	AssType = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)Attacker + 0x2098;
	AssPK = *(reinterpret_cast<int*>(addrs));

	AssPK -= 1;
	addrs = (DWORD)Attacker + 0x2098;
	*(reinterpret_cast<int*>(addrs)) = AssPK;

	addrs = (int)ASSASSIN_LIMIT_PK;
	*(reinterpret_cast<char*>(addrs)) = (char)AssPK;
	
	addrs = (DWORD)Attacker + 0x1098;
	pThis = *(reinterpret_cast<int*>(addrs));
	if (pThis != 0)
	{
		SendPacketEX(pThis, 0x1474, (int)ASSASSIN_LIMIT_PK, 0x1);
	}

	if (AssPK == 0)
	{
		addrs = (DWORD)Attacker + 0x2094;
		*(reinterpret_cast<int*>(addrs)) = 0x2;

		addrs = (DWORD)Attacker + 0x209C;
		*(reinterpret_cast<int*>(addrs)) = 0x1F4;
		
		addrs = (int)ASSASSIN_LIMIT_TYPE;
		*(reinterpret_cast<char*>(addrs)) = 0x2;
		addrs = (int)ASSASSIN_LIMIT_TYPE + 1;
		*(reinterpret_cast<char*>(addrs)) = 0x0;
		addrs = (int)ASSASSIN_LIMIT_TYPE + 2;
		*(reinterpret_cast<short*>(addrs)) = 0x1F4;

		addrs = (DWORD)Attacker + 0x1098;
		pThis = *(reinterpret_cast<int*>(addrs));
		if (pThis != 0)
		{
			SendPacketEX(pThis, 0x1473, (int)ASSASSIN_LIMIT_TYPE, 0x4);
		}
	}

	// Update DBTask
	pThis = Attacker;
	UpdateAssassinInfo(pThis);
}

int GetKillPoint(int AttackerLevel, int AttackeeLevel)
{
	int KillPoint = 0;
	int LevelDiff;

	LevelDiff = AttackeeLevel - AttackerLevel;

	if (LevelDiff > 9) return 30;
	if (LevelDiff < -9) return 0;

	switch(LevelDiff)
	{
		case -9: KillPoint = 1; break;
		case -8: KillPoint = 2; break;
		case -7: KillPoint = 3; break;
		case -6: KillPoint = 4; break;
		case -5: KillPoint = 5; break;
		case -4: KillPoint = 6; break;
		case -3: KillPoint = 7; break;
		case -2: KillPoint = 8; break;
		case -1: KillPoint = 9; break;
		case 0: KillPoint = 10; break;
		case 1: KillPoint = 11; break;
		case 2: KillPoint = 12; break;
		case 3: KillPoint = 13; break;
		case 4: KillPoint = 14; break;
		case 5: KillPoint = 15; break;
		case 6: KillPoint = 17; break;
		case 7: KillPoint = 19; break;
		case 8: KillPoint = 23; break;
		case 9: KillPoint = 30; break;
	}

	return KillPoint;
}

/************ Assassin Info MK ************/
void AssassinBattleMK()
{
	// Orig Code
	__asm mov dword ptr ss:[ebp-0x78],eax
	__asm mov dword ptr ss:[ebp-0x74],ecx

	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm mov ASSASSIN_BATTLEMK_PLAYER,ecx
	// Attacker Mode
	__asm cmp dword ptr ds:[ecx+0x1980],0x0
	__asm je RETEND
	// Attacker PL/MK Type
	__asm cmp dword ptr ds:[ecx+0x2094],0x2
	__asm jne RETEND

	AssassinInfoMK(ASSASSIN_BATTLEMK_PLAYER);

RETEND:
	__asm jmp ASSASSIN_BATTLEMK_RET
}

void AssassinInfoMK(int pPlayer)
{
	int addrs;
	int pThis;
	int AssType = 0;
	int AssMK = 0;

	unsigned char ASSASSIN_LIMIT_MK[2] = {0};
	unsigned char ASSASSIN_LIMIT_TYPE[4] = {0};

	// Assassin Limit MK
	addrs = (DWORD)pPlayer + 0x2094;
	AssType = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x209C;
	AssMK = *(reinterpret_cast<int*>(addrs));
	AssMK -= 1;
	addrs = (DWORD)pPlayer + 0x209C;
	*(reinterpret_cast<int*>(addrs)) = AssMK;

	addrs = (int)ASSASSIN_LIMIT_MK;
	*(reinterpret_cast<short*>(addrs)) = (short)AssMK;
	
	addrs = (DWORD)pPlayer + 0x1098;
	pThis = *(reinterpret_cast<int*>(addrs));
	if (pThis != 0)
	{
		SendPacketEX(pThis, 0x1475, (int)ASSASSIN_LIMIT_MK, 0x2);
	}

	if (AssMK == 0)
	{
		addrs = (DWORD)pPlayer + 0x2094;
		*(reinterpret_cast<int*>(addrs)) = 0x1;
		addrs = (DWORD)pPlayer + 0x2098;
		*(reinterpret_cast<int*>(addrs)) = 0xA;
		addrs = (DWORD)pPlayer + 0x209C;
		*(reinterpret_cast<int*>(addrs)) = 0x1F4;

		addrs = (int)ASSASSIN_LIMIT_TYPE;
		*(reinterpret_cast<char*>(addrs)) = 0x1;
		addrs = (int)ASSASSIN_LIMIT_TYPE + 1;
		*(reinterpret_cast<char*>(addrs)) = 0xA;
		addrs = (int)ASSASSIN_LIMIT_TYPE + 2;
		*(reinterpret_cast<short*>(addrs)) = 0x1F4;

		addrs = (DWORD)pPlayer + 0x1098;
		pThis = *(reinterpret_cast<int*>(addrs));
		if (pThis != 0)
		{
			SendPacketEX(pThis, 0x1473, (int)ASSASSIN_LIMIT_TYPE, 0x4);
		}
	}

	// Update DBTask
	pThis = pPlayer;
	UpdateAssassinInfo(pThis);
}

/************ Assassin MK Mode Limit ************/
void AssassinMKLimit()
{
	__asm mov eax,dword ptr ss:[ebp-0x14]
	__asm mov MKLIMIT_ATTACKER,eax
	__asm mov ecx,dword ptr ss:[ebp-0x10]
	__asm mov MKLIMIT_ATTACKEE,ecx

	__asm cmp dword ptr ds:[eax+0x1980],0x1
	__asm jne ORIG
	__asm cmp dword ptr ds:[eax+0x2094],0x2
	__asm jne ORIG

	// Check CType
	__asm cmp byte ptr ds:[ecx+0x2E],0x3
	__asm je EXIT

ORIG:
	__asm mov ecx,dword ptr ss:[ebp-0x10]
	__asm mov edx,dword ptr ds:[ecx+0x1980]
	__asm jmp MKLIMIT_RETORIG

EXIT:
	__asm jmp MKLIMIT_RETEXIT
}

/************ Update Assassin Info ************/
void UpdateAssassinInfo(int pPlayer)
{
	//define handles and variables
	SQLHENV   SHENV  = SQL_NULL_HENV;   // Environment
	SQLHDBC   SHDBC  = SQL_NULL_HDBC;   // Connection handle
	SQLHSTMT  SHSTMT = SQL_NULL_HSTMT;  // Statement handle

	ODBCConnectDB(SHENV, SHDBC, SHSTMT);

	int addrs;
	int CharID;
	int AccumulatedKillCount = 0;
	int AccumulatedKillPoint = 0;
	int WeeklyKillCount = 0;
	int WeeklyKillPoint = 0;
	int AssType = 0;
	int AssPK = 0;
	int AssMK = 0;

	unsigned char cmdstr0[] = "UPDATE RohanGame.dbo.TAssassinInfo SET accumulated_killcount = ?, accumulated_killpoint = ?, weekly_killcount = ?, weekly_killpoint = ?, type = ?, pk = ?, mk = ? WHERE char_id = ?";

	addrs = (DWORD)pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)pPlayer + 0x2080;
	AccumulatedKillCount = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x2084;
	AccumulatedKillPoint = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x2088;
	WeeklyKillCount = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x208C;
	WeeklyKillPoint = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)pPlayer + 0x2094;
	AssType = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x2098;
	AssPK = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x209C;
	AssMK = *(reinterpret_cast<int*>(addrs));

	SQLBindParameter(SHSTMT, 1, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &AccumulatedKillCount, 0, 0);
	SQLBindParameter(SHSTMT, 2, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &AccumulatedKillPoint, 0, 0);
	SQLBindParameter(SHSTMT, 3, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &WeeklyKillCount, 0, 0);
	SQLBindParameter(SHSTMT, 4, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &WeeklyKillPoint, 0, 0);
	SQLBindParameter(SHSTMT, 5, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &AssType, 0, 0);
	SQLBindParameter(SHSTMT, 6, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &AssPK, 0, 0);
	SQLBindParameter(SHSTMT, 7, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &AssMK, 0, 0);
	SQLBindParameter(SHSTMT, 8, SQL_PARAM_INPUT, SQL_C_SLONG, SQL_INTEGER, 0, 0, &CharID, 0, 0);

	SQLExecDirect(SHSTMT, (SQLCHAR*)cmdstr0, SQL_NTS);
	// GO
	SQLFreeStmt(SHSTMT, SQL_CLOSE);

	ODBCDisconnectDB(SHENV, SHDBC, SHSTMT);

}