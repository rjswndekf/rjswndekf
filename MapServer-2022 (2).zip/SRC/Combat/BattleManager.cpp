#include <BattleManager.h>
#include <MapFunctions.h>
//#include <SkillManager.h>

using namespace std;

int ATTACKSTATUS_THIS;
int ATTACKSTATUS_RET = 0x0052BEC4;

int PAR_DYNAMICPTR;
int PAR_pPlayer;
int PANameSRCPTR;
int PANameDSTPTR;

unsigned char POWERARENAREWARD_BUFFER[45] = {0};
int POWERARENAREWARD_ADDRS = (DWORD)POWERARENAREWARD_BUFFER;
int POWERARENAREWARD_RET = 0x0062CC55;

int ADD_HUNTING_RATIO = 140;

void AttackStatus()
{
	__asm mov edx,dword ptr ss:[ebp-0x274]
	__asm mov ATTACKSTATUS_THIS, edx

	BattleMode(ATTACKSTATUS_THIS);

	__asm mov edx,dword ptr ss:[ebp-0x274]
	__asm mov eax,dword ptr ds:[edx+0x1CC]
	__asm mov dword ptr ss:[ebp-0x120],eax
	__asm jmp ATTACKSTATUS_RET
}

void BattleMode(int pAttack)
{
	int addrs = 0;
	int pPlayer = 0;
	int pTarget = 0;
	int pThis = 0;
	int AttackerType = 0;
	int AttackeeType = 0;

	addrs = (DWORD)pAttack + 0x1CC;
	pPlayer = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)pAttack + 0x1D4;
	pThis = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pThis;
	pTarget = *(reinterpret_cast<int*>(addrs));

	// 2021 Check Battle Status
	addrs = (DWORD)pPlayer + 0x2E;
	AttackerType = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)pTarget + 0x2E;
	AttackeeType = *(reinterpret_cast<char*>(addrs));

	if (AttackerType == 3)
	{
		pThis = pPlayer;
		StartBattleStatus(pThis);
	}
	if (AttackeeType == 3)
	{
		pThis = pTarget;
		StartBattleStatus(pThis);
	}
}

void StartBattleStatus(int pPlayer)
{
	int addrs = 0;
	int pThis = 0;
	int CurSeconds = 0;
	int CurHuntSeconds = 0;
	int HuntingIncTime = 0;
	int HuntingMode;
	int IncHunTime = 0;
	int CurHunRate;

	unsigned char BATTLEMODE_BUFFER[1] = {0};
	int BATTLEMODE_ADDRS = (DWORD)BATTLEMODE_BUFFER;

	unsigned char HUNTINGRATE[4] = {0};
	int HUNTINGRATE_ADDRS = (DWORD)HUNTINGRATE;

	// Setings Stop Time
	CurSeconds = GetCurSeconds();
	CurSeconds += 0x6;

	pThis = (DWORD)pPlayer + 0x1140;
	EntityBaseStatusSetAbility(pThis, 0xF0, CurSeconds);

	pThis = (DWORD)pPlayer + 0x1140;
	EntityBaseStatusSetAbility(pThis, 0xF1, 0x1);

	*(reinterpret_cast<char*>(BATTLEMODE_ADDRS)) = 1;

	addrs = (DWORD)pPlayer + 0x1098;
	pThis =  *(reinterpret_cast<int*>(addrs));
	SendPacket(pThis, 0x131F, BATTLEMODE_ADDRS, 0x1);

	// Hunting Inc Time
	pThis = (DWORD)pPlayer + 0x1140;
	HuntingMode = EntityBaseStatusGetAbility(pThis, 0xF2);
	if (HuntingMode == 0)
	{
		// Hunting Inc Time
		HuntingIncTime = GetCurSeconds();
		HuntingIncTime += 10;
		pThis = (DWORD)pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0xF3, HuntingIncTime);
		// HuntingMode Enable
		pThis = (DWORD)pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0xF2, 0x1);
	}
	else
	{
		pThis = (DWORD)pPlayer + 0x1140;
		IncHunTime = EntityBaseStatusGetAbility(pThis, 0xF3);
		CurHuntSeconds = GetCurSeconds();
		if (CurHuntSeconds > IncHunTime)
		{
			// Inc Hunt Time
			CurHuntSeconds += 10;
			pThis = (DWORD)pPlayer + 0x1140;
			EntityBaseStatusSetAbility(pThis, 0xF3, CurHuntSeconds);

			// inc Hunt Rate
			CurHunRate = EntityBaseStatusGetAbility(pThis, 0xF5);
			if (CurHunRate < 100000)
			{
				CurHunRate += ADD_HUNTING_RATIO;
				if (CurHunRate > 100000) CurHunRate = 100000;
				pThis = (DWORD)pPlayer + 0x1140;
				EntityBaseStatusSetAbility(pThis, 0xF5, CurHunRate);

				// Create Hunt Packet
				addrs = (DWORD)HUNTINGRATE_ADDRS;
				*(reinterpret_cast<int*>(addrs)) = CurHunRate;

				// Send Hunt Packet
				addrs = (DWORD)pPlayer + 0x1098;
				pThis =  *(reinterpret_cast<int*>(addrs));
				SendPacket(pThis, 0x1A4C, HUNTINGRATE_ADDRS, 0x4);
			}
		}
	}
}

void StopBattleStatus(int pPlayer)
{
	int addrs = 0;
	int pThis = 0;
	int CurSeconds = 0;
	int StopSeconds = 0;
	int BattleMode = 0;
	int Type = 0;
	int HuntingMode;
	int HuntingDecTime;
	int CurHuntSeconds;
	int DecHunTime;
	int CurHunRate;

	unsigned char BATTLEMODE_BUFFER[1] = {0};
	int BATTLEMODE_ADDRS = (DWORD)BATTLEMODE_BUFFER;

	unsigned char HUNTINGRATE[4] = {0};
	int HUNTINGRATE_ADDRS = (DWORD)HUNTINGRATE;

	addrs = (DWORD)pPlayer + 0x2E;
	Type = *(reinterpret_cast<char*>(addrs));

	if (Type == 3)
	{
		pThis = (DWORD)pPlayer + 0x1140;
		BattleMode = EntityBaseStatusGetAbility(pThis, 0xF1);
		if (BattleMode == 1)
		{
			CurSeconds = GetCurSeconds();
			pThis = (DWORD)pPlayer + 0x1140;
			StopSeconds = EntityBaseStatusGetAbility(pThis, 0xF0);
			if (CurSeconds >= StopSeconds)
			{
				*(reinterpret_cast<char*>(BATTLEMODE_ADDRS)) = 0;

				addrs = (DWORD)pPlayer + 0x1098;
				pThis =  *(reinterpret_cast<int*>(addrs));
				SendPacket(pThis, 0x131F, BATTLEMODE_ADDRS, 0x1);

				pThis = (DWORD)pPlayer + 0x1140;
				EntityBaseStatusSetAbility(pThis, 0xF0, 0x0);
				pThis = (DWORD)pPlayer + 0x1140;
				EntityBaseStatusSetAbility(pThis, 0xF1, 0x0);
			}
		}
		else
		{
			pThis = (DWORD)pPlayer + 0x1140;
			HuntingMode = EntityBaseStatusGetAbility(pThis, 0xF2);
			if (HuntingMode == 1)
			{
				// HuntingMode Disable
				pThis = (DWORD)pPlayer + 0x1140;
				EntityBaseStatusSetAbility(pThis, 0xF2, 0x0);
				// Setting Dec Hunt Rate
				HuntingDecTime = GetCurSeconds();
				HuntingDecTime += 10;
				pThis = (DWORD)pPlayer + 0x1140;
				EntityBaseStatusSetAbility(pThis, 0xF4, HuntingDecTime);
			}
			else
			{
				pThis = (DWORD)pPlayer + 0x1140;
				DecHunTime = EntityBaseStatusGetAbility(pThis, 0xF4);
				CurHuntSeconds = GetCurSeconds();
				if (CurHuntSeconds > DecHunTime)
				{
					// Dec Hunt Time
					CurHuntSeconds += 10;
					pThis = (DWORD)pPlayer + 0x1140;
					EntityBaseStatusSetAbility(pThis, 0xF4, CurHuntSeconds);
					// inc Hunt Rate
					CurHunRate = EntityBaseStatusGetAbility(pThis, 0xF5);
					if ((CurHunRate > 0) && (CurHunRate < 100000))
					{
						CurHunRate -= ADD_HUNTING_RATIO;
						if (CurHunRate < 0) CurHunRate = 0;
						pThis = (DWORD)pPlayer + 0x1140;
						EntityBaseStatusSetAbility(pThis, 0xF5, CurHunRate);

						// Create Hunt Packet
						addrs = (DWORD)HUNTINGRATE_ADDRS;
						*(reinterpret_cast<int*>(addrs)) = CurHunRate;

						// Send Hunt Packet
						addrs = (DWORD)pPlayer + 0x1098;
						pThis =  *(reinterpret_cast<int*>(addrs));
						SendPacket(pThis, 0x1A4C, HUNTINGRATE_ADDRS, 0x4);
					}
				}
			}
		}
	}
}

void PowerArenaReward()
{
	// Init Packet
	memset(POWERARENAREWARD_BUFFER,0,sizeof(char)*45);
	
	__asm mov edi,POWERARENAREWARD_ADDRS

	// +0 ADEL
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov dword ptr es:[edi],eax

	// +4 HELIA
	__asm mov eax,dword ptr ss:[ebp+0xC]
	__asm mov dword ptr es:[edi+0x4],eax

	// PADataPTR
	__asm mov edx,dword ptr ss:[ebp-0x4]

	// +8 PK Point
	__asm mov ecx,dword ptr ds:[edx+0x10]
	__asm mov dword ptr es:[edi+0x8],ecx

	// +C MK Point
	__asm mov eax,dword ptr ds:[edx+0x14]
	__asm mov dword ptr es:[edi+0xC],eax

	// +29 TOP Point (MK + PK)
	__asm add eax,ecx
	__asm mov dword ptr es:[edi+0x29],eax

	// +25 My Ranking
	__asm movzx eax,word ptr ds:[edx+0x20]
	__asm mov dword ptr es:[edi+0x25],eax

	// pPlayer
	__asm mov eax,dword ptr ss:[ebp-0x40]
	__asm mov PAR_pPlayer, eax

	// Get PartyPlayer Name
	PANameSRCPTR = PlayerGetName(PAR_pPlayer);
	PANameDSTPTR = POWERARENAREWARD_ADDRS + 0x10;
	StringsCopy(PANameDSTPTR, PANameSRCPTR, 0x15);

	// DynamicPTR
	__asm mov ecx, dword ptr ss:[ebp-0x3C]
	__asm mov PAR_DYNAMICPTR,ecx

	SendPacketEX(PAR_DYNAMICPTR, 0x2802, POWERARENAREWARD_ADDRS, 0x2D);

	__asm jmp POWERARENAREWARD_RET
}
