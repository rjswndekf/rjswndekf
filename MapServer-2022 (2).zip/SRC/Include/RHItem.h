#include <MapServer.h>

// Get DBItem Data
void DBGetItem();
int DBGetItemData(int CharID);

// ASM + C Ver
void GetCharItemProc(int Inventory);
int GetItemOfCharacter(int pDynamic, int Inventory);
void InitItemPacket();

void EquipItemP1(int SendPacketPTR);
//void EquipItemP2();
void EquipItemP3();
void UnEquipItemP1(int SendPacketPTR);
void UnEquipItemP2();
//void UnEquipItemP3();
void UnEquipItemP4();
void ExchangeEquipItem(int SendPacketPTR);

int EquipItem(int ToSlot, int pItem);
int UnEquipItem(int FormSlot, int ToInventory, int ToSlot);
int ReplaceEquipItem(int EquipSlot, int BagInventory, int BagSlot);
int EquipAllow(int pInventory, int Slot, int pItem);
void CalEquipProperty(int Slot, int pItem, int Active);
void CalEquipOption(int pInventory, int pItem, int Slot, int Active, int MaxAttribute);
void PlayerEquipItemCheck();
void RaceEquipItemCheck();

// Arrendal Syatem
void ArrendalGrowthAutomatic(int pPlayer, int pExp);
void GetArrendalGrowthAutomatic(int pPlayer, int pExp);
void ArrendalGrowthManual(int pDynamic, int pSendPacket);
int GetArrendalGrowthManual(int pDynamic, int pSendData);
void ArrendalEvolution(int pDynamic, int pSendPacket);
int GetArrendalEvolution(int pDynamic, int pSendData);
void ItemWeaponEvolution(unsigned int ItemID, unsigned int MeteriaID, int &MeteriaCheck, int &SuccessRate, int &NeedReinforce);
void ArrendalTransmutation(int pDynamic, int pSendPacket);
int GetArrendalTransmutation(int pDynamic, int pSendData);
int GetTransmutationInfo(int ItemIDMaterial);

// Talisman
void TalismanRegister(int ItemSubType, int TargetAddrs);
int GetUnRegType(int IconOrder);
void TalismanList(int pDynamic, int pSendPacket);
int EguipTalisman(int pItem, int Active);
void EquipTalismanType(int pItem);
void UnEquipTalismanType(int pItem);

void EnchantItemLevel(int pSendData);
void EnchantItemLevelDown(int pPlayer, int pSendData);
void EnchantSetVar();
void EnhancementTicket(int pDynamic, int pSendPacket);
int GetEnhancementItem(int pDynamic, int pSendData);
void ReinforceAnvientItem();

// Item Socket
void ItemSocketReinforce(int pDynamic, int pSendPacket);
int GetItemSocket(int pDynamic, int pSendData);
void TransItemSocketReinforce(int pDynamic, int pSendPacket);
int GetTransItemSocket(int pDynamic, int pSendData);
void AccessorySocketReinforce(int pDynamic, int pSendPacket);
int GetAccessorySocket(int pDynamic, int pSendData);

void BankGetInfo(int DynamicPTR, int SendPacketPTR);
void BankGetInfoPacket();
void ExtendBanktabInfo(int DynamicPTR, int SendPacketPTR);
int GetExtendBanktabInfo(int DynamicPTR);
void GetBankExtendDay();
void BankUpdateMaxSlot();
void BankExpansionTicket(int DynamicPTR, int SendPacketPTR);
int UpdateBankExpireTime(int DynamicPTR, int SendPacketData);
void UpdateBankTabTime(int BankPTR, int CouponTime);
void BankSecretInfo(int DynamicPTR, int SendPacketPTR);

// RCM_MAP_USE_DC_ITEM 0x1459
void CheckItemExp();
void CheckExp64(int pPlayer, int pScript);
void UseDCItemPacket();
void UseDCItemPacketSend(int pDynamic, int pSrcData);
// RCM_MAP_USE_DC_ITEM 0x1477
void OpenUseItem(int pDynamic, int pSendPacket);
int GetOpenUseItem(int pDynamic, int pSendData, int PacketType);
int GetExp64(int ItemID);

void GetMallItemSend();
void GetMallItemRecv();
void SetMallItem(int pPlayer, int pItem, int pData);
void EventItemSetOptionValue();

void GetMailList();

void ItemsSort(int DynamicPTR, int SendPacketPTR);
void SortsArrangement(int SRC, int DST, int SortsCount, int MaxType);
int GetItemSort(int pItem);

// ItemType
void CalStateGuarderType();

// NPC Equip Dismantle
void EquipDismantle(int pDynamic, int pSendPacket);
int GetEquipDismantle(int pDynamic, int pSendData);
int GetEquipDisGroupID(int ItemID);
int GetRewardItem(int GroupID, int ReinforceLevel, int pRewardData);

// Transcendence Racipe
void TranscendenceEquipRacipe(int pDynamic, int pSendPacket);
int GetTranscendenceEquip(int pDynamic, int pSendData);
int GetRacipeEquip(int MaterialID);

void TranscendenceAccessoryRacipe(int pDynamic, int pSendPacket);
int GetTranscendenceAccessory(int pDynamic, int pSendData);
int GetRacipeAccess(int UseItem, int MaterialItem);

void TranscendenceWeaponsRacipe(int pDynamic, int pSendPacket);
int GetTranscendenceWeapons(int pDynamic, int pSendData);
int CheckRacipeWeapons(int UseItem, int MaterialItem, int ItemID);

// Igniel's & Sky Item Racipe
void IgnielSkyItemRacipe(int pDynamic, int pSendPacket);
int GetIgnielSkyItem(int pDynamic, int pSendData);
int GetRacipeItem(int UseItem, int Material);

// Smelt Hammer
void ChakraSmelt(int pDynamic, int pSendPacket);
int GetAddChakraSocket(int pDynamic, int pSendData);
void GetItemAddSocketDetails(int UseItem, int ItemID, int &AddSocket, int &ReinforceRate);

// +12 Item Upgrade
void UpgradeItem();
int GetUpgradeItemID(int pPlayer, int pSendData, int pUpgradeItemID);

// Enchant Talisman
void EnchantTalisman(int pDynamic, int pSendPacket);
int GetEnchantTalisman(int pDynamic, int pSendData);
int GetEnchantTalismanScript(int UseItem, int Material1, int Material2, int Material3);

void ItemAttr();
int BinAttributeExt(int BinAttribute, int AttributeClass, int pRes);

// Exhange Rune
void ExhangeRune(int pDynamic, int pSendPacket);
int GetExhangeRune(int pDynamic, int pSendData);
// Enchant Rune
void EnchantRune(int pDynamic, int pSendPacket);
int GetEnchantRune(int pDynamic, int pSendData);
int GetRuneScript(int ItemID);

// Item Recipe
void ItemRecipe(int pDynamic, int pSendPacket);
int GetRecipeItem(int pDynamic, int pSendData);

// Sky Item Special Option
void SkyItemAddSpecialOption(int pDynamic, int pSendPacket);
int GetItemAddSpecialOption(int pDynamic, int pSendData);
void SkyItemSpecialOptionGrantConfirm(int pDynamic, int pSendPacket);
int GetItemSpecialOptionGrantConfirm(int pDynamic, int pSendData);
void SkyItemSpecialOptionReset(int pDynamic, int pSendPacket);
int GetItemSpecialOptionReset(int pDynamic, int pSendData);
void SkyItemSpecialOptionReassignment(int pDynamic, int pSendPacket);
int GetItemSpecialOptionReassignment(int pDynamic, int pSendData);
int GetSpecialOptionTypeScript(int ItemType);
int GetSpecialOptionValueScript(int ItemType, int AttrbuteType);
int GetSpecialOptionCostScript(int UseCount);

// Wish Ticket GetItem
void WishGetItem(int pDynamic, int pSendPacket);
int WishGetItemEtc(int pDynamic, int pSendData);
int GetWishGetItemScript(int ItemID);

// Wish Ticket Item Exchange
void WishItemExchange(int pDynamic, int pSendPacket);
int GetWishItemExchange(int pDynamic, int pSendData, int PacketType);
int GetWishItemExchangeScript(int ItemID);

// Wish Transition
void WishTransition(int pDynamic, int pSendPacket);
int GetWishTransition(int pDynamic, int pSendData);
int GetWishTransitionScript(int ItemID);
int CheckWishTransitionOption(int GroupID, int AttrbuteOption);

// Wish Option Change
void WishEquipOptionChange(int pDynamic, int pSendPacket);
int GetWishEquipOptionChange(int pDynamic, int pSendData, int PacketType);
int GetOptionChangeScript(int ItemID);

// Wish Level Enchant
void WishLevelEnchant(int pDynamic, int pSendPacket);
int GetWishLevelEnchant(int pDynamic, int pSendData);
int GetWishLevelEnchantScript(int ItemID);

// Wish Reinforce
void WishReinforce(int pDynamic, int pSendPacket);
int GetWishReinforce(int pDynamic, int pSendData);
int GetWishReinforceScript(int ItemID, int BootsLevel);

// RandomBox Reward
void RandomBoxReward(int pDynamic, int pSendPacket);
int GetRandomBoxReward(int pDynamic, int pSendData);
int GetRandomBoxRewardScript(int RewardGrade, int Chance);

// ItemCombination EX 2022
void ItemCombinationEX(int pDynamic, int pSendPacket);
int GetItemCombinationEX(int pDynamic, int pSendData);
void CombinationEXSend43();
void CombinationEXSend6();
