#include <MapServer.h>

/****************************************************************************************
 *** BioticBase Functions
 ****************************************************************************************/
int BioticBaseGetAbility(int TargetPTR, int AbilityType);
int BioticBaseSetAbility(int TargetPTR, int AbilityType, int Value);
void BioticBaseAddAbility(int TargetPTR, int AbilityType, int Value);
void BioticBroadCastAroundPlayers(int PlayerPTR, int PacketType, int pData, int PacketSize, int IncludeMe, int CellRange);
int BioticBaseGetRandom(int PlayerPTR, int nMax);
int FindBioticID(unsigned int EntityID);
int GetCharAllLevel(int PlayerPTR);
int GetRaceBaseAttrVaule(int CType, int Attribute);
int GetAllStatPoints(int Level);

/****************************************************************************************
 *** EntityBaseStatus Functions
 ****************************************************************************************/
int EntityBaseStatusGetAbility(int TargetPTR, int Ability);
void EntityBaseStatusIncAbility(int TargetPTR, int AbilityType, int Value);
void EntityBaseStatusSetAbility(int TargetPTR, int AbilityType, int Value);
int CalAttackForce(int Value, int Level);
int GetCollectGrade(int ARG1, int ARG2);
int EntityManagerGetPlayer(unsigned int EntityID);
void EntityManagerBroadcastAllPlayer(int PacketType, int PacketData, int PacketSize);
int GetNpc(int NpcEntityID);
int GetNpcPTR(int pNpcType);
int CheckNpc(int NpcType);

/****************************************************************************************
 *** EpochItem Functions
 ****************************************************************************************/
int GetAttribute(int pItem, int AttributeType);
int SetAttribute(int pItem, int AttributeType, int Value);
int ItemOptionGetType(int pItem, int OptionType);
int ItemOptionSetType(int pItem, int OptionType, int Value);
int ItemOptionGetValue(int pItemScript, int OptionType);
int ItemOptionSetValue(int pItem, int OptionType, int Value);
void SetItemBinOptionValue(int pItem);
void EpochItemBaseGetItemGR(int pItem, int pItemGR);
void tagItemInit(int pItemGR);
void AllocItem(int pResult, unsigned int ItemID);
int CreateItem(int pResult, int Stack);
void GetItemStamp(int pItem, int pStamp);
void TimerItemManager(int pPlayer, int pItem, int pStamp);
int GetItemOptionType(int AttributeType, int Opt);
int GetPlayerCalValue(int pPlayer, int Value);
int GetCTypeCalValue(int pPlayer, int Value);
void CalItemOption(int pInventory, int OptionType, int CalValue, int Active);
void ItemCalQualities(int pInventory, int OptionType, int Value, int Active);
int GetEquipInfo(int ItemID);
int GetReinforceType(int pItem);
void SetItemScriptAttrbute(int pThis, int Option, int Value);
void SetItemScript(int pThis, int ItemID, int pItemScript);

/****************************************************************************************
 *** Charm Functions
 ****************************************************************************************/
int GetCharmAttribute(int pInventory, int CharmSubType, int AttributeType);
void SetCharmExpBonus(int pPlayer, int CharmValue);
void SetCharmAddExpBonus(int pPlayer, int CharmValue);
void SetCharmPartyExpBonus(int pParty);
void SetCharmMKBonus(int pPlayer, int CharmValue);
void SetCharmPartyMKBonus(int pParty);
void SetCharmPartyElement(int pParty);
void SetCastingTime(int pPlayer, int AttributeValue);

/****************************************************************************************
 *** Inventory Functions
 ****************************************************************************************/
int SetItem(int pInventory, int Inventory, int Slot, int pItem);
int GetItem(int pInventory, int Inventory, int Slot);
int GetItemData(int pItemGR);
int GetCurCount(int pInventory, int Inventory);
int GetAllowCount(int pInventory, int Inventory);
int InventorySlotInit(int pBag, int pItem);
int ResetInventory(int pInventory, int Inventory);
void ClearItem(int pInventory, int Inventory, int Slot);
int GetItemBinAttribute(int pItemScript, unsigned int AttributeType);
int GetItemBinScriptInfo(unsigned int ItemID);
int GetItemMallScriptInfo(unsigned int ItemID);
void WeightStateBroadcast(int pInventory);
// OpenUseItem Funs
int GetOpenUseItemScript(int ItemID);
int GetItemTimer(int pPlayer, int pItem);
void ReleaseItemTimer(int pPlayer, int nID);
void RemoveItemTimer(int pPlayer, int nID);
int GetQusetIDStatus(int Status, int RunQuestID);
int GetItemLimitList(int GetItemID, int Count);
int GetItemScriptAttrbute(int pScript, int AttrbuteValue);
void OpenItemAddExp(int pPlayer, int ExpL, int ExpH);
void OpenItemAddIP(int pPlayer, int IpL, int IpH);
void OpenItemAddMoney(int pPlayer, int MoneyL, int MoneyH);

/****************************************************************************************
 *** Packet Functions
 ****************************************************************************************/
void CharStatusPacket(int pPacketType);
void SendPacket(int DynamicPTR, int PacketType, int PacketPTR, int PacketSize);
void SendPacketEX(int DynamicPTR, int PacketType, int PacketPTR, int PacketSize);
void SendCryptPacket(int DynamicPTR, int PacketType, int PacketPTR, int PacketSize);
void SendOptPacket(int DynamicPTR, int PacketType, int PacketPTR, int PacketSize, int OPT);

/****************************************************************************************
 *** Pet Functions
 ****************************************************************************************/
void PetCalOption(int InventoryPTR, int OptionType, int Param, int Active);
void PetSetOption(int InventoryPTR, int OptionType, int Param);
int GetPetParams(int RDPTR, int Pnum);

/****************************************************************************************
 *** Player Functions
 ****************************************************************************************/
void PlayerSendStatus(int pPlayer);
void PlayerBroadcastIncAbility(int pPlayer);
int PlayerDBTaskIncAbility(int pPlayer, int AbilityType, int Value);
void PlayerSendGetExperience(int pPlayer);
void PlayerCheckUpLevel(int pPlayer);
void PlayerSubMoney(int pPlayer, unsigned int PriceL, unsigned int PriceH, int Reason, int SendClient);
unsigned int GetHashData(unsigned int CurCronL, unsigned int CurCronH, unsigned int CharID);
void PlayerBroadcastUpLevel(int pPlayer);
void PlayerSendConquerorLevel(int pPlayer);
float PlayerGetCurExpRate(int pPlayer);
float GetIndunRewardExpRate(int pPlayer, int pRewardExp);
int GetExpScript(int Level);
int PlayerGetName(int pPlayer);
int PlayerGetCurLife(int pPlayer);
int PlayerGetCurMana(int pPlayer);
int PlayerCheckSelfItemWork(int pPlayer, int Prisoner);
int PlayerCheckWorkItem(int pPlayer, unsigned int EpochID);
int PlayerCheckTradeItemWork(int pPlayer, int Prisoner);
int PlayerGetConquerorData(int ConquerorLevel);
void PlayerCalAllAbility(int pPlayer);
void PlayerCalAbility(int pPlayer, int AbilityType);
void CalCharAbility(int pPlayer);
void PlayerSendNotice(int pPlayer, int PacketType, int pData, int PacketSize, int CharNameSize);
void SetTransMode(int CharID);
void SetTransStat(int pPlayer);
void ShowTransMode(int CharID, int pLevel, int pTrans);
void InitTransState(int pPlayer);
void SetCharAllLevel(int pPlayer);

/*** Character Status ***/
void PlayerGetStatusInfo(int PlayerPTR, int pAddrs);

/****************************************************************************************
 *** Guild Functions
 ****************************************************************************************/
int GetGuildInfo(int CharID);

/****************************************************************************************
 *** Party Functions
 ****************************************************************************************/
int GetParty(int EntityID);

/****************************************************************************************
 *** PlayerItemSlot Functions
 ****************************************************************************************/
int GetSocketOption(int pThis, int nType);
int GetSocketAttribute(int pThis, int nType);
int GetSocketInfo(int pSocket,  int nId, int pSlocketInfo);
int CheckSocketOptionType(int pSocket, int OptionType1, int OptionType2);
int ClearSocketSlot(int pSocket, int nID, int SocketSlot);
int SocketSlotAdd(int pSocket, int nID, int SocketSlot, int ItemIDStore, int Timestamp);
int GetEquipItemType(int pInventory, int pEquipType);
int IsEquipShield(int pInventory);
int RemoveItem(int InventoryPTR, int ItemPTR);
void ClearItem(int pInventory, int Inventory, int Slot);
int GetFreeInventorySlot(int InventoryPTR, int pInventory, int pSlot);
int GetFreeSlotCount(int pInventory);
int UseItem(int InventoryPTR, int pItem, int CurStack);
int UseItemMaterial(int pInventory, int pItem, int Stack, int pCurStack);
int AddItem(int InventoryPTR, int pItem, int Inventory, int Slot, int SendDB);
int AddTimerItem(int pPlayer, int pItem, int pRecipeInfo, int Timestamp);
int CreateMallItem(int InventoryPTR, int ItemID, int Count, int pItemGR, int pAddCurStack);
int GetItemCurrentStack(int pInventory, int ItemID);
int FindItem(int pInventory, int ItemID);
void RemoveItemsInInventory(int pInventory, int pItem, int nNumber);
int GetBank(unsigned int UserID);
int IsBankOwner(int PlayerPTR, unsigned int UserID, unsigned int CharID);
int GetBankMaxSlot(int BankPTR, unsigned int UserID);
unsigned int GetBankExpireTime(int BankPTR, unsigned int UserID);
int CheckExpireTime(int BankPTR);
unsigned int GetDBBankExpireTime(unsigned int UserID);
void SetDBBankExpireTime(unsigned int UserID, unsigned int ExpireTime);
int SoltToInventory(int Slot);

/****************************************************************************************
 *** RecipeManager Functions
 ****************************************************************************************/
int GetRecipeData(int pRecipeManager, int RecipeID, int pRecipeData);
int GetRecipeInfo(int pThis, int RecipeID);
int GetRecipeResourceList(int pInventory, int pRecipeInfo, int pList);
void SetCraftItem(int pPlayer, int pItem);
void UpdateRecipe(int pRecipeManager, int RecipeID, int Timestamp);
void UpdateRecipeInfo(int pPlayer);

/****************************************************************************************
 *** Skill Functions
 ****************************************************************************************/
int GetTotalDynamicLevel(int TargetPTR, int Kind);
int GetSkillInfo(int Kind);
int GetParamPTR(int TargetPTR, int Kind);
void AddAffectSkill(int CalAffectPTR, int AffectedSkillPTR);
int ReflectSkill(int CalAffectPTR, int pAffectedSkill);
void tagAffectSkillInit(int tagAffectSkillPTR);
int GetParams(int Paddrs, int Pnum);
void QualitiesCalOption(int CalAffectPTR, int AffectOption, int Param, int ActiveOption);
void QualitiesSetOption(int CalAffectPTR, int OptionType, int Value);
int QualitiesGetOption(int CalAffectPTR, int OptionType);
int SkillDamageCalculation(int DynamicPTR, int SkillDamage, int OptionType);
int GetAffectOptionValue(int CalAffectPTR, int AffectOption);
int CheckAffectSkillStatus(int CalAffectPTR, unsigned int Kind);
int IsAffectSkill(int CalAffectPTR, unsigned int Kind, int pAffectedSkill);
void EndAffectSkill(int CalAffectPTR, unsigned int Kind, unsigned int Reason, unsigned int Param, unsigned int Skiller);
void EnableAffectSkill(int CalAffectPTR, unsigned int Kind);
int GetAffectSkillList(int CalAffectPTR, int pSkills, int MaxCount);
int CheckAffectStatus(int CalAffectPTR, int Kind);
int GetBuffSkillList(int CalAffect, int pSkills, int MaxCount);
int CheckBuffSkillStatus(int CalAffectPTR, int Kind);
int EndBuffSkill(int CalAffectPTR, unsigned int Kind, int Operate);
void ChangeConditionBySkill(int TargetPTR, unsigned int Condition, int MilliSecond, int Kind);
void ClearSkillCondition(int TargetPTR, unsigned int Condition, int Kind);
void EraseBuffSkill(int TargetPTR, int RemoveCount);
int CheckConditionResist(int CalAffectPTR, int Kind);
void AroundPlayers(int PlayerPTR, unsigned int EntityID, int Diff);
void InitTP(int PlayerPTR);
int GetCurTP(int PlayerPTR);
void IncTP(int PlayerPTR, int Value);
void DecTP(int PlayerPTR, int Value);
void SendTPBroadcast(int PlayerPTR);
void ChangeLife(int CalAffectPTR, int Diff, int OPT);
void ChangeMana(int CalAffectPTR, int Diff, int OPT);
void SendLifeManaBroadcast(int PlayerPTR);
int StateToAttackRate(int StateValue, int Params);
int GetCharAffectSkill(int CalAffectPTR, int pASkill, int Count);
void DeleteCharAffectSkill(int CalAffectPTR, int Kind);
void ReduceDamage(int CalAffectPTR, int FullRate, int RemainderRate, int Active);
int GetTargetResistance(int pAttack, int Target, int Resistance, int Kind);
int CheckResistance(int CalAffectPTR, int Kind);
int CalAttachDamage(int Target, int LowDamage, int HighDamage);
int GetTargetCount(int CalAffect, int pSkill, int pCharIDList, int pMaxCount);

/****************************************************************************************
 *** Mis Functions
 ****************************************************************************************/
int RTDynamicCast(int pDynamic, int VfDelta, int SrcType, int TargetType, int isReference);
void CIOObjectRelease(int pTarget);
void CIOItemRelease(int pItem);
void CIOCraftRelease(int pPlayer);
void StringsCopy(int DST, int SRC, int StrSize);
int GetCutTime();
int GetCurSeconds();
int GetStringSize(int pStrings);
int ItemScriptInit(int pItemScript);
void SetScriptStrings(int DST, int SRC, int StrSize);

/****************************************************************************************
 *** Protal Functions
 ****************************************************************************************/
void GetPortalInfo(int pProtalInfo, int pStr, int StrSize);
void SetPortalInfo(int pProtalInfo, int Action, int Option);
void SetPortal(int pProtal, int pProtalInfo, int PortalID);
int GetPortalLock(int pThis, int pProtalInfo);
int SetPortalLock(int pThis, int pProtalInfo);
int GeoBaseIsLocked(int pThis);

/****************************************************************************************
 *** Arrendal Functions
 ****************************************************************************************/
void TrinityWeaponInfo(int PlayerPTR);
float GetArrendalExpRate(int PlayerPTR, unsigned int ItemID);
int GetWeaponBindData(int PlayerPTR);
unsigned int GetWeaponBindItem(int PlayerPTR, unsigned int nID);
unsigned int GetWeaponBindEpochID(int PlayerPTR, unsigned int ItemID);
void InsWeaponBindData(int PlayerPTR, unsigned int ItemID, unsigned int EpochID);
void DelWeaponBindData(int PlayerPTR);
void SaveTrinityWeaponInfo(int PlayerPTR, unsigned int nID, unsigned int ItemID, int FullRate);
void UpgradeTrinityWeaponInfo(int PlayerPTR, unsigned int nID, unsigned int ItemID, int AutoUpgrade);
void ArrendalInitBroadcast(int PlayerPTR, unsigned int ItemID, unsigned int nID);
