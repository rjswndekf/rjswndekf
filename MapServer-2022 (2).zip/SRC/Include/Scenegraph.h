#include <MapServer.h>


void TagAffectSkillP1();
void TagAffectSkillP2();
void TagAffectSkillP3();
void TagAffectSkillSize();
void GetCharLevelInfo();
