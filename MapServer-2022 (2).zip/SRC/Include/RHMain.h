#include <MapServer.h>

/********************* Enc Packet *********************/
void UserDataInit(int pDynamic, int pSendPacket);
/******************** UnEnc Packet ********************/
void Packet280C(int pDynamic, int pSendPacket);
void HuntingBonusInit(int pDynamic, int pSendPacket);

void GMWhoPlayer();
void StartGame();

void EnterWorldProc();
void EnterWorld(int pDynamic);
void RespawnProc();
//void LeaveWorldProc();
//void LeaveWorld(int pDynamic);

// LuckyNumber
void LuckyNumber(int pDynamic, int pSendPacket);
void NumberSelect(int pDynamic, int pSendPacket);
void LuckyNumberLast(int pDynamic, int pSendPacket);
void GetLuckyNumberReward(int pDynamic, int pSendPacket);
int GetLuckyNumberItem(int Grade);
void LuckyNumberSendReward(int pDynamic, int ItemID);
void LuckyNumberInit(int pDynamic);
void SetSelectNumber(int pDynamic, int No, int Number);
void LuckyNumberReset();
void LuckyNumberUserReset(int pDynamic);

// Main Time Event
void MainTimeEventProc();
void MainTimeEvent();
void MainTimeEventPlayerProc();

// PC-Bang Mall
void GetPCBangPoint(int pDynamic);
void GetDBSKPPoint(int pDynamic);
void BuyPCMallItem(int pDynamic, int pSendPacket);
int GetPCMallItem(int pDynamic, int pData);
void UpdateDBSKPPoint(int pDynamic);
int GetPMallPrice(int ItemID);
void IncPCBangPoint(int pPlayerr);

// Assassin System
void LoadAssassinInfo(int pDynamic);
void GetAssassinInfo(int pDynamic);
void AssassinRank(int pDynamic);
