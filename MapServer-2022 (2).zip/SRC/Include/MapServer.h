#include <windows.h>
#include <stdio.h>
#include <string>

void HookMain();

void SrvInit();
void GetSQLConnStrs();
/*** Load Bin ***/
void AttendanceBin();
void ChangeAccessoryBin();
void ChangeCharmBin();
void ChangeItemBin();
void ChangeWeaponBin();
void ItemAddSocketDetailsBin();
void ItemDismantleLevelBin();
void ItemDismantleReinforceBin();
void ItemRandomBoxBin();
void ItemRandomBoxRewardBin();
void ItemRuneBin();
void ItemWeaponEvolutionBin();
void ItemWeaponTransitionBin();
void LuckynumberBin();
void RuneReinforceBin();
void SpecialOptionCostBin();
void SpecialOptionTypeBin();
void SpecialOptionTypeValueBin();
void TranscendenceRacipeBin();
void TransItemBin();
void UltimateLevelStatBin();
void VipBossBin();
void WishGroupRecipeBin();
int GetWishGroupIDScript(int ID);
int CheckGroupID(int pScript, int ItemID);
void WishTicketGetItemBin();
void WishTicketItemExchangeBin();
void WishTicketLevelEnchantBin();
void WishTicketOptionChangeBin();
void WishTicketReinforceBin();
void WishTicketTransitionBin();
void WishTransitionGroupBin();

/*** VIP Room Init ***/
void VIPRoomInit();

/**** Load Rate Sttings ****/
void LoadMapSetting();

/**** Load AssassinRank ****/
void AssassinRankLoad();
