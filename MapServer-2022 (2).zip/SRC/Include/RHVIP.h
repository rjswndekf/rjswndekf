#include <MapServer.h>

// VIP State
void VIPState(int pDynamic, int pSendPacket);
void GetVIPStatus(int pDynamic);
void SetVIPStatus(int pPlayer);

// VIP Room
void VIPRoomEnter(int pDynamic, int pSendPacket);
void VIPRoomLeave(int pDynamic, int pSendPacket);
void VIPRooms(int pDynamic, int pSendPacket);
int GetVIPRooms(int pDynamic, int pData);

// VIP Boos
void VIPBoos(int pDynamic, int pSendPacket);
int GetVIPBoos(int pDynamic, int pData);

// VIP Bank
void VIPBank();
void VIPBankToBag();
void BagToVIPBank();
void VIPBankItemMove();
void VIPBankDeposit();
void VIPBankWithdraw();
int CheckVIPBank(int pPlayer);

// VIP No Item Drop
void VIPNoItemDrop();
int CheckVIPDorp(int pPlayer);

// VIP Reward
void VIPReward(int pPlayer);
