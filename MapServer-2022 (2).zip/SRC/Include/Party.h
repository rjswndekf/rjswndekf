#include <MapServer.h>

void HighLevelShow();
void CreateParty();
void PartyRuneInfo(int pDynamic, int pSendPacket);
void ChangePartyLeader();

/**** Rune System ****/
void CreatePartyRuneProc();
void AddMemberRuneProc();
void ChangeLeaderRuneProc();
void WithdrawPartyRuneProc();
void DestroyPartyRuneProc();
void RuneAttrButeSetting(int pParty);
void RuneAttrButeLoad(int pParty);
void RuneAttrButeUnload(int pParty);
int GetItemRune(int pPlayer);

/**** Party Match ****/
void PartyMatchListReg();
void PartyMatchListRegLevel();
void PartyMatchListUnReg();
void PartyMatchListUnRegLevel();
int GetPartyMatchGate(int pPlayer);
void CreatePartyMatch();
void CleanPartyMatch();
void FindPartyMatch();
void AddPartyMatch();
void GetPartyMatch();
