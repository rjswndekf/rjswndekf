#include <MapServer.h>

void AttackStatus();
void BattleMode(int pAttack);
void StartBattleStatus(int pPlayer);
void StopBattleStatus(int pPlayer);
void PowerArenaReward();

void HuntingBonus(int pDynamic, int pSendPacket);
int GetHuntingBonus(int pDynamic, int pSendData);
void ResetHuntingBonus(int pDynamic);

// Assassin Info
void AssassinBattlePK();
void AssassinInfoPK(int Attacker, int Attackee);
int GetKillPoint(int AttackerLevel, int AttackeeLevel);
void AssassinBattleMK();
void AssassinInfoMK(int pPlayer);
void AssassinMKLimit();
void UpdateAssassinInfo(int pPlayer);
