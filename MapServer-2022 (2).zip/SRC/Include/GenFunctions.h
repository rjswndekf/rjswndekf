#include <MapServer.h>

// GenFuns
// 2021 Load GuildWar Npc (Room.bin) Patch for Taiwan Version
void GuildWarNPC();
void AshkeenaMonGroup();
int SetLmonGroup(int pIndunMonster);
void IndunMonsterExp();
int CheckIndunMonsterType(int MonsterType);
// Cal Monster Stat
void MonStatProc();
void CalMonStat(int pBinData);

// ItemBin Read
void ItemBinRead();
void ItemRandomBoxRead(int pScriptThis, int pBinData);
void SetRandomBoxScript(int pScriptThis, int pItemData);
void ItemRuneRead(int pScriptThis, int pBinData);
void SetRuneScript(int pScriptThis, int pItemData);
