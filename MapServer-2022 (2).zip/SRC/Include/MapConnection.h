#include <MapServer.h>

void GetStatus();
void IncabilityBroadcast();
void IncabilityDBTask();
void IncabilityDBTaskMore();
void ChangeJob();
void UseTransJob(int SendPacketPTR);

void UseInitSkill(int SendPacketPTR);
void MapInitSkill();
void UseInitStatus();
void MallUseInitStatus();
void InitStatus();
void QuestInitStatus();
void CharBaseStatus();

void LoadPortal();
void Portal();
void MapTeleport(int SendPacketPTR);
unsigned int GetTeleportPrice(int level);

void DailyLoginRewards(int DynamicPTR, int SendPacketPTR);

// Quest Check
void QuestStateCheckProc();
int QuestCheck(int pPlayer, int QuestID);
int Quest2219StateCheck(int pPlayer);

void ArrendalQuestItemCheck();
