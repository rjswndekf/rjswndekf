#include <MapServer.h>

void InitSkill();
void MapGetEXPP1();
void MapGetEXPP2();
void CharacterDeath();
void TitleChange();
void SocketCharStatus();
// Assassin Mode Change
void ModeChangeProc();
void AssassinModeChange(int pPlayer, int Mode);

// **** New Class Patch ************************************
void CharClassProc();
void CharClassSkillItem();
void CharClassSkillWithJobStore();
void IsChangeJobProc();
int CheckJobID(int NewCtype);
void ConquerorProc();
void GetEXPLimit();
void GetEXPLVHLV();
void NewConquerorEXPRate();
int ConquerorExperience(int HLV, int Mode);
void PlayerSetConquerorLevel(int pPlayer, int HLV, int OptionType);
//void PlayerLoadAbility(int pData);

void LastDropExp();
void ExpRecoveryNPC();

void CharacterTranscendence(int pDynamic, int pSendPacket);
void TranscendenceStat(int pDynamic, int pSendPacket);
int GetTransStatX();
void LoadTransAbility(int pPlayer);
void TranscendenceExhange(int pDynamic, int pSendPacket);
__int64 TransExhangeScript(int ItemID, int AttributeType);
int UltLevelStatScript(int UltimateLevel, int UltimateOption);

void ApplyCalAbility(int pPlayer);
void CalculateAbility();
void CalAbilityExt(int pPlayer);

// Reward Ability
void SmeltAbility();
int CalSmeltAbility(int pPlayer, int BaseRate);
void RankDownA();
void RankDownB();
int CalRankDownAbility(int pPlayer);
void SlillReinforceAbilityA();
void SlillReinforceAbilityB();
int CalSlillReinforceAbility(int pPlayer);
void CombineAbility();
int CalCombineAbility(int pPlayer);
void CronDropAbility();
int CalCronDropAbility(int pPlayer);

/*** 2020 RCM_MAP_EXPRATE_BROADCAST 0x1A44 ***/
void ExpRateBroadcast01();
void ExpRateBroadcast02();
void ExpRateBroadcast03();
void ExpRateBroadcast04();
void ExpRateBroadcast05();
void ExpRateBroadcast06();
void ExpRateBroadcast07();
void ExpRateBroadcast08();
void ExpRateBroadcast09();
void ExpRateBroadcast10();
void ExpRateBroadcast11();
void ExpRateBroadcast12();
void ExpRateBroadcast13();
void BroadcastExpRate(int DynamicPTR, int pData);
void BroadcastExpRateEX(int DynamicPTR, int pData);

/*** Player All Level Settings ***/
void ItemInitStatLevel();
void NpcInitSkillCheck();
void NpcInitSkillLevel();
void NpcInitStatLevel();
void ResponseInviteGuildMasterLevel();
void ResponseInviteGuildMemberLevel();
void UltimateSkillLearn();
void QuestGrantLevel();
void LindunMinLevel();
void LindunMaxLevel();
void LindunEnterLevel();

/*** Player Load Stat ***/
void PlayerAttrInit();
void PlayerAttriButeInit(int pPlayer);

/*** Cal Stat/Skill Rest Point ***/
void CalStatPointByNpc();
void CalStatRestPointByNpc(int pPlayer, int pResetScript);
void CalAllStatInitPoint();
void CalAllStatAndInitPoint(int pPlayer, int pResetScript, int InitPoint, int pResult);
void CalAllStatPointByItem();
void CalAllStatPointByItemetc(int pPlayer);
void CalSkillPoint();
int GetAllSkillPoint(int pPlayer);

/*** Elemental Indun StageRewardEXP ***/
void ElementalStageRewardEXP();
void StageRewardInfo(int pPlayer, int pStageRewardInfo, int RewardType, int pExpData);
__int64 GetRewardExp(int IndunType, int Stage);
void ElementalAddExperience();
void ElementalExpNotice();
