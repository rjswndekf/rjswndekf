#include <MapServer.h>

void CryptPacketProc(int SendPacketPTR);
void NoCryptPacketProc(int pSendPacket);
int  NoCryptPacketType(int pDynamic, int pSendPacket);

void UnknownCryptPacketProc();
void UnknownNoCryptPacketProc();
int CaptureUnknownPacket(int PacketPTR, int PacketSize, int Crypt);
int CheckPacket(int PacketPTR, int PacketSize, int Crypt);

/*** Anti-Packet Attack ***/
// Anti-Packet Attack Check
void AntiPacketAttack(int SendPacketPTR);
// Send Packet PTR Check
void PacketPTRCheck();
// Qualities Empty Pointer Check
void QualitiesEmptyCheck();
// DBSK Empty Pointer Check
void DBSKEmptyCheck();
