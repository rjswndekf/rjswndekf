#include <MapServer.h>

// Attack Skills
void GetSkillAttackForce(int pSkill, int pAttackType);
int SkillAttackForce(int PlayerPTR, int pSkill, int pAttackType, int pDamage, int pParams);
void CalSkillDamage(int BC, int SAO, int Damage);
int CalSkillAttackDamage(int pAttack, int BC, int SAO, int pParams, int pDamage);

// Affect Skills
void CalAffect(int CharID, int Kind, int pParams, int Active);
int CalAffectSkill(int pCalAffect, int CharID, int Kind, int pParams, int Active);
void OnAffect_Active(int pASkill, int Active);
int OnAffectSkill(int pCalAffect, int Kind, int pParams, int Active);

// RCM_SKILL_SKILLEVENT 0x1603
// void SkillEvent(int @CalAffect, int pSkillMode, int pASO)
void SkillEventOn();
void SkillEventOff();

// RCM_SKILL_AFFECTSKILLEVENT 0x1604
// void AffectSkillEvent(int CalAffectPTR, int Event, int ASPTR, int Reason, unsigned int Damage);
void AffcetSkillEvent();

// RCM_SKILL_AFFECTSKILLEVENT_EX 0x160D
// void AffectSkillEventEX(int CalAffectPTR, int Event, int ASPTR, int Reason, unsigned int Damage);
void AffcetSkillEventEX();

// 0x4A13 DBTASK_SAVEAFFECTSKILL ExitGame
int SaveAffectSkill(int Active);
// AffectSkillEvent
void OnAffectSkillEventType();
void OnAffectSkillEvent();

void DecLife(int CalAffectPTR, int Params, int Active);

/************* Skill Proc ************/
// Dekan Skill 0x4048 / 0x402F Skill Depends (Dragon Sage)
void AffcetDepends();
// Dekan Skill 0x400D Patch
void SeparationDependProcess();
// Trinity Mer Base Damage Fix
void AttackInfoProc();
void AttackBaseDamage(int DynamicPTR, int AttackInfoPTR);
// Trinity Skill Pentagram of Light Attack Count
void PentagramOfLightAttackCount();
// Trinity Darkness Calling Range Patch
void SkillSetType();
// Trinity Dormant Power Enable Fix
void AffectSkillON(int PlayerPTR);
// Trinity Dormant Power Disable Fix
void AffectSkillOFF(int PlayerPTR);
// Trinity Learn Skill Dormant Power Patch
void AffcetClickProc();
void AffcetClickCheck(int CalAffectPTR, int Kind);
// Start Heroic Power For Aesir
void StartHeroicPower();
// Trinity Generate TP
void TrinityPoints(int PlayerPTR, int Kind);
// Set Attack Skill Add Affect
void SetAttackAffect();
// Check Target Skill Defense
void SkillDefenseCheck();

// Attack Action
void AttackAction();
void AttackAttackeeAction(int pAttack, int SAO, int pDamage);
// CalAffected Skill Damage
void AffectedSkillDamageProc();
void CalAffectedSkillDamage(int DynamicPTR, int BC, int SAO, int DamagePTR, int TargetPTR);
// SkillReflect
void AddSkillCheck();
int SkillReflectCheck(int CalAffectPTR, int pAffectedSkill);
// SkillEvent Buff
void EventBuff(int Kind, int ParamPTR, int Active);
int BuffCalAffect(int CalAffectPTR, int Kind, int ParamPTR, int Active);
void BuffAffectActive();
// Critical Damage Attackee Action
void CriticalDamageAttackeeAction(int Damage, int Kind, int Result);
void CriticalDamage(int pAttack, int pDamage, int Kind, int Result);
void IncCriticalDamage();
unsigned int CalAddCriticalDamage(int pAttack, unsigned int Damage, int CriticalValue, int Kind, int IgnoresCritical);
// Elemental Skill Damage
void ElementalDamage();
int CalElementalDamage(int pAttack, int BC, int ASO, unsigned int Damage);
// Consumes Trinity Point
void ConsumesPoint();
void ConsumesTrinityPoint(int PlayerPTR);
// Attack Range Target
void AttackRange();
void AffectRangeTargetList();
// Ignores Target Defense & ReductionDamage
void IgnoresTargetProc();
int IgnoresTargetReductionDamage(int pAttack, int BC, int SAO);
// Damage Reflect
void AttackeeDamageReflect();
void AttackerDamageReflect();
// Revive Skill
void ReviveCheckTarget();
void ReleaseTargetStateOfDeath();
void CalReviveLifeMana();
void CheckReviveSkillItem();
void UseItemSkillReviveScroll();
// Blocks & Confines
void IsBlocks();
void ConfinesRange();
// Hit Control
void HitChance(int BC, int SAO);
void HitControl(int pAttack, int BC, int SAO);
// Damage Drain Limit
void DamageDrain();
void DamageDrainLimit(int pAttack);
// Learn Skill
void LearnSkillGen();
void DBTaskLearnSkillGen();
void DBTaskLearnSkillADD1();
void DBTaskLearnSkillADD2();
void DBTaskLearnSkillDEL1();
void DBTaskLearnSkillDEL2();
// Pet Skill CoolTime Dec Rate
void SkillCoolTimeProc();
int SkillCoolTime(int pPlayer, int CoolTime);

/*************** Human ***************/
// Damage
// Skill 135 0x87 Assault Crash
void AssaultCrashAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void AssaultCrash(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Affect
// Skill 131 0x83 Bless Shield
void BlessShield(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 132 0x84 Invoke
void Invoke(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 179 0xB3 Empower
void Empower(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 181 0xB5 Sword Mastery
void SwordMastery(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 182 0xB6 Aimed Blow
void AimedBlow(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 186 0xBA Order Swing
void OrderSwing(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 187 0xBB Crazy Swing
void CrazySwing(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 191 0xBF Critical Aura
void CriticalAura(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 215 0xD7 Stone Skin
void StoneSkin(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 164 0xA4 Blunt Mastery
void BluntMasteryA(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 166 0xA6 Shield Mastery
void ShieldMastery(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 172 0xAC Powered Heavy Armor
void PoweredHeavyArmor(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 199 0xC7 Over Crowd
void OverCrowd(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 214 0xD6 Ultimate Bastion
void UltimateBastion(int CalAffectPTR, int ParamsPTR, int Active);

/**************** Elf ****************/
// Damage
//Skill 289 0x121 Divine Beam
void DivineBeamAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void DivineBeam(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
//Skill 258 0x102 Holy Light
void HolyLightAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void HolyLight(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 306 0x132 Marea's Hammer
void MareasHammer(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
// Skill 309 0x135 Final Attempt
void FinalAttempt(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
// Skill 310 0x136 Marea's Anger
void MareasAngerAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void MareasAnger(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 311 0x137 Destruction
void Destruction(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
// Affect
// Skill 338 0x152 Mana Charge
void ManaChargeAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active);
// Skill 260 0x104 Mental Barrier
void MentalBarrier(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 339 0x153 Group All Mighty
void GroupAllMighty(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 322 0x142 Marea's Grace
void MareasGrace(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 292 0x124 Soul Meditation
void SoulMeditation(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 318 0x13E Staff Mastery
void StaffMastery(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 303 0x12F Blunt Mastery
void BluntMasteryB(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 305 0x131 Reflection
void Reflection(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 337 0x151 Heaven's Dawn
void HeavensDawn(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 352 0x160 Last Divine
void LastDivine(int CalAffectPTR, int ParamsPTR, int Active);

/************* Half Elf **************/
// Damage
// Skill 544 0x220 Brandish Kick (Archer)
void BrandishKickAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
// Affect
// Skill 515 0x203 Fatal
void Fatal(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 562 0x232 Crossbow Mastery (Ranger)
void CrossbowMastery(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 567 0x237 Siege Shot
void SiegeShot(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 569 0x239 Kaels Bolt (Ranger)
void KaelsBolt(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 572 0x23C Rank Shot (Ranger)
void RankShotA(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 574 0x23E Premium Shot (Ranger)
void PremiumShotA(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 583 0x247 Death Chaser (Ranger)
//void DeathChaser(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 547 0x223 Bow Mastery (Scout)
void BowMastery(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 550 0x226 Sharp Melee (Scout)
void SharpMelee(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 553 0x229 Kaels Arrow (Scout)
void KaelsArrow(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 556 Ghost Arrow
void GhostArrow(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 557 0x22D Premium Shot (Scout)
void PremiumShotB(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 559 0x22F Rank Shot (Scout)
void RankShotB(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 598 0x256 Cataclysm (Scout)
void Cataclysm(int CalAffectPTR, int ParamsPTR, int Active);

/*************** Dhan ****************/
// Affect
// Skill 1040 0x410 Strength
void Strength(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 1027 0x403 Deadly Blow
void DeadlyBlow(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 1077 0x435 Suicide
void SuicideAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void Suicide(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 1068 0x42C Katar Mastery
void KatarMasteryA(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 1077 0x435 Suicide
// Skill 1085 0x43D Katar Mastery
void KatarMasteryB(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 1099 0x44B Royal Mask
void RoyalMask(int CalAffectPTR, int ParamsPTR, int Active);
//void RoyalMaskAffectAcive(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 1110 0x456 Crown's Laughter
void CrownsLaughter(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 1125 0x465 Isolation Stealth
void IsolationStealth(int CalAffectPTR, int ParamsPTR, int Active);

/*************** Giant ***************/
// Skill 2052 0x804 Battle Chant
void BattleChant(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 2054 0x806 Find Hole
void FindHole(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 2064 0x810 Polearm Mastery
void PolearmMastery(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 2065 0x811 Criminal Mind
void CriminalMind(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 2082 0x822 Dual Sword Mastery
void DualSwordMastery(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 2084 0x824 Rampage Force
void RampageForce(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 2085 0x825 Ferocious
void Ferocious(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 2087 0x827 Monster Mind
void MonsterMind(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 2089 0x829 Brutality
void Brutality(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 2103 0x837 Gigantic Storm
void GiganticStorm(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 2118 0x846 Fury Tempest
void FuryTempest(int CalAffectPTR, int ParamsPTR, int Active);

/************* Dark Elf **************/
// Skill 32979 0x80D3 Ability Drain (Player)
void AbilityDrainP(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 4121 0x1019 Ability Drain (Target)
void AbilityDrainT(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 4127 0x101F Area Toxic Potion
//void AreaToxicPotion(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 4099 0x1003 Dark Message
void DarkMessage(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 4116 0x1014 Staff Mastery
void StaffMasteryA(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 4117 0x1015 Add Intention
void AddIntention(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 4160 0x1040 Mana Incineration
void ManaIncineration(int CalAffectPTR, int ParamsPTR, int Active);
void ManaIncinerationAffectAcive(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 4135 0x1027 Staff Mastery
void StaffMasteryB(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 4136 0x1028 Add Temper
void AddTemper(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 4162 0x1042 Spell Liberation
void SpellLiberation(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 4177 0x1051 Spell Extension
void SpellExtension(int CalAffectPTR, int ParamsPTR, int Active);

/*************** Dekan ***************/
// Damage
// Skill 16456 0x4048 Wide Forefoot Swing (Dragon Sage)
void WideForefootSwing(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Affect
// Skill 16401 0x4011 Zhen Mastery (Dragon Knight)
void ZhenMasteryA(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16402 0x4012 Blue Defense (Dragon Knight)
void BlueDefense(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16403 0x4013 Critical Immunity (Dragon Knight)
void CriticalImmunityA(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16408 0x4018 Forced Lock (Dragon Knight)
void ForcedLock(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16443 0x403B Elderblood Awaken (Dragon Knight)
void ElderbloodAwaken(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16419 0x4023 Zhen Mastery (Dragon Sage)
void ZhenMasteryB(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16420 0x4024 Blue Intelligence (Dragon Sage)
void BlueIntelligence(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16422 0x4026 Critical Immunity (Dragon Sage)
void CriticalImmunityB(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16427 0x402B Rapid Lock (Dragon Sage)
void RapidLock(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16435 0x4033 Impenetrable (Dragon Sage)
void Impenetrable(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16470 0x4056 Evolve Separation (Dragon Sage)
void EvolveSeparation(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16458 0x404A Reverse Scale (Dragon Sage)
void ReverseScale(int CalAffectPTR, int ParamsPTR, int Active);

/************** Trinity **************/
// Damage
// Skill 8193 0x2001 Pentagram of Light
void PentagramOfLightAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void PentagramOfLight(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 8194 0x2002 Darkness Calling
void DarknessCallingAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void DarknessCalling(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 8204 0x200C Dark Side Trace
void DarkSideTraceAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void DarkSideTrace(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 8212 0x2014 Dark Side Zone
void DarkSideZoneAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void DarkSideZone(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 8210 0x2012 Mana Bombing
void ManaBombingAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void ManaBombing(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 8217 0x2019 Lightning Swift
void LightningSwiftAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void LightningSwift(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 8238 0x202E Absolute Flash
void AbsoluteFlashAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void AbsoluteFlash(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 8220 0x201C Wound of Restriction
void WoundOfRestrictionAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void WoundOfRestriction(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 8224 0x2020 Penetrating Darkness
void PenetratingDarknessAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void PenetratingDarkness(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 8227 0x2023 Windy Chain
void WindyChainAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void WindyChain(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 8230 0x2026 Thunderstroke
void ThunderstrokeAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void Thunderstroke(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 8233 0x2029 Airburst
void AirburstAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void Airburst(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 8252 0x203C Distortion Claw - Chaos
void DistortionClawChaosAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void DistortionClawChaos(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 8253 0x203D Dimensional Scar
void DimensionalScarAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void DimensionalScar(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Affect
// Skill 8195 0x2003 Tune of Life
void TuneOfLife(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8196 0x2004 Vine of Light
void VineOfLightAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active);
// Skill 8197 0x2005 Dormant Power
void DormantPower(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8198 0x2006 Arrendal Mastery TR
void ArrendalMasteryA(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8199 0x2007 Prism Sphere
void PrismSphere(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8200 0x2008 Trinity Force TR
void TrinityForceA(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8201 0x2009 Dark Side Force
//void DarkSideForce(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8202 0x200A Nature Unity
void NatureUnityCCalAffect(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8203 0x200B Light Trace
void LightTraceAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active);
// Skill 8207 0x200F Pulsating Light
void PulsatingLight(int CalAffectPTR, int ParamsPTR, int Active);
void PulsatingLightAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active);
// Skill 8208 0x2010 Dark Side of Light
void DarkSideOfLightASEvent(int TargetPTR, int ParamsPTR, int pAffectSkill, int pDamage);
// Skill 8211 0x2013 Sanctuary
void SanctuaryAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active);
// Skill 8213 0x2015 Life Circulation
void LifeCirculationAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active);
// Skill 8205 0x200D Sequoias Favor
void SequoiasFavor(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8206 0x200E Vine Protection
void VineProtection(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8209 0x2011 Blessed Crown
void BlessedCrown(int CalAffectPTR, int ParamsPTR, int Active);
void BlessedCrownAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active);
// Skill 8214 0x2016 Causal Loop/Dark Side Loop
void CausalLoop(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8216 0x2018 Growth Acceleration
void GrowthAcceleration(int CalAffectPTR, int ParamsPTR, int Active);
void GrowthAccelerationAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active);
// Skill 8218 0x201A Revive Force
void ReviveForce(int CalAffectPTR, int ParamsPTR, int Active);
void ReviveForceAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active);
// Skill 8236 0x202C Heroic Power TR
//void HeroicPowerA(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8239 0x202F Eternal Aria
void EternalAria(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8219 0x201B Arrendal Mastery TN
void ArrendalMasteryB(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8221 0x201D Trinity Force TN
void TrinityForceB(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8222 0x201E Thorns Whip
void ThornsWhipASEvent(int TargetPTR, int ParamsPTR, int pAffectSkill, int pDamage);
void ThornsWhipAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active);
// Skill 8223 0x201F Phantom Spirit
void PhantomSpiritAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active);
// Skill 8225 0x2021 Dark Assimilation
void DarkAssimilation(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8228 0x2024 Spirit Concentration
void SpiritConcentration(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8235 0x202B Dimensional Coat
void DimensionalCoat(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8237 0x202D Spirit Assimilation
void SpiritAssimilationAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active);
// Skill 8251 0x203B Heroic Power TN
//void HeroicPowerB(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8252 0x203C Distortion Claw - Chaos
void DistortionClawChaosCalAffect(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 8253 0x203D Dimensional Scar
void DimensionalScarAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active);
void DimensionalScarASEvent(int TargetPTR, int ParamsPTR, int pAffectSkill, int pDamage);
// Skill 8254 0x203E Silent Noise
void SilentNoise(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 32989 0x80DD Rear Blast
void RearBlastASEvent(int TargetPTR, int ParamsPTR, int pAffectSkill, int pDamage);

/*************** AESIR ***************/
// Skill 16526 0x408E BluntMastery
void BluntMasteryC(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16527 0x408F Mentalty Amror
void MentaltyAmror(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16532 0x4094 DispelMagic
void DispelMagicAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active);
// Skill 16533 0x4095 MentalityTemper
void MentalityTemper(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16534 0x4096 CounterHunteress
void CounterHunteress(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16535 0x4097 ReserveWide
void ReserveWideASEvent(int TargetPTR, int ParamsPTR, int pAffectSkill, int pDamage);
// Skill 16536 0x4098 MagicStay
void MagicStayAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
// Skill 16537 0x4099 GroupFatal
void GroupFatal(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16538 0x409A MarshMaze
void MarshMazeAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void MarshMazeCalDamage(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 16539 0x409B RegiShield
void RegiShieldCalAffect(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16540 0x409C MagicianAura
void MagicianAura(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16541 0x409D CaelsAura
void CaelsAura(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16542 0x409E RisingAura
void RisingAura(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16562 0x40B2 MagicBobySquare
void MagicBobySquare(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16563 0x40B3 StealthReviver
void StealthReviver(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16543 0x409F AxeMastery
void AxeMastery(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16545 0x40A1 Whispel
void WhispelAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void WhispelCalDamage(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
void WhispelAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active);
// Skill 16547 0x40A3 DoubleAxeMastery
void DoubleAxeMastery(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16551 0x40A7 WhisperMind
void WhisperMind(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16552 0x40A8 RohasShiled
void RohasShiledCalAffect(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16553 0x40A9 Excalibur
void Excalibur(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16556 0x40AC LastWhisper
void LastWhisperAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR);
void LastWhisperCalDamage(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR);
// Skill 16559 0x40AF MurderRemissionC
void MurderRemissionC(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16557 0x40AD AxeClock
void AxeClock(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16558 0x40AE WhisperLimit
void WhisperLimit(int CalAffectPTR, int ParamsPTR, int Active);
// Skill 16576 0x40C0 AxeRange
void AxeRange(int CalAffectPTR, int ParamsPTR, int Active);

/************** Common Skill **************/
void HeroicPower(int CalAffectPTR, int ParamsPTR, int Active);
void Aegis(int CalAffectPTR, int ParamsPTR, int Active);

/************ Guild Slill ***********/
// RCM_SKILL_CHANGEATTITUDE 0x1828
void SkillChangeAttitude(int pDynamic, int pSendPacket);
// Skill -28639 0x9021 Change Attitude
void ChangeAttitudeAffectAcive(int pCalAffect, int pParams, int pASkill, int Active);

/************ Scroll Skill ***********/
// Skill Drop Cron Rate
void DropCronRate(int pCalAffect, int pParams, int Active);
// Skill Melee Attack Force Rate
void MeleeAttackForceRate(int pCalAffect, int pParams, int Active);
// Skill Missile Attack Force Rate
void MissileAttackForceRate(int pCalAffect, int pParams, int Active);
// Skill Magic Attack Force Rate
void MagicAttackForceRate(int pCalAffect, int pParams, int Active);
// Skill Add Physical Defense Rate
void AddPhysicalDefenseRate(int pCalAffect, int pParams, int Active);
// Skill Add Magic Defense Rate
void AddMagicDefenseRate(int pCalAffect, int pParams, int Active);
// Skill Add Max Life Rate
void AddMaxLifeRate(int pCalAffect, int pParams, int Active);
// Skill Add Max Life Value
void AddMaxLifeValue(int pCalAffect, int pParams, int Active);
// Skill Add Move Speed Rate
void AddMoveSpeedRate(int pCalAffect, int pParams, int Active);
// Skill Add Critical Damage Rate
void AddCriticalDamageRate(int pCalAffect, int pParams, int Active);
// Skill Add All Stats Rate
void AddAllStatsRate(int pCalAffect, int pParams, int Active);
// Skill 41185 0xA0E1 Transcendence Scroll
void TranscendenceScroll(int pCalAffect, int pParams, int Active);
// Skill 41186 0xA0E2 Conqueror Scroll
void ConquerorScroll(int pCalAffect, int pParams, int Active);
