#include <MapServer.h>

void PetDataInit();
void PetDataSet();
void PetAffectProc(int Active);
int GetPetAffect(int RDPTR, int Active);
