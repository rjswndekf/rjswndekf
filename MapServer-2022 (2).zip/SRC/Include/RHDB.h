#include <MapServer.h>
#include <sqlext.h>

void ODBCConnectDB(SQLHENV &henv, SQLHDBC &hdbc, SQLHSTMT &hstmt);
void ODBCDisconnectDB(SQLHENV &henv, SQLHDBC &hdbc, SQLHSTMT &hstmt);
