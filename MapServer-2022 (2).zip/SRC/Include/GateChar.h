#include <MapServer.h>

void GetCharList();
//void SendGateCharPacket();
void GetCharacter();
void CreateCharacterProc();
