#include <MapServer.h>

void IndunBuyItem();
int CheckIPTradeItemCountPrice(int PlayerPTR, int pPrice, int ItemCount);
void PowerBadgeMall();

void SetTradeItemProc();
int SetTradeItemList(int ItemScriptType);
