#include <Trade.h>
#include <MapFunctions.h>

using namespace std;

int INDUN_PLAYERPTR;
int INDUN_PRICE;
int INDUN_ITEMVOUNT;
int RET_IP_ENOUGH = 0x0047995D;
int RET_IP_NOT_ENOUGH = 0x0047990F;

int POWERBADGEMALL_RET = 0x0048BD1B;

int TRADEITEMTYPE;

// **** RCM_MAP_INDUN_BUY_ITEM 0x251C *****************************************
void IndunBuyItem()
{
	// PlaterPTR
	__asm mov eax,dword ptr ss:[ebp-0x18]
	__asm mov INDUN_PLAYERPTR, eax
	// Price
	__asm lea ecx, dword ptr ss:[ebp-0x4]
	__asm mov INDUN_PRICE, ecx
	// ItemCount
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm movzx edx,byte ptr ds:[ecx+0x11]
	__asm mov INDUN_ITEMVOUNT, edx
	
	CheckIPTradeItemCountPrice(INDUN_PLAYERPTR, INDUN_PRICE, INDUN_ITEMVOUNT);

	__asm cmp eax,0x1
	__asm je IP_ENOUGH
	__asm jmp RET_IP_NOT_ENOUGH
IP_ENOUGH:
	__asm jmp RET_IP_ENOUGH

}

int CheckIPTradeItemCountPrice(int PlayerPTR, int pPrice, int ItemCount)
{
	int Result = 0;
	int addrs;
	int Price;
	int CalPrice;
	int TotalPrice;
	// IndunPoint = PlaterPTR + 0x1970 [0x1970 IPL / 0x1974 IPH]
	int IndunPoint;

	addrs = (DWORD)pPrice;
	Price = *(reinterpret_cast<int *>(addrs));

	TotalPrice = Price * ItemCount;
	
	CalPrice = TotalPrice;
	addrs = (DWORD)pPrice;
	*(reinterpret_cast<int *>(addrs)) = CalPrice;

	// CheckIndunPoint
	addrs = (DWORD)PlayerPTR + 0x1970;
	IndunPoint = *(reinterpret_cast<__int64 *>(addrs));

	if (IndunPoint >= CalPrice) Result = 1;
	else Result = 0;

	return Result;
}

// Power Badge Mall 0x280A Patch
void PowerBadgeMall()
{
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov byte ptr ds:[eax+0xC],0x1
	__asm add eax,0x4
	__asm jmp POWERBADGEMALL_RET
}

// Trade Item List Fix
void SetTradeItemProc()
{
	// ItemScript Type
	__asm push 0x0
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov ecx,dword ptr ds:[eax+0x4]
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov eax,dword ptr ds:[edx+0x4]
	__asm mov edx,dword ptr ds:[ecx]
	__asm mov ecx,eax
	__asm call dword ptr ds:[edx+0x4]
	__asm mov dword ptr ss:[ebp-0x4],eax

	__asm mov TRADEITEMTYPE,eax

	SetTradeItemList(TRADEITEMTYPE);

	__asm jmp eax;
}

int SetTradeItemList(int ItemScriptType)
{
	int RetAddrs = 0x0074E055;

	switch(ItemScriptType)
	{
		// Job 258 Ranged Weapon Merchant Bag3
		case 219: RetAddrs = 0x0074E1D5; break;
		case 220: RetAddrs = 0x0074E1D5; break;
		// Job 260 Armor Merchant Bag1
		case 228: RetAddrs = 0x0074E22D; break;
		case 229: RetAddrs = 0x0074E22D; break;
		case 230: RetAddrs = 0x0074E22D; break;
		case 231: RetAddrs = 0x0074E22D; break;
		case 232: RetAddrs = 0x0074E22D; break;
		// Job 261 Sundries Merchant Bag2
		case 163: RetAddrs = 0x0074E2EA; break;
		case 164: RetAddrs = 0x0074E2EA; break;
		case 165: RetAddrs = 0x0074E2EA; break;
		// Job 261 Rare Material Dealer Bag2
		case 266: RetAddrs = 0x0074E2BD; break;
		case 278: RetAddrs = 0x0074E2BD; break;
		// Job 263 Pet Merchant Bag2
		case 194: RetAddrs = 0x0074E411; break;
		case 195: RetAddrs = 0x0074E411; break;
		case 196: RetAddrs = 0x0074E411; break;
		// Job 270 Chimera Weapon Merchant Bag1
		case 209: RetAddrs = 0x0074E4A7; break;
		// Job 271 Artisan Supplies Shop Owner
		case 224: RetAddrs = 0x0074E508; break;
	}

	return RetAddrs;
}