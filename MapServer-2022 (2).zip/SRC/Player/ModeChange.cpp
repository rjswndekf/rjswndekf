#include <Player.h>
#include <MapFunctions.h>
#include <ctime>

using namespace std;


unsigned char ASSASSIN_INFO_PL[20] = {0};
unsigned char ASSASSIN_LIMIT_TYPE_PL[4] = {0};

int MODE_CHANGE_RET = 0x004376D2;
int MODE_CHANGE_PLAYER;
int MODE_CHANGE_MODE;

void ModeChangeProc()
{
	__asm mov ecx,dword ptr ss:[ebp-0x8]
	__asm mov MODE_CHANGE_PLAYER,ecx
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov cl,byte ptr ds:[eax]
	__asm and ecx,0xFF
	__asm mov MODE_CHANGE_MODE,ecx

	AssassinModeChange(MODE_CHANGE_PLAYER, MODE_CHANGE_MODE);

	// Orig Code
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov cl,byte ptr ds:[eax]
	__asm jmp MODE_CHANGE_RET
}

void AssassinModeChange(int pPlayer, int Mode)
{
	int addrs;
	int pThis;
	int AccumulatedKillCount = 0;
	int WeeklyKillCount = 0;
	int AccumulatedKillPoint = 0;
	int WeeklyKillPoint = 0;
	int ChangeTime = 0;
	int AssType = 0;
	int AssPK = 0;
	int AssMK = 0;

	if (Mode == 1)
	{
		time_t now = time(0);
		ChangeTime = (int)now;
	
		addrs = (DWORD)pPlayer + 0x2090;
		*(reinterpret_cast<int*>(addrs)) = ChangeTime;
	}
	else
	{
		addrs = (DWORD)pPlayer + 0x2090;
		ChangeTime = *(reinterpret_cast<int*>(addrs));		
	}

	// Load Assassin Info
	addrs = (DWORD)pPlayer + 0x2080;
	AccumulatedKillCount = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x2084;
	AccumulatedKillPoint = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x2088;
	WeeklyKillCount = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x208C;
	WeeklyKillPoint = *(reinterpret_cast<int*>(addrs));

	// Client Packet
	addrs = (int)ASSASSIN_INFO_PL;
	*(reinterpret_cast<int*>(addrs)) = ChangeTime;
	addrs = (int)ASSASSIN_INFO_PL + 0x4;
	*(reinterpret_cast<int*>(addrs)) = AccumulatedKillCount;
	addrs = (int)ASSASSIN_INFO_PL + 0x8;
	*(reinterpret_cast<int*>(addrs)) = AccumulatedKillPoint;
	addrs = (int)ASSASSIN_INFO_PL + 0xC;
	*(reinterpret_cast<int*>(addrs)) = WeeklyKillCount;
	addrs = (int)ASSASSIN_INFO_PL + 0x10;
	*(reinterpret_cast<int*>(addrs)) = WeeklyKillPoint;

	addrs = pPlayer + 0x1098;
	pThis = *(reinterpret_cast<int*>(addrs));
	SendPacketEX(pThis, 0x1311, (int)ASSASSIN_INFO_PL, 0x14);

	if (Mode == 1)
	{
		// Assassin Limit Type
		addrs = (DWORD)pPlayer + 0x2094;
		*(reinterpret_cast<int*>(addrs)) = 0x1;
		addrs = (DWORD)pPlayer + 0x2098;
		*(reinterpret_cast<int*>(addrs)) = 0xA;
		addrs = (DWORD)pPlayer + 0x209C;
		*(reinterpret_cast<int*>(addrs)) = 0x1F4;
	}
	else
	{
		// Assassin Limit Type
		addrs = (DWORD)pPlayer + 0x2094;
		*(reinterpret_cast<int*>(addrs)) = 0x0;
		addrs = (DWORD)pPlayer + 0x2098;
		*(reinterpret_cast<int*>(addrs)) = 0x0;
		addrs = (DWORD)pPlayer + 0x209C;
		*(reinterpret_cast<int*>(addrs)) = 0x0;
	}

	// Client Packet
	addrs = (DWORD)pPlayer + 0x2094;
	AssType = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x2098;
	AssPK = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pPlayer + 0x209C;
	AssMK = *(reinterpret_cast<int*>(addrs));

	addrs = (int)ASSASSIN_LIMIT_TYPE_PL;
	*(reinterpret_cast<char*>(addrs)) = (char)AssType;
	addrs = (int)ASSASSIN_LIMIT_TYPE_PL + 1;
	*(reinterpret_cast<char*>(addrs)) = (char)AssPK;
	addrs = (int)ASSASSIN_LIMIT_TYPE_PL + 2;
	*(reinterpret_cast<short*>(addrs)) = (short)AssMK;

	addrs = pPlayer + 0x1098;
	pThis = *(reinterpret_cast<int*>(addrs));
	SendPacketEX(pThis, 0x1473, (int)ASSASSIN_LIMIT_TYPE_PL, 0x4);
}