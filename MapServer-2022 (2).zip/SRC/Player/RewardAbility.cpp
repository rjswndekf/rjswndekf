#include <Player.h>
#include <MapFunctions.h>

using namespace std; 

int SMELT_RET = 0x004C5E08;
int SMELT_ORIG_RATE;
int SMELT_PLAYER;

int RANKDOWNA_RET = 0x0056C30F;
int RANKDOWNA_PLAYER;
int RANKDOWNB_RET = 0x00575724;
int RANKDOWNB_PLAYER;

int SKILLREINFA_RET = 0x0050691D;
int SKILLREINFA_PLAYER;
int SKILLREINFB_RET = 0x00506DDF;
int SKILLREINFB_PLAYER;

int COMBINE_RET = 0x004C5E33;
int COMBINE_PLAYER;

int CRONDROP_RET = 0x004C5EBD;
int CRONDROP_PLAYER;

// Smelt Probability Ability
void SmeltAbility()
{
	// Orig code
	__asm mov ecx,dword ptr ds:[eax+0x92C]
	__asm mov SMELT_ORIG_RATE,ecx
	
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm mov SMELT_PLAYER,ecx

	CalSmeltAbility(SMELT_PLAYER, SMELT_ORIG_RATE);
	
	__asm jmp SMELT_RET

}

int CalSmeltAbility(int pPlayer, int BaseRate)
{
	int pThis;
	int Value = 0;
	int CalValue = 0;

	pThis = pPlayer;
	Value = BioticBaseGetAbility(pThis, 0x92);
	if (Value != 0)
	{
		CalValue = Value * 10000;
	}
	CalValue += BaseRate;

	return CalValue;
}

void RankDownA()
{
	__asm mov eax,dword ptr ss:[ebp-0x78]
	__asm mov ecx,dword ptr ds:[eax+0x24]
	__asm mov RANKDOWNA_PLAYER,ecx

	CalRankDownAbility(RANKDOWNA_PLAYER);

	__asm jmp RANKDOWNA_RET

}

void RankDownB()
{
	__asm mov edx,dword ptr ss:[ebp-0x80]
	__asm mov eax,dword ptr ds:[edx+0x24]
	__asm mov RANKDOWNB_PLAYER,eax

	CalRankDownAbility(RANKDOWNB_PLAYER);

	__asm jmp RANKDOWNB_RET

}

int CalRankDownAbility(int pPlayer)
{
	int pThis;
	int Value = 0;
	int ValueAdd = 0;
	int CalValue = 0;
	
	pThis = pPlayer;
	Value = BioticBaseGetAbility(pPlayer, 0x92);
	if (Value != 0)
	{
		CalValue = Value * 10000;
	}

	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xC5);

	CalValue += ValueAdd;

	return CalValue;
}


// Slill Reinforce Probability Ability
void SlillReinforceAbilityA()
{
	__asm mov ecx,dword ptr ss:[ebp-0xE8]
	__asm mov SKILLREINFA_PLAYER,ecx
	
	CalSlillReinforceAbility(SKILLREINFA_PLAYER);

	__asm jmp SKILLREINFA_RET
}
void SlillReinforceAbilityB()
{
	__asm mov ecx,dword ptr ss:[ebp-0x108]
	__asm mov SKILLREINFB_PLAYER,ecx

	CalSlillReinforceAbility(SKILLREINFB_PLAYER);

	__asm jmp SKILLREINFB_RET
}

int CalSlillReinforceAbility(int pPlayer)
{
	int pThis;
	int Value = 0;
	int ValueAdd = 0;
	int CalValue = 0;
	
	pThis = pPlayer;
	Value = BioticBaseGetAbility(pPlayer, 0x93);
	if (Value != 0)
	{
		CalValue = Value * 10000;
	}

	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xC3);

	CalValue += ValueAdd;

	return CalValue;
}

// Combine Probability Ability
void CombineAbility()
{
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm mov COMBINE_PLAYER,ecx

	CalCombineAbility(COMBINE_PLAYER);

	__asm jmp COMBINE_RET
}

int CalCombineAbility(int pPlayer)
{
	int pThis;
	int Value = 0;
	int ValueAdd = 0;
	int CalValue = 0;
	
	pThis = pPlayer;
	Value = BioticBaseGetAbility(pPlayer, 0x94);
	if (Value != 0)
	{
		CalValue = Value * 10000;
	}

	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xC2);

	CalValue += ValueAdd;

	return CalValue;
}


// Cron Drop Ability
void CronDropAbility()
{
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm mov CRONDROP_PLAYER,ecx

	CalCronDropAbility(CRONDROP_PLAYER);

	__asm jmp CRONDROP_RET
}

int CalCronDropAbility(int pPlayer)
{
	int pThis;
	int Value = 0;
	int ValueAdd = 0;

	pThis = pPlayer;
	Value = BioticBaseGetAbility(pPlayer, 0x95);

	pThis = pPlayer + 0x1140;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x95);
	Value += ValueAdd;

	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x95);
	Value += ValueAdd;

	return Value;
}
