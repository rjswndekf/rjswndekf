#include <Player.h>
#include <MapFunctions.h>

using namespace std; 

int CONQUEROR_READ_RET = 0x006DC53C;
int GETEXPLIMIT_RET = 0x00535C53;
int GETEXPLVHLV_RET = 0x00535CB3;
int CONQUEROREXPRATE_RET = 0x004F1AED;
//int SETCONQUERORLEVEL = (DWORD)PlayerSetConquerorLevel;

unsigned char SAVECONQUERORLEVEL[30] = {0};
int SAVECONQUERORLEVEL_ADDRS = (DWORD)SAVECONQUERORLEVEL;

unsigned char CONQUERORNOTICE[29] = {0};
int CONQUERORNOTICE_ADDRS = (DWORD)CONQUERORNOTICE;

unsigned char HLVDBSK_LEVELUP[18] = {0};
int HLVDBSK_LEVELUP_ADDRS = (DWORD)HLVDBSK_LEVELUP;

/******* ASM Funs *******/
extern int CONQUEROR_READ;
extern int SENDCONQUERORLEVEL;
extern int SENDUPLEVEL;
extern int SENDSTATUS;
extern int SENDGETEXP;
extern int GETABILITY;
extern int SETABILITY;
extern int SENDPACKET_FUN;
extern int SENDPACKETEX_FUN;
extern int GETENTITYSTATUS;

/*********** Conqueror Level Limit Patch to LV 115 + 50 (HLV 50) ***********/
// Conquerorlevel bin Read Fix
void ConquerorProc()
{
	__asm mov dword ptr ss:[ebp-0x30],ecx
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm cmp eax, 0xA
	__asm jle HLVLOW
	__asm mov dword ptr ss:[ebp+0x8],0xA
	
HLVLOW:
	__asm lea eax,dword ptr ss:[ebp+0x8]
	__asm jmp CONQUEROR_READ_RET
}

/*** Level 115+ GetEXP Limit Patch ***/
void GetEXPLimit()
{
	__asm push 0x15
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm call GETABILITY
	__asm cmp eax,0x74
	__asm jb RET_TARGET
	__asm mov eax,0x73

RET_TARGET:
	__asm jmp GETEXPLIMIT_RET

}
void GetEXPLVHLV()
{
	__asm push 0x15
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm call GETABILITY
	__asm cmp eax,0x74
	__asm jb RET_TARGET
	__asm mov eax,0x73

RET_TARGET:
	__asm jmp GETEXPLVHLV_RET
	
}

/*** New Conqueror EXP Rate % Calculation ***/
void NewConquerorEXPRate()
{
	// Level + ConquerorLevel
	__asm cmp eax, 0x74
	__asm jb ADDHLV
	__asm mov eax,0x73
	__asm mov dword ptr ss:[ebp-0x24],eax

ADDHLV:
	// Adding HLV
	__asm push 0x65
	__asm mov ecx,dword ptr ss:[ebp-0x3C]
	__asm call GETABILITY
	__asm add dword ptr ss:[ebp-0x24],eax

	// Original Code
	__asm mov dword ptr ss:[ebp-0x30],0x0

	__asm jmp CONQUEROREXPRATE_RET
}

/**************************************
 Fun 0x00516300
 HLV Upgrade fun_0x00515AF0(HLV, 0x2B)
 HLV Downgrade fun_0x00515AF0(HLV, 0x2D)
 HLV LevelZero fun_0x00515AF0(HLV, 0x2F)
 **************************************/
int ConquerorExperience(int HLV, int Mode)
{
	int PlayerPTR;
	float CurEXP;
	float MixRate = 100.0;
	float MinRate = 0.0;
	int CurLV;
	int SetLV;
	int SetHLV = 0;

	__asm mov PlayerPTR,ecx

	if (HLV == 50)
	{
		// Reset Level
		CurLV = BioticBaseGetAbility(PlayerPTR, 0x15);
		if (CurLV > 115) CurLV = 115;
		SetLV = CurLV + HLV;
		BioticBaseSetAbility(PlayerPTR, 0x15, SetLV);
		return 0;
	}

	CurLV = BioticBaseGetAbility(PlayerPTR, 0x15);
	if (CurLV > 115) CurLV = 115;
	BioticBaseSetAbility(PlayerPTR, 0x15, CurLV);

	CurEXP = PlayerGetCurExpRate(PlayerPTR);

	if (CurEXP > MixRate)
	{
		if (HLV < 50)
		{
			SetHLV = HLV + 1;
			
			// Reset Level
			CurLV = BioticBaseGetAbility(PlayerPTR, 0x15);
			if (CurLV > 115) CurLV = 115;
			SetLV = CurLV + SetHLV;
			BioticBaseSetAbility(PlayerPTR, 0x15, SetLV);

			// Setting Conqueror Level
			Mode = 0x2B;
			PlayerPTR = PlayerPTR;
			PlayerSetConquerorLevel(PlayerPTR, SetHLV, Mode);

			return 1;
		}
	}

	// Reset Level
	CurLV = BioticBaseGetAbility(PlayerPTR, 0x15);
	if (CurLV > 115) CurLV = 115;
	SetLV = CurLV + HLV;
	BioticBaseSetAbility(PlayerPTR, 0x15, SetLV);

	return 0;
}

void PlayerSetConquerorLevel(int pPlayer, int HLV, int OptionType)
{
	int addrs;
	int pThis;
	int i = 0;
	int LV = 0;
	int ULV = 0;
	int AllLV = 0;
	int CLCLV = 0;
	int pExpScript;
	int CharID;

	int Value = 0;
	int StatPoint = 0;
	int SkillPoint = 0;
	int AllStats = 0;
	int EXPBonusRate = 0;
	int MaxLifeRate = 0;
	int AllDefense = 0;

	int STR;
	int DEX;
	int PSY;
	int INT;
	int VIT;
	int AGI;
	__int64 CurExp = 0;

	pThis = pPlayer;
	LV = BioticBaseGetAbility(pThis, 0x15);
	pThis = pPlayer;
	ULV = BioticBaseGetAbility(pThis, 0x78);
	AllLV = LV + HLV + ULV;

	if (HLV > 0)
	{
		// Clean Current Reward		
		for(i = 0; i < 6; i++ )
		{
			pThis = pPlayer + 0x1140;
			Value = EntityBaseStatusGetAbility(pThis, i);
			pThis = pPlayer + 0x1140;
			AllStats = EntityBaseStatusGetAbility(pThis, 0x70);
			Value -= AllStats;
			pThis = pPlayer + 0x1140;
			EntityBaseStatusSetAbility(pThis, i, Value);
		}

		pThis = pPlayer + 0x1140;
		EXPBonusRate = EntityBaseStatusGetAbility(pThis, 0x77);
		addrs = pPlayer + 0x1AA4;
		Value = *(reinterpret_cast<int*>(addrs));
		Value -= EXPBonusRate;
		*(reinterpret_cast<int*>(addrs)) = Value;

		// Set Upgrade Reward
		if (AllLV > 165) CLCLV = 165;
		else CLCLV = AllLV;
		pExpScript = GetExpScript(CLCLV);
		// Stat Point
		addrs = pExpScript + 0x34;
		StatPoint = *(reinterpret_cast<int*>(addrs));
		// All Stats Attribute 99 0x63
		addrs = pExpScript + 0x3C;
		AllStats = *(reinterpret_cast<int*>(addrs));
		// EXP Bonus Rate Attribute 86 0x56
		addrs = pExpScript + 0x44;
		EXPBonusRate = *(reinterpret_cast<int*>(addrs));
		// Max Life Rate Attribute 23 0x17
		addrs = pExpScript + 0x4C;
		MaxLifeRate = *(reinterpret_cast<int*>(addrs));
		// All Defense Attribute 72 0x48
		addrs = pExpScript + 0x54;
		AllDefense = *(reinterpret_cast<int*>(addrs));

		// All Stats
		pThis = pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0x70, AllStats);

		for(i = 0; i < 6; i++ )
		{
			pThis = pPlayer + 0x1140;
			Value = EntityBaseStatusGetAbility(pThis, i);
			pThis = pPlayer + 0x1140;
			AllStats = EntityBaseStatusGetAbility(pThis, 0x70);
			Value += AllStats;
			pThis = pPlayer + 0x1140;
			EntityBaseStatusSetAbility(pThis, i, Value);
		}

		// EXP Bonus Rate (pPlater + 0x1AA4)
		pThis = pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0x77, EXPBonusRate);
		addrs = pPlayer + 0x1AA4;
		Value = *(reinterpret_cast<int*>(addrs));
		Value += EXPBonusRate;
		*(reinterpret_cast<int*>(addrs)) = Value;

		// Max Life Rate
		pThis = pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0x76, MaxLifeRate);

		// All Defense
		pThis = pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0x74, AllDefense);

		// CalAllAbility
		pThis = pPlayer;
		PlayerCalAllAbility(pThis);

		// Send Status
		pThis = pPlayer;
		PlayerSendStatus(pThis);

		// Set Conqueror Level
		pThis = pPlayer;
		BioticBaseSetAbility(pThis, 0x65, HLV);

		// DBTASK_SAVECONQUERORLEVEL 0x82A6
		// Get All Stats
		pThis = pPlayer + 0x1140;
		STR = EntityBaseStatusGetAbility(pThis, 0x0);
		pThis = pPlayer + 0x1140;
		DEX = EntityBaseStatusGetAbility(pThis, 0x3);
		pThis = pPlayer + 0x1140;
		PSY = EntityBaseStatusGetAbility(pThis, 0x4);
		pThis = pPlayer + 0x1140;
		INT = EntityBaseStatusGetAbility(pThis, 0x2);
		pThis = pPlayer + 0x1140;
		VIT = EntityBaseStatusGetAbility(pThis, 0x1);
		pThis = pPlayer + 0x1140;
		AGI = EntityBaseStatusGetAbility(pThis, 0x5);

		pThis = pPlayer;
		Value = BioticBaseGetAbility(pThis, 0x17);
		StatPoint += Value;
		BioticBaseSetAbility(pThis, 0x17, StatPoint);

		pThis = pPlayer;
		addrs = (DWORD)pThis + 0x30;
		CharID = *(reinterpret_cast<unsigned int*>(addrs));
		// CharID
		addrs = (DWORD)SAVECONQUERORLEVEL;
		*(reinterpret_cast<unsigned int*>(addrs)) = CharID;
		// Conqueror Level
		addrs = (DWORD)SAVECONQUERORLEVEL + 0x4;
		*(reinterpret_cast<unsigned int*>(addrs)) = HLV;
		// AttributeType
		addrs = (DWORD)SAVECONQUERORLEVEL + 0x8;
		*(reinterpret_cast<unsigned int*>(addrs)) = 0x63;
		// AttributeValue
		addrs = (DWORD)SAVECONQUERORLEVEL + 0xC;
		*(reinterpret_cast<unsigned int*>(addrs)) = AllStats;
		// Property Points
		addrs = (DWORD)SAVECONQUERORLEVEL + 0x10;
		*(reinterpret_cast<unsigned short*>(addrs)) = StatPoint;
		// STR
		addrs = (DWORD)SAVECONQUERORLEVEL + 0x12;
		*(reinterpret_cast<unsigned short*>(addrs)) = (unsigned short)STR;
		// DEX
		addrs = (DWORD)SAVECONQUERORLEVEL + 0x14;
		*(reinterpret_cast<unsigned short*>(addrs)) = (unsigned short)DEX;
		// PSY
		addrs = (DWORD)SAVECONQUERORLEVEL + 0x16;
		*(reinterpret_cast<unsigned short*>(addrs)) = (unsigned short)PSY;
		// INT
		addrs = (DWORD)SAVECONQUERORLEVEL + 0x18;
		*(reinterpret_cast<unsigned short*>(addrs)) = (unsigned short)INT;
		// VIT
		addrs = (DWORD)SAVECONQUERORLEVEL + 0x1A;
		*(reinterpret_cast<unsigned short*>(addrs)) = (unsigned short)VIT;
		// AGI
		addrs = (DWORD)SAVECONQUERORLEVEL + 0x1C;
		*(reinterpret_cast<unsigned short*>(addrs)) = (unsigned short)AGI;
		// Send Packet
		SendPacketEX(0x007F23A0, 0x82A6, SAVECONQUERORLEVEL_ADDRS, 0x1E);
		
		// DBTASK_LEVELUP 0x4A03
		pThis = pPlayer;
		SkillPoint = BioticBaseGetAbility(pThis, 0x16);

		addrs = pPlayer + 0x1950;
		CurExp = *(reinterpret_cast<__int64*>(addrs));

		addrs = (DWORD)HLVDBSK_LEVELUP_ADDRS;
		*(reinterpret_cast<unsigned int*>(addrs)) = CharID;
		addrs = (DWORD)HLVDBSK_LEVELUP_ADDRS + 0x4;
		*(reinterpret_cast<unsigned short*>(addrs)) = (unsigned short)StatPoint;
		addrs = (DWORD)HLVDBSK_LEVELUP_ADDRS + 0x6;
		*(reinterpret_cast<unsigned short*>(addrs)) = (unsigned short)SkillPoint;
		addrs = (DWORD)HLVDBSK_LEVELUP_ADDRS + 0x8;
		*(reinterpret_cast<unsigned short*>(addrs)) = 115;
		addrs = (DWORD)HLVDBSK_LEVELUP_ADDRS + 0xA;
		*(reinterpret_cast<__int64*>(addrs)) = CurExp;
		// Send Packet
		SendPacketEX(0x007F23A0, 0x4A03, HLVDBSK_LEVELUP_ADDRS, 0x12);
	}

	// MCM_MAP_INCABILITY_BROADCAST
	pThis = pPlayer;
	PlayerBroadcastIncAbility(pThis);

	// Send Conqueror Level Broadcast
	pThis = pPlayer;
	PlayerSendConquerorLevel(pThis);

	// Send Conqueror Notice
	addrs = (DWORD)CONQUERORNOTICE + 0x15;
	*(reinterpret_cast<int*>(addrs)) = HLV;
	addrs = (DWORD)CONQUERORNOTICE + 0x19;
	*(reinterpret_cast<int*>(addrs)) = HLV;
	addrs = (DWORD)CONQUERORNOTICE + 0x1C;
	*(reinterpret_cast<char*>(addrs)) = 0;
	pThis = pPlayer;
	PlayerSendNotice(pThis, 0xF052, CONQUERORNOTICE_ADDRS, 0x1D, 0x15);

}
