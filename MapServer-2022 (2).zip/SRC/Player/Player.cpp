#include <Player.h>
#include <MapFunctions.h>
#include <RHItem.h>

using namespace std; 

unsigned char PK1818_BUFFER[203] = {0};
int PK1818_ADDRS = (DWORD)PK1818_BUFFER;
int PK1818_RET = 0x0050AE4A;

unsigned char GETEXP1_BUFFER[12] = {0};
int GETEXP1_ADDRS = (DWORD)GETEXP1_BUFFER;
int MAPGETEXP1_RET = 0x004FADE4;

unsigned char GETEXP2_BUFFER[12] = {0};
int GETEXP2_ADDRS = (DWORD)GETEXP2_BUFFER;
int MAPGETEXP2_RET = 0x004FAFD2;

unsigned char DIEPENALTY_BUFFER[212] = {0};
int DIEPENALTY_ADDRS = (DWORD)DIEPENALTY_BUFFER;
int DIEPENALTY_RET = 0x004FDEF3;

unsigned char TITLECHANGE_BUFFER[201] = {0};
int TITLECHANGE_ADDRS = (DWORD)TITLECHANGE_BUFFER;
int TITLECHANGE_RET = 0x005143EB;

unsigned char SOCKETCHARSTATUSINFO_BUFFER[196] = {0};
int SOCKETCHARSTATUSINFO_ADDRS = (DWORD)SOCKETCHARSTATUSINFO_BUFFER;
int SOCKETCHARSTATUSINFO_RET = 0x00520AB6;

int CHARCLASSPROC_RET = 0x00694644;
int CHARCLASSPSKILL_RET = 0x006946FB;
int CHARCLASSBYSTORE_RET = 0x00694C45;

int ISCHJOB_RET_ORIG = 0x004F1CAE;
int ISCHJOB_RET_END = 0x004F2342;

extern int CHARSTATUS_SIZE;
int PK1818_PKSIZE = 0x7 + CHARSTATUS_SIZE;
int DIEPENALTY_PKSIZE = 0x10 + CHARSTATUS_SIZE;
int TITLECHANGE_PKSIZE = 0x5 + CHARSTATUS_SIZE;

int GETEXP_PLAYERPTR;
int GETEXP_EXP64PTR;
int GETEXP_CURLV;
int GETEXP_CURHLV;
int GETEXP_MAXCOUNT;

int CONQUEROREXP = 0x00516300;

/******* ASM Funs *******/
extern int GETSTATUS;
extern int GETABILITY;
extern int SENDPACKET_FUN;
extern int SENDGETEXP;

// **** 2018 RCM_MAP_INIT_SKILL 0x1818 ***********************************************
void InitSkill()
{
	__asm mov edi, PK1818_ADDRS

	__asm mov byte ptr es:[edi],0x0

	__asm mov dl, byte ptr ss:[ebp-0x4F]
	__asm mov byte ptr es:[edi+0x1],dl
	
	__asm mov dl, byte ptr ss:[ebp-0x4E]
	__asm mov byte ptr es:[edi+0x2],dl

	__asm add edi, 0x3
	__asm push edi
	__asm mov ecx,dword ptr ss:[ebp-0xF4]
	__asm push ecx
	__asm call GETSTATUS
	__asm mov eax,CHARSTATUS_SIZE
	__asm add edi, eax

	__asm push 0x16
	__asm mov ecx,dword ptr ss:[ebp-0xF4]
	__asm call GETABILITY
	__asm mov dword ptr es:[edi],eax

	// Send Packet 1818
	// 2021 PacketSize 0xB7; 2018 PacketSize 0x73;
	__asm mov edi, PK1818_ADDRS
	__asm mov eax,PK1818_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x1818
	__asm mov ecx,dword ptr ss:[ebp-0xE0]
	__asm call SENDPACKET_FUN

	__asm jmp PK1818_RET

}

// **** 2018 RCM_MAP_GETEXPERIENCE 0x1809 ********************************************
void MapGetEXPP1()
{
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm mov GETEXP_PLAYERPTR,ecx

	// GetArrendalExp Start =========================
	__asm cmp dword ptr ss:[ebp+0x1C],0x0
	__asm jne GEN_EXP
	
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm mov eax,dword ptr ds:[ecx+0x2C]
	__asm cmp eax,0x34036
	__asm je GET_ARRENDALEXP
	__asm cmp eax,0x34037
	__asm jne GEN_EXP
GET_ARRENDALEXP:
	__asm lea eax, dword ptr ss:[ebp+0x8]
	__asm mov GETEXP_EXP64PTR,eax
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm mov GETEXP_PLAYERPTR,ecx

	ArrendalGrowthAutomatic(GETEXP_PLAYERPTR, GETEXP_EXP64PTR);

GEN_EXP:
	// GetArrendalExp End ===========================
	GETEXP_CURLV = BioticBaseGetAbility(GETEXP_PLAYERPTR, 0x15);
	GETEXP_MAXCOUNT = 115 - GETEXP_CURLV;
	if (GETEXP_CURLV < 115)
	{
		for(int i=0; i < GETEXP_MAXCOUNT; i++ )
		{
			PlayerCheckUpLevel(GETEXP_PLAYERPTR);
		}
	}

	GETEXP_CURLV = BioticBaseGetAbility(GETEXP_PLAYERPTR, 0x15);
	if (GETEXP_CURLV > 114)
	{
		GETEXP_CURHLV = BioticBaseGetAbility(GETEXP_PLAYERPTR, 0x65);
		if (GETEXP_CURHLV < 50)
		{
			GETEXP_MAXCOUNT = 50 - GETEXP_CURHLV;
			for(int i=0; i < GETEXP_MAXCOUNT; i++ )
			{
				GETEXP_CURHLV = BioticBaseGetAbility(GETEXP_PLAYERPTR, 0x65);
				__asm mov edx,GETEXP_CURHLV

				__asm push 0x2B
				__asm push edx
				__asm mov ecx,dword ptr ss:[ebp-0x64]
				__asm call CONQUEROREXP
				__asm add esp,0x8
			}
		}
	}

	__asm mov edi,GETEXP1_ADDRS

	// Get Player Level
	__asm push 0x15
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm call GETABILITY
	__asm mov word ptr es:[edi],ax
	// EXPL
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm mov eax,dword ptr ds:[ecx+0x1950]
	__asm mov dword ptr es:[edi+0x2],eax
	// EXPH
	__asm mov eax,dword ptr ds:[ecx+0x1954]
	__asm mov dword ptr es:[edi+0x6],eax
	// M.Kill
	__asm mov eax,dword ptr ds:[ecx+0x1984]
	__asm mov word ptr es:[edi+0xA],ax
	
	__asm mov eax,dword ptr ds:[ecx+0x1098]
	__asm mov dword ptr ss:[ebp-0x60],eax
	__asm cmp dword ptr ss:[ebp-0x60],0x0
	__asm je RET_TARGET

	__asm mov edi, GETEXP1_ADDRS
	__asm push 0xC
	__asm push edi
	__asm push 0x1809
	__asm mov ecx,dword ptr ss:[ebp-0x60]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp MAPGETEXP1_RET
}

void MapGetEXPP2()
{
	__asm mov edi,GETEXP2_ADDRS

	// Get Player Level
	__asm push 0x15
	__asm mov ecx,dword ptr ss:[ebp-0x1C]
	__asm call GETABILITY
	__asm mov word ptr es:[edi],ax
	// EXPL
	__asm mov ecx,dword ptr ss:[ebp-0x1C]
	__asm mov eax,dword ptr ds:[ecx+0x1950]
	__asm mov dword ptr es:[edi+0x2],eax
	// EXPH
	__asm mov eax,dword ptr ds:[ecx+0x1954]
	__asm mov dword ptr es:[edi+0x6],eax
	// M.Kill
	__asm mov eax,dword ptr ds:[ecx+0x1984]
	__asm mov word ptr es:[edi+0xA],ax
	
	__asm mov eax,dword ptr ds:[ecx+0x1098]
	__asm mov dword ptr ss:[ebp-0x18],eax
	__asm cmp dword ptr ss:[ebp-0x18],0x0
	__asm je RET_TARGET

	__asm mov edi, GETEXP2_ADDRS
	__asm push 0xC
	__asm push edi
	__asm push 0x1809
	__asm mov ecx,dword ptr ss:[ebp-0x18]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp MAPGETEXP2_RET

}

// **** 2018 RCM_MAP_DIEPENALTY 0x1309 ***********************************************
void CharacterDeath()
{
	__asm mov edi, DIEPENALTY_ADDRS

	__asm push edi
	__asm mov ecx,dword ptr ss:[ebp-0x12C]
	__asm push ecx
	__asm call GETSTATUS
	__asm mov eax,CHARSTATUS_SIZE
	__asm add edi, eax

	// PlayerPTR
	__asm mov ecx,dword ptr ss:[ebp-0x12C]
	// Write Experience L Dword
	__asm mov eax,dword ptr ss:[ecx+0x1950]
	__asm mov dword ptr ss:[edi],eax
	// Write Experience H Dword
	__asm mov eax,dword ptr ss:[ecx+0x1954]
	__asm mov dword ptr ss:[edi+0x4],eax
	__asm add edi, 0x8

	// Write Money
	__asm mov ecx,dword ptr ss:[ebp-0x12C]
	__asm mov edx,dword ptr ds:[ecx+0x1958]
	__asm mov dword ptr ss:[ebp-0x110],edx
	__asm mov eax,dword ptr ds:[ecx+0x195C]
	__asm mov dword ptr ss:[ebp-0x10C],eax
	__asm mov ecx,dword ptr ss:[ebp-0x110]
	__asm mov dword ptr ss:[edi],ecx
	__asm add edi, 0x4
	
	__asm mov edx,dword ptr ss:[ebp-0x10C]
	__asm mov dword ptr ss:[edi],edx
	__asm add edi, 0x4
	
	__asm mov eax,dword ptr ss:[ebp-0x12C]
	__asm mov ecx,dword ptr ds:[eax+0x1098]
	__asm mov dword ptr ss:[ebp-0x114],ecx
	__asm cmp dword ptr ss:[ebp-0x114],0x0
	__asm je RET_TARGET

	// Send Packet
	// 2021 PacketSize 0xC0; 2018 PacketSize 0x7C;
	__asm mov edi, DIEPENALTY_ADDRS
	__asm mov eax,DIEPENALTY_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x1309
	__asm mov ecx,dword ptr ss:[ebp-0x114]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp DIEPENALTY_RET

}

// **** 2018 RCM_MAP_TITLE_CHANGE 0x1A2A *********************************************
void TitleChange()
{
	__asm mov edi, TITLECHANGE_ADDRS

	// Write +0 1 byte
	__asm mov byte ptr ss:[edi],0x0
	__asm add edi, 0x1

	// Write +2 4 byte
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov dword ptr ss:[edi],edx
	__asm add edi, 0x4

	// Write +5 Char Status 0xB0 Byte
	__asm push edi
	__asm mov ecx,dword ptr ss:[ebp-0xF8]
	__asm push ecx
	__asm call GETSTATUS
	__asm mov eax,CHARSTATUS_SIZE
	__asm add edi, eax

	__asm mov ecx,dword ptr ss:[ebp-0xF8]
	__asm mov edx,dword ptr ds:[ecx+0x1098]
	__asm mov dword ptr ss:[ebp-0xE0],edx
	__asm cmp dword ptr ss:[ebp-0xE0],0x0
	__asm je RET_TARGET

	// Send Packet
	// 2021 PacketSize 0xB5; 2018 PacketSize 0x71;
	__asm mov edi, TITLECHANGE_ADDRS
	__asm mov eax,TITLECHANGE_PKSIZE
	__asm push eax
	__asm push edi
	__asm push 0x1A2A
	__asm mov ecx,dword ptr ss:[ebp-0xE0]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp TITLECHANGE_RET

}

// **** 2018 RCM_MAP_SOCKET_CHARSTATUSINFO 0x2318 ************************************
void SocketCharStatus()
{
	__asm mov edi, SOCKETCHARSTATUSINFO_ADDRS

	__asm push edi
	__asm mov ecx,dword ptr ss:[ebp-0x10]
	__asm push ecx
	__asm call GETSTATUS

	__asm mov edx,dword ptr ss:[ebp-0x10]
	__asm mov eax,dword ptr ds:[edx+0x1098]
	__asm mov dword ptr ss:[ebp-0x84],eax
	__asm cmp dword ptr ss:[ebp-0x84],0x0
	__asm je RET_TARGET

	// Send Packet
	// 2021 PacketSize 0xB0; 2018 PacketSize 0x6C;
	__asm mov edi, SOCKETCHARSTATUSINFO_ADDRS
	__asm mov eax,CHARSTATUS_SIZE
	__asm push eax
	__asm push edi
	__asm push 0x2318
	__asm mov ecx,dword ptr ss:[ebp-0x84]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp SOCKETCHARSTATUSINFO_RET

}

// **** LEARNSKILL Class Patch ************************************
void CharClassProc()
{
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm and edx,0x3F
	__asm sar edx,1
	__asm and edx,0xFFFFFFFC
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm and eax,0x3F
	__asm and eax,0x3
	__asm add edx,eax
	__asm cmp dword ptr ss:[ebp+0x8], 0x00039044
	__asm jb OLD_CLASS
	__asm add edx,0x20

OLD_CLASS:
	__asm mov dword ptr ss:[ebp-0x8],edx
	__asm jmp CHARCLASSPROC_RET
}

void CharClassSkillItem()
{
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm and eax,0x3F
	__asm sar eax,1
	__asm and eax,0xFFFFFFFC
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm and ecx,0x3F
	__asm and ecx,0x3
	__asm add eax,ecx
	__asm cmp dword ptr ss:[ebp+0x8], 0x00039044
	__asm jb OLD_CLASS
	__asm add eax,0x20
OLD_CLASS:
	__asm mov dword ptr ss:[ebp-0x4],eax
	__asm jmp CHARCLASSPSKILL_RET
}

void CharClassSkillWithJobStore()
{
	__asm cmp dword ptr ss:[ebp+0x8], 0x00039044
	__asm jb OLD_CLASS
	__asm add eax,0x20
OLD_CLASS:
	__asm mov dword ptr ss:[ebp-0x4],eax
	__asm mov eax,dword ptr ss:[ebp-0x4]
	__asm jmp CHARCLASSBYSTORE_RET
	
}

// **** IsChangeJob Patch ************************************
void IsChangeJobProc()
{
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov dword ptr ss:[ebp-0x14],eax
	
	// Check Ctype
	__asm cmp eax, 0x39046
	__asm je AESIRF
	__asm cmp eax, 0x39047
	__asm je AESIRF

	__asm cmp eax, 0x390C2
	__asm je AESIRM
	__asm cmp eax, 0x390C3
	__asm je AESIRM
	
	__asm jmp RET_ORIG

AESIRF:
	__asm cmp dword ptr ss:[ebp-0x4], 0x39045
	__asm je CHECK_LEVEL
	__asm jmp RET_ORIG

AESIRM:
	__asm cmp dword ptr ss:[ebp-0x4], 0x390C1
	__asm je CHECK_LEVEL
	__asm jmp RET_ORIG

CHECK_LEVEL:
	// Check Level
	__asm cmp dword ptr ss:[ebp-0x8],0x32
	__asm jl RET_NO
	__asm mov eax,0x1
	__asm jmp ISCHJOB_RET_END

RET_NO:
	__asm mov eax,0x0
	__asm jmp ISCHJOB_RET_END

RET_ORIG:
	__asm jmp ISCHJOB_RET_ORIG

}

int CheckJobID(int NewCtype)
{
	int pJob;
	__asm mov pJob,ecx
	int addrs;
	int JobID;
	int Result = 0;
	
	addrs = pJob + 0x88;
	JobID = *(reinterpret_cast<int*>(addrs));
	if (JobID < 18)
	{
		switch(JobID)
		{
			// Human_Guardian
			case 0: if ((NewCtype == 0x30182) || (NewCtype == 0x30106)) Result = 1; break;
			// Elf_Priest
			case 1: if ((NewCtype == 0x3028A) || (NewCtype == 0x3020E)) Result = 1; break;
			// HalfElf_Ranger
			case 2: if ((NewCtype == 0x30492) || (NewCtype == 0x30416)) Result = 1; break;
			// Dan_Avenger
			case 3: if ((NewCtype == 0x3089A) || (NewCtype == 0x3081E)) Result = 1; break;
			// Human_Defender
			case 4: if ((NewCtype == 0x30183) || (NewCtype == 0x30107)) Result = 1; break;
			// Elf_Templer
			case 5: if ((NewCtype == 0x3028B) || (NewCtype == 0x3020F)) Result = 1; break;
			// HalfElf_Scout
			case 6: if ((NewCtype == 0x30493) || (NewCtype == 0x30417)) Result = 1; break;
			// Dan_Predator
			case 7: if ((NewCtype == 0x3089B) || (NewCtype == 0x3081F)) Result = 1; break;
			// Dekan_Dragon_Knight
			case 8: if ((NewCtype == 0x380BA) || (NewCtype == 0x3803E)) Result = 1; break;
			// Dekan_Dragon_Sage
			case 9: if ((NewCtype == 0x380BB) || (NewCtype == 0x3803F)) Result = 1; break;
			// DarkElf_Elder_Rich
			case 10: if ((NewCtype == 0x320AA) || (NewCtype == 0x3202E)) Result = 1; break;
			// DarkElf_Sermoner
			case 11: if ((NewCtype == 0x320AB) || (NewCtype == 0x3202F)) Result = 1; break;
			// Giant_Berserker
			case 12: if ((NewCtype == 0x310A2) || (NewCtype == 0x31026)) Result = 1; break;
			// Giant_Savage
			case 13: if ((NewCtype == 0x310A3) || (NewCtype == 0x31027)) Result = 1; break;
			// Trinity_Rumir
			case 14: if (NewCtype == 0x34036) Result = 1; break;
			// Trinity_Noir
			case 15: if (NewCtype == 0x34037) Result = 1; break;
			// Aesir_Embla
			case 16: if ((NewCtype == 0x390C2) || (NewCtype == 0x39046)) Result = 1; break;
			// Aesir_Whisper
			case 17: if ((NewCtype == 0x390C3) || (NewCtype == 0x39047)) Result = 1; break;
		}
	}
	return Result;
}
