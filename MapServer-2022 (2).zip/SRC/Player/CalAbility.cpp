#include <Player.h>
#include <MapFunctions.h>

using namespace std; 

int APPLYCALABILITY = (DWORD)CalculateAbility;

void ApplyCalAbility(int pPlayer)
{
	__asm mov ecx, pPlayer
	__asm call APPLYCALABILITY
}

void CalculateAbility()
{
	int addrs;
	int pPlayer;
	int pThis = 0;
	int Value = 0;
	int ValueAdd = 0;
	int ValueAdd1 = 0;
	int ValueAdd2 = 0;
	int CalValue1 = 0;
	int CalValue2 = 0;
	int DW_04BEEB50 = 0;
	int Grade = 0;
	int MaxLife = 0;
	int CurLife = 0;
	int MaxMana = 0;
	int CurMana = 0;

	__asm mov pPlayer,ecx

	/*** Level Init ****/
	Value = BioticBaseGetAbility(pPlayer, 0x15);
	if (Value > 115) Value = 115;
	BioticBaseSetAbility(pPlayer, 0x15, Value);

	/*** Call All Ability ***/
	CalCharAbility(pPlayer);
	CalAbilityExt(pPlayer);

	/*** CA_ATTACK_RANGE ***/
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	Value = EntityBaseStatusGetAbility(pThis, 0x8);
	// Skill 0x5D ATTACK_RANGE_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x5D);
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd1 = EntityBaseStatusGetAbility(pThis, 0x7);
	if (ValueAdd1 == 2)
	{
		// Skill 0x5C MISSILE_ATTACK_RANGE_RATE
		pThis = pPlayer + 0x160;
		ValueAdd2 = EntityBaseStatusGetAbility(pThis, 0x5C);
		ValueAdd += ValueAdd2;
	}
	if (ValueAdd != 0)
	{
		Value = (ValueAdd + 100) * Value / 100;
	}
	if (Value == 0) Value = 300;
	if (Value > 4800) Value = 4800;

	BioticBaseSetAbility(pPlayer, 0x1B, Value);
	
	/*** CA_MISS_RATE ***/
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	Value = EntityBaseStatusGetAbility(pThis, 0x9);

	BioticBaseSetAbility(pPlayer, 0x1C, Value);
	
	/*** CA_CRITICAL_RATE ***/
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	Value = EntityBaseStatusGetAbility(pThis, 0xA);
	// Skill 0x5B WEAPON_CRITICAL_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x5B);
	Value += ValueAdd;
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xD);
	Value += ValueAdd;
	// Skill 0x73 CRITICAL_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x73);
	Value += ValueAdd;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x29);
	Value += ValueAdd;
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0xD);
	Value += ValueAdd;
	
	BioticBaseSetAbility(pPlayer, 0x1D, Value);

	/*** CA_CRITICAL_FACTOR ***/
	addrs = 0x7F2CBC;
	Value = *(reinterpret_cast<int*>(addrs));
	// Skill 0x57 CRITICAL_FACTOR
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x57);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x1E, Value);

	/*** CA_BLOCK_PROBABILITY ***/
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	Value = EntityBaseStatusGetAbility(pThis, 0xB);
	pThis = pPlayer + 0xCC8;	
	ValueAdd1 = IsEquipShield(pThis);
	if (ValueAdd1 != 0)
	{
		// Skill 0x6B BLOCK_RATE
		pThis = pPlayer + 0x160;
		ValueAdd = EntityBaseStatusGetAbility(pThis, 0x6B);
		Value += ValueAdd;
	}
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd2 = EntityBaseStatusGetAbility(pThis, 0x27);
	if (ValueAdd2 != 0)
	{
		Value += ValueAdd2;
	}

	BioticBaseSetAbility(pPlayer, 0x1F, Value);

	/*** CA_LIFE_DRAIN_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0xE);
	// Skill 0x78 LIFE_DRAIN_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x78);
	Value += ValueAdd;
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0xE);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x25, Value);

	/*** CA_LIFE_DRAIN_BONUS ***/
	// Skill 0x79 LIFE_DRAIN_BONUS_BY_MENTALITY
	pThis = pPlayer + 0x160;
	ValueAdd1 = EntityBaseStatusGetAbility(pThis, 0x79);
	ValueAdd2 = BioticBaseGetAbility(pPlayer, 0x4);
	Value = (ValueAdd1 * ValueAdd2) / 100;

	// Skill 0xFE LIFE_DRAIN
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xFE);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x37, Value);

	/*** CA_LIFE_DRAIN_RATE_OTHER ***/
	// Skill 0x7A LIFE_DRAIN_RATE_OTHER
	pThis = pPlayer + 0x160;
	Value = EntityBaseStatusGetAbility(pThis, 0x7A);

	BioticBaseSetAbility(pPlayer, 0x38, Value);

	/*** CA_LIFE_DRAIN_BONUS_OTHER ***/
	// Skill 0x7B LIFE_DRAIN_BONUS_OTHER_BY_MENTALITY
	pThis = pPlayer + 0x160;
	ValueAdd1 = EntityBaseStatusGetAbility(pThis, 0x7B);
	ValueAdd2 = BioticBaseGetAbility(pPlayer, 0x4);

	Value = (ValueAdd1 * ValueAdd2) / 100;

	BioticBaseSetAbility(pPlayer, 0x39, Value);

	/*** CA_MANA_DRAIN_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0xF);
	// Item Attr
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xDB);
	Value += ValueAdd;
	// Skill 0x7C MANA_DRAIN_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x7C);
	Value += ValueAdd;
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0xF);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x26, Value);

	/*** CA_POTION_RECOVERY_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x1F);
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x75);
	Value += ValueAdd;
	// Item Attr
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xE1);
	Value += ValueAdd;
	// Skill 0x6C POTION_RECOVERY_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x6C);
	Value += ValueAdd;
	// Skill 0xB0 RECOVERY_RATE_BY_GUILD_POTION_VALUE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xB0);
	Value += ValueAdd;
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0x1F);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x27, Value);

	/*** CA_DEC_DAMAGE_RATE ***/
	// Level Reward Dec Damage Rate (2018)
	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 0x80);
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x22);
	if (Value != 0)
	{
		addrs = 0x04BEEB50;
		DW_04BEEB50 = *(reinterpret_cast<int*>(addrs));
		if (DW_04BEEB50 != 0)
		{
			Grade = GetCollectGrade(0x149, 0xA6);
		}
		else
		{
			Grade = 0xFFFFFFFF;
		}
		if ((Grade != 0xFFFFFFFF) && (Value > Grade))
		{
			Value = Grade;
		}
	}
	Value += ValueAdd;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xC2);
	Value += ValueAdd;
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0x22);
	Value += ValueAdd;
	// Skill 0xF1 DAMAGE_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xF1);
	Value += ValueAdd;
	
	CalValue1 = 0 - Value;

	BioticBaseSetAbility(pPlayer, 0x2B, CalValue1);

	/*** CA_NOT_USE_ARROW_PROBABILITY ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x23);
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0x23);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x2C, Value);

	/*** CA_HEAL_RECOVERY_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x24);

	BioticBaseSetAbility(pPlayer, 0x2D, Value);

	/*** CA_PARRY_PROBABILITY ***/
	// Skill 0x6E PARRY_PROBABILITY
	pThis = pPlayer + 0x160;
	Value = EntityBaseStatusGetAbility(pThis, 0x6E);

	BioticBaseSetAbility(pPlayer, 0x2A, Value);

	/*** CA_SKILL_SAVING_MANA ***/
	// Skill 0x6F MANA_SAVING_RATE_BY_MENTALITY
	Value = 0;
	pThis = pPlayer + 0x160;
	ValueAdd1 = EntityBaseStatusGetAbility(pThis, 0x6F);
	if (ValueAdd1 > 0)
	{
		ValueAdd2 = BioticBaseGetAbility(pPlayer, 0x4);
		Value = (ValueAdd1 * ValueAdd2) / 100;
	}

	BioticBaseSetAbility(pPlayer, 0x2E, Value);

	/*** CA_SKILL_MANA_DEC_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x20);

	BioticBaseSetAbility(pPlayer, 0x35, Value);

	/*** CA_DART_ATTACK_FORCE ***/
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	Value = EntityBaseStatusGetAbility(pThis, 0x14);

	BioticBaseSetAbility(pPlayer, 0x33, Value);

	/*** CA_AXE_ATTACK_FORCE ***/
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	Value = EntityBaseStatusGetAbility(pThis, 0x15);

	BioticBaseSetAbility(pPlayer, 0x34, Value);

	/*** CA_ATTACK_NULL_PROBABILITY ***/
	// Skill 0x48 ATTACK_NULL_PROBABILITY
	pThis = pPlayer + 0x160;
	Value = EntityBaseStatusGetAbility(pThis, 0x48);
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xE2);
	Value += ValueAdd;
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x21);
	Value += ValueAdd;
	if (Value < 0) Value = 0;
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x6C);
	Value += ValueAdd;
	if (Value < 0) Value = 0;

	BioticBaseSetAbility(pPlayer, 0x28, Value);

	/*** CA_PHYSICS_ATTACK_NULL ***/
	// Skill 0x76 PHYSICS_ATTACK_NULL
	pThis = pPlayer + 0x160;
	Value = EntityBaseStatusGetAbility(pThis, 0x76);

	BioticBaseSetAbility(pPlayer, 0x29, Value);

	/*** CA_MAGICS_ATTACK_NULL ***/
	// Skill 0x77 MAGICS_ATTACK_NULL
	pThis = pPlayer + 0x160;
	Value = EntityBaseStatusGetAbility(pThis, 0x77);

	BioticBaseSetAbility(pPlayer, 0x36, Value);

	/*** CA_RESISTANCE_BLAZING ***/
	Value = BioticBaseGetAbility(pPlayer, 0x11);
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd1 = EntityBaseStatusGetAbility(pThis, 0x10);
	//if (ValueAdd1 < 50) ValueAdd1 = 50;
	// Skill 0x1 BLAZING_FORCE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x1);
	ValueAdd += ValueAdd1;
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x2F, Value);

	/*** CA_RESISTANCE_FROZEN ***/
	Value = BioticBaseGetAbility(pPlayer, 0x11);
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd1 = EntityBaseStatusGetAbility(pThis, 0x11);
	//if (ValueAdd1 < 50) ValueAdd1 = 50;
	// Skill 0x3 FROZEN_FORCE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x3);
	ValueAdd += ValueAdd1;
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x30, Value);

	/*** CA_RESISTANCE_DARKNESS ***/
	Value = BioticBaseGetAbility(pPlayer, 0x11);
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd1 = EntityBaseStatusGetAbility(pThis, 0x12);
	//if (ValueAdd1 < 50) ValueAdd1 = 50;
	// Skill 0x5 DARKNESS_RESISTANCE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x5);
	ValueAdd += ValueAdd1;
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x31, Value);

	/*** CA_RESISTANCE_DIVINE ***/
	Value = BioticBaseGetAbility(pPlayer, 0x11);
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd1 = EntityBaseStatusGetAbility(pThis, 0x13);
	//if (ValueAdd1 < 50) ValueAdd1 = 50;
	// Skill 0x7 DIVINE_RESISTANCE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x7);
	ValueAdd += ValueAdd1;
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x32, Value);

	/*** CA_DAMAGE_REFLECTION_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x28);
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xD7);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x3A, Value);

	/*** CA_DAMAGE_REFLECTION_VALUE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x32);
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0x32);
	Value += ValueAdd;
	// Skill 0xFD DAMAGE_REFLECTION_VALUE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xFD);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x43, Value);

	/*** CA_LEVEL_DAMAGE_REDUCTION_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x33);
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0x33);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x3B, Value);

	/*** CA_RECORVERY_HP_BY_DAMAGE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x36);
	// Skill 0xFB RECORVERY_HP_BY_DAMAGE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xFB);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x3C, Value);

	/*** CA_RECORVERY_MP_BY_DAMAGE ***/
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x37);
	// Skill 0xFC RECORVERY_MP_BY_DAMAGE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xFC);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x3D, Value);

	/*** CA_RESIST_STUN_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x34);
	// Item Attr
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xDF);
	Value += ValueAdd;
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0x34);
	Value += ValueAdd;
	// Skill 0x8E RESIST_STUN_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x8E);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x40, Value);

	/*** CA_RESIST_POISON_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x35);

	BioticBaseSetAbility(pPlayer, 0x41, Value);

	/*** CA_CRITICAL_DAMAGE_REDUCTION ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x3B);
	// Skill 0x82 DEC_CRITICAL_DAMAGE_VALUE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x82);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x42, Value);
	
	// Check Life Mana
	MaxLife = BioticBaseGetAbility(pPlayer, 0xD);
	addrs = (DWORD)pPlayer + 0xAC;
	CurLife = *(reinterpret_cast<int*>(addrs));
	if (CurLife > MaxLife)
	{
		addrs = (DWORD)pPlayer + 0xAC;
		*(reinterpret_cast<int*>(addrs)) = MaxLife;
	}

	MaxMana = BioticBaseGetAbility(pPlayer, 0xF);
	addrs = (DWORD)pPlayer + 0xB0;
	CurMana = *(reinterpret_cast<int*>(addrs));
	if (CurMana > MaxMana)
	{
		addrs = (DWORD)pPlayer + 0xB0;
		*(reinterpret_cast<int*>(addrs)) = MaxMana;
	}

	/*** CA_DAMAGE_RECOVERY_RATE ***/
	// Skill 0xEC DAMAGE_RECOVERY_RATE/(PET)
	pThis = pPlayer + 0x160;
	Value = EntityBaseStatusGetAbility(pThis, 0xEC);

	BioticBaseSetAbility(pPlayer, 0x5F, Value);

	/*** CA_DECREASE_PHYSICS_DEFENCE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x59);

	BioticBaseSetAbility(pPlayer, 0x60, Value);

	/*** CA_DECREASE_MAGIC_DEFENCE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x5A);

	BioticBaseSetAbility(pPlayer, 0x61, Value);

	/*** CA_DECREASE_SKILL_DAMAGE_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x5B);
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0x5B);
	Value += ValueAdd;
	// Skill 0xF9 DECREASE_SKILL_DAMAGE_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xF9);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x62, Value);

	/*** CA_DONT_MOVE_CONDITION_REDUCE_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x5C);

	BioticBaseSetAbility(pPlayer, 0x63, Value);

	/*** CA_PENETRATE_DEC_DMG_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x5E);
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0x5E);
	Value += ValueAdd;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xC1);
	Value += ValueAdd;
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketAttribute(pThis, 0xC1);
	Value += ValueAdd;
	// Skill 0xF2 PENETRATE_DEC_DMG_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xF2);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x6A, Value);

	/*** CA_INC_CRITICAL_DMG_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x5F);
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xDD);
	Value += ValueAdd;
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0x5F);
	Value += ValueAdd;
	// Skill 0xCF CRITICAL_DAMAGE_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xCF);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x6B, Value);

	/*** CA_PENETRATE_DEF_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x60);
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0x60);
	Value += ValueAdd;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xD5);
	Value += ValueAdd;
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketAttribute(pThis, 0xD5);
	Value += ValueAdd;
	// Skill 0xF3 PENETRATE_DEF_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xF3);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x6C, Value);

	/*** CA_PVP_ATTACK_RATE ***/
	// Level Reward PvP Attack Rate
	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 0x6D);
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x61);
	Value += ValueAdd;
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x71);
	Value += ValueAdd;
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0x61);
	Value += ValueAdd;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xB5);
	Value += ValueAdd;
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketAttribute(pThis, 0xB5);
	Value += ValueAdd;
	// Skill 0xF4 PVP_ATTACK_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xF4);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x6D, Value);

	/*** CA_PVP_DEFENCE_RATE ***/
	// Level Reward PvP Defense Rate
	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 0x6E);
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x4C);
	Value += ValueAdd;
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x62);
	Value += ValueAdd;
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x72);
	Value += ValueAdd;
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0x62);
	Value += ValueAdd;
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketAttribute(pThis, 0xAF);
	Value += ValueAdd;
	// Skill 0xF5 PVP_DEFENCE_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xF5);
	Value += ValueAdd;

	if (Value > 100) Value = 100;

	BioticBaseSetAbility(pPlayer, 0x6E, Value);

	/*** CA_SKILL_DAMAGE_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x63);
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0x63);
	Value += ValueAdd;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xB7);
	Value += ValueAdd;
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketAttribute(pThis, 0xB7);
	Value += ValueAdd;
	// Skill 0xF6 SKILL_DAMAGE_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xF6);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x79, Value);

	/*** CA_SKILL_DEFENCE_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x5B);
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x73);
	Value += ValueAdd;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xB3);
	Value += ValueAdd;
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketAttribute(pThis, 0xB3);
	Value += ValueAdd;

	if (Value > 100) Value = 100;

	BioticBaseSetAbility(pPlayer, 0x62, Value);

	/*** CA_PVE_ATTACK_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x64);
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0x6D);
	Value += ValueAdd;
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0x64);
	Value += ValueAdd;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xB6);
	Value += ValueAdd;
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketAttribute(pThis, 0xB6);
	Value += ValueAdd;
	// Skill 0xF7 PVE_ATTACK_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xF7);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x80, Value);

	/*** CA_PVE_DEFENCE_RATE ***/
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value = EntityBaseStatusGetAbility(pThis, 0x65);
	// Socket Option
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketOption(pThis, 0x65);
	Value += ValueAdd;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xB0);
	Value += ValueAdd;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xCB);
	Value += ValueAdd;
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	ValueAdd = GetSocketAttribute(pThis, 0xCB);
	Value += ValueAdd;
	// Skill 0xF8 PVE_DEFENCE_RATE
	pThis = pPlayer + 0x160;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xF8);
	Value += ValueAdd;

	if (Value > 100) Value = 100;

	BioticBaseSetAbility(pPlayer, 0x81, Value);
	
	/*** CA_CRITICAL_DAMAGE_REDUCTION_RATE ***/
	// Skill 0x117 CRITICAL_DAMAGE_REDUCTION_RATE
	pThis = pPlayer + 0x160;
	Value = EntityBaseStatusGetAbility(pThis, 0x117);
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ValueAdd = EntityBaseStatusGetAbility(pThis, 0xDE);
	Value += ValueAdd;

	BioticBaseSetAbility(pPlayer, 0x82, Value);

	/*** CA_INC_CRITICAL_DAMAGE ***/
	Value = 0;
	// Skill 0x60 CRITICAL_ADD_DAMAGE_BY_STR
	pThis = pPlayer + 0x160;
	CalValue1 = EntityBaseStatusGetAbility(pThis, 0x60);
	if (CalValue1 != 0)
	{
		CalValue2 = BioticBaseGetAbility(pPlayer, 0);
		ValueAdd = CalValue1 * CalValue2 / 100;
		Value += ValueAdd;
	}
	// Skill 0x114 CRITICAL_ADD_DAMAGE_BY_VIT
	pThis = pPlayer + 0x160;
	CalValue1 = EntityBaseStatusGetAbility(pThis, 0x114);
	if (CalValue1 != 0)
	{
		CalValue2 = BioticBaseGetAbility(pPlayer, 1);
		ValueAdd = CalValue1 * CalValue2 / 100;
		Value += ValueAdd;
	}
	// Skill 0x5F CRITICAL_ADD_DAMAGE_BY_INT
	pThis = pPlayer + 0x160;
	CalValue1 = EntityBaseStatusGetAbility(pThis, 0x5F);
	if (CalValue1 != 0)
	{
		CalValue2 = BioticBaseGetAbility(pPlayer, 2);
		ValueAdd = CalValue1 * CalValue2 / 100;
		Value += ValueAdd;
	}
	// Skill 0x61 CRITICAL_ADD_DAMAGE_BY_DEX
	pThis = pPlayer + 0x160;
	CalValue1 = EntityBaseStatusGetAbility(pThis, 0x61);
	if (CalValue1 != 0)
	{
		CalValue2 = BioticBaseGetAbility(pPlayer, 3);
		ValueAdd = CalValue1 * CalValue2 / 100;
		Value += ValueAdd;
	}
	// Skill 0x94 CRITICAL_ADD_DAMAGE_BY_PSY
	pThis = pPlayer + 0x160;
	CalValue1 = EntityBaseStatusGetAbility(pThis, 0x94);
	if (CalValue1 != 0)
	{
		CalValue2 = BioticBaseGetAbility(pPlayer, 4);
		ValueAdd = CalValue1 * CalValue2 / 100;
		Value += ValueAdd;
	}
	// Skill 0x58 CRITICAL_ADD_DAMAGE_BY_AGI
	pThis = pPlayer + 0x160;
	CalValue1 = EntityBaseStatusGetAbility(pThis, 0x58);
	if (CalValue1 != 0)
	{
		CalValue2 = BioticBaseGetAbility(pPlayer, 5);
		ValueAdd = CalValue1 * CalValue2 / 100;
		Value += ValueAdd;
	}

	BioticBaseSetAbility(pPlayer, 0x83, Value);

	/*** Weight State Broadcast ***/
	pThis = pPlayer + 0xCC8;
	WeightStateBroadcast(pThis);

	/*** Setting All Level***/
	pThis = pPlayer;
	Value = GetCharAllLevel(pThis);
	BioticBaseSetAbility(pPlayer, 0x15, Value);
}

void CalAbilityExt(int pPlayer)
{
	int pThis = 0;
	int Value1 = 0;
	int Value2 = 0;
	int CalValue1 = 0;
	int CalValue2 = 0;
	int SkillValue = 0;
	int StatValue = 0;
	int ItemAttrs = 0;
	int RewardValue = 0;

	// ALL_STATUS
	/*** CA_STRENGTH ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0x0);
	// Socket Option
	pThis = pPlayer + 0x1E40;
	Value2 = GetSocketOption(pThis, 0x46);
	Value1 += Value2;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xBD);
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	CalValue1 = GetSocketAttribute(pThis, 0xBD);
	ItemAttrs += CalValue1;
	if (ItemAttrs != 0)
	{
		CalValue2 = (Value1 * ItemAttrs) / 100;
		Value1 += CalValue2;
	}
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value2 = EntityBaseStatusGetAbility(pThis, 0x7B);
	Value1 += Value2;

	BioticBaseSetAbility(pPlayer, 0x0, Value1);

	/*** CA_VITALITY ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0x1);
	// Socket Option
	pThis = pPlayer + 0x1E40;
	Value2 = GetSocketOption(pThis, 0x46);
	Value1 += Value2;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xBD);
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	CalValue1 = GetSocketAttribute(pThis, 0xBD);
	ItemAttrs += CalValue1;
	if (ItemAttrs != 0)
	{
		CalValue2 = (Value1 * ItemAttrs) / 100;
		Value1 += CalValue2;
	}
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value2 = EntityBaseStatusGetAbility(pThis, 0x7B);
	Value1 += Value2;

	BioticBaseSetAbility(pPlayer, 0x1, Value1);

	/*** CA_INTELLIGENCE ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0x2);
	// Socket Option
	pThis = pPlayer + 0x1E40;
	Value2 = GetSocketOption(pThis, 0x46);
	Value1 += Value2;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xBD);
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	CalValue1 = GetSocketAttribute(pThis, 0xBD);
	ItemAttrs += CalValue1;
	if (ItemAttrs != 0)
	{
		CalValue2 = (Value1 * ItemAttrs) / 100;
		Value1 += CalValue2;
	}
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value2 = EntityBaseStatusGetAbility(pThis, 0x7B);
	Value1 += Value2;

	BioticBaseSetAbility(pPlayer, 0x2, Value1);

	/*** CA_DEXTERITY ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0x3);
	// Socket Option
	pThis = pPlayer + 0x1E40;
	Value2 = GetSocketOption(pThis, 0x46);
	Value1 += Value2;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xBD);
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	CalValue1 = GetSocketAttribute(pThis, 0xBD);
	ItemAttrs += CalValue1;
	if (ItemAttrs != 0)
	{
		CalValue2 = (Value1 * ItemAttrs) / 100;
		Value1 += CalValue2;
	}
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value2 = EntityBaseStatusGetAbility(pThis, 0x7B);
	Value1 += Value2;

	BioticBaseSetAbility(pPlayer, 0x3, Value1);

	/*** CA_MENTALITY ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0x4);
	// Socket Option
	pThis = pPlayer + 0x1E40;
	Value2 = GetSocketOption(pThis, 0x46);
	Value1 += Value2;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xBD);
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	CalValue1 = GetSocketAttribute(pThis, 0xBD);
	ItemAttrs += CalValue1;
	if (ItemAttrs != 0)
	{
		CalValue2 = (Value1 * ItemAttrs) / 100;
		Value1 += CalValue2;
	}
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value2 = EntityBaseStatusGetAbility(pThis, 0x7B);
	Value1 += Value2;

	BioticBaseSetAbility(pPlayer, 0x4, Value1);

	/*** CA_QUICKNESS ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0x5);
	// Socket Option
	pThis = pPlayer + 0x1E40;
	Value2 = GetSocketOption(pThis, 0x46);
	Value1 += Value2;
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xBD);
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	CalValue1 = GetSocketAttribute(pThis, 0xBD);
	ItemAttrs += CalValue1;
	if (ItemAttrs != 0)
	{
		CalValue2 = (Value1 * ItemAttrs) / 100;
		Value1 += CalValue2;
	}
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	Value2 = EntityBaseStatusGetAbility(pThis, 0x7B);
	Value1 += Value2;

	BioticBaseSetAbility(pPlayer, 0x5, Value1);

	/*** MELEE_ATTACK_FORCE ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0x6);
	Value2 = BioticBaseGetAbility(pPlayer, 0x20);
	// Level Reward Attack Rate
	pThis = pPlayer + 0x1140;
	RewardValue = EntityBaseStatusGetAbility(pThis, 0x73);
	if (RewardValue != 0)
	{
		CalValue1 = (Value1 * RewardValue) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}
	// VIP Reward Attack
	pThis = pPlayer + 0x1140;
	RewardValue = EntityBaseStatusGetAbility(pThis, 0x72);
	if (RewardValue != 0)
	{
		Value1 += RewardValue;
		CalValue1 = RewardValue >> 2;
		Value2 += CalValue1;
	}
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xBC);
	if (ItemAttrs != 0)
	{
		CalValue1 = (Value1 * ItemAttrs) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}
	// Item Bin Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0x12);
	if (ItemAttrs != 0)
	{
		CalValue1 = (Value1 * ItemAttrs) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	ItemAttrs = GetSocketAttribute(pThis, 0xBC);
	if (ItemAttrs != 0)
	{
		CalValue1 = (Value1 * ItemAttrs) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}

	// Skill 0x10B Melee Attack Force By STR
	pThis = pPlayer + 0x160;
	SkillValue = EntityBaseStatusGetAbility(pThis, 0x10B);
	if (SkillValue != 0)
	{
		StatValue = BioticBaseGetAbility(pPlayer, 0x0);
		CalValue1 = (StatValue * SkillValue) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}
	// Skill 0x10C Melee Attack Force By VIT
	pThis = pPlayer + 0x160;
	SkillValue = EntityBaseStatusGetAbility(pThis, 0x10C);
	if (SkillValue != 0)
	{
		StatValue = BioticBaseGetAbility(pPlayer, 0x1);
		CalValue1 = (StatValue * SkillValue) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}
	// Skill 0x10D Melee Attack Force By INT
	pThis = pPlayer + 0x160;
	SkillValue = EntityBaseStatusGetAbility(pThis, 0x10D);
	if (SkillValue != 0)
	{
		StatValue = BioticBaseGetAbility(pPlayer, 0x2);
		CalValue1 = (StatValue * SkillValue) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}
	// Skill 0x10E Melee Attack Force By AGI
	pThis = pPlayer + 0x160;
	SkillValue = EntityBaseStatusGetAbility(pThis, 0x10E);
	if (SkillValue != 0)
	{
		StatValue = BioticBaseGetAbility(pPlayer, 0x5);
		CalValue1 = (StatValue * SkillValue) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}
	// Skill 0x10F Melee Attack Force By PSY
	pThis = pPlayer + 0x160;
	SkillValue = EntityBaseStatusGetAbility(pThis, 0x10F);
	if (SkillValue != 0)
	{
		StatValue = BioticBaseGetAbility(pPlayer, 0x4);
		CalValue1 = (StatValue * SkillValue) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}

	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0x77);
	if (ItemAttrs != 0)
	{
		CalValue2 = ItemAttrs >> 2;
		Value1 += ItemAttrs;
		Value2 += CalValue2;
	}

	BioticBaseSetAbility(pPlayer, 0x6, Value1);
	BioticBaseSetAbility(pPlayer, 0x20, Value2);

	/*** MISSILE_ATTACK_FORCE ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0x7);
	Value2 = BioticBaseGetAbility(pPlayer, 0x21);
	// Level Reward Attack Rate
	pThis = pPlayer + 0x1140;
	RewardValue = EntityBaseStatusGetAbility(pThis, 0x73);
	if (RewardValue != 0)
	{
		CalValue1 = (Value1 * RewardValue) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}
	// VIP Reward Attack
	pThis = pPlayer + 0x1140;
	RewardValue = EntityBaseStatusGetAbility(pThis, 0x72);
	if (RewardValue != 0)
	{
		Value1 += RewardValue;
		CalValue1 = RewardValue >> 2;
		Value2 += CalValue1;
	}
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xBC);
	if (ItemAttrs != 0)
	{
		CalValue1 = (Value1 * ItemAttrs) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}
	// Item Bin Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0x13);
	if (ItemAttrs != 0)
	{
		CalValue1 = (Value1 * ItemAttrs) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	ItemAttrs = GetSocketAttribute(pThis, 0xBC);
	if (ItemAttrs != 0)
	{
		CalValue1 = (Value1 * ItemAttrs) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}

	// Skill 0x110 Missile Attack Force By DEX
	pThis = pPlayer + 0x160;
	SkillValue = EntityBaseStatusGetAbility(pThis, 0x110);
	if (SkillValue != 0)
	{
		StatValue = BioticBaseGetAbility(pPlayer, 0x3);
		CalValue1 = (StatValue * SkillValue) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}

	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0x78);
	if (ItemAttrs != 0)
	{
		CalValue2 = ItemAttrs >> 2;
		Value1 += ItemAttrs;
		Value2 += CalValue2;
	}

	BioticBaseSetAbility(pPlayer, 0x7, Value1);
	BioticBaseSetAbility(pPlayer, 0x21, Value2);

	/*** MAGIC_ATTACK_FORCE ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0x8);
	Value2 = BioticBaseGetAbility(pPlayer, 0x22);
	// Level Reward Attack Rate
	pThis = pPlayer + 0x1140;
	RewardValue = EntityBaseStatusGetAbility(pThis, 0x73);
	if (RewardValue != 0)
	{
		CalValue1 = (Value1 * RewardValue) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}
	// VIP Reward Attack
	pThis = pPlayer + 0x1140;
	RewardValue = EntityBaseStatusGetAbility(pThis, 0x72);
	if (RewardValue != 0)
	{
		Value1 += RewardValue;
		CalValue1 = RewardValue >> 2;
		Value2 += CalValue1;
	}
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xBC);
	if (ItemAttrs != 0)
	{
		CalValue1 = (Value1 * ItemAttrs) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}
	// Item Bin Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0x11);
	if (ItemAttrs != 0)
	{
		CalValue1 = (Value1 * ItemAttrs) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	ItemAttrs = GetSocketAttribute(pThis, 0xBC);
	if (ItemAttrs != 0)
	{
		CalValue1 = (Value1 * ItemAttrs) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}

	// Skill 0x111 Magic Attack Force By INT
	pThis = pPlayer + 0x160;
	SkillValue = EntityBaseStatusGetAbility(pThis, 0x111);
	if (SkillValue != 0)
	{
		StatValue = BioticBaseGetAbility(pPlayer, 0x2);
		CalValue1 = (StatValue * SkillValue) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}
	// Skill 0x112 Magic Attack Force By PSY
	pThis = pPlayer + 0x160;
	SkillValue = EntityBaseStatusGetAbility(pThis, 0x112);
	if (SkillValue != 0)
	{
		StatValue = BioticBaseGetAbility(pPlayer, 0x4);
		CalValue1 = (StatValue * SkillValue) / 100;
		CalValue2 = CalValue1 >> 2;
		Value1 += CalValue1;
		Value2 += CalValue2;
	}

	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0x76);
	if (ItemAttrs != 0)
	{
		CalValue2 = ItemAttrs >> 2;
		Value1 += ItemAttrs;
		Value2 += CalValue2;
	}

	BioticBaseSetAbility(pPlayer, 0x8, Value1);
	BioticBaseSetAbility(pPlayer, 0x22, Value2);

	/*** MAXLIFE_ADD ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0xD);
	// Level Reward Max Life Rate
	pThis = pPlayer + 0x1140;
	Value2 = EntityBaseStatusGetAbility(pThis, 0x76);
	if (Value2 != 0)
	{
		CalValue1 = (Value1 * Value2) / 100;
		Value1 += CalValue1;
	}
	// VIP Reward Max Life
	pThis = pPlayer + 0x1140;
	Value2 = EntityBaseStatusGetAbility(pThis, 0x75);
	Value1 += Value2;
	// Item Bin Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xF);
	if (ItemAttrs != 0)
	{
		CalValue1 = (Value1 * ItemAttrs) / 100;
		Value1 += CalValue1;
	}
	// Item Bin Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xC0);
	if (ItemAttrs != 0)
	{
		CalValue1 = (Value1 * ItemAttrs) / 100;
		Value1 += CalValue1;
	}
	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0x74);
	if (ItemAttrs != 0)
	{
		CalValue1 = (Value1 * ItemAttrs) / 100;
		Value1 += CalValue1;
	}
	// Skill 0x113 Max Life Add By PSY
	pThis = pPlayer + 0x160;
	SkillValue = EntityBaseStatusGetAbility(pThis, 0x113);
	if (SkillValue != 0)
	{
		StatValue = BioticBaseGetAbility(pPlayer, 0x4);
		CalValue1 = (StatValue * SkillValue) / 100;
		Value1 += CalValue1;
	}

	BioticBaseSetAbility(pPlayer, 0xD, Value1);

	/*** MAXMANA_ADD ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0xF);
	// Item Bin Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xC0);
	if (ItemAttrs != 0)
	{
		CalValue1 = (Value1 * ItemAttrs) / 100;
		Value1 += CalValue1;
	}

	BioticBaseSetAbility(pPlayer, 0xF, Value1);

	/*** ALL_DEFENCE ***/
	// CA_PHYSICS_DEFENCE 0x9
	Value1 = BioticBaseGetAbility(pPlayer, 0x9);
	// Level Reward All Defense
	pThis = pPlayer + 0x1140;
	Value2 = EntityBaseStatusGetAbility(pThis, 0x74);
	Value1 += Value2;
	// Skill 0x115 Physics Defence By Int & Psy
	pThis = pPlayer + 0x160;
	SkillValue = EntityBaseStatusGetAbility(pThis, 0x115);
	if (SkillValue != 0)
	{
		StatValue = BioticBaseGetAbility(pPlayer, 0x2);
		Value2 = BioticBaseGetAbility(pPlayer, 0x4);
		StatValue += Value2;
		CalValue1 = (StatValue * SkillValue) / 100;
		Value1 += CalValue1;
	}
	// Skill 0x118 Physics Defence By Int Rate
	pThis = pPlayer + 0x160;
	SkillValue = EntityBaseStatusGetAbility(pThis, 0x118);
	if (SkillValue != 0)
	{
		StatValue = BioticBaseGetAbility(pPlayer, 0x2);
		CalValue1 = (StatValue * SkillValue) / 100;
		Value1 += CalValue1;
	}
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xB9);
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	CalValue1 = GetSocketAttribute(pThis, 0xB9);
	ItemAttrs += CalValue1;
	if (ItemAttrs != 0)
	{
		CalValue2 = (Value1 * ItemAttrs) / 100;
		Value1 += CalValue2;
	}

	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0x7A);
	if (ItemAttrs != 0)
	{
		Value1 += ItemAttrs;
	}

	BioticBaseSetAbility(pPlayer, 0x9, Value1);

	// CA_MAGIC_DEFENCE 0xA
	Value1 = BioticBaseGetAbility(pPlayer, 0xA);
	// Level Reward All Defense
	pThis = pPlayer + 0x1140;
	Value2 = EntityBaseStatusGetAbility(pThis, 0x74);
	Value1 += Value2;
	// Skill 0x119 Magic Defence By Int Rate
	pThis = pPlayer + 0x160;
	SkillValue = EntityBaseStatusGetAbility(pThis, 0x119);
	if (SkillValue != 0)
	{
		StatValue = BioticBaseGetAbility(pPlayer, 0x2);
		CalValue1 = (StatValue * SkillValue) / 100;
		Value1 += CalValue1;
	}
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xB9);
	// Socket Attribute
	pThis = pPlayer + 0x1E40;
	CalValue1 = GetSocketAttribute(pThis, 0xB9);
	ItemAttrs += CalValue1;
	if (ItemAttrs != 0)
	{
		CalValue2 = (Value1 * ItemAttrs) / 100;
		Value1 += CalValue2;
	}

	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0x79);
	if (ItemAttrs != 0)
	{
		Value1 += ItemAttrs;
	}

	BioticBaseSetAbility(pPlayer, 0xA, Value1);

	/*** MOVE_SPEED_RATE ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0x12);
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0x96);
	if (ItemAttrs != 0)
	{
		Value2 = (Value1 * ItemAttrs) / 100;
		Value1 += Value2;
	}

	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0x70);
	if (ItemAttrs != 0)
	{
		Value2 = (Value1 * ItemAttrs) / 100;
		Value1 += Value2;
	}

	BioticBaseSetAbility(pPlayer, 0x12, Value1);

	/*** ATTACK_SPEED_RATE ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0x13);
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xB4);
	if (ItemAttrs != 0)
	{
		Value2 = (Value1 * ItemAttrs) / 100;
		Value1 += Value2;
	}

	// Item Option(Attr)
	pThis = pPlayer + 0xD00;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0x6F);
	if (ItemAttrs != 0)
	{
		Value2 = (Value1 * ItemAttrs) / 100;
		Value1 += Value2;
	}

	BioticBaseSetAbility(pPlayer, 0x13, Value1);

	/*** MANA_RECOVERY ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0x10);
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xE0);
	if (ItemAttrs > 0)
	{
		Value2 = (Value1 * ItemAttrs) / 100;
		Value1 += Value2;
	}

	BioticBaseSetAbility(pPlayer, 0x10, Value1);


	/*** DROP_CRON_RATE ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0x95);
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xD8);
	if (ItemAttrs > 0)
	{
		Value1 += ItemAttrs;
	}

	BioticBaseSetAbility(pPlayer, 0x95, Value1);

	/*** SKILL_COOL_TIME ***/
	Value1 = BioticBaseGetAbility(pPlayer, 0x96);
	// Item Attribute
	pThis = pPlayer + 0xCF0;
	ItemAttrs = EntityBaseStatusGetAbility(pThis, 0xB8);
	if (ItemAttrs > 0)
	{
		Value1 += ItemAttrs;
	}

	BioticBaseSetAbility(pPlayer, 0x96, Value1);
}

/***
Skill 0x119

CA:
TRANS CA 0x70 - 0x78
CA_SKILL_DAMAGE_RATE CA 0x79
CA_PVE_ATTACK_RATE CA 0x80
CA_PVE_DEFENCE_RATE CA 0x81
CA_CRITICAL_DAMAGE_REDUCTION_RATE 0x82
CA_INC_CRITICAL_DANAGE 0x83
VIP_LEVEL CA 0x90
VIP_ACTIVATE CA 0x91
Smelt Probability CA 0x92
Slill Reinforce Probability CA 0x93
Combine Probability CA 0x94
DROP_CRON_RATE CA 0x95
SKILL_COOL_TIME CA 0x96

***/