#include <Player.h>
#include <MapFunctions.h>
#include <time.h> 

using namespace std; 

extern int ULTLEVELSTAT_ADDRS;
extern int ULTLEVELSTAT_SIZE;

unsigned char TRANS_BUFFER[9] = {0};
unsigned char SAVECONQUERORLEVEL_BUFFER[30] = {0};
unsigned char TRANSSTAT_BUFFER[27] = {0};
unsigned char STATECOUNT_BUFFER[9] = {0};
unsigned char TRANSEXHANGE_BUFFER[92] = {0};

int EnableTransULV = 1;

/******* ASM Funs *******/
//extern int SETABILITY;

/*********** Transcendence System 2.0 ***********/
void CharacterTranscendence(int pDynamic, int pSendPacket)
{
	int addrs;
	int pPlayer;
	int pThis;
	unsigned int CharID;
	int CType;
	//int LV;
	int HLV;
	int pExpScript;
	float CurEXP;
	float MixRate = 100.0;
	int StatValue;
	__int64 EXP64Min;

	addrs = pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	
	addrs = pPlayer + 0x30;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = pPlayer + 0x2C;
	CType = *(reinterpret_cast<int*>(addrs));

	pThis = pPlayer;
	HLV = BioticBaseGetAbility(pThis, 0x65);

	if (HLV == 50)
	{
		pThis = pPlayer;
		CurEXP = PlayerGetCurExpRate(pPlayer);
		if (CurEXP >= MixRate)
		{
			
			// Set Character EXP;
			pExpScript = GetExpScript(164);
			addrs = pExpScript + 0x10;
			EXP64Min = *(reinterpret_cast<__int64*>(addrs));
			
			addrs = pPlayer + 0x1950;
			*(reinterpret_cast<__int64*>(addrs)) = EXP64Min;

			pThis = pPlayer;
			PlayerSendGetExperience(pThis);

			/*** DBTASK_SAVECONQUERORLEVEL ***/
			// +0 CharID
			addrs = (int)SAVECONQUERORLEVEL_BUFFER;
			*(reinterpret_cast<unsigned int*>(addrs)) = CharID;
			// +0x4 ConquerorLevel
			addrs = (int)SAVECONQUERORLEVEL_BUFFER + 0x4;
			*(reinterpret_cast<int*>(addrs)) = 50;
			// +0x8 AttributeType 99 (All Stat)
			addrs = (int)SAVECONQUERORLEVEL_BUFFER + 0x8;
			*(reinterpret_cast<int*>(addrs)) = 99;
			// +0xC AttributeValue 100
			addrs = (int)SAVECONQUERORLEVEL_BUFFER + 0xC;
			*(reinterpret_cast<int*>(addrs)) = 100;
			// +0x10 Stat Points
			addrs = (int)SAVECONQUERORLEVEL_BUFFER + 0xC;
			*(reinterpret_cast<int*>(addrs)) = 0;
			// +0x12 STR
			pThis = pPlayer + 0x1140;
			StatValue = EntityBaseStatusGetAbility(pThis, 0);
			addrs = (int)SAVECONQUERORLEVEL_BUFFER + 0x12;
			*(reinterpret_cast<unsigned short*>(addrs)) = (unsigned short)StatValue;
			// +0x14 DEX
			pThis = pPlayer + 0x1140;
			StatValue = EntityBaseStatusGetAbility(pThis, 3);
			addrs = (int)SAVECONQUERORLEVEL_BUFFER + 0x14;
			*(reinterpret_cast<unsigned short*>(addrs)) = (unsigned short)StatValue;
			// +0x16 PSY
			pThis = pPlayer + 0x1140;
			StatValue = EntityBaseStatusGetAbility(pThis, 4);
			addrs = (int)SAVECONQUERORLEVEL_BUFFER + 0x16;
			*(reinterpret_cast<unsigned short*>(addrs)) = (unsigned short)StatValue;
			// +0x18 INT
			pThis = pPlayer + 0x1140;
			StatValue = EntityBaseStatusGetAbility(pThis, 2);
			addrs = (int)SAVECONQUERORLEVEL_BUFFER + 0x18;
			*(reinterpret_cast<unsigned short*>(addrs)) = (unsigned short)StatValue;
			// +0x1A VIT
			pThis = pPlayer + 0x1140;
			StatValue = EntityBaseStatusGetAbility(pThis, 1);
			addrs = (int)SAVECONQUERORLEVEL_BUFFER + 0x1A;
			*(reinterpret_cast<unsigned short*>(addrs)) = (unsigned short)StatValue;
			// +0x1C AGI
			pThis = pPlayer + 0x1140;
			StatValue = EntityBaseStatusGetAbility(pThis, 5);
			addrs = (int)SAVECONQUERORLEVEL_BUFFER + 0x1C;
			*(reinterpret_cast<unsigned short*>(addrs)) = (unsigned short)StatValue;
			// DBTask Packet
			SendPacketEX(0x007F23A0, 0x82A6, (int)SAVECONQUERORLEVEL_BUFFER, 0x1E);

			/*** Transcendence 2.0 Packet ***/
			// Packet 0x2322
			addrs = (int)TRANS_BUFFER;
			*(reinterpret_cast<char*>(addrs)) = 0;
			addrs = (int)TRANS_BUFFER + 1;
			*(reinterpret_cast<char*>(addrs)) = 1;
			pThis = pDynamic;
			SendPacket(pThis, 0x2322, (int)TRANS_BUFFER, 2);
			// Packet 0x184F
			// +0 CType
			addrs = (int)TRANS_BUFFER;
			*(reinterpret_cast<int*>(addrs)) = CType;
			// +4 CharID
			addrs = (int)TRANS_BUFFER + 4;
			*(reinterpret_cast<int*>(addrs)) = CharID;
			// +8 Enable ULV
			addrs = (int)TRANS_BUFFER + 8;
			*(reinterpret_cast<char*>(addrs)) = 1;
			pThis = pDynamic;
			SendPacket(pThis, 0x184F, (int)TRANS_BUFFER, 9);

			// Set Trans
			pThis = pPlayer;
			BioticBaseSetAbility(pThis, 0x76, 1);

			SetTransMode(CharID);

			// Transcendence 3.0 ULV 1
			/***
			if (EnableTransULV == 1)
			{
				// Settings ULV1
				pThis = pPlayer;
				BioticBaseSetAbility(pThis, 0x78, 1);

				// CalAllAbility
				pThis = pPlayer;
				PlayerCalAllAbility(pThis);

				// Broadcast UpLevel 0x180A
				pThis = pPlayer;
				LV = GetCharAllLevel(pThis);
				pThis = pPlayer;
				BioticBaseSetAbility(pThis, 0x15, LV);
				pThis = pPlayer;
				PlayerBroadcastUpLevel(pThis);

				// Save Database
				pThis = pPlayer;
				SetTransStat(pThis);
			}
			***/
		}
	}
}

/*********** Transcendence Stat ***********/
void TranscendenceStat(int pDynamic, int pSendPacket)
{
	int addrs;
	int SendPacketData;
	int pPlayer;
	int pItem = 0;
	int pThis;
	int TranCase;
	int TransStatAddrs;
	int pStats;

	int STR = 0;
	int DEX = 0;
	int INT = 0;
	int PSY = 0;
	int VIT = 0;
	int AGI = 0;

	int StatusSTR = 0;
	int StatusDEX = 0;
	int StatusINT = 0;
	int StatusPSY = 0;
	int StatusVIT = 0;
	int StatusAGI = 0;

	int STATECOUNT = 0;
	int COUNTTEMP;
	int LV;
	int ULV;

	int ABI;
	int i = 0;
	int Value = 0;
	int CalValue = 0;

	int AttackRate = 0;
	int PvPAttackRate = 0;
	int PvPDefenseRate = 0;
	int AllStatsRate = 0;
	int SkillPoint = 0;

	int MaterialCurStack;
	int ItemIDMaterial = 2886164;
	int nIDMaterial;
	int InventoryMaterial;
	int SlotMaterial;
	int StackMaterial;
	int pItemMaterial;

	int ItemID;
	int nID;
	int Inventory = 0;
	int Slot = 0;
	int OrigStat = 0;
	int StatType;

	__int64 Price = 0x9502F900;
	__int64 NeedExp = 0x1D1A94A2000;
	unsigned int PriceL;
	unsigned int PriceH;
	__int64 CurExp;
	
	unsigned char REMOVEITEM[12] = {0};

	SendPacketData = pSendPacket + 0x4;

	addrs = pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<unsigned int*>(addrs));

	memset(TRANSSTAT_BUFFER,0,sizeof(char)*27);

	// pData +0
	addrs = SendPacketData;
	TranCase = *(reinterpret_cast<unsigned int*>(addrs));

	// Case 0
	if (TranCase == 0)
	{
		// pData +4 ItemID
		addrs = SendPacketData + 0x4;
		ItemID = *(reinterpret_cast<unsigned int*>(addrs));
		// pData +8 nID
		addrs = SendPacketData + 0x8;
		nID = *(reinterpret_cast<unsigned int*>(addrs));
		// pData +C Inventory
		addrs = SendPacketData + 0xC;
		Inventory = *(reinterpret_cast<char*>(addrs));
		// pData +D Slot
		addrs = SendPacketData + 0xD;
		Slot = *(reinterpret_cast<char*>(addrs));
		// pData +E StatType
		addrs = SendPacketData + 0xE;
		StatType = *(reinterpret_cast<unsigned int*>(addrs));

		if (Inventory != 0)
		{
			pThis = pPlayer + 0xCC8;
			pItem = GetItem(pThis, Inventory, Slot);
		}

		if (pItem != 0)
		{
			// Attribute 177 0xB1 AddStat
			OrigStat = GetAttribute(pItem, 0xB1);

			pThis = pPlayer + 0xCC8;
			RemoveItem(pThis, pItem);
		}

		// Assign TransStat
		TransStatAddrs = GetTransStatX();
		addrs = TransStatAddrs;
		STR = *(reinterpret_cast<char*>(addrs));
		addrs = TransStatAddrs + 1;
		DEX = *(reinterpret_cast<char*>(addrs));
		addrs = TransStatAddrs + 2;
		VIT = *(reinterpret_cast<char*>(addrs));
		addrs = TransStatAddrs + 3;
		INT = *(reinterpret_cast<char*>(addrs));
		addrs = TransStatAddrs + 4;
		PSY = *(reinterpret_cast<char*>(addrs));
		addrs = TransStatAddrs + 5;
		AGI = *(reinterpret_cast<char*>(addrs));

		// Origin of Transcendence
		if (StatType == 0x70) STR += OrigStat;
		else if (StatType == 0x71) VIT += OrigStat;
		else if (StatType == 0x72) INT += OrigStat;
		else if (StatType == 0x73) DEX += OrigStat;
		else if (StatType == 0x74) PSY += OrigStat;
		else if (StatType == 0x75) AGI += OrigStat;

		// Save Temp TransStat
		pStats = pPlayer + 0x2070;
		addrs = pStats;
		*(reinterpret_cast<char*>(addrs)) = (char)STR;
		addrs = pStats + 1;
		*(reinterpret_cast<char*>(addrs)) = (char)DEX;
		addrs = pStats + 2;
		*(reinterpret_cast<char*>(addrs)) = (char)VIT;
		addrs = pStats + 3;
		*(reinterpret_cast<char*>(addrs)) = (char)INT;
		addrs = pStats + 4;
		*(reinterpret_cast<char*>(addrs)) = (char)PSY;
		addrs = pStats + 5;
		*(reinterpret_cast<char*>(addrs)) = (char)AGI;


		// Create Packet 0x1850
		addrs = (int)TRANSSTAT_BUFFER;
		*(reinterpret_cast<char*>(addrs)) = 0;
		addrs = (int)TRANSSTAT_BUFFER + 0x1;
		*(reinterpret_cast<int*>(addrs)) = TranCase;
		addrs = (int)TRANSSTAT_BUFFER + 0x5;
		*(reinterpret_cast<int*>(addrs)) = ItemID;
		addrs = (int)TRANSSTAT_BUFFER + 0x9;
		*(reinterpret_cast<int*>(addrs)) = nID;
		addrs = (int)TRANSSTAT_BUFFER + 0xD;
		*(reinterpret_cast<char*>(addrs)) = (char)Inventory;
		addrs = (int)TRANSSTAT_BUFFER + 0xE;
		*(reinterpret_cast<char*>(addrs)) = (char)Slot;
		addrs = (int)TRANSSTAT_BUFFER + 0xF;
		*(reinterpret_cast<int*>(addrs)) = StatType;

		addrs = (int)TRANSSTAT_BUFFER + 0x15;
		*(reinterpret_cast<char*>(addrs)) = (char)STR;
		addrs = (int)TRANSSTAT_BUFFER + 0x16;
		*(reinterpret_cast<char*>(addrs)) = (char)DEX;
		addrs = (int)TRANSSTAT_BUFFER + 0x17;
		*(reinterpret_cast<char*>(addrs)) = (char)VIT;
		addrs = (int)TRANSSTAT_BUFFER + 0x18;
		*(reinterpret_cast<char*>(addrs)) = (char)INT;
		addrs = (int)TRANSSTAT_BUFFER + 0x19;
		*(reinterpret_cast<char*>(addrs)) = (char)PSY;
		addrs = (int)TRANSSTAT_BUFFER + 0x1A;
		*(reinterpret_cast<char*>(addrs)) = (char)AGI;

		addrs = pPlayer + 0x1098;
		pThis = *(reinterpret_cast<int*>(addrs));
		if (pThis != 0)
		{
			SendPacket(pThis, 0x1850, (int)TRANSSTAT_BUFFER, 0x1B);
		}
	}

	// Case 1
	if (TranCase == 1)
	{
		// Check Current Stack
		pThis = pPlayer + 0xCC8;
		MaterialCurStack = GetItemCurrentStack(pThis, ItemIDMaterial);
		if (MaterialCurStack != 0)
		{
			pThis = pPlayer + 0xCC8;
			pItemMaterial = FindItem(pThis, ItemIDMaterial);
			if (pItemMaterial != 0)
			{
				// Remove Item
				addrs = pItemMaterial + 0x24;
				nIDMaterial = *(reinterpret_cast<int*>(addrs));
				pThis = pItemMaterial;
				InventoryMaterial = GetAttribute(pThis, 0xC);
				pThis = pItemMaterial;
				SlotMaterial = GetAttribute(pThis, 0xD);
				pThis = pItemMaterial;
				StackMaterial = GetAttribute(pThis, 0x9);
				StackMaterial -= 1;
				//pThis = pItemMaterial;
				//SetAttribute(pThis, 0x9, StackMaterial);

				addrs = (int)REMOVEITEM;
				*(reinterpret_cast<char*>(addrs)) = 0;
				addrs = (int)REMOVEITEM + 0x1;
				*(reinterpret_cast<int*>(addrs)) = ItemIDMaterial;
				addrs = (int)REMOVEITEM + 0x5;
				*(reinterpret_cast<int*>(addrs)) = nIDMaterial;
				addrs = (int)REMOVEITEM + 0x9;
				*(reinterpret_cast<char*>(addrs)) = (char)InventoryMaterial;
				addrs = (int)REMOVEITEM + 0xA;
				*(reinterpret_cast<char*>(addrs)) = (char)SlotMaterial;
				addrs = (int)REMOVEITEM + 0xB;
				*(reinterpret_cast<char*>(addrs)) = (char)StackMaterial;

				addrs = pPlayer + 0x1098;
				pThis = *(reinterpret_cast<int*>(addrs));
				if (pThis != 0)
				{
					SendPacketEX(pThis, 0x1512, (int)REMOVEITEM, 0xC);
				}

				pThis = pPlayer + 0xCC8;
				RemoveItemsInInventory(pThis, pItemMaterial, 1);

				// pData +4 ItemID
				addrs = (DWORD)SendPacketData + 0x4;
				ItemID = *(reinterpret_cast<unsigned int*>(addrs));
				// pData +8 nID
				addrs = (DWORD)SendPacketData + 0x8;
				nID = *(reinterpret_cast<unsigned int*>(addrs));
				// pData +C Inventory
				addrs = (DWORD)SendPacketData + 0xC;
				Inventory = *(reinterpret_cast<char*>(addrs));
				// pData +D Slot
				addrs = (DWORD)SendPacketData + 0xD;
				Slot = *(reinterpret_cast<char*>(addrs));
				// pData +E StatType
				addrs = (DWORD)SendPacketData + 0xE;
				StatType = *(reinterpret_cast<unsigned int*>(addrs));

				if (Inventory != 0)
				{
					pThis = pPlayer + 0xCC8;
					pItem = GetItem(pThis, Inventory, Slot);
				}

				if (pItem != 0)
				{
					// Attribute 177 0xB1 AddStat
					OrigStat = GetAttribute(pItem, 0xB1);

					pThis = pPlayer + 0xCC8;
					RemoveItem(pThis, pItem);
				}

				// Assign TransStat
				TransStatAddrs = GetTransStatX();
				addrs = (DWORD)TransStatAddrs;
				STR = *(reinterpret_cast<char*>(addrs));
				addrs = (DWORD)TransStatAddrs + 1;
				DEX = *(reinterpret_cast<char*>(addrs));
				addrs = (DWORD)TransStatAddrs + 2;
				VIT = *(reinterpret_cast<char*>(addrs));
				addrs = (DWORD)TransStatAddrs + 3;
				INT = *(reinterpret_cast<char*>(addrs));
				addrs = (DWORD)TransStatAddrs + 4;
				PSY = *(reinterpret_cast<char*>(addrs));
				addrs = (DWORD)TransStatAddrs + 5;
				AGI = *(reinterpret_cast<char*>(addrs));

				// Origin of Transcendence
				if (StatType == 0x70) STR += OrigStat;
				else if (StatType == 0x71) VIT += OrigStat;
				else if (StatType == 0x72) INT += OrigStat;
				else if (StatType == 0x73) DEX += OrigStat;
				else if (StatType == 0x74) PSY += OrigStat;
				else if (StatType == 0x75) AGI += OrigStat;

				// Save Temp TransStat
				pStats = (DWORD)pPlayer + 0x2070;
				addrs = (DWORD)pStats;
				*(reinterpret_cast<char*>(addrs)) = (char)STR;
				addrs = (DWORD)pStats + 1;
				*(reinterpret_cast<char*>(addrs)) = (char)DEX;
				addrs = (DWORD)pStats + 2;
				*(reinterpret_cast<char*>(addrs)) = (char)VIT;
				addrs = (DWORD)pStats + 3;
				*(reinterpret_cast<char*>(addrs)) = (char)INT;
				addrs = (DWORD)pStats + 4;
				*(reinterpret_cast<char*>(addrs)) = (char)PSY;
				addrs = (DWORD)pStats + 5;
				*(reinterpret_cast<char*>(addrs)) = (char)AGI;

				// Create Packet 0x1850
				addrs = (int)TRANSSTAT_BUFFER;
				*(reinterpret_cast<char*>(addrs)) = 0;
				addrs = (int)TRANSSTAT_BUFFER + 0x1;
				*(reinterpret_cast<int*>(addrs)) = TranCase;
				addrs = (int)TRANSSTAT_BUFFER + 0x5;
				*(reinterpret_cast<int*>(addrs)) = ItemID;
				addrs = (int)TRANSSTAT_BUFFER + 0x9;
				*(reinterpret_cast<int*>(addrs)) = nID;
				addrs = (int)TRANSSTAT_BUFFER + 0xD;
				*(reinterpret_cast<char*>(addrs)) = (char)Inventory;
				addrs = (int)TRANSSTAT_BUFFER + 0xE;
				*(reinterpret_cast<char*>(addrs)) = (char)Slot;
				addrs = (int)TRANSSTAT_BUFFER + 0xF;
				*(reinterpret_cast<int*>(addrs)) = StatType;

				addrs = (int)TRANSSTAT_BUFFER + 0x15;
				*(reinterpret_cast<char*>(addrs)) = (char)STR;
				addrs = (int)TRANSSTAT_BUFFER + 0x16;
				*(reinterpret_cast<char*>(addrs)) = (char)DEX;
				addrs = (int)TRANSSTAT_BUFFER + 0x17;
				*(reinterpret_cast<char*>(addrs)) = (char)VIT;
				addrs = (int)TRANSSTAT_BUFFER + 0x18;
				*(reinterpret_cast<char*>(addrs)) = (char)INT;
				addrs = (int)TRANSSTAT_BUFFER + 0x19;
				*(reinterpret_cast<char*>(addrs)) = (char)PSY;
				addrs = (int)TRANSSTAT_BUFFER + 0x1A;
				*(reinterpret_cast<char*>(addrs)) = (char)AGI;

				addrs = pPlayer + 0x1098;
				pDynamic = *(reinterpret_cast<int*>(addrs));
				if (pDynamic != 0)
				{
					SendPacket(pDynamic, 0x1850, (int)TRANSSTAT_BUFFER, 0x1B);
				}
			}
		}
	}

	// Case 2
	if (TranCase == 2)
	{
		// Sub Money
		PriceH = Price >> 32;
		PriceL = (unsigned int)Price;
		pThis = pPlayer;
		PlayerSubMoney(pThis, PriceL, PriceH, 0x4D, 1);

		// Sub EXP
		addrs = (DWORD)pPlayer + 0x1950;
		CurExp = *(reinterpret_cast<__int64*>(addrs));
		CurExp -= NeedExp;
		*(reinterpret_cast<__int64*>(addrs)) = CurExp;

		pThis = pPlayer;
		PlayerSendGetExperience(pThis);

		// Get Assign TransStat
		pStats = (DWORD)pPlayer + 0x2070;

		addrs = (DWORD)pStats;
		STR = *(reinterpret_cast<char*>(addrs));
		STR &= 0xFF;
		addrs = (DWORD)pStats + 1;
		DEX = *(reinterpret_cast<char*>(addrs));
		DEX &= 0xFF;
		addrs = (DWORD)pStats + 2;
		VIT = *(reinterpret_cast<char*>(addrs));
		VIT &= 0xFF;
		addrs = (DWORD)pStats + 3;
		INT = *(reinterpret_cast<char*>(addrs));
		INT &= 0xFF;
		addrs = (DWORD)pStats + 4;
		PSY = *(reinterpret_cast<char*>(addrs));
		PSY &= 0xFF;
		addrs = (DWORD)pStats + 5;
		AGI = *(reinterpret_cast<char*>(addrs));
		AGI &= 0xFF;

		// Set CharTransStat
		// STR
		pThis = pPlayer;
		ABI = BioticBaseGetAbility(pThis, 0x70);
		ABI += STR;
		BioticBaseSetAbility(pThis, 0x70, ABI);
		pThis = pPlayer + 0x1140;
		StatusSTR = EntityBaseStatusGetAbility(pThis, 0x0);
		StatusSTR += STR;
		EntityBaseStatusSetAbility(pThis, 0x0, StatusSTR);

		// VIT
		pThis = pPlayer;
		ABI = BioticBaseGetAbility(pThis, 0x71);
		ABI += VIT;
		BioticBaseSetAbility(pThis, 0x71, ABI);
		pThis = pPlayer + 0x1140;
		StatusVIT = EntityBaseStatusGetAbility(pThis, 0x1);
		StatusVIT += VIT;
		EntityBaseStatusSetAbility(pThis, 0x1, StatusVIT);

		// INT
		pThis = pPlayer;
		ABI = BioticBaseGetAbility(pThis, 0x72);
		ABI += INT;
		BioticBaseSetAbility(pThis, 0x72, ABI);
		pThis = pPlayer + 0x1140;
		StatusINT = EntityBaseStatusGetAbility(pThis, 0x2);
		StatusINT += INT;
		EntityBaseStatusSetAbility(pThis, 0x2, StatusINT);

		// DEX
		pThis = pPlayer;
		ABI = BioticBaseGetAbility(pThis, 0x73);
		ABI += DEX;
		BioticBaseSetAbility(pThis, 0x73, ABI);
		pThis = pPlayer + 0x1140;
		StatusDEX = EntityBaseStatusGetAbility(pThis, 0x3);
		StatusDEX += DEX;
		EntityBaseStatusSetAbility(pThis, 0x3, StatusDEX);

		// PSY
		pThis = pPlayer;
		ABI = BioticBaseGetAbility(pThis, 0x74);
		ABI += PSY;
		BioticBaseSetAbility(pThis, 0x74, ABI);
		pThis = pPlayer + 0x1140;
		StatusPSY = EntityBaseStatusGetAbility(pThis, 0x4);
		StatusPSY += PSY;
		EntityBaseStatusSetAbility(pThis, 0x4, StatusPSY);

		//AGI
		pThis = pPlayer;
		ABI = BioticBaseGetAbility(pThis, 0x75);
		ABI += AGI;
		BioticBaseSetAbility(pThis, 0x75, ABI);
		pThis = pPlayer + 0x1140;
		StatusAGI = EntityBaseStatusGetAbility(pThis, 0x5);
		StatusAGI += AGI;
		EntityBaseStatusSetAbility(pThis, 0x5, StatusAGI);

		// Cal All Ability
		pThis = pPlayer;
		PlayerCalAllAbility(pThis);

		pThis = pPlayer;
		STATECOUNT = BioticBaseGetAbility(pThis, 0x77);
		STATECOUNT += 1;
		BioticBaseSetAbility(pThis, 0x77, STATECOUNT);

		/*********** Transcendence System 3.0 ***********/
		if (EnableTransULV == 1)
		{
			pThis = pPlayer;
			ULV = BioticBaseGetAbility(pThis, 0x78);
			COUNTTEMP = STATECOUNT / 10;
			if (COUNTTEMP > ULV)
			{
				// Clean PreReward
				pThis = pPlayer;
				ULV = BioticBaseGetAbility(pThis, 0x78);

				// All Stats Rate
				AllStatsRate = UltLevelStatScript(ULV, 4);
				pThis = pPlayer + 0x1140;
				EntityBaseStatusSetAbility(pThis, 0x71, AllStatsRate);
				for(i = 0; i < 6; i++ )
				{
					pThis = pPlayer + 0x1140;
					Value = EntityBaseStatusGetAbility(pThis, i);

					pThis = pPlayer + 0x1140;
					AllStatsRate = EntityBaseStatusGetAbility(pThis, 0x71);
					if (AllStatsRate != 0)
					{
						CalValue = (Value * AllStatsRate) / 100;
						Value -= CalValue;
						pThis = pPlayer + 0x1140;
						EntityBaseStatusSetAbility(pThis, i, Value);
					}
				}

				// Setting New ULV
				pThis = pPlayer;
				BioticBaseSetAbility(pThis, 0x78, COUNTTEMP);

				// Set Upgrade Reward
				pThis = pPlayer;
				ULV = BioticBaseGetAbility(pThis, 0x78);

				// Attack Rate
				AttackRate = UltLevelStatScript(ULV, 1);
				pThis = pPlayer + 0x1140;
				EntityBaseStatusSetAbility(pThis, 0x73, AttackRate);

				// PvP Attack Rate
				PvPAttackRate = UltLevelStatScript(ULV, 2);
				pThis = pPlayer + 0x1140;
				EntityBaseStatusSetAbility(pThis, 0x6D, PvPAttackRate);

				// PvP Defense Rate
				PvPDefenseRate = UltLevelStatScript(ULV, 3);
				pThis = pPlayer + 0x1140;
				EntityBaseStatusSetAbility(pThis, 0x6E, PvPAttackRate);

				// All Stats Rate
				AllStatsRate = UltLevelStatScript(ULV, 4);
				pThis = pPlayer + 0x1140;
				EntityBaseStatusSetAbility(pThis, 0x71, AllStatsRate);
				for(i = 0; i < 6; i++ )
				{
					pThis = pPlayer + 0x1140;
					Value = EntityBaseStatusGetAbility(pThis, i);

					pThis = pPlayer + 0x1140;
					AllStatsRate = EntityBaseStatusGetAbility(pThis, 0x71);
					if (AllStatsRate != 0)
					{
						CalValue = (Value * AllStatsRate) / 100;
						Value += CalValue;
						pThis = pPlayer + 0x1140;
						EntityBaseStatusSetAbility(pThis, i, Value);
					}
				}

				// Skill Point
				SkillPoint = UltLevelStatScript(ULV, 5);
				pThis = pPlayer;
				Value = BioticBaseGetAbility(pThis, 0x16);
				Value += SkillPoint;
				pThis = pPlayer;
				BioticBaseSetAbility(pThis, 0x16, Value);

				// CalAllAbility
				pThis = pPlayer;
				PlayerCalAllAbility(pThis);

				// Broadcast UpLevel 0x180A
				pThis = pPlayer;
				LV = GetCharAllLevel(pThis);
				pThis = pPlayer;
				BioticBaseSetAbility(pThis, 0x15, LV);
				pThis = pPlayer;
				PlayerBroadcastUpLevel(pThis);
			}
		}
		/*********** Transcendence System 3.0 END***********/

		// Create Packet 0x1852 STATECOUNT
		pThis = pPlayer;
		STATECOUNT = BioticBaseGetAbility(pThis, 0x77);
		addrs = (int)STATECOUNT_BUFFER;
		*(reinterpret_cast<char*>(addrs)) = 0;
		addrs = (int)STATECOUNT_BUFFER + 0x1;
		*(reinterpret_cast<int*>(addrs)) = STATECOUNT;
		addrs = (int)STATECOUNT_BUFFER + 0x5;
		*(reinterpret_cast<int*>(addrs)) = 0;

		addrs = (DWORD)pPlayer + 0x1098;
		pDynamic = *(reinterpret_cast<int*>(addrs));
		SendPacketEX(pDynamic, 0x1852, (int)STATECOUNT_BUFFER, 0x09);

		// Send CharStatus
		pThis = pPlayer;
		PlayerSendStatus(pThis);

		// StatCount Packet 0x1850
		addrs = (int)TRANSSTAT_BUFFER + 0x1;
		*(reinterpret_cast<int*>(addrs)) = TranCase;
		addrs = (int)TRANSSTAT_BUFFER + 0x5;
		*(reinterpret_cast<int*>(addrs)) = 0;
		addrs = (int)TRANSSTAT_BUFFER + 0x9;
		*(reinterpret_cast<int*>(addrs)) = 0;
		addrs = (int)TRANSSTAT_BUFFER + 0xD;
		*(reinterpret_cast<int*>(addrs)) = 0;
		addrs = (int)TRANSSTAT_BUFFER + 0x11;
		*(reinterpret_cast<int*>(addrs)) = 0;
		addrs = (int)TRANSSTAT_BUFFER + 0x15;
		*(reinterpret_cast<int*>(addrs)) = 0;
		addrs = (int)TRANSSTAT_BUFFER + 0x19;
		*(reinterpret_cast<short*>(addrs)) = 0;
		pThis = pPlayer;
		addrs = (DWORD)pThis + 0x1098;
		pDynamic = *(reinterpret_cast<int*>(addrs));
		if (pDynamic != 0)
		{
			SendPacket(pDynamic, 0x1850, (int)TRANSSTAT_BUFFER, 0x1B);
		}

		// Save Database
		pThis = pPlayer;
		SetTransStat(pThis);
	}
}

int GetTransStatX()
{
	int StateNADDRS;
	unsigned char StateN[6] = {0};
	int i=0,array_size=sizeof(StateN)/sizeof(char);
	srand( (unsigned)time( NULL ) );

	for( i=0; i < 15;i++ )
		StateN[rand()%array_size]+=1;

	StateNADDRS = (DWORD)StateN;

	return StateNADDRS;
}

/*** Player Load Trans Ability ***/
void LoadTransAbility(int pPlayer)
{
	int pThis;
	int Trans = 0;
	int STR = 0;
	int DEX = 0;
	int INT = 0;
	int PSY = 0;
	int VIT = 0;
	int AGI = 0;
	int StatusSTR = 0;
	int StatusDEX = 0;
	int StatusINT = 0;
	int StatusPSY = 0;
	int StatusVIT = 0;
	int StatusAGI = 0;

	pThis = pPlayer;
	Trans = BioticBaseGetAbility(pThis, 0x76);
	if (Trans != 0)
	{
		pThis = pPlayer;
		STR = BioticBaseGetAbility(pThis, 0x70);
		pThis = pPlayer;
		VIT = BioticBaseGetAbility(pThis, 0x71);
		pThis = pPlayer;
		INT = BioticBaseGetAbility(pThis, 0x72);
		pThis = pPlayer;
		DEX = BioticBaseGetAbility(pThis, 0x73);
		pThis = pPlayer;
		PSY = BioticBaseGetAbility(pThis, 0x74);
		pThis = pPlayer;
		AGI = BioticBaseGetAbility(pThis, 0x75);
	}
	
	// Set Player Trans Stat
	pThis = pPlayer + 0x1140;
	StatusSTR = EntityBaseStatusGetAbility(pThis, 0x0);
	StatusSTR += STR;
	pThis = pPlayer + 0x1140;
	EntityBaseStatusSetAbility(pThis, 0x0, StatusSTR);

	pThis = pPlayer + 0x1140;
	StatusVIT = EntityBaseStatusGetAbility(pThis, 0x1);
	StatusVIT += VIT;
	pThis = pPlayer + 0x1140;
	EntityBaseStatusSetAbility(pThis, 0x1, StatusVIT);

	pThis = pPlayer + 0x1140;
	StatusINT = EntityBaseStatusGetAbility(pThis, 0x2);
	StatusINT += INT;
	pThis = pPlayer + 0x1140;
	EntityBaseStatusSetAbility(pThis, 0x2, StatusINT);

	pThis = pPlayer + 0x1140;
	StatusDEX = EntityBaseStatusGetAbility(pThis, 0x3);
	StatusDEX += DEX;
	pThis = pPlayer + 0x1140;
	EntityBaseStatusSetAbility(pThis, 0x3, StatusDEX);

	pThis = pPlayer + 0x1140;
	StatusPSY = EntityBaseStatusGetAbility(pThis, 0x4);
	StatusPSY += PSY;
	pThis = pPlayer + 0x1140;
	EntityBaseStatusSetAbility(pThis, 0x4, StatusPSY);

	pThis = pPlayer + 0x1140;
	StatusAGI = EntityBaseStatusGetAbility(pThis, 0x5);
	StatusAGI += AGI;
	pThis = pPlayer + 0x1140;
	EntityBaseStatusSetAbility(pThis, 0x5, StatusAGI);
	
	pThis = pPlayer;
	PlayerCalAllAbility(pThis);
}

/*********** Transcendence Exhange ***********/
void TranscendenceExhange(int pDynamic, int pSendPacket)
{
	int addrs;
	int pPlayer;
	int pThis;
	int Result;
	int SendPacketData;
	int NpcID;
	int NpcEntityID;
	int ItemID;
	//int Inventory;
	int pInventory;
	//int Slot;
	int pSlot;
	int Stack;
	int error = 0;
	__int64 Cron;
	__int64 CurCron;
	unsigned int CronL;
	unsigned int CronH;
	__int64 Exp;
	__int64 CurExp;
	int pItemGR;
	int AddCurStack;

	// SendPacketData
	SendPacketData = (DWORD)pSendPacket + 0x4;

	addrs = SendPacketData;
	NpcID = *(reinterpret_cast<unsigned int*>(addrs));

	addrs = SendPacketData + 0x4;
	NpcEntityID = *(reinterpret_cast<unsigned int*>(addrs));

	addrs = SendPacketData + 0x9;
	ItemID = *(reinterpret_cast<unsigned int*>(addrs));
	
	addrs = SendPacketData + 0x11;
	//Stack = *(reinterpret_cast<unsigned char*>(addrs));
	Stack = 1;
	
	addrs = (DWORD)pDynamic + 0x534;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	
	// init
	addrs = (int)TRANSEXHANGE_BUFFER;
	*(reinterpret_cast<int*>(addrs)) = 0;

	if (pPlayer != 0)
	{
		pInventory = (int)TRANSEXHANGE_BUFFER + 0x54;
		*(reinterpret_cast<int*>(pInventory)) = 0xFF;
		pSlot = (int)TRANSEXHANGE_BUFFER + 0x58;
		*(reinterpret_cast<int*>(pSlot)) = 0xFF;
		
		pThis = (DWORD)pPlayer + 0xCC8;
		Result = GetFreeInventorySlot(pThis, pInventory, pSlot);
		if (Result != 0)
		{
			pThis = (DWORD)pPlayer;
			Result = PlayerCheckTradeItemWork(pThis, 0);
			if (Result != 0)
			{
				// Create MallItem
				pItemGR = (int)TRANSEXHANGE_BUFFER + 0x1;
				AddCurStack = (int)TRANSEXHANGE_BUFFER +0x50;
				*(reinterpret_cast<int*>(AddCurStack)) = 0;
				pThis = (DWORD)pPlayer + 0xCC8;
				Result = CreateMallItem(pThis, ItemID, Stack, pItemGR, AddCurStack);
				if (Result == 0)
				{
					// Sub Cron
					Cron = TransExhangeScript(ItemID, 1);
					addrs = (DWORD)pPlayer + 0x1958;
					CurCron = *(reinterpret_cast<__int64*>(addrs));
					CurCron -= Cron;
					// Packet
					addrs = (int)TRANSEXHANGE_BUFFER + 0x3E;
					*(reinterpret_cast<__int64*>(addrs)) = CurCron;

					CronH = Cron >> 32;
					CronL = (unsigned int)Cron;
					pThis = (DWORD)pPlayer;
					PlayerSubMoney(pThis, CronL, CronH, 0x8, 1);

					// Sub EXP
					Exp = TransExhangeScript(ItemID, 0);
					addrs = (DWORD)pPlayer + 0x1950;
					CurExp = *(reinterpret_cast<__int64*>(addrs));
					CurExp -= Exp;
					*(reinterpret_cast<__int64*>(addrs)) = CurExp;
					// Packet
					addrs = (int)TRANSEXHANGE_BUFFER + 0x47;
					*(reinterpret_cast<__int64*>(addrs)) = CurExp;

					pThis = (DWORD)pPlayer;
					PlayerSendGetExperience(pThis);

					pThis = (DWORD)pDynamic;
					SendPacket(pThis, 0x151B, (int)TRANSEXHANGE_BUFFER, 0x4E);
				}
				else
				{
					error = 1;
					addrs = (int)TRANSEXHANGE_BUFFER;
					*(reinterpret_cast<int*>(addrs)) = Result;
				}
			}
			else
			{
				error = 1;
				Result = 85;
				addrs = (int)TRANSEXHANGE_BUFFER;
				*(reinterpret_cast<int*>(addrs)) = Result;
			}
		}
		else
		{
			error = 1;
			Result = 4;
			addrs = (int)TRANSEXHANGE_BUFFER;
			*(reinterpret_cast<int*>(addrs)) = Result;
		}
	}
	else
	{
		error = 1;
		Result = 0;
		addrs = (int)TRANSEXHANGE_BUFFER;
		*(reinterpret_cast<int*>(addrs)) = Result;
	}

	if (error == 1)
	{
		pThis = (DWORD)pDynamic;
		SendPacket(pThis, 0x151B, (int)TRANSEXHANGE_BUFFER, 0x1);
	}
}

// AttributeType: 0 = EXP; 1 = Cron; 
__int64 TransExhangeScript(int ItemID, int AttributeType)
{
	__int64 Attribute;
	__int64 Exp = 0;
	__int64 Cron = 0;

	switch(ItemID)
	{
		case 3710017: Exp = 2000000000000; Cron = 2500000000; break;
		case 2887162: Exp = 2000000000000; Cron = 500000000; break;
		case 2896588: Exp = 2000000000000; Cron = 100000000; break;
		case 2909817: Exp = 0; Cron = 50000000000; break;
		case 2909818: Exp = 0; Cron = 100000000000; break;
		case 4456396: Exp = 100000000000000; Cron = 0; break;
		case 2948695: Exp = 30000000000000; Cron = 0; break;
	}
	
	if (AttributeType == 0)
	{
		Attribute = Exp;
		return Attribute;
	}
	else
	{
		Attribute = Cron;
		return Attribute;
	}
}

// GetUltimateLevelStat
int UltLevelStatScript(int UltimateLevel, int UltimateOption)
{
	int addrs;
	int AttackRate = 0;
	int PvPAttackRate = 0;
	int PvPDefenseRate = 0;
	int AllStatsRate = 0;
	int BinPoint = 0;
	int SkillPoint = 0;

	int MaxCount = 0;
	int Offset = 0;
	int Index = 0;
	int BinLevel = 0;
	int CmpLevel = 0;

	if (UltimateLevel < 10) return 0;
	if (UltimateLevel > 400) UltimateLevel = 400;

	Index = UltimateLevel / 10;
	CmpLevel = Index * 10;

	MaxCount = ULTLEVELSTAT_SIZE / 0x18;
	Offset = (DWORD)ULTLEVELSTAT_ADDRS;

	for( int i = 0; i < MaxCount; i++ )
	{
		addrs = Offset;
		BinLevel = *(reinterpret_cast<int*>(addrs));
		if (CmpLevel == BinLevel)
		{
			addrs = Offset + 0x4;
			AttackRate = *(reinterpret_cast<int*>(addrs));
			addrs = Offset + 0x8;
			PvPAttackRate = *(reinterpret_cast<int*>(addrs));
			addrs = Offset + 0xC;
			PvPDefenseRate = *(reinterpret_cast<int*>(addrs));
			addrs = Offset + 0x10;
			AllStatsRate = *(reinterpret_cast<int*>(addrs));
			addrs = Offset + 0x14;
			BinPoint = *(reinterpret_cast<int*>(addrs));
			break;
		}
		Offset += 0x18;
	}

	if (UltimateLevel == BinLevel)
	{
		SkillPoint = BinPoint;
	}
	else
	{
		SkillPoint = 0;
	}

	if (UltimateOption == 1) return AttackRate;
	if (UltimateOption == 2) return PvPAttackRate;
	if (UltimateOption == 3) return PvPDefenseRate;
	if (UltimateOption == 4) return AllStatsRate;
	if (UltimateOption == 5) return SkillPoint;

	return 0;
}