#include <Player.h>
#include <MapFunctions.h>

using namespace std; 

int EXPRATEBROADCAST01_RET = 0x004573EC;
int EXPRATEBROADCAST02_RET = 0x004CEF1E;
int EXPRATEBROADCAST03_RET = 0x004E0102;
int EXPRATEBROADCAST04_RET = 0x005154DB;
int EXPRATEBROADCAST05_RET = 0x005155AB;
int EXPRATEBROADCAST06_RET = 0x0051566C;
int EXPRATEBROADCAST07_RET = 0x00515734;
int EXPRATEBROADCAST08_RET = 0x005157ED;
int EXPRATEBROADCAST09_RET = 0x0051589D;
int EXPRATEBROADCAST10_RET = 0x00544A4D;
int EXPRATEBROADCAST11_RET = 0x005460BF;
int EXPRATEBROADCAST12_RET = 0x0054708F;
int EXPRATEBROADCAST13_RET = 0x005473AD;

int EXPRATEBROADCAST01_DATA;
int EXPRATEBROADCAST01_THIS;
int EXPRATEBROADCAST02_DATA;
int EXPRATEBROADCAST02_THIS;
int EXPRATEBROADCAST03_DATA;
int EXPRATEBROADCAST03_THIS;
int EXPRATEBROADCAST04_DATA;
int EXPRATEBROADCAST04_THIS;
int EXPRATEBROADCAST05_DATA;
int EXPRATEBROADCAST05_THIS;
int EXPRATEBROADCAST06_DATA;
int EXPRATEBROADCAST06_THIS;
int EXPRATEBROADCAST07_DATA;
int EXPRATEBROADCAST07_THIS;
int EXPRATEBROADCAST08_DATA;
int EXPRATEBROADCAST08_THIS;
int EXPRATEBROADCAST09_DATA;
int EXPRATEBROADCAST09_THIS;
int EXPRATEBROADCAST10_DATA;
int EXPRATEBROADCAST10_THIS;
int EXPRATEBROADCAST11_DATA;
int EXPRATEBROADCAST11_THIS;
int EXPRATEBROADCAST12_DATA;
int EXPRATEBROADCAST12_THIS;
int EXPRATEBROADCAST13_DATA;
int EXPRATEBROADCAST13_THIS;

/******* ASM Funs *******/
//extern int SENDPACKET_FUN;

// ExpRate Broadcast 1
void ExpRateBroadcast01()
{
	__asm lea edx,dword ptr ds:[eax+0x2048]
	__asm mov EXPRATEBROADCAST01_DATA,edx

	__asm mov edx,dword ptr ss:[ebp+0xFFFF9D54]
	__asm mov EXPRATEBROADCAST01_THIS,edx

	BroadcastExpRateEX(EXPRATEBROADCAST01_THIS, EXPRATEBROADCAST01_DATA);

	__asm jmp EXPRATEBROADCAST01_RET
}

// ExpRate Broadcast 2
void ExpRateBroadcast02()
{
	__asm lea edx,dword ptr ss:[ebp-0x7C4]
	__asm mov ecx,dword ptr ss:[ebp-0x940]

	__asm mov EXPRATEBROADCAST02_DATA,edx
	__asm mov EXPRATEBROADCAST02_THIS,ecx

	BroadcastExpRate(EXPRATEBROADCAST02_THIS, EXPRATEBROADCAST02_DATA);

	__asm jmp EXPRATEBROADCAST02_RET
}

// ExpRate Broadcast 3
void ExpRateBroadcast03()
{
	__asm lea edx,dword ptr ss:[ebp-0xC]
	__asm mov ecx,dword ptr ss:[ebp-0x10]

	__asm mov EXPRATEBROADCAST03_DATA,edx
	__asm mov EXPRATEBROADCAST03_THIS,ecx

	BroadcastExpRate(EXPRATEBROADCAST03_THIS, EXPRATEBROADCAST03_DATA);

	__asm jmp EXPRATEBROADCAST03_RET
}

// ExpRate Broadcast 4
void ExpRateBroadcast04()
{
	__asm lea edx,dword ptr ss:[ebp-0x8]
	__asm mov ecx,dword ptr ss:[ebp-0x14]

	__asm mov EXPRATEBROADCAST04_DATA,edx
	__asm mov EXPRATEBROADCAST04_THIS,ecx

	BroadcastExpRate(EXPRATEBROADCAST04_THIS, EXPRATEBROADCAST04_DATA);

	__asm jmp EXPRATEBROADCAST04_RET
}

// ExpRate Broadcast 5
void ExpRateBroadcast05()
{
	__asm lea edx,dword ptr ss:[ebp-0x8]
	__asm mov ecx,dword ptr ss:[ebp-0x14]

	__asm mov EXPRATEBROADCAST05_DATA,edx
	__asm mov EXPRATEBROADCAST05_THIS,ecx

	BroadcastExpRate(EXPRATEBROADCAST05_THIS, EXPRATEBROADCAST05_DATA);

	__asm jmp EXPRATEBROADCAST05_RET
}

// ExpRate Broadcast 6
void ExpRateBroadcast06()
{
	__asm lea edx,dword ptr ss:[ebp-0x8]
	__asm mov ecx,dword ptr ss:[ebp-0x10]

	__asm mov EXPRATEBROADCAST06_DATA,edx
	__asm mov EXPRATEBROADCAST06_THIS,ecx

	BroadcastExpRate(EXPRATEBROADCAST06_THIS, EXPRATEBROADCAST06_DATA);

	__asm jmp EXPRATEBROADCAST06_RET
}

// ExpRate Broadcast 7
void ExpRateBroadcast07()
{
	__asm lea edx,dword ptr ss:[ebp-0x4]
	__asm mov ecx,dword ptr ss:[ebp-0x8]

	__asm mov EXPRATEBROADCAST07_DATA,edx
	__asm mov EXPRATEBROADCAST07_THIS,ecx

	BroadcastExpRate(EXPRATEBROADCAST07_THIS, EXPRATEBROADCAST07_DATA);

	__asm jmp EXPRATEBROADCAST07_RET
}

// ExpRate Broadcast 8
void ExpRateBroadcast08()
{
	__asm lea edx,dword ptr ss:[ebp-0x8]
	__asm mov ecx,dword ptr ss:[ebp-0xC]

	__asm mov EXPRATEBROADCAST08_DATA,edx
	__asm mov EXPRATEBROADCAST08_THIS,ecx

	BroadcastExpRate(EXPRATEBROADCAST08_THIS, EXPRATEBROADCAST08_DATA);

	__asm jmp EXPRATEBROADCAST08_RET
}

// ExpRate Broadcast 9
void ExpRateBroadcast09()
{
	__asm lea edx,dword ptr ss:[ebp-0x8]
	__asm mov ecx,dword ptr ss:[ebp-0xC]

	__asm mov EXPRATEBROADCAST09_DATA,edx
	__asm mov EXPRATEBROADCAST09_THIS,ecx

	BroadcastExpRate(EXPRATEBROADCAST09_THIS, EXPRATEBROADCAST09_DATA);

	__asm jmp EXPRATEBROADCAST09_RET
}

// ExpRate Broadcast 10
void ExpRateBroadcast10()
{
	__asm lea edx,dword ptr ss:[ebp-0xC]
	__asm mov ecx,dword ptr ss:[ebp-0x2C]
	
	__asm mov EXPRATEBROADCAST10_DATA,edx
	__asm mov EXPRATEBROADCAST10_THIS,ecx

	BroadcastExpRate(EXPRATEBROADCAST10_THIS, EXPRATEBROADCAST10_DATA);

	__asm jmp EXPRATEBROADCAST10_RET
}

// ExpRate Broadcast 11
void ExpRateBroadcast11()
{
	__asm lea edx,dword ptr ss:[ebp-0x14]
	__asm mov ecx,dword ptr ss:[ebp-0x24]

	__asm mov EXPRATEBROADCAST11_DATA,edx
	__asm mov EXPRATEBROADCAST11_THIS,ecx

	BroadcastExpRate(EXPRATEBROADCAST11_THIS, EXPRATEBROADCAST11_DATA);

	__asm jmp EXPRATEBROADCAST11_RET
}

// ExpRate Broadcast 12
void ExpRateBroadcast12()
{
	__asm lea edx,dword ptr ss:[ebp-0x34]
	__asm mov ecx,dword ptr ss:[ebp-0x50]

	__asm mov EXPRATEBROADCAST12_DATA,edx
	__asm mov EXPRATEBROADCAST12_THIS,ecx

	BroadcastExpRate(EXPRATEBROADCAST12_THIS, EXPRATEBROADCAST12_DATA);

	__asm jmp EXPRATEBROADCAST12_RET
}

// ExpRate Broadcast 13
void ExpRateBroadcast13()
{
	__asm lea edx,dword ptr ss:[ebp-0x2C]
	__asm mov ecx,dword ptr ss:[ebp-0x50]

	__asm mov EXPRATEBROADCAST13_DATA,edx
	__asm mov EXPRATEBROADCAST13_THIS,ecx

	BroadcastExpRate(EXPRATEBROADCAST13_THIS, EXPRATEBROADCAST13_DATA);

	__asm jmp EXPRATEBROADCAST13_RET
}

// 2020 RCM_MAP_EXPRATE_BROADCAST 0x1A44
void BroadcastExpRate(int DynamicPTR, int pData)
{
	int addrs = 0;
	int pThis = 0;
	int TClass = 0;
	int TType = 0;
	unsigned char EXPRATE_BUFFER[4] = {0};
	int EXPRATE_ADDRS = (DWORD)EXPRATE_BUFFER;
	
	*(reinterpret_cast<int*>(EXPRATE_ADDRS)) = 0;

	addrs = (DWORD)pData;
	TType = *(reinterpret_cast<unsigned char*>(addrs));
	//TType += 8;
	addrs = (DWORD)EXPRATE_ADDRS;
	*(reinterpret_cast<unsigned char*>(addrs)) = (unsigned char)TType;

	addrs = (DWORD)pData + 1;
	TClass = *(reinterpret_cast<unsigned char*>(addrs));
	if (TClass == 0xF0) TClass = 0xF9;
	addrs = (DWORD)EXPRATE_ADDRS + 3;
	*(reinterpret_cast<unsigned char*>(addrs)) = (unsigned char)TClass;

	pThis = (DWORD)DynamicPTR;
	SendPacket(pThis, 0x1A44, EXPRATE_ADDRS, 4);
}

void BroadcastExpRateEX(int DynamicPTR, int pData)
{
	int addrs = 0;
	int pThis = 0;
	int TClass = 0;
	int TType = 0;
	unsigned char EXPRATEEX_BUFFER[4] = {0};
	int EXPRATEEX_ADDRS = (DWORD)EXPRATEEX_BUFFER;
	
	*(reinterpret_cast<int*>(EXPRATEEX_ADDRS)) = 0;

	addrs = (DWORD)pData;
	TType = *(reinterpret_cast<unsigned char*>(addrs));
	//TType += 8;
	addrs = (DWORD)EXPRATEEX_ADDRS;
	*(reinterpret_cast<unsigned char*>(addrs)) = (unsigned char)TType;

	addrs = (DWORD)pData + 1;
	TClass = *(reinterpret_cast<unsigned char*>(addrs));
	if (TClass == 0xF0) TClass = 0xF9;
	addrs = (DWORD)EXPRATEEX_ADDRS + 3;
	*(reinterpret_cast<unsigned char*>(addrs)) = (unsigned char)TClass;

	pThis = (DWORD)DynamicPTR;
	SendPacketEX(pThis, 0x1A44, EXPRATEEX_ADDRS, 4);
}
