#include <Player.h>
#include <MapFunctions.h>

using namespace std; 

int CALSTATBYNPC_PLAYER;
int CALSTATBYNPC_SCRIPT;
int CALSTATBYNPC_RET = 0x00508EE3;

unsigned char INITSTATUSBYNPC[18] = {0};
int INITSTATUSBYNPC_ADDRS = (DWORD)INITSTATUSBYNPC;

int CALSTAT_INITPOINT_PLAYER;
int CALSTAT_INITPOINT_SCRIPT;
int CALSTAT_INITPOINT;
int CALSTAT_INITPOINT_RESULT;
int CALSTAT_INITPOINT_RET = 0x005092C1;

unsigned char INITSTATUSBYINITPOINT[18] = {0};
int INITSTATUSBYINITPOINT_ADDRS = (DWORD)INITSTATUSBYINITPOINT;

int CALALLSTAT_PLAYER;
int CALALLSTAT_RET = 0x00508B8B;

unsigned char INITALLSTATUS[18] = {0};
int INITALLSTATUS_ADDRS = (DWORD)INITALLSTATUS;

int CALSKILL_PLAYER;
int CALSKILL_RET = 0x0050AF64;

/**** Reset Stat By NPC ****/
void CalStatPointByNpc()
{
	__asm mov ecx,dword ptr ss:[ebp-0x74]
	__asm mov CALSTATBYNPC_PLAYER,ecx

	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov CALSTATBYNPC_SCRIPT,eax
	
	CalStatRestPointByNpc(CALSTATBYNPC_PLAYER, CALSTATBYNPC_SCRIPT);
	
	__asm jmp CALSTATBYNPC_RET
}

void CalStatRestPointByNpc(int pPlayer, int pResetScript)
{
	int addrs;
	int pThis;
	int i;
	int HLV;
	int AllLV;
	int CharID;
	int CType;
	int pExpScript = 0;
	int AllStats = 0;
	int Value = 0;
	int BaseStat = 0;
	int ResetCount = 0;
	int pResetList = 0;
	int StatType = 0;
	
	pThis = pPlayer;
	HLV = BioticBaseGetAbility(pThis, 0x65);

	if (HLV > 0)
	{
		pThis = pPlayer;
		AllLV = GetCharAllLevel(pThis);
		if (AllLV > 165) AllLV = 165;

		pExpScript = GetExpScript(AllLV);
		// All Stats Attribute 99 0x63
		addrs = pExpScript + 0x3C;
		AllStats = *(reinterpret_cast<int*>(addrs));

		pThis = pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0x70, AllStats);

		for(i = 0; i < 6; i++ )
		{
			pThis = pPlayer + 0x1140;
			Value = EntityBaseStatusGetAbility(pThis, i);
			Value -= AllStats;

			pThis = pPlayer + 0x1140;
			EntityBaseStatusSetAbility(pThis, i, Value);
		}
	}

	addrs = pResetScript + 0x8;
	ResetCount = *(reinterpret_cast<int*>(addrs));

	addrs = pResetScript + 0x4;
	pResetList = *(reinterpret_cast<int*>(addrs));

	if (ResetCount > 0)
	{
		for(i = 0; i < ResetCount; i++ )
		{
			addrs = pResetList + (i * 4);
			StatType = *(reinterpret_cast<int*>(addrs));

			addrs = pPlayer + 0x2C;
			CType = *(reinterpret_cast<int*>(addrs));

			BaseStat = GetRaceBaseAttrVaule(CType, StatType);

			pThis = pPlayer + 0x1140;
			Value = EntityBaseStatusGetAbility(pThis, StatType);
			Value -= BaseStat;

			pThis = pPlayer + 0x1140;
			EntityBaseStatusSetAbility(pThis, StatType, BaseStat);

			pThis = pPlayer;
			BioticBaseAddAbility(pThis, 0x17, Value);
		}
	}
	
	// DBTASK_INITSTATUS 0x4A16
	addrs = pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));
	addrs = INITSTATUSBYNPC_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = CharID;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 0);
	addrs = INITSTATUSBYNPC_ADDRS + 0x4;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 3);
	addrs = INITSTATUSBYNPC_ADDRS + 0x6;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 2);
	addrs = INITSTATUSBYNPC_ADDRS + 0x8;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 4);
	addrs = INITSTATUSBYNPC_ADDRS + 0xA;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 1);
	addrs = INITSTATUSBYNPC_ADDRS + 0xC;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 5);
	addrs = INITSTATUSBYNPC_ADDRS + 0xE;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;
	
	pThis = pPlayer;
	Value = BioticBaseGetAbility(pThis, 0x17);
	addrs = INITSTATUSBYNPC_ADDRS + 0x10;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	SendPacketEX(0x7F23A0, 0x4A16, INITSTATUSBYNPC_ADDRS, 0x12);

	if (HLV > 0)
	{
		pThis = pPlayer + 0x1140;
		AllStats = EntityBaseStatusGetAbility(pThis, 0x70);

		for(i = 0; i < 6; i++ )
		{
			pThis = pPlayer + 0x1140;
			Value = EntityBaseStatusGetAbility(pThis, i);
			Value += AllStats;

			pThis = pPlayer + 0x1140;
			EntityBaseStatusSetAbility(pThis, i, Value);
		}
	}
}

/**** Reset Stat By Item & InitPoint ****/
void CalAllStatInitPoint()
{
	__asm mov ecx,dword ptr ss:[ebp-0x7C]
	__asm mov CALSTAT_INITPOINT_PLAYER,ecx

	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov CALSTAT_INITPOINT_SCRIPT,eax

	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov CALSTAT_INITPOINT,edx
	
	__asm lea eax,dword ptr ss:[ebp-0x9]
	__asm mov CALSTAT_INITPOINT_RESULT,eax

	CalAllStatAndInitPoint(CALSTAT_INITPOINT_PLAYER, CALSTAT_INITPOINT_SCRIPT, CALSTAT_INITPOINT, CALSTAT_INITPOINT_RESULT);
	
	__asm jmp CALSTAT_INITPOINT_RET	
}

void CalAllStatAndInitPoint(int pPlayer, int pResetScript, int InitPoint, int pResult)
{
	int addrs;
	int pThis;
	int i;
	int HLV;
	int AllLV;
	int CharID;
	int CType;
	int pExpScript = 0;
	int AllStats = 0;
	int Value = 0;
	int CalValue = 0;
	int BaseStat = 0;
	int ResetCount = 0;
	int pResetList = 0;
	int StatType = 0;

	pThis = pPlayer;
	HLV = BioticBaseGetAbility(pThis, 0x65);

	if (HLV > 0)
	{
		pThis = pPlayer;
		AllLV = GetCharAllLevel(pThis);
		if (AllLV > 165) AllLV = 165;

		pExpScript = GetExpScript(AllLV);
		// All Stats Attribute 99 0x63
		addrs = pExpScript + 0x3C;
		AllStats = *(reinterpret_cast<int*>(addrs));

		pThis = pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0x70, AllStats);

		for(i = 0; i < 6; i++ )
		{
			pThis = pPlayer + 0x1140;
			Value = EntityBaseStatusGetAbility(pThis, i);
			Value -= AllStats;

			pThis = pPlayer + 0x1140;
			EntityBaseStatusSetAbility(pThis, i, Value);
		}
	}

	addrs = pResetScript + 0x8;
	ResetCount = *(reinterpret_cast<int*>(addrs));

	addrs = pResetScript + 0x4;
	pResetList = *(reinterpret_cast<int*>(addrs));

	if (ResetCount > 0)
	{
		for(i = 0; i < ResetCount; i++ )
		{
			addrs = pResetList + (i * 4);
			StatType = *(reinterpret_cast<int*>(addrs));

			addrs = pPlayer + 0x2C;
			CType = *(reinterpret_cast<int*>(addrs));

			BaseStat = GetRaceBaseAttrVaule(CType, StatType);

			pThis = pPlayer + 0x1140;
			Value = EntityBaseStatusGetAbility(pThis, StatType);

			if (InitPoint == 0)
			{
				pThis = pPlayer + 0x1140;
				EntityBaseStatusSetAbility(pThis, StatType, BaseStat);

				Value -= BaseStat;
				pThis = pPlayer;
				BioticBaseAddAbility(pThis, 0x17, Value);

				addrs = pResult;
				*(reinterpret_cast<char*>(addrs)) = 1;
			}
			else
			{
				CalValue = Value - InitPoint;
				if (CalValue < BaseStat)
				{
					pThis = pPlayer + 0x1140;
					EntityBaseStatusSetAbility(pThis, StatType, BaseStat);

					Value -= BaseStat;
					pThis = pPlayer;
					BioticBaseAddAbility(pThis, 0x17, Value);

					addrs = pResult;
					*(reinterpret_cast<char*>(addrs)) = 1;
				}
				else
				{
					pThis = pPlayer + 0x1140;
					EntityBaseStatusSetAbility(pThis, StatType, CalValue);

					pThis = pPlayer;
					BioticBaseAddAbility(pThis, 0x17, InitPoint);

					addrs = pResult;
					*(reinterpret_cast<char*>(addrs)) = 1;
				}
			}
		}
	}

	// DBTASK_INITSTATUS 0x4A16
	addrs = pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));
	addrs = INITSTATUSBYINITPOINT_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = CharID;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 0);
	addrs = INITSTATUSBYINITPOINT_ADDRS + 0x4;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 3);
	addrs = INITSTATUSBYINITPOINT_ADDRS + 0x6;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 2);
	addrs = INITSTATUSBYINITPOINT_ADDRS + 0x8;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 4);
	addrs = INITSTATUSBYINITPOINT_ADDRS + 0xA;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 1);
	addrs = INITSTATUSBYINITPOINT_ADDRS + 0xC;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 5);
	addrs = INITSTATUSBYINITPOINT_ADDRS + 0xE;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;
	
	pThis = pPlayer;
	Value = BioticBaseGetAbility(pThis, 0x17);
	addrs = INITSTATUSBYINITPOINT_ADDRS + 0x10;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	SendPacketEX(0x7F23A0, 0x4A16, INITSTATUSBYINITPOINT_ADDRS, 0x12);

	if (HLV > 0)
	{
		pThis = pPlayer + 0x1140;
		AllStats = EntityBaseStatusGetAbility(pThis, 0x70);

		for(i = 0; i < 6; i++ )
		{
			pThis = pPlayer + 0x1140;
			Value = EntityBaseStatusGetAbility(pThis, i);
			Value += AllStats;

			pThis = pPlayer + 0x1140;
			EntityBaseStatusSetAbility(pThis, i, Value);
		}
	}
}

/**** Reset All Stat By Item ****/
void CalAllStatPointByItem()
{
	__asm mov eax,dword ptr ss:[ebp-0x58]
	__asm mov CALALLSTAT_PLAYER,eax

	CalAllStatPointByItemetc(CALALLSTAT_PLAYER);

	__asm jmp CALALLSTAT_RET
}

void CalAllStatPointByItemetc(int pPlayer)
{
	int addrs;
	int pThis;
	int i;
	int HLV;
	int AllLV;
	int CharID;
	int CType;
	int pExpScript = 0;
	int AllStats = 0;
	int AllPoint = 0;
	int Value = 0;

	pThis = pPlayer;
	AllLV = GetCharAllLevel(pThis);
	if (AllLV > 165) AllLV = 165;

	pExpScript = GetExpScript(AllLV);
	// All Stats Attribute 99 0x63
	addrs = pExpScript + 0x3C;
	AllStats = *(reinterpret_cast<int*>(addrs));

	pThis = pPlayer + 0x1140;
	EntityBaseStatusSetAbility(pThis, 0x70, AllStats);

	addrs = pPlayer + 0x2C;
	CType = *(reinterpret_cast<int*>(addrs));

	for(i = 0; i < 6; i++ )
	{
		Value = GetRaceBaseAttrVaule(CType, i);

		pThis = pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, i, Value);
	}

	AllPoint = GetAllStatPoints(AllLV);
	pThis = pPlayer;
	BioticBaseSetAbility(pThis, 0x17, AllPoint);

	// DBTASK_INITSTATUS 0x4A16
	addrs = pPlayer + 0x30;
	CharID = *(reinterpret_cast<int*>(addrs));
	addrs = INITALLSTATUS_ADDRS;
	*(reinterpret_cast<int*>(addrs)) = CharID;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 0);
	addrs = INITALLSTATUS_ADDRS + 0x4;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 3);
	addrs = INITALLSTATUS_ADDRS + 0x6;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 2);
	addrs = INITALLSTATUS_ADDRS + 0x8;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 4);
	addrs = INITALLSTATUS_ADDRS + 0xA;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 1);
	addrs = INITALLSTATUS_ADDRS + 0xC;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer + 0x1140;
	Value = EntityBaseStatusGetAbility(pThis, 5);
	addrs = INITALLSTATUS_ADDRS + 0xE;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	pThis = pPlayer;
	Value = BioticBaseGetAbility(pThis, 0x17);
	addrs = INITALLSTATUS_ADDRS + 0x10;
	*(reinterpret_cast<unsigned short*>(addrs)) = Value;

	SendPacketEX(0x7F23A0, 0x4A16, INITALLSTATUS_ADDRS, 0x12);

	pThis = pPlayer;
	HLV = BioticBaseGetAbility(pThis, 0x65);

	if (HLV > 0)
	{
		pThis = pPlayer + 0x1140;
		AllStats = EntityBaseStatusGetAbility(pThis, 0x70);

		for(i = 0; i < 6; i++ )
		{
			Value = GetRaceBaseAttrVaule(CType, i);
			Value += AllStats;

			pThis = pPlayer + 0x1140;
			EntityBaseStatusSetAbility(pThis, i, Value);
		}
	}
}

/**** Reset Skill Point ****/
void CalSkillPoint()
{
	__asm mov ecx,dword ptr ss:[ebp-0xCB4]
	__asm mov CALSKILL_PLAYER,ecx

	GetAllSkillPoint(CALSKILL_PLAYER);

	__asm mov dword ptr ss:[ebp-0xC98],eax
	__asm jmp CALSKILL_RET
}

int GetAllSkillPoint(int pPlayer)
{
	int SkillPoint = 0;
	int pThis;
	int ULV = 0;
	int Value = 0;

	pThis = pPlayer;
	SkillPoint = BioticBaseGetAbility(pThis, 0x15);
	if (SkillPoint > 115) SkillPoint = 115;

	pThis = pPlayer;
	ULV = BioticBaseGetAbility(pThis, 0x78);
	if (ULV > 400) ULV = 400;

	Value = ULV / 50;
	if (ULV > 9) Value += 1;

	SkillPoint += Value;

	return SkillPoint;
}
