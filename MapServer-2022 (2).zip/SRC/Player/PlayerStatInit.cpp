#include <Player.h>
#include <MapFunctions.h>

using namespace std; 

extern int CRON_DROP_RATE;

void PlayerAttrInit()
{
	int pPlayer;
	int RetAddr = 0x00516600;
	__asm mov pPlayer,ecx

	SetCharAllLevel(pPlayer);

	PlayerAttriButeInit(pPlayer);

	__asm jmp RetAddr
}

void PlayerAttriButeInit(int pPlayer)
{
	int addrs;
	int pThis;
	int i = 0;
	int LV = 0;
	int HLV = 0;
	int ULV = 0;
	int AllLV = 0;
	int CLCLV = 0;
	int pExpScript = 0;

	int Value = 0;
	int CalValue = 0;
	int AllStats = 0;
	int EXPBonusRate = 0;
	int MaxLifeRate = 0;
	int AllDefense = 0;
	int AttackRate = 0;
	int PvPAttackRate = 0;
	int PvPDefenseRate = 0;
	int AllStatsRate = 0;

	pThis = pPlayer;
	LV = BioticBaseGetAbility(pThis, 0x15);
	pThis = pPlayer;
	HLV = BioticBaseGetAbility(pThis, 0x65);
	pThis = pPlayer;
	ULV = BioticBaseGetAbility(pThis, 0x78);
	AllLV = LV + HLV + ULV;

	// Settings Money Drop Rate
	pThis = pPlayer + 0x1140;
	EntityBaseStatusSetAbility(pThis, 0x95, CRON_DROP_RATE);

	if (HLV > 0)
	{
		if (AllLV > 165) CLCLV = 165;
		else CLCLV = AllLV;

		pExpScript = GetExpScript(CLCLV);

		// All Stats Attribute 99 0x63
		addrs = pExpScript + 0x3C;
		AllStats = *(reinterpret_cast<int*>(addrs));
		// EXP Bonus Rate Attribute 86 0x56
		addrs = pExpScript + 0x44;
		EXPBonusRate = *(reinterpret_cast<int*>(addrs));
		// Max Life Rate Attribute 23 0x17
		addrs = pExpScript + 0x4C;
		MaxLifeRate = *(reinterpret_cast<int*>(addrs));
		// All Defense Attribute 72 0x48
		addrs = pExpScript + 0x54;
		AllDefense = *(reinterpret_cast<int*>(addrs));

		// All Stats
		pThis = pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0x70, AllStats);

		for(i = 0; i < 6; i++ )
		{
			pThis = pPlayer + 0x1140;
			Value = EntityBaseStatusGetAbility(pThis, i);
			pThis = pPlayer + 0x1140;
			AllStats = EntityBaseStatusGetAbility(pThis, 0x70);
			Value += AllStats;
			pThis = pPlayer + 0x1140;
			EntityBaseStatusSetAbility(pThis, i, Value);
		}

		// EXP Bonus Rate (pPlater + 0x1AA4)
		pThis = pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0x77, EXPBonusRate);
		addrs = pPlayer + 0x1AA4;
		Value = *(reinterpret_cast<int*>(addrs));
		EXPBonusRate += Value;
		*(reinterpret_cast<int*>(addrs)) = EXPBonusRate;

		// Max Life Rate
		pThis = pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0x76, MaxLifeRate);

		// All Defense
		pThis = pPlayer + 0x1140;
		EntityBaseStatusSetAbility(pThis, 0x74, AllDefense);

		if (ULV > 9)
		{
			// Attack Rate
			AttackRate = UltLevelStatScript(ULV, 1);
			pThis = pPlayer + 0x1140;
			EntityBaseStatusSetAbility(pThis, 0x73, AttackRate);

			// PvP Attack Rate
			PvPAttackRate = UltLevelStatScript(ULV, 2);
			pThis = pPlayer + 0x1140;
			EntityBaseStatusSetAbility(pThis, 0x6D, PvPAttackRate);

			// PvP Defense Rate
			PvPDefenseRate = UltLevelStatScript(ULV, 3);
			pThis = pPlayer + 0x1140;
			EntityBaseStatusSetAbility(pThis, 0x6E, PvPAttackRate);

			// All Stats Rate
			AllStatsRate = UltLevelStatScript(ULV, 4);
			pThis = pPlayer + 0x1140;
			EntityBaseStatusSetAbility(pThis, 0x71, AllStatsRate);
			for(i = 0; i < 6; i++ )
			{
				pThis = pPlayer + 0x1140;
				Value = EntityBaseStatusGetAbility(pThis, i);

				pThis = pPlayer + 0x1140;
				AllStatsRate = EntityBaseStatusGetAbility(pThis, 0x71);
				if (AllStatsRate != 0)
				{
					CalValue = (Value * AllStatsRate) / 100;
					Value += CalValue;
					pThis = pPlayer + 0x1140;
					EntityBaseStatusSetAbility(pThis, i, Value);
				}
			}
		}
		/*** ULV END ***/
	}
}
