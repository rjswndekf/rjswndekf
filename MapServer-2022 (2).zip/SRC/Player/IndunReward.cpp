#include <Player.h>
#include <MapFunctions.h>

using namespace std;

int STAGE_DATAEXP;
int STAGE_RAWARTYPE;
int STAGE_RAWARINFO;
int STAGE_PLAYER;
int STAGE_RAWAR_RET = 0x00611C2C;


int ELEMENTAL_ADDEXP_FUN = 0x004FABE0;
int ELEMENTAL_ADDEXP_RET = 0x00611D3D;

int ELEMENTAL_NOTICE_RET = 0x00611E5D;

// Elemental Indun SendStageRewardEXP
void ElementalStageRewardEXP()
{
	__asm movzx edx,byte ptr ss:[ebp+0x8]
	__asm mov STAGE_RAWARTYPE,edx
	__asm mov eax,dword ptr ss:[ebp-0x370]
	__asm mov STAGE_RAWARINFO,eax
	__asm mov ecx,dword ptr ss:[ebp-0x1C]
	__asm mov STAGE_PLAYER,ecx

	__asm lea edx,dword ptr ss:[ebp-0x6C]
	__asm mov STAGE_DATAEXP,edx

	StageRewardInfo(STAGE_PLAYER, STAGE_RAWARINFO, STAGE_RAWARTYPE, STAGE_DATAEXP);

	__asm jmp STAGE_RAWAR_RET
}

void StageRewardInfo(int pPlayer, int pStageRewardInfo, int RewardType, int pExpData)
{
	float RewardExpRate;
	int addrs;
	int pThis;
	int IndunType;
	int Stage;
	int pRewardExp;
	__int64 RewardExp;

	addrs = pStageRewardInfo + 0xE0;
	Stage = *(reinterpret_cast<int*>(addrs));

	addrs = pStageRewardInfo + (RewardType * 0x64) + 0x10C;
	IndunType = *(reinterpret_cast<int*>(addrs));

	RewardExp = GetRewardExp(IndunType, Stage);

	addrs = pStageRewardInfo + (RewardType * 0x64) + 0x12C;
	*(reinterpret_cast<__int64*>(addrs)) = RewardExp;

	pRewardExp = pStageRewardInfo + (RewardType * 0x64) + 0x12C;
	pThis = pPlayer;
	RewardExpRate = GetIndunRewardExpRate(pThis, pRewardExp);

	addrs = pExpData;
	*(reinterpret_cast<float*>(addrs)) = RewardExpRate;
}

// IndunRewardExp v2022
__int64 GetRewardExp(int IndunType, int Stage)
{
	__int64 RewardExp = 0;

	if (IndunType == 0)
	{
		if (Stage == 1) RewardExp = 500000000;
		if (Stage == 2) RewardExp = 500000000;
		if (Stage == 3) RewardExp = 500000000;
		if (Stage == 4) RewardExp = 500000000;
		if (Stage == 5) RewardExp = 3000000000;
	}
	else if (IndunType == 1)
	{
		if (Stage == 1) RewardExp = 800000000;
		if (Stage == 2) RewardExp = 800000000;
		if (Stage == 3) RewardExp = 800000000;
		if (Stage == 4) RewardExp = 800000000;
		if (Stage == 5) RewardExp = 800000000;
		if (Stage == 6) RewardExp = 3700000000;
		if (Stage == 7) RewardExp = 3700000000;
		if (Stage == 8) RewardExp = 4300000000;
		if (Stage == 9) RewardExp = 4300000000;
		if (Stage == 10) RewardExp = 30000000000;
	}
	else if (IndunType == 2)
	{
		if (Stage == 1) RewardExp = 2500000000;
		if (Stage == 2) RewardExp = 2500000000;
		if (Stage == 3) RewardExp = 2500000000;
		if (Stage == 4) RewardExp = 2500000000;
		if (Stage == 5) RewardExp = 13000000000;
		if (Stage == 6) RewardExp = 5500000000;
		if (Stage == 7) RewardExp = 5500000000;
		if (Stage == 8) RewardExp = 6500000000;
		if (Stage == 9) RewardExp = 6500000000;
		if (Stage == 10) RewardExp = 37000000000;
		if (Stage == 11) RewardExp = 17000000000;
		if (Stage == 12) RewardExp = 17000000000;
		if (Stage == 13) RewardExp = 21000000000;
		if (Stage == 14) RewardExp = 21000000000;
		if (Stage == 15) RewardExp = 90000000000;
	}

	return RewardExp;
}

void ElementalAddExperience()
{
	__asm push 0x0
	__asm push 0x3F800000
	// RewardType
	__asm movzx edx,byte ptr ss:[ebp+0x8]
	__asm imul edx,edx,0x64
	__asm mov ecx,dword ptr ss:[ebp-0x370]
	// RewardEXPL
	__asm mov eax,dword ptr ds:[ecx+edx+0x12C]
	// RewardEXPH
	__asm mov edx,dword ptr ds:[ecx+edx+0x130]
	__asm push edx
	__asm push eax
	__asm push edx
	__asm push eax
	// pPlayer
	__asm mov ecx,dword ptr ss:[ebp-0x1C]
	__asm call ELEMENTAL_ADDEXP_FUN

	__asm jmp ELEMENTAL_ADDEXP_RET
}

void ElementalExpNotice()
{
	// RewardType
	__asm movzx edx,byte ptr ss:[ebp+0x8]
	__asm imul edx,edx,0x64
	__asm mov ecx,dword ptr ss:[ebp-0x370]
	// RewardEXPL
	__asm mov eax,dword ptr ds:[ecx+edx+0x12C]
	// RewardEXPH
	__asm mov edx,dword ptr ds:[ecx+edx+0x130]

	__asm mov dword ptr ss:[ebp-0xB6],eax
	__asm mov dword ptr ss:[ebp-0xB2],edx

	__asm jmp ELEMENTAL_NOTICE_RET
}
