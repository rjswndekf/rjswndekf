#include <Player.h>
#include <MapFunctions.h>

using namespace std; 

unsigned char LASTDROPEXP_BUFFER[20] = {0};
int LASTDROPEXP_ADDRS = (DWORD)LASTDROPEXP_BUFFER;
int LASTDROPEXP_RET = 0x0041C285;

unsigned char EXPRECOVERY_BUFFER[17] = {0};
int EXPRECOVERY_ADDRS = (DWORD)EXPRECOVERY_BUFFER;
int EXPRECOVERY_RET_TARGET = 0x00441CFA;
int EXPRECOVERY_RET_NOMONEY = 0x00441B3D;

/******* ASM Funs *******/
extern int SENDPACKET_FUN;


// **** RCM_MAP_LAST_DROP_EXP 0x182C Patch ***********************************************
void LastDropExp()
{
	__asm mov edi, LASTDROPEXP_ADDRS

	__asm mov eax, dword ptr ss:[ebp-0x18C0]
	__asm mov dword ptr ds:[edi], eax

	__asm mov eax, dword ptr ss:[ebp-0x18BC]
	__asm mov dword ptr ds:[edi+0x4], eax

	// LAST_DROP_EXP %
	__asm mov eax, dword ptr ss:[ebp-0x18B8]
	__asm mov dword ptr ds:[edi+0x8], eax

	 // [PlayerPTR+0x1968] = LAST_DROP_EXP L_DWORD
	__asm mov eax, dword ptr ss:[edx+0x1968]
	__asm mov dword ptr ds:[edi+0x0C], eax

	 // [PlayerPTR+0x196C] = LAST_DROP_EXP H_DWORD
	__asm mov eax, dword ptr ss:[edx+0x196C]
	__asm mov dword ptr ds:[edi+0x10], eax

	__asm mov edi, LASTDROPEXP_ADDRS
	__asm push 0x14
	__asm push edi
	__asm push 0x182C
	__asm mov eax,dword ptr ss:[ebp+0xFFFF8468]
	__asm mov edx,dword ptr ds:[eax]
	__asm mov ecx,dword ptr ss:[ebp+0xFFFF8468]
	__asm call dword ptr ds:[edx+0x2C]

	__asm jmp LASTDROPEXP_RET

}

// **** RCM_MAP_EXP_RECOVERY 0x1817 Patch ***********************************************
void ExpRecoveryNPC()
{
	// Check Money
	__asm mov edx,dword ptr ss:[ebp-0x1C]
	__asm mov ecx,dword ptr ds:[edx+0x195C]
	__asm mov eax,dword ptr ds:[edx+0x196C]
	__asm cmp ecx,eax
	__asm jb NOT_ENOUGH_MONEY

	__asm mov ecx,dword ptr ds:[edx+0x1958]
	__asm mov eax,dword ptr ds:[edx+0x1968]
	__asm cmp ecx,eax
	__asm jb NOT_ENOUGH_MONEY

	// Deduct Money
	__asm movq mm0,qword ptr ds:[edx+0x1958]
	__asm movq mm1,qword ptr ds:[edx+0x1968]
	__asm psubd mm0,mm1
	__asm movq qword ptr ds:[edx+0x1958],mm0

	// Add Current Experience
	__asm movq mm0,qword ptr ds:[edx+0x1950]
	__asm movq mm1,qword ptr ds:[edx+0x1968]
	__asm paddd mm0,mm1
	__asm movq qword ptr ds:[edx+0x1950],mm0

	// Clean LAST_DROP_EXP
	__asm mov dword ptr ds:[edx+0x1968],0x0
	__asm mov dword ptr ds:[edx+0x196C],0x0
	__asm emms

	// Create Packet
	__asm mov edi, EXPRECOVERY_ADDRS
	__asm mov byte ptr ds:[edi],0x0
	__asm mov eax, dword ptr ds:[edx+0x1950]
	__asm mov dword ptr ds:[edi+0x1],eax
	__asm mov eax, dword ptr ds:[edx+0x1954]
	__asm mov dword ptr ds:[edi+0x5],eax
	__asm mov eax, dword ptr ds:[edx+0x1958]
	__asm mov dword ptr ds:[edi+0x9],eax
	__asm mov eax, dword ptr ds:[edx+0x195C]
	__asm mov dword ptr ds:[edi+0xD],eax

	__asm mov ecx,dword ptr ss:[ebp-0x1C]
	__asm mov edx,dword ptr ds:[ecx+0x1098]
	__asm mov dword ptr ss:[ebp-0x5C],edx
	__asm cmp dword ptr ss:[ebp-0x5C],0x0
	__asm je RET_TARGET

	// Send Packet
	__asm mov edi, EXPRECOVERY_ADDRS
	__asm push 0x11
	__asm push edi
	__asm push 0x1817
	__asm mov ecx,dword ptr ss:[ebp-0x5C]
	__asm call SENDPACKET_FUN

RET_TARGET:
	__asm jmp EXPRECOVERY_RET_TARGET

NOT_ENOUGH_MONEY:
	__asm jmp EXPRECOVERY_RET_NOMONEY
}