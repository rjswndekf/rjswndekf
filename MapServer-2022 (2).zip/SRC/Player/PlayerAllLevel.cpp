#include <Player.h>
#include <MapFunctions.h>

using namespace std; 

int ITEMINITSTAT_RET = 0x00508A10;
int NPCINITSKILLCHECK_RET = 0x00442F8B;
int NPCINITSKILL_RET = 0x0050AA41;
int NPCINITSTAT_RET = 0x0044349D;
int RIGUILDMASTER_RET = 0x005AD3A7;
int RIGUILDMEMBER_RET = 0x005B531B;

int LEARNSKILL_PLAYER;
int LEARNSKILL_RET = 0x00504D43;

int QUESTGRANT_PLAYER;
int QUESTGRANT_RET = 0x00596DC9;

int INDUN1_PLAYER;
int INDUN2_PLAYER;
int INDUN_PLAYER;

int INDUN_MIN_RETORIG = 0x00478200;
int INDUN_MIN_RETEXIT = 0x00478204;
int INDUN_MIN_RETTRAN = 0x0047820E;
int INDUN_MAX_RETORIG = 0x0047822E;
int INDUN_ENT_RET = 0x00478695;

/******* ASM Funs *******/
extern int GETABILITY;

// **** RCM_MAP_MALL_USE_INITSTATUS 0x1433 Patch ***************************
void ItemInitStatLevel()
{
	__asm push 0x15
	__asm mov ecx,dword ptr ss:[ebp-0x58]
	__asm call GETABILITY
	__asm cmp eax,0x73
	__asm jbe NOHLV
	__asm mov eax,0x73

NOHLV:
	__asm mov esi,eax
	__asm push 0x65
	__asm mov ecx,dword ptr ss:[ebp-0x58]
	__asm call GETABILITY
	__asm add eax,esi

	__asm jmp ITEMINITSTAT_RET
}

// **** RCM_MAP_INIT_SKILL 0x1818 Patch ************************************
void NpcInitSkillCheck()
{
	__asm mov dword ptr ss:[ebp-0x48],0x0
	__asm push 0x15
	__asm mov ecx,dword ptr ss:[ebp-0x40]
	__asm call GETABILITY
	__asm cmp eax,0x73
	__asm jbe ORIG
	__asm mov eax,0x73
ORIG:
	__asm jmp NPCINITSKILLCHECK_RET
}

void NpcInitSkillLevel()
{
	__asm mov dword ptr ss:[ebp-0x58],0x0
	__asm push 0x15
	__asm mov ecx,dword ptr ss:[ebp-0xF4]
	__asm call GETABILITY
	__asm cmp eax,0x73
	__asm jbe ORIG
	__asm mov eax,0x73
ORIG:
	__asm jmp NPCINITSKILL_RET
}

// **** RCM_MAP_INIT_STATUS 0x181C Patch ***********************************
void NpcInitStatLevel()
{
	__asm mov dword ptr ss:[ebp-0x6C],0x0
	__asm push 0x15
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm call GETABILITY
	__asm cmp eax,0x73
	__asm jbe ORIG
	__asm mov eax,0x73
ORIG:
	__asm jmp NPCINITSTAT_RET
}

// **** RCM_MAP_RESPONSE_INVITE_GUILD_NEW 0x210E Patch *********************
void ResponseInviteGuildMasterLevel()
{
	__asm cmp eax,0x73
	__asm jbe ORIG
	__asm mov eax,0x73

ORIG:
	__asm mov dword ptr ss:[ebp-0x117],eax
	__asm jmp RIGUILDMASTER_RET
}

void ResponseInviteGuildMemberLevel()
{
	__asm push 0x15
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm call GETABILITY
	__asm cmp eax,0x73
	__asm jbe ORIG
	__asm mov eax,0x73

ORIG:
	__asm jmp RIGUILDMEMBER_RET	
}

// **** RCM_SKILL_LEARNSKILL 0x1601 Patch **********************************
void UltimateSkillLearn()
{
	__asm mov dword ptr ss:[ebp-0xC],0x0
	
	__asm mov ecx,dword ptr ss:[ebp-0xAC]
	__asm mov LEARNSKILL_PLAYER,ecx

	GetCharAllLevel(LEARNSKILL_PLAYER);

	__asm mov dword ptr ss:[ebp-0xC],eax

	__asm jmp LEARNSKILL_RET
	
}

// **** RCM_MAP_QUEST_GRANT 0x1A03 Patch ************************************
void QuestGrantLevel()
{
	__asm mov dword ptr ss:[ebp-0x19C],eax

	__asm mov ecx,dword ptr ss:[ebp-0x2C8]
	__asm mov ecx,dword ptr ds:[ecx+0x40]
	__asm mov QUESTGRANT_PLAYER,ecx

	GetCharAllLevel(QUESTGRANT_PLAYER);

	__asm add eax,dword ptr ss:[ebp-0x19C]
	__asm mov dword ptr ss:[ebp-0x4],eax

	__asm jmp QUESTGRANT_RET
}

// **** RCM_MAP_INDUN_REGISTER 0x2501 Patch *********************************
// Lindun Level Check
void LindunMinLevel()
{
	__asm mov ecx,dword ptr ss:[ebp-0x4]
	__asm mov INDUN1_PLAYER,ecx

	__asm cmp esi,0xA5
	__asm je TRANS_INDUN

	__asm jmp ORIG

TRANS_INDUN:
	BioticBaseGetAbility(INDUN1_PLAYER, 0x76);
	__asm test eax,eax
	__asm je EXIT
	__asm jmp INDUN_MIN_RETTRAN

ORIG:
	GetCharAllLevel(INDUN1_PLAYER);
	__asm jmp INDUN_MIN_RETORIG

EXIT:
	__asm jmp INDUN_MIN_RETEXIT

}

void LindunMaxLevel()
{
	__asm mov ecx,dword ptr ss:[ebp-0x4]
	__asm mov INDUN2_PLAYER,ecx

	GetCharAllLevel(INDUN2_PLAYER);
	
	__asm cmp eax,0xA5
	__asm jbe ORIG
	__asm mov eax,0xA5

ORIG:
	__asm jmp INDUN_MAX_RETORIG

}

void LindunEnterLevel()
{
	__asm mov ecx,dword ptr ss:[ebp-0x10]
	__asm mov INDUN_PLAYER,ecx

	GetCharAllLevel(INDUN_PLAYER);

	__asm cmp eax,0xA5
	__asm jbe ORIG
	__asm mov eax,0xA5

ORIG:
	__asm jmp INDUN_ENT_RET
}
