#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 


// Skill 135 0x87 Assault Crash
void AssaultCrashAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int MeleeAttackDamage;
	int Damage;

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 1;

	MeleeAttackDamage = BioticBaseGetAbility(PlayerPTR, 0x20);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));
	
	Damage += MeleeAttackDamage;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

void AssaultCrash(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int Damage;
	int AddDamage;
	
	int Param1, Param2, Param3, Param4, Param5;

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	AddDamage = (Damage * Param1) / 100;

	Damage += AddDamage;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 131 0x83 Bless Shield
void BlessShield(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x41, Param1, Active);
}
// Skill 132 0x84 Invoke
void Invoke(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x0B, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x61, Param1, Active);
}
// Skill 179 0xB3 Empower
void Empower(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x2F, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x33, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x36, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x3F, Param2, Active);
}
// Skill 181 0xB5 Sword Mastery
void SwordMastery(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x24, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10B, Param2, Active);

}
// Skill 182 0xB6 Aimed Blow
void AimedBlow(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x6E, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x73, Param2, Active);
}
// Skill 186 0xBA Order Swing
void OrderSwing(int CalAffectPTR, int ParamsPTR, int Active)
{
	int addrs;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x51, Param1, Active);

	// Clean Accumulation
	addrs = (DWORD)CalAffectPTR + 0xF0;
	*(reinterpret_cast<int*>(addrs)) = 0;
}

// Skill 187 0xBB Crazy Swing
void CrazySwing(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x51, Param1, Active);

}
// Skill 191 0xBF Critical Aura
void CriticalAura(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x73, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x39, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x2F, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x33, Param2, Active);

}
// Skill 215 0xD7 Stone Skin
void StoneSkin(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x76, 0x64, Active);
	QualitiesCalOption(CalAffectPTR, 0x77, Param5, Active);

}
// Skill 164 0xA4 Blunt Mastery
void BluntMasteryA(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x25, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10C, Param2, Active);
}
// Skill 166 0xA6 Shield Mastery
void ShieldMastery(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// Original SHIELD_DEFENCE_RATE = 0x41
	//QualitiesCalOption(CalAffectPTR, 0x41, Param1, Active);
	// BLOCK_RATE = 0x6B
	QualitiesCalOption(CalAffectPTR, 0x6B, Param1, Active);
}
// Skill 172 0xAC Powered Heavy Armor
void PoweredHeavyArmor(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x25, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x47, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x63, Param3, Active);
}
// Skill 199 0xC7 Over Crowd
void OverCrowd(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x36, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x51, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x62, Param3, Active);
	QualitiesCalOption(CalAffectPTR, 0x78, Param4, Active);
}
// Skill 214 0xD6 Ultimate Bastion
void UltimateBastion(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x81, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0xFB, Param2, Active);

}
