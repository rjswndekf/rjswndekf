#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std;

/************ Scroll Skill ***********/
// Skill Drop Cron Rate
void DropCronRate(int pCalAffect, int pParams, int Active)
{
	int Param1;
	Param1 = GetParams(pParams, 1);
	QualitiesCalOption(pCalAffect, 0x95, Param1, Active);
}
// Skill Melee Attack Force Rate
void MeleeAttackForceRate(int pCalAffect, int pParams, int Active)
{
	int Param1;
	Param1 = GetParams(pParams, 1);
	QualitiesCalOption(pCalAffect, 0x36, Param1, Active);
}
// Skill Missile Attack Force Rate
void MissileAttackForceRate(int pCalAffect, int pParams, int Active)
{
	int Param1;
	Param1 = GetParams(pParams, 1);
	QualitiesCalOption(pCalAffect, 0x33, Param1, Active);
}
// Skill Magic Attack Force Rate
void MagicAttackForceRate(int pCalAffect, int pParams, int Active)
{
	int Param1;
	Param1 = GetParams(pParams, 1);
	QualitiesCalOption(pCalAffect, 0x2F, Param1, Active);
}
// Skill Add Physical Defense Rate
void AddPhysicalDefenseRate(int pCalAffect, int pParams, int Active)
{
	int Param1;
	Param1 = GetParams(pParams, 1);
	QualitiesCalOption(pCalAffect, 0x3F, Param1, Active);
}
// Skill Add Magic Defense Rate
void AddMagicDefenseRate(int pCalAffect, int pParams, int Active)
{
	int Param1;
	Param1 = GetParams(pParams, 1);
	QualitiesCalOption(pCalAffect, 0x44, Param1, Active);
}
// Skill Add Max Life Rate
void AddMaxLifeRate(int pCalAffect, int pParams, int Active)
{
	int Param1;
	Param1 = GetParams(pParams, 1);
	QualitiesCalOption(pCalAffect, 0x66, Param1, Active);
}
// Skill Add Max Life Value
void AddMaxLifeValue(int pCalAffect, int pParams, int Active)
{
	int Param1;
	Param1 = GetParams(pParams, 1);
	QualitiesCalOption(pCalAffect, 0xD6, Param1, Active);
}
// Skill Add Move Speed Rate
void AddMoveSpeedRate(int pCalAffect, int pParams, int Active)
{
	int Param1;
	Param1 = GetParams(pParams, 1);
	QualitiesCalOption(pCalAffect, 0x62, Param1, Active);
}
// Skill Add Critical Damage Rate
void AddCriticalDamageRate(int pCalAffect, int pParams, int Active)
{
	int Param1;
	Param1 = GetParams(pParams, 1);
	QualitiesCalOption(pCalAffect, 0xCF, Param1, Active);
}
// Skill Add All Stats Rate
void AddAllStatsRate(int pCalAffect, int pParams, int Active)
{
	int Param1;
	Param1 = GetParams(pParams, 1);
	QualitiesCalOption(pCalAffect, 0x09, Param1, Active);
	QualitiesCalOption(pCalAffect, 0x0B, Param1, Active);
	QualitiesCalOption(pCalAffect, 0x0D, Param1, Active);
	QualitiesCalOption(pCalAffect, 0x10, Param1, Active);
	QualitiesCalOption(pCalAffect, 0x12, Param1, Active);
	QualitiesCalOption(pCalAffect, 0x14, Param1, Active);
}
// Skill 41185 0xA0E1 Transcendence Scroll
void TranscendenceScroll(int pCalAffect, int pParams, int Active)
{
	int Param1, Param2;
	Param1 = GetParams(pParams, 1);
	Param2 = GetParams(pParams, 2);
	QualitiesCalOption(pCalAffect, 0xF4, Param1, Active);
	QualitiesCalOption(pCalAffect, 0xD6, Param2, Active);
}
// Skill 41186 0xA0E2 Conqueror Scroll
void ConquerorScroll(int pCalAffect, int pParams, int Active)
{
	int Param1, Param2;
	Param1 = GetParams(pParams, 1);
	Param2 = GetParams(pParams, 2);
	QualitiesCalOption(pCalAffect, 0xF7, Param1, Active);
	QualitiesCalOption(pCalAffect, 0xD6, Param2, Active);
}
