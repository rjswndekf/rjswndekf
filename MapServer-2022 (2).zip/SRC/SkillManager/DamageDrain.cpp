#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std;

int DMGDRAIN_ATTACK;
int DMGDRAIN_RET = 0x0052E541;

void DamageDrain()
{
	// Orig Code
	__asm mov dword ptr ss:[ebp-0x4],0x0
	__asm mov DMGDRAIN_ATTACK,ecx
	
	DamageDrainLimit(DMGDRAIN_ATTACK);

	__asm jmp DMGDRAIN_RET
}

/*** pAttack + 0x15 0:Limit / 1:Drain ***/
void DamageDrainLimit(int pAttack)
{
	int addrs = 0;
	int PlayerPTR = 0;
	int TargetPTR = 0;
	int pThis = 0;
	int SelfCalAffectPTR = 0;
	int TargetCalAffectPTR = 0;
	int State = 0;

	addrs = (DWORD)pAttack + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	SelfCalAffectPTR = (DWORD)PlayerPTR + 0x100;

	addrs = (DWORD)pAttack + 0x1D4;
	pThis = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pThis;
	TargetPTR = *(reinterpret_cast<int*>(addrs));
	TargetCalAffectPTR = (DWORD)TargetPTR + 0x100;

	// Skill 16558 0x40AE WhisperLimit
	State = CheckAffectStatus(SelfCalAffectPTR, 0x40AE);
	if (State == 1)
	{
		addrs = (DWORD)pAttack + 0x15;
		*(reinterpret_cast<char*>(addrs)) = 0;
	}
}
