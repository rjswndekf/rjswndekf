#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std;

// RCM_SKILL_CHANGEATTITUDE 0x1828
void SkillChangeAttitude(int pDynamic, int pSendPacket)
{
	int addrs;
	int pData;
	int pThis;
	int pTarget;
	int pTargetCalAffect;
	int State = 0;
	unsigned int CutTime = 0;

	int CType1;
	unsigned int CharID1;
	int pGuild1;
	unsigned int Guild1 = 0;
	int CType2;
	unsigned int CharID2;
	int pGuild2;
	unsigned int Guild2 = 0;

	unsigned char CHANGEATTITUDE[18] = {0};
	int CHANGEATTITUDE_ADDRS = (DWORD)CHANGEATTITUDE;

	unsigned char TAGAFFECTSKILL[36];
	int ASADDRS = (DWORD)TAGAFFECTSKILL;

	pData = pSendPacket + 0x4;

	// Send Packet
	addrs = (DWORD)pData + 0x1;
	CType1 = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pData + 0x5;
	CharID1 = *(reinterpret_cast<unsigned int*>(addrs));
	addrs = (DWORD)pData + 0x9;
	CType2 = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pData + 0xD;
	CharID2 = *(reinterpret_cast<unsigned int*>(addrs));
	
	pGuild1 = GetGuildInfo(CharID1);
	if (pGuild1 == 0)
	{
		Guild1 = 0;
	}
	else
	{
		addrs = (DWORD)pGuild1 + 0x10;
		Guild1 = *(reinterpret_cast<unsigned int*>(addrs));
	}

	pGuild2 = GetGuildInfo(CharID2);
	if (pGuild2 == 0)
	{
		Guild2 = 0;
	}
	else
	{
		addrs = (DWORD)pGuild2 + 0x10;
		Guild2 = *(reinterpret_cast<unsigned int*>(addrs));
	}

	addrs = (DWORD)CHANGEATTITUDE + 0x1;
	*(reinterpret_cast<char*>(addrs)) = 0;

	pTarget = FindBioticID(CharID2);

	if (pTarget != 0)
	{
		pTargetCalAffect = pTarget + 0x100;
		State = CheckAffectStatus(pTargetCalAffect, 0x9021);
		if (State == 0)
		{
			if (Guild2 == Guild1)
			{
				tagAffectSkillInit(ASADDRS);

				CutTime = GetCutTime();
				addrs = (DWORD)ASADDRS;
				*(reinterpret_cast<int*>(addrs)) = 0x9021;
				addrs = (DWORD)ASADDRS + 0x2;
				*(reinterpret_cast<char*>(addrs)) = 0;
				addrs = (DWORD)ASADDRS + 0x3;
				*(reinterpret_cast<int*>(addrs)) = CutTime;
				addrs = (DWORD)ASADDRS + 0x7;
				*(reinterpret_cast<int*>(addrs)) = CutTime;
				addrs = (DWORD)ASADDRS + 0x10;
				*(reinterpret_cast<int*>(addrs)) = CharID2;

				AddAffectSkill(pTargetCalAffect, ASADDRS);

				addrs = (DWORD)CHANGEATTITUDE + 0x1;
				*(reinterpret_cast<char*>(addrs)) = 0;
			}
			else
			{
				addrs = (DWORD)CHANGEATTITUDE + 0x1;
				*(reinterpret_cast<char*>(addrs)) = 0;
			}
		}

		CIOObjectRelease(pTarget);
	}

	// Clinet Packet
	addrs = (DWORD)CHANGEATTITUDE;
	*(reinterpret_cast<char*>(addrs)) = 0x0;

	addrs = (DWORD)CHANGEATTITUDE + 0x2;
	*(reinterpret_cast<int*>(addrs)) = CType1;
	addrs = (DWORD)CHANGEATTITUDE + 0x6;
	*(reinterpret_cast<unsigned int*>(addrs)) = CharID1;
	addrs = (DWORD)CHANGEATTITUDE + 0xA;
	*(reinterpret_cast<int*>(addrs)) = CType2;
	addrs = (DWORD)CHANGEATTITUDE + 0xE;
	*(reinterpret_cast<unsigned int*>(addrs)) = CharID2;

	pThis = pDynamic;
	SendPacket(pThis, 0x1828, CHANGEATTITUDE_ADDRS, 0x12);
}

// Skill -28639 0x9021 Change Attitude
void ChangeAttitudeAffectAcive(int pCalAffect, int pParams, int pASkill, int Active)
{
	int addrs;
	int pPlayer;
	int CurEXPRate;
	int Param1; // EXP Rate
	//int Param2; // Add MaxLife

	addrs = pCalAffect + 0x58;
	pPlayer = *(reinterpret_cast<int*>(addrs));

	Param1 = GetParams(pParams, 1);

	if (Active == 1)
	{
		addrs = pPlayer + 0x1AA4;
		CurEXPRate = *(reinterpret_cast<int*>(addrs));
		CurEXPRate += Param1;
		*(reinterpret_cast<int*>(addrs)) = CurEXPRate;
	}
	else
	{
		addrs = pPlayer + 0x1AA4;
		CurEXPRate = *(reinterpret_cast<int*>(addrs));
		CurEXPRate -= Param1;
		if (CurEXPRate < 0) CurEXPRate = 0;
		*(reinterpret_cast<int*>(addrs)) = CurEXPRate;
	}
}

