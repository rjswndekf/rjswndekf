#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 


// Skill 1040 0x410 Strength
void Strength(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x09, Param1, Active);
}
// Skill 1027 0x403 Deadly Blow
void DeadlyBlow(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x14, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x58, Param1, Active);
}

// Skill 1077 0x435 Suicide
void SuicideAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int CalAffectPTR;
	int CurLife;
	int BaseDamage;
	int Diff;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);
	
	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 1;
	
	CalAffectPTR = (DWORD)PlayerPTR + 0x100;

	CurLife = PlayerGetCurLife(PlayerPTR);
	Diff = (CurLife * Param1) / 100;
	
	addrs = (DWORD)DamagePTR;
	BaseDamage = *(reinterpret_cast<int*>(addrs));
	
	BaseDamage += Diff;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = BaseDamage;
	
	ChangeLife(CalAffectPTR, Diff, 0);
	SendLifeManaBroadcast(PlayerPTR);
}
void Suicide(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int MeleeAttackDamage;
	int AttackDamage;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	MeleeAttackDamage = BioticBaseGetAbility(PlayerPTR, 0x20) * Param2 / 100;
	
	addrs = (DWORD)DamagePTR;
	AttackDamage = *(reinterpret_cast<int*>(addrs));

	AttackDamage += MeleeAttackDamage;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = AttackDamage;

}

// Skill 1068 0x42C Katar Mastery
void KatarMasteryA(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x2A, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10E, Param2, Active);	
}

// Skill 1085 0x43D Katar Mastery
void KatarMasteryB(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x2A, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10E, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x73, Param3, Active);
}
// Skill 1099 0x44B Royal Mask
void RoyalMask(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x7D, Param1, Active);

	QualitiesCalOption(CalAffectPTR, 0x09, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x0B, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x0D, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x10, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x12, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x14, Param2, Active);
}
/***
void RoyalMaskAffectAcive(int CalAffectPTR, int ParamsPTR, int Active)
{
	int addrs;
	int PlayerPTR;
	int CutLV;
	int CUTHLV;
	int CharLV;
	int SkillLV;
	int SetLV;
	int Runset;
	
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	CutLV = BioticBaseGetAbility(PlayerPTR, 0x15);
	CUTHLV = BioticBaseGetAbility(PlayerPTR, 0x65);
	SkillLV = CutLV + CUTHLV + Param1;
	CharLV = CutLV + CUTHLV;
	
	if (Active == 1)
	{
		if (SkillLV > 115)
		{
			SetLV = SkillLV - 115;
			Runset = BioticBaseSetAbility(PlayerPTR, 0x65, SetLV);
			SendConquerorLevel(PlayerPTR);
		}
		else
		{
			Runset = BioticBaseSetAbility(PlayerPTR, 0x15, SkillLV);
		}
	}
	else
	{
		if (CharLV > 115)
		{
			Runset = BioticBaseSetAbility(PlayerPTR, 0x65, CUTHLV);
			SendConquerorLevel(PlayerPTR);
		}
		else
		{
			if (SkillLV > 115)
			{
				Runset = BioticBaseSetAbility(PlayerPTR, 0x65, 0);
				SendConquerorLevel(PlayerPTR);
			}
			Runset = BioticBaseSetAbility(PlayerPTR, 0x15, CutLV);
		}
	}

	SendStatus(PlayerPTR);
}
***/
// Skill 1110 0x456 Crown's Laughter
void CrownsLaughter(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);
	
	QualitiesCalOption(CalAffectPTR, 0xF2, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x51, Param2, Active);
}
// Skill 1125 0x465 Isolation Stealth
void IsolationStealth(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x86, Param1, Active);
}
