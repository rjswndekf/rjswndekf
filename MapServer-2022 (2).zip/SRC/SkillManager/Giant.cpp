#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 

// Skill 2052 0x804 Battle Chant
void BattleChant(int CalAffectPTR, int ParamsPTR, int Active)
{
	int addrs;
	int PlayerPTR;
	int StrVar;
	int DexVar;
	int AddVar;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);
	
	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	StrVar = BioticBaseGetAbility(PlayerPTR, 0x0);
	DexVar = BioticBaseGetAbility(PlayerPTR, 0x3);
	AddVar = (StrVar + DexVar) * Param1 / 100;

	QualitiesCalOption(CalAffectPTR, 0xD6, AddVar, Active);
}
// Skill 2054 0x806 Find Hole
void FindHole(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x78, Param1, Active);
}
// Skill 2064 0x810 Polearm Mastery
void PolearmMastery(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0xE9, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10B, Param2, Active);
}
// Skill 2065 0x811 Criminal Mind
void CriminalMind(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x117, Param2, Active);
}
// Skill 2082 0x822 Dual Sword Mastery
void DualSwordMastery(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0xDC, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10B, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x51, Param3, Active);
}
// Skill 2084 0x824 Rampage Force
void RampageForce(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	if (Active == 1)
	{
		QualitiesSetOption(CalAffectPTR, 0x87, Param1);
		QualitiesSetOption(CalAffectPTR, 0x85, Param2);
		QualitiesSetOption(CalAffectPTR, 0x89, Param4);
	}
	else
	{
		QualitiesSetOption(CalAffectPTR, 0x87, 0x0);
		QualitiesSetOption(CalAffectPTR, 0x85, 0x0);
		QualitiesSetOption(CalAffectPTR, 0x89, 0x0);
	}
}
// Skill 2085 0x825 Ferocious
void Ferocious(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x62, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x117, Param2, Active);
}
// Skill 2087 0x827 Monster Mind
void MonsterMind(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// CA_PVE_ATTACK_RATE 0x80
	QualitiesCalOption(CalAffectPTR, 0xF7, Param1, Active);
}
// Skill 2089 0x829 Brutality
void Brutality(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x09, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x0D, Param2, Active);
}
// Skill 2103 0x837 Gigantic Storm
void GiganticStorm(int CalAffectPTR, int ParamsPTR, int Active)
{

	//int DecSpeed;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	//DecSpeed = 0 - Param1;

	QualitiesCalOption(CalAffectPTR, 0x51, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0xE9, Param2, Active);

	// CA_PVP_ATTACK_RATE 0x6D
	QualitiesCalOption(CalAffectPTR, 0xF4, Param3, Active);
}
// Skill 2118 0x846 Fury Tempest
void FuryTempest(int CalAffectPTR, int ParamsPTR, int Active)
{
	int addrs;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x51, Param1, Active);

	// Clean Accumulation
	addrs = (DWORD)CalAffectPTR + 0xF0;
	*(reinterpret_cast<int*>(addrs)) = 0;
}

