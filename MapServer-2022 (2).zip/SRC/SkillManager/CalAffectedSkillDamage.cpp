#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std;

int CALAFSKDMG_RET = 0x00533BFF;

int CALAFSKDMG_TARGET;
int CALAFSKDMG_DAMAGE;
int CALAFSKDMG_SAO;
int CALAFSKDMG_BC;
int CALAFSKDMG_THIS;

void AffectedSkillDamageProc()
{
	// Original Code
	__asm mov dword ptr ss:[ebp-0x190],ecx

	// TargetPTR
	__asm mov edx,dword ptr ss:[ebp+0x14]
	__asm mov CALAFSKDMG_TARGET,edx
	// DamagePTR
	__asm lea ecx,dword ptr ss:[ebp+0x10]
	__asm mov CALAFSKDMG_DAMAGE,ecx
	// SAO
	__asm mov eax,dword ptr ss:[ebp+0xC]
	__asm mov CALAFSKDMG_SAO,eax
	// BC
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov CALAFSKDMG_BC,edx
	// DynamicPTR
	__asm mov ecx, dword ptr ss:[ebp-0x190]
	__asm mov CALAFSKDMG_THIS,ecx
	
	CalAffectedSkillDamage(CALAFSKDMG_THIS, CALAFSKDMG_BC, CALAFSKDMG_SAO, CALAFSKDMG_DAMAGE, CALAFSKDMG_TARGET);

	__asm jmp CALAFSKDMG_RET
}

void CalAffectedSkillDamage(int DynamicPTR, int BC, int SAO, int DamagePTR, int TargetPTR)
{
	int addrs;
	int PlayerPTR = 0;
	int SelfCalAffectPTR = 0;
	int TargetCalAffectPTR = 0;
	char AttackerType;
	char AttackeeType;
	int State = 0;
	int Kind = 0;
	unsigned int Damage = 0;
	unsigned int DamageRate = 0;
	unsigned int AddDamage = 0;
	unsigned int ACDamage = 0;
	unsigned int NACDamage = 0;
	int AttackCount = 0;
	int ParamPTR = 0;
	int Param1 = 0;
	int Param2 = 0;
	int Param3 = 0;
	int Param4 = 0;

	addrs = (DWORD)SAO + 0x4C;
	Kind = *(reinterpret_cast<unsigned short*>(addrs));

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	SelfCalAffectPTR = (DWORD)PlayerPTR + 0x100;
	TargetCalAffectPTR = (DWORD)TargetPTR + 0x100;

	addrs = (DWORD)PlayerPTR + 0x2E;
	AttackerType = *(reinterpret_cast<char*>(addrs));
	addrs = (DWORD)TargetPTR + 0x2E;
	AttackeeType = *(reinterpret_cast<char*>(addrs));

	// PvP Attack Damage Rate
	if (AttackerType == 3)
	{
		if (AttackeeType == 3)
		{
			DamageRate = BioticBaseGetAbility(PlayerPTR, 0x6D);
			if (DamageRate != 0)
			{
				addrs = (DWORD)DamagePTR;
				Damage = *(reinterpret_cast<int*>(addrs));

				AddDamage = (Damage * DamageRate) / 100;
				Damage += AddDamage;

				addrs = (DWORD)DamagePTR;
				*(reinterpret_cast<int*>(addrs)) = Damage;
			}
		}
	}

	// PvE Attack Damage Rate
	if (AttackerType == 3)
	{
		if (AttackeeType == 4)
		{
			DamageRate = BioticBaseGetAbility(PlayerPTR, 0x80);
			if (DamageRate != 0)
			{
				addrs = (DWORD)DamagePTR;
				Damage = *(reinterpret_cast<int*>(addrs));

				AddDamage = (Damage * DamageRate) / 100;
				Damage += AddDamage;

				addrs = (DWORD)DamagePTR;
				*(reinterpret_cast<int*>(addrs)) = Damage;
			}
		}
	}

	// Skill 186 0xBA Order Swing
	State = CheckAffectStatus(SelfCalAffectPTR, 0xBA);
	if (State == 1)
	{
		// Get Params
		ParamPTR = GetParamPTR(PlayerPTR, 0xBA);
		addrs = (DWORD)ParamPTR + 0x4;
		Param2 = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)ParamPTR + 0xC;
		Param4 = *(reinterpret_cast<int*>(addrs));

		addrs = (DWORD)DamagePTR;
		Damage = *(reinterpret_cast<int*>(addrs));

		// Attack Count
		addrs = (DWORD)SelfCalAffectPTR + 0xF0;
		AttackCount = *(reinterpret_cast<int*>(addrs));

		ACDamage = (Damage * Param4) / 100;
		NACDamage = ACDamage * AttackCount;

		// Increase Damage
		AddDamage = (Damage * Param2) / 100;

		Damage += AddDamage;
		Damage += NACDamage;

		addrs = (DWORD)DamagePTR;
		*(reinterpret_cast<int*>(addrs)) = Damage;

		// Save AttackCount
		AttackCount += 1;
		addrs = (DWORD)SelfCalAffectPTR + 0xF0;
		*(reinterpret_cast<int*>(addrs)) = AttackCount;
	}

	// Skill 187 0xBB Crazy Swing
	State = CheckAffectStatus(SelfCalAffectPTR, 0xBB);
	if (State == 1)
	{
		// Get Params
		ParamPTR = GetParamPTR(PlayerPTR, 0xBB);
		addrs = (DWORD)ParamPTR + 0x4;
		Param2 = *(reinterpret_cast<int*>(addrs));

		addrs = (DWORD)DamagePTR;
		Damage = *(reinterpret_cast<int*>(addrs));

		// Increase Damage
		AddDamage = (Damage * Param2) / 100;

		Damage += AddDamage;
		addrs = (DWORD)DamagePTR;
		*(reinterpret_cast<int*>(addrs)) = Damage;
	}

	// Skill 2118 0x846 Fury Tempest
	State = CheckAffectStatus(SelfCalAffectPTR, 0x846);
	if (State == 1)
	{
		// Get Params
		ParamPTR = GetParamPTR(PlayerPTR, 0x846);
		addrs = (DWORD)ParamPTR + 0x4;
		Param2 = *(reinterpret_cast<int*>(addrs));

		addrs = (DWORD)DamagePTR;
		Damage = *(reinterpret_cast<int*>(addrs));

		// Accumulation Damage
		addrs = (DWORD)SelfCalAffectPTR + 0xF0;
		AttackCount = *(reinterpret_cast<int*>(addrs));

		ACDamage = (Damage * Param2) / 100;
		NACDamage = ACDamage * AttackCount;

		// Increase Damage
		Damage += NACDamage;;
		addrs = (DWORD)DamagePTR;
		*(reinterpret_cast<int*>(addrs)) = Damage;

		// Save AttackCount
		AttackCount += 1;
		addrs = (DWORD)SelfCalAffectPTR + 0xF0;
		*(reinterpret_cast<int*>(addrs)) = AttackCount;
	}

	// Skill 4177 0x1051 Spell Extension
	State = CheckAffectStatus(SelfCalAffectPTR, 0x1051);
	if (State == 1)
	{
		if (Kind != 0)
		{
			// Get Params
			ParamPTR = GetParamPTR(PlayerPTR, 0x1051);
			addrs = (DWORD)ParamPTR;
			Param1 = *(reinterpret_cast<int*>(addrs));

			addrs = (DWORD)DamagePTR;
			Damage = *(reinterpret_cast<int*>(addrs));

			// Increase Damage
			AddDamage = (Damage * Param1) / 100;

			Damage += AddDamage;
			addrs = (DWORD)DamagePTR;
			*(reinterpret_cast<int*>(addrs)) = Damage;
		}
	}

	// Skill 32990 0x80DE Death Chaser
	State = CheckAffectStatus(TargetCalAffectPTR, 0x80DE);
	if (State == 1)
	{
		// Get Params
		ParamPTR = GetParamPTR(PlayerPTR, 0x247);
		addrs = (DWORD)ParamPTR;
		Param1 = *(reinterpret_cast<int*>(addrs));

		addrs = (DWORD)DamagePTR;
		Damage = *(reinterpret_cast<int*>(addrs));

		// Increase Damage
		AddDamage = (Damage * Param1) / 100;

		Damage += AddDamage;
		addrs = (DWORD)DamagePTR;
		*(reinterpret_cast<int*>(addrs)) = Damage;
	}

	// Skill 16553 0x40A9 Excalibur
	State = CheckAffectStatus(SelfCalAffectPTR, 0x40A9);
	if (State == 1)
	{
		// Get Params
		ParamPTR = GetParamPTR(PlayerPTR, 0x40A9);
		addrs = (DWORD)ParamPTR + 0x4;
		Param2 = *(reinterpret_cast<int*>(addrs));
		addrs = (DWORD)ParamPTR + 0x8;
		Param3 = *(reinterpret_cast<int*>(addrs));

		addrs = (DWORD)DamagePTR;
		Damage = *(reinterpret_cast<int*>(addrs));

		// Attack Count
		addrs = (DWORD)SelfCalAffectPTR + 0xF0;
		AttackCount = *(reinterpret_cast<int*>(addrs));

		ACDamage = (Damage * Param3) / 100;
		NACDamage = ACDamage * AttackCount;

		// Increase Damage
		AddDamage = (Damage * Param2) / 100;

		Damage += AddDamage;
		Damage += NACDamage;

		addrs = (DWORD)DamagePTR;
		*(reinterpret_cast<int*>(addrs)) = Damage;

		// Save AttackCount
		AttackCount += 1;
		addrs = (DWORD)SelfCalAffectPTR + 0xF0;
		*(reinterpret_cast<int*>(addrs)) = AttackCount;
	}

}