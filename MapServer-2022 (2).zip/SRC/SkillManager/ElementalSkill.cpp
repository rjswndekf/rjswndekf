#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std;

int EDMG_RETORG = 0x005298F2;
int EDMG_RETEND = 0x005299F2;

int EDMG_THIS;
int EDMG_BC;
int EDMG_ASO;
unsigned int EDMG_DMG;

void ElementalDamage()
{
	// pAttack
	__asm mov ecx,dword ptr ss:[ebp-0x10]
	__asm mov EDMG_THIS,ecx
	// BC
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov ecx,dword ptr ds:[eax+0x2C]
	__asm mov dword ptr ss:[ebp-0x4],ecx
	__asm mov EDMG_BC,eax
	// ASO
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov EDMG_ASO,edx
	// Damage
	__asm mov eax,dword ptr ss:[ebp+0x10]
	__asm mov EDMG_DMG,eax

	CalElementalDamage(EDMG_THIS, EDMG_BC, EDMG_ASO, EDMG_DMG);

	__asm test eax,eax
	__asm je RETORIG
	__asm jmp EDMG_RETEND

RETORIG:
	__asm jmp EDMG_RETORG

}

int CalElementalDamage(int pAttack, int BC, int ASO, unsigned int Damage)
{
	int Result = 0;
	int addrs = 0;
	int PlayerPTR;
	int TargetPTR = 0;
	int Resistance = 0;
	int Kind = 0;
	int TResist = 0;
	int pElemeDamage = 0;
	unsigned int ElemeDamage = 0;
	int ParamPTR = 0;
	unsigned int AddRate = 0;
	unsigned int AddDamage = 0;

	addrs = (DWORD)ASO + 0x4C;
	Kind = *(reinterpret_cast<unsigned short*>(addrs));

	addrs = (DWORD)ASO + 0x50;
	Resistance = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)pAttack + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)BC + 0x2C;
	TargetPTR = *(reinterpret_cast<int*>(addrs));

	pElemeDamage = (DWORD)BC + 0x20;

	// Skill 8222 0x201E Thorns Whip
	if (Kind = 0x201E)
	{
		TResist = GetTargetResistance(pAttack, TargetPTR, Resistance, Kind);
		if (TResist > 0)
		{
			ElemeDamage = ((Damage * TResist) / 100) / 2;

			ParamPTR = GetParamPTR(PlayerPTR, 0x201E);
			if (ParamPTR != 0)
			{
				addrs = (DWORD)ParamPTR;
				AddRate = *(reinterpret_cast<int*>(addrs));
				AddDamage = (ElemeDamage * AddRate) / 100;
			}

			ElemeDamage += AddDamage;
			*(reinterpret_cast<int*>(pElemeDamage)) = ElemeDamage;

			Result = 1;
		}
	}

	return Result;
}
