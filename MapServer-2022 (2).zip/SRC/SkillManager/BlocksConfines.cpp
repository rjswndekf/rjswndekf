#include <SkillManager.h>
//#include <MapFunctions.h>

using namespace std;

int ISBLOCK_RETORG = 0x004A19F2;
int ISBLOCK_SK40C1 = 0x004A1A0F;

int CONFINES_RETORG = 0x004D8987;
int CONFINES_SK40C1 = 0x004D8A01;

void IsBlocks()
{
	// Original Code Kind
	__asm mov dword ptr ss:[ebp-0x400],edx
	__asm cmp dword ptr ss:[ebp-0x400],0x40C1
	__asm je SK_40C1

	__asm jmp ISBLOCK_RETORG

SK_40C1:
	__asm jmp ISBLOCK_SK40C1
}

void ConfinesRange()
{
	// Original Code Kind
	__asm mov dword ptr ss:[ebp-0x188],edx

	__asm cmp dword ptr ss:[ebp-0x188],0x40C1
	__asm je SK_40C1

	__asm jmp CONFINES_RETORG

SK_40C1:
	__asm jmp CONFINES_SK40C1
}
