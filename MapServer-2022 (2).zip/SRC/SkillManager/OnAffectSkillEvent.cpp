#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 

int ONASTYPE_RETORG = 0x0049D447;
int ONASTYPE_TYPE7 = 0x0049DABA;
int ONASTYPE_TYPE8 = 0x0049D895;

int ONASEVENT_RETORG = 0x004A6A8E;
int ONASEVENT_SK101F = 0x004A6FDB;
int ONASEVENT_CALDMG = 0x004A7178;
int ONASEVENT_DAMAGE;
int ONASEVENT_ASPTR;
int ONASEVENT_PARAM;
int ONASEVENT_TARGET;

void OnAffectSkillEventType()
{
	// Orig Code
	__asm mov dword ptr ss:[ebp-0x168],edx
	// Skill 339 0x153 Group All Mighty
	__asm cmp edx,0x153
	__asm je TYPE7
	// Skill 4127 0x101F Area Toxic Potion
	__asm cmp edx,0x101F
	__asm je TYPE8
	// Skill 8208 0x2010 Dark Side of Light
	__asm cmp edx,0x2010
	__asm je TYPE8	
	// Skill 8209 0x2011 Blessed Crown
	__asm cmp edx,0x2011
	__asm je TYPE7
	// Skill 8222 0x201E Thorns Whip
	__asm cmp edx,0x201E
	__asm je TYPE8
	// Skill 8253 0x203D Dimensional Scar
	__asm cmp edx,0x203D
	__asm je TYPE8
	// Skill 32989 0x80DD Rear Blast
	__asm cmp edx,0x80DD
	__asm je TYPE8
	// Skill 16535 0x4097 ReserveWide
	__asm cmp edx,0x4097
	__asm je TYPE8
	// Skill 16540 0x409C MagicianAura
	__asm cmp edx,0x409C
	__asm je TYPE7
	// Skill 16541 0x409D CaelsAura
	__asm cmp edx,0x409D
	__asm je TYPE7
	// Skill 16542 0x409E RisingAura
	__asm cmp edx,0x409E
	__asm je TYPE7
	// Skill 16559 0x40AF Murder Remission Counting
	__asm cmp edx,0x40AF
	__asm je TYPE7

	__asm jmp ONASTYPE_RETORG

TYPE7:
	__asm jmp ONASTYPE_TYPE7

TYPE8:
	__asm jmp ONASTYPE_TYPE8

}

void OnAffectSkillEvent()
{
	// Orig Code
	__asm mov dword ptr ss:[ebp-0x104],ecx

	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov ONASEVENT_ASPTR,edx
	__asm mov ecx,dword ptr ss:[ebp-0x4]
	__asm mov ONASEVENT_PARAM,ecx
	__asm mov ecx,dword ptr ss:[ebp-0xFC]
	__asm mov eax,dword ptr ds:[ecx+0x58]
	__asm mov ONASEVENT_TARGET,eax
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov ONASEVENT_DAMAGE,edx

	__asm mov ecx,dword ptr ss:[ebp-0x104]

	// Skill 4127 0x101F Area Toxic Potion
	__asm cmp ecx,0x101F
	__asm je SK101F

	// Skill 8208 0x2010 Dark Side of Light
	__asm cmp ecx,0x2010
	__asm je SK2010

	// Skill 8222 0x201E Thorns Whip
	__asm cmp ecx,0x201E
	__asm je SK201E

	// Skill 8253 0x203D Dimensional Scar
	__asm cmp ecx,0x203D
	__asm je SK203D

	// Skill 32989 0x80DD Rear Blast
	__asm cmp ecx,0x80DD
	__asm je SK80DD

	// Skill 16535 0x4097 ReserveWide
	__asm cmp ecx,0x4097
	__asm je SK4097
	
	__asm jmp ONASEVENT_RETORG

SK101F:
	__asm jmp ONASEVENT_SK101F

SK2010:
	// Skill 8208 0x2010 Dark Side of Light
	DarkSideOfLightASEvent(ONASEVENT_TARGET, ONASEVENT_PARAM, ONASEVENT_ASPTR, ONASEVENT_DAMAGE);
	__asm jmp ONASEVENT_CALDMG

SK201E:
	// Skill 8222 0x201E Thorns Whip
	ThornsWhipASEvent(ONASEVENT_TARGET, ONASEVENT_PARAM, ONASEVENT_ASPTR, ONASEVENT_DAMAGE);
	__asm jmp ONASEVENT_CALDMG

SK203D:
	// Skill 8253 0x203D Dimensional Scar
	DimensionalScarASEvent(ONASEVENT_TARGET, ONASEVENT_PARAM, ONASEVENT_ASPTR, ONASEVENT_DAMAGE);
	__asm jmp ONASEVENT_CALDMG

SK80DD:
	// Skill 32989 0x80DD Rear Blast
	RearBlastASEvent(ONASEVENT_TARGET, ONASEVENT_PARAM, ONASEVENT_ASPTR, ONASEVENT_DAMAGE);
	__asm jmp ONASEVENT_CALDMG

SK4097:
	// Skill 16535 0x4097 ReserveWide
	ReserveWideASEvent(ONASEVENT_TARGET, ONASEVENT_PARAM, ONASEVENT_ASPTR, ONASEVENT_DAMAGE);
	__asm jmp ONASEVENT_CALDMG

}
