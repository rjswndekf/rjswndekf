#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 


//Skill 289 0x121 Divine Beam
void DivineBeamAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int MagicDamage;
	int Damage;

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 3;
	MagicDamage = BioticBaseGetAbility(PlayerPTR, 0x22);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += MagicDamage;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;

}
void DivineBeam(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int PsyVar;
	int Damage;

	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	PsyVar = BioticBaseGetAbility(PlayerPTR, 0x4) * Param1 / 100;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += PsyVar;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;

}

//Skill 258 0x102 Holy Light
void HolyLightAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int MagicDamage;
	int Damage;

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 3;
	MagicDamage = BioticBaseGetAbility(PlayerPTR, 0x22);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += MagicDamage;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;

}
void HolyLight(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int IntVar;
	int Damage;

	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	IntVar = BioticBaseGetAbility(PlayerPTR, 0x2) * Param1 / 100;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += IntVar;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 306 0x132 Marea's Hammer
void MareasHammer(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int MagicAttackForce;
	int MagicAttackRate;
	int Damage;

	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 3;

	MagicAttackForce = BioticBaseGetAbility(PlayerPTR, 0x22);
	MagicAttackRate = (MagicAttackForce * Param1) / 100;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += MagicAttackRate;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 309 0x135 Final Attempt
void FinalAttempt(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int MagicAttackForce;
	int MagicAttackRate;
	int Damage;

	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 3;

	MagicAttackForce = BioticBaseGetAbility(PlayerPTR, 0x22);
	MagicAttackRate = (MagicAttackForce * Param1) / 100;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += MagicAttackRate;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}
// Skill 310 0x136 Marea's Anger
void MareasAngerAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int MagicAttackForce;
	int Damage;

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 3;

	MagicAttackForce = BioticBaseGetAbility(PlayerPTR, 0x22);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += MagicAttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

void MareasAnger(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int pPlayer;
	//int pCalAffect;
	//int pTarget;
	//int pTargetCalAffect;
	int MagicAttackRate;
	int Damage;
	//int Diff;

	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	pPlayer = *(reinterpret_cast<int*>(addrs));
	//pCalAffect = (DWORD)pPlayer + 0x100;

	//addrs = (DWORD)BC + 0x2C;
	//pTarget = *(reinterpret_cast<int*>(addrs));
	//pTargetCalAffect = (DWORD)pTarget + 0x100;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	MagicAttackRate = Damage * Param1;

	Damage += MagicAttackRate;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;

	//Diff = (Damage * Param2) / 100;
	//ChangeMana(pCalAffect, Diff, 0);
}

// Skill 311 0x137 Destruction
void Destruction(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int MagicAttackForce;
	int MagicAttackRate;
	int Damage;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 3;

	MagicAttackForce = BioticBaseGetAbility(PlayerPTR, 0x22);
	MagicAttackRate = (MagicAttackForce * Param1) / 100;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += MagicAttackRate;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 338 0x152 Mana Charge
void ManaChargeAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active)
{
	int addrs;
	int pPlayer;
	int MaxMana;

	if (Active == 1)
	{
		addrs = (DWORD)CalAffectPTR + 0x58;
		pPlayer = *(reinterpret_cast<int*>(addrs));
		MaxMana = BioticBaseGetAbility(pPlayer, 0x0F);
		// Current Mana
		addrs = (DWORD)pPlayer + 0xB0;
		*(reinterpret_cast<int*>(addrs)) = MaxMana;

		SendLifeManaBroadcast(pPlayer);
	}
}

// Skill 260 0x104 Mental Barrier
void MentalBarrier(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x115, Param1, Active);
}

// Skill 339 0x153 Group All Mighty
void GroupAllMighty(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x09, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x0B, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x0D, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x12, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x14, Param1, Active);
}
// Skill 322 0x142 Marea's Grace
void MareasGrace(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);
	// CA_PENETRATE_DEC_DMG_RATE 0x6A
	QualitiesCalOption(CalAffectPTR, 0xF2, Param1, Active);
}
// Skill 292 0x124 Soul Meditation
void SoulMeditation(int CalAffectPTR, int ParamsPTR, int Active)
{
	int addrs;
	int PlayerPTR;
	int PsyVar;
	int ReduceDamage;

	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	PsyVar = BioticBaseGetAbility(PlayerPTR, 0x4);
	ReduceDamage = (PsyVar * Param1) / 100;
	QualitiesCalOption(CalAffectPTR, 0x81, ReduceDamage, Active);
	
}
// Skill 318 0x13E Staff Mastery
void StaffMastery(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x28, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x112, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x113, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x7C, Param3, Active);
}
// Skill 303 0x12F Blunt Mastery
void BluntMasteryB(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x25, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x26, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x4A, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10D, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x55, Param3, Active);
}
// Skill 305 0x131 Reflection
void Reflection(int CalAffectPTR, int ParamsPTR, int Active)
{
	//int RemainderRate;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// CA_DAMAGE_RATE 0x2B
	//RemainderRate = 0 - Param2;
	QualitiesCalOption(CalAffectPTR, 0xF1, Param2, Active);
}
// Skill 337 0x151 Heaven's Dawn
void HeavensDawn(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x09, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x0B, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x0D, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x12, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x14, Param1, Active);
	
	QualitiesCalOption(CalAffectPTR, 0x2F, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x33, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x36, Param2, Active);
	
	QualitiesCalOption(CalAffectPTR, 0x51, Param3, Active);

	QualitiesCalOption(CalAffectPTR, 0x73, Param4, Active);
	
	QualitiesCalOption(CalAffectPTR, 0x49, Param5, Active);

}
// Skill 352 0x160 Last Divine
void LastDivine(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x73, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x117, Param2, Active);
}
