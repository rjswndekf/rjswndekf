#include <SkillManager.h>

using namespace std; 

/*************************
 AT_MELEE = 1
 AT_MISSILE = 2
 AT_MAGIC = 3
 AT_INVALID_SKILL = 4
 AT_DAMAGE_ZONE = 5
 AT_NONE = 6
 *************************/

int GETATK_RET_ORIG = 0x004D9D50;
int GETATK_RET_CHECKTYPE = 0x004DA70C;

int GETATK_PLAYERPTR;
int GETATK_BASEDMG;
int GETATK_PARAMPTR;

/*** Aesir Skill Funs ***/
int AESIR_BERM = 0x004DA4DA;
int AESIR_SHST = 0x004DA39B;

// Kind = *(pSkill + 0x18)
// GetSkillAttackForce(@pPlayer, pSkill, pAttackType)
void GetSkillAttackForce(int pSkill, int pAttackType)
{
	// Kind
	__asm movzx ecx,word ptr ss:[ebp-0x4E]
	__asm mov dword ptr ss:[ebp-0x5C],ecx

	// Player Pointer
	__asm mov ecx, dword ptr ss:[ebp-0x58]
	__asm mov GETATK_PLAYERPTR, ecx

	// GETATK_BASEDMG
	__asm lea ecx, dword ptr ss:[ebp-0x8]
	__asm mov GETATK_BASEDMG, ecx

	// GETATK_PARAMPTR
	__asm mov ecx, dword ptr ss:[ebp-0x4]
	__asm mov GETATK_PARAMPTR, ecx
	
	SkillAttackForce(GETATK_PLAYERPTR, pSkill, pAttackType, GETATK_BASEDMG, GETATK_PARAMPTR);

	__asm jmp eax
}

int SkillAttackForce(int PlayerPTR, int pSkill, int pAttackType, int pDamage, int pParams)
{
	int RetAddrs = GETATK_RET_ORIG;
	int addrs = 0;
	int Kind = 0;

	addrs = (DWORD)pSkill + 0x18;
	Kind = *(reinterpret_cast<unsigned short*>(addrs));
	
	switch(Kind)
	{
		/*************** Human ***************/
		// Skill 135 Assault Crash
		case 0x87:
		{
			AssaultCrashAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		/**************** Elf ****************/
		//Skill 289 0x121 Divine Beam
		case 0x121:
		{
			DivineBeamAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		//Skill 258 0x102 Holy Light
		case 0x102:
		{
			HolyLightAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 306 0x132 Marea's Hammer
		case 0x132:
		{
			MareasHammer(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 309 0x135 Final Attempt
		case 0x135:
		{
			FinalAttempt(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 310 0x136 Marea's Anger
		case 0x136:
		{
			MareasAngerAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 311 0x137 Destruction
		case 0x137:
		{
			Destruction(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		/************* Half Elf **************/
		// Skill 544 0x220 Brandish Kick
		case 0x220:
		{
			BrandishKickAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		/*************** Dhan ****************/
		// Skill 1077 0x435 Suicide
		case 0x435:
		{
			SuicideAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		/************** Trinity **************/
		// Skill 8193 0x2001 Pentagram of Light
		case 0x2001:
		{
			PentagramOfLightAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 8194 0x2002 Darkness Calling
		case 0x2002:
		{
			DarknessCallingAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 8204 0x200C Dark Side Trace
		case 0x200C:
		{
			DarkSideTraceAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 8212 0x2014 Dark Side Zone
		case 0x2014:
		{
			DarkSideZoneAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 8210 0x2012 Mana Bombing
		case 0x2012:
		{
			ManaBombingAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 8217 0x2019 Lightning Swift
		case 0x2019:
		{
			LightningSwiftAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 8238 0x202E Absolute Flash
		case 0x202E:
		{
			AbsoluteFlashAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 8220 0x201C Wound of Restriction
		case 0x201C:
		{
			WoundOfRestrictionAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 8224 0x2020 Penetrating Darkness
		case 0x2020:
		{
			PenetratingDarknessAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 8227 0x2023 Windy Chain
		case 0x2023:
		{
			WindyChainAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 8230 0x2026 Thunderstroke
		case 0x2026:
		{
			ThunderstrokeAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 8233 0x2029 Airburst
		case 0x2029:
		{
			AirburstAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 8252 0x203C Distortion Claw - Chaos
		case 0x203C:
		{
			DistortionClawChaosAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 8253 0x203D Dimensional Scar
		case 0x203D:
		{
			DimensionalScarAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		/*************** Aesir* **************/
		// Skill 16525 0x408D Intelligence Beam
		case 0x408D:
		{
			RetAddrs = AESIR_BERM;
		}
		break;
		// Skill 16536 0x4098 MagicStay
		case 0x4098:
		{
			MagicStayAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 16538 0x409A MarshMaze
		case 0x409A:
		{
			MarshMazeAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 16545 0x40A1 Whispel
		case 0x40A1:
		{
			WhispelAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 16556 0x40AC LastWhisper
		case 0x40AC:
		{
			LastWhisperAttackForce(PlayerPTR, pAttackType, pDamage, pParams);
			RetAddrs = GETATK_RET_CHECKTYPE;
		}
		break;
		// Skill 16561 0x40B1 Shield Strike
		case 0x40B1:
		{
			RetAddrs = AESIR_SHST;
		}
		break;
	}

	return RetAddrs;
}
