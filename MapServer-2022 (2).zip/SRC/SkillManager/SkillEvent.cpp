#include <SkillManager.h>
//#include <MapFunctions.h>

using namespace std;

int SKILLEVENTON_RET = 0x004A168B;
int SKILLEVENTOFF_RET = 0x004A1EAD;

// RCM_SKILL_SKILLEVENT 0x1603
// SkillEvent(int @CalAffect, int pSkillMode, int pASO)
// pSkill = pASO +0x18; Size 0xE
// Mode = *(Char)pSkillMode
void SkillEventOn()
{
	// Kind +0x14
	__asm movzx ecx,word ptr ss:[ebp-0x1C]
	__asm mov dword ptr ss:[ebp-0x10],ecx
	// Level + AddPoint +0x17
	__asm mov byte ptr ss:[ebp-0xD],al
	__asm jmp SKILLEVENTON_RET
}

void SkillEventOff()
{
	// Kind
	__asm movzx eax,word ptr ss:[ebp-0x2AC]
	// +0x14 Kind
	__asm mov dword ptr ss:[ebp-0x2A0],eax
	// +0x17 Level
	__asm mov byte ptr ss:[ebp-0x29D],dl

	__asm mov edx,dword ptr ss:[ebp+0x10]
	__asm cmp edx,0x0
	__asm jne RET_ORIG

	__asm mov dword ptr ss:[ebp-0x2A9],0x0
	__asm mov dword ptr ss:[ebp-0x2A5],0x0
	__asm mov dword ptr ss:[ebp-0x2A1],0x0
	__asm mov dword ptr ss:[ebp-0x29D],0x0
	__asm mov dword ptr ss:[ebp-0x299],0x0
	__asm mov word ptr ss:[ebp-0x295],0x0

RET_ORIG:
	// RET ORIG
	__asm movzx eax,word ptr ss:[ebp-0x2AC]
	__asm jmp SKILLEVENTOFF_RET
}