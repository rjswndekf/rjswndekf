#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 

int CRITICALDMG_RET = 0x00532DC8;
int CRITICALDMG_THIS;
int CRITICAL_DAMAGE;;
int CRITICAL_AFFECT;

int INCCDMG_RET = 0x00530997;
int INCCDMG_ATTACK;
unsigned int INCCDMG_DAMAGE;
int INCCDMG_VALUE;
int INCCDMG_KIND;
int INCCDMG_IGNORES;

void CriticalDamageAttackeeAction(int Damage, int Kind, int Result)
{
	__asm mov eax,dword ptr ss:[ebp-0x9C]
	__asm mov CRITICALDMG_THIS,eax
	__asm mov ecx,dword ptr ds:[eax+0x1D4]
	__asm mov dword ptr ss:[ebp-0x78],ecx
	
	__asm lea edx,dword ptr ss:[ebp+0x8]
	__asm mov CRITICAL_DAMAGE,edx

	CriticalDamage(CRITICALDMG_THIS, CRITICAL_DAMAGE, Kind, Result);

	__asm jmp CRITICALDMG_RET
}

void CriticalDamage(int pAttack, int pDamage, int Kind, int Result)
{
	int addrs = 0;
	int PlayerPTR = 0;
	int TargetPTR = 0;
	int SelfCalAffectPTR = 0;
	int TargetCalAffectPTR = 0;
	int pThis = 0;
	int State = 0;
	unsigned int Damage = 0;
	unsigned int AddDamage = 0;
	unsigned int SubDamage = 0;
	unsigned int SubDamageRate = 0;
	int ParamPTR = 0;
	int DrainLife = 0;
	int Param1 = 0;
	int Param2 = 0;

	//tagAffectSkillInit(CRITICALAS_ADDRS);

	addrs = (DWORD)pAttack + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	SelfCalAffectPTR = (DWORD)PlayerPTR + 0x100;

	addrs = (DWORD)pAttack + 0x1D4;
	pThis = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pThis;
	TargetPTR = *(reinterpret_cast<int*>(addrs));

	TargetCalAffectPTR = (DWORD)TargetPTR + 0x100;

	// Skill 8214 0x2016 Causal Loop/Dark Side Loop
	State = CheckAffectStatus(TargetCalAffectPTR, 0x2016);
	if (State == 1)
	{
		// Get Params
		ParamPTR = GetParamPTR(TargetPTR, 0x2016);
		addrs = (DWORD)ParamPTR;
		Param1 = *(reinterpret_cast<int*>(addrs));

		addrs = (DWORD)pDamage;
		Damage = *(reinterpret_cast<int*>(addrs));

		//DrainLife = (Damage * Param1) / 100;
		//ChangeLife(TargetCalAffectPTR, DrainLife, 1);
		//SendLifeManaBroadcast(TargetPTR);

		addrs = (DWORD)pDamage;
		*(reinterpret_cast<int*>(addrs)) = 0;
	}
	// Skill 8215 0x2017 Dark Side Loop
	State = CheckAffectStatus(TargetCalAffectPTR, 0x2017);
	if (State == 1)
	{
		// Get Params
		ParamPTR = GetParamPTR(TargetPTR, 0x2017);
		addrs = (DWORD)ParamPTR;
		Param1 = *(reinterpret_cast<int*>(addrs));

		addrs = (DWORD)pDamage;
		Damage = *(reinterpret_cast<int*>(addrs));

		AddDamage = (Damage * Param1) / 100;
		
		Damage += AddDamage;

		addrs = (DWORD)pDamage;
		*(reinterpret_cast<int*>(addrs)) = Damage;
	}
	
	// Skill 16547 0x40A3 DoubleAxeMastery
	State = CheckAffectStatus(SelfCalAffectPTR, 0x40A3);
	if (State == 1)
	{
		// Get Params
		ParamPTR = GetParamPTR(PlayerPTR, 0x40A3);
		addrs = (DWORD)ParamPTR + 0x4;
		Param2 = *(reinterpret_cast<int*>(addrs));

		addrs = (DWORD)pDamage;
		Damage = *(reinterpret_cast<int*>(addrs));

		AddDamage = (Damage * Param2) / 100;

		Damage += AddDamage;

		addrs = (DWORD)pDamage;
		*(reinterpret_cast<int*>(addrs)) = Damage;
	}

	// CA_CRITICAL_DAMAGE_REDUCTION_RATE 0x82 / Skill 0x117
	SubDamageRate = BioticBaseGetAbility(TargetPTR, 0x82);
	if (SubDamageRate != 0)
	{
		addrs = (DWORD)pDamage;
		Damage = *(reinterpret_cast<int*>(addrs));

		SubDamage = (Damage * SubDamageRate) / 100;
		Damage -= SubDamage;

		addrs = (DWORD)pDamage;
		*(reinterpret_cast<int*>(addrs)) = Damage;
	}
}

void IncCriticalDamage()
{
	// pAttack
	__asm mov INCCDMG_ATTACK,ecx
	// Damage
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov INCCDMG_DAMAGE,eax
	// CriticalValue
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm mov INCCDMG_VALUE,ecx
	// Kind
	__asm mov edx,dword ptr ss:[ebp+0x10]
	__asm and edx, 0xFFFF
	__asm mov INCCDMG_KIND,edx
	// IgnoresCritical
	__asm mov eax,dword ptr ss:[ebp+0x14]
	__asm mov INCCDMG_IGNORES,eax
	
	CalAddCriticalDamage(INCCDMG_ATTACK, INCCDMG_DAMAGE, INCCDMG_VALUE, INCCDMG_KIND, INCCDMG_IGNORES);
	
	__asm mov dword ptr ss:[ebp+0x8],eax
	__asm mov eax,dword ptr ss:[ebp+0x8]

	__asm jmp INCCDMG_RET
}

unsigned int CalAddCriticalDamage(int pAttack, unsigned int Damage, int CriticalValue, int Kind, int IgnoresCritical)
{
	int addrs;
	int pPlayer;
	int CheckPlayer = 0;
	int pItemWeapon = 0;
	int CheckItem = 0;
	int ItemType = 0;
	int pThis = 0;
	int SkillValue = 0;
	int StatValue = 0;
	unsigned int CalValue = 0;
	float SkillValueFP = 0.0;
	float StatValueFP = 0.0;
	float CalValueFP = 0.0;
	int State = 0;

	addrs = (DWORD)pAttack + 0x1CC;
	pPlayer = *(reinterpret_cast<int*>(addrs));

	CalValue = Damage * CriticalValue / 100;

	Damage = CalValue;

	if (IgnoresCritical == 0)
	{
		// Skill 0x5F CRITICAL_ADD_DAMAGE_BY_INT
		pThis = pPlayer + 0x160;
		SkillValue = EntityBaseStatusGetAbility(pThis, 0x5F);
		if (SkillValue != 0)
		{
			// CA_INTELLIGENCE
			StatValue = BioticBaseGetAbility(pPlayer, 2);
			CalValue = SkillValue * StatValue / 100;
			Damage += CalValue;
		}
		// Skill 0x60 CRITICAL_ADD_DAMAGE_BY_STR
		pThis = pPlayer + 0x160;
		SkillValue = EntityBaseStatusGetAbility(pThis, 0x60);
		if (SkillValue != 0)
		{
			// CA_STRENGTH
			StatValue = BioticBaseGetAbility(pPlayer, 0);
			CalValue = SkillValue * StatValue / 100;
			Damage += CalValue;
		}
		// Skill 0x61 CRITICAL_ADD_DAMAGE_BY_DEX
		pThis = pPlayer + 0x160;
		SkillValue = EntityBaseStatusGetAbility(pThis, 0x61);
		if (SkillValue != 0)
		{
			// CA_DEXTERITY
			StatValue = BioticBaseGetAbility(pPlayer, 3);
			CalValue = SkillValue * StatValue / 100;
			Damage += CalValue;
		}
		// Skill 0x94 CRITICAL_ADD_DAMAGE_BY_PSY
		pThis = pPlayer + 0x160;
		SkillValue = EntityBaseStatusGetAbility(pThis, 0x94);
		if (SkillValue != 0)
		{
			// CA_MENTALITY
			StatValue = BioticBaseGetAbility(pPlayer, 4);
			CalValue = SkillValue * StatValue / 100;
			Damage += CalValue;
		}
		// Skill 0x114 CRITICAL_ADD_DAMAGE_BY_VIT
		pThis = pPlayer + 0x160;
		SkillValue = EntityBaseStatusGetAbility(pThis, 0x114);
		if (SkillValue != 0)
		{
			// CA_HEALTH
			StatValue = BioticBaseGetAbility(pPlayer, 1);
			CalValue = SkillValue * StatValue / 100;
			Damage += CalValue;
		}
	}
	// Check Kind
	// Skill 1026 0x402 Psychic Phantom
	// Skill 1076 0x434 Double Psychic Phantom
	if ((Kind != 0x402) && (Kind != 0x434))
	{
		// Skill 0x58 CRITICAL_ADD_DAMAGE_BY_AGI
		pThis = pPlayer + 0x160;
		SkillValue = EntityBaseStatusGetAbility(pThis, 0x58);
		if (SkillValue != 0)
		{
			// CA_QUICKNESS
			StatValue = BioticBaseGetAbility(pPlayer, 5);
			SkillValueFP = (float)SkillValue;
			StatValueFP = (float)StatValue;
			CalValueFP = SkillValueFP * StatValueFP / 100;
			CalValue = (int)CalValueFP;
			Damage += CalValue;
		}
		// Skill 0x59 CRITICAL_ADD_DAMAGE_BY_DEXTERITY_2
		pThis = pPlayer + 0x160;
		SkillValue = EntityBaseStatusGetAbility(pThis, 0x59);
		if (SkillValue != 0)
		{
			// CA_DEXTERITY
			StatValue = BioticBaseGetAbility(pPlayer, 3);
			SkillValueFP = (float)SkillValue;
			StatValueFP = (float)StatValue;
			CalValueFP = (StatValue / 2.2) * SkillValueFP;
			CalValue = (int)CalValueFP;
			Damage += CalValue;
		}
		// Skill 0x5A CRITICAL_ADD_DAMAGE_BY_DEXTERITY_3
		pThis = pPlayer + 0x160;
		SkillValue = EntityBaseStatusGetAbility(pThis, 0x5A);
		if (SkillValue != 0)
		{
			// CA_DEXTERITY
			StatValue = BioticBaseGetAbility(pPlayer, 3);
			SkillValueFP = (float)SkillValue;
			StatValueFP = (float)StatValue;
			CalValueFP = (StatValue / 1.7) * SkillValueFP;
			CalValue = (int)CalValueFP;
			Damage += CalValue;
		}
		// Skill 0xDA INC_CRITICAL_DAMAGE_POLEARM_MASTERY
		pThis = pPlayer + 0x160;
		SkillValue = EntityBaseStatusGetAbility(pThis, 0xDA);
		if (SkillValue != 0)
		{
			CheckPlayer = RTDynamicCast(pPlayer, 0, 0x7E9608, 0x7E9638, 0);
			if (CheckPlayer != 0)
			{
				pThis = pPlayer + 0xCC8;
				pItemWeapon = GetItem(pThis, 0, 5);
				CheckItem = RTDynamicCast(pItemWeapon, 0, 0x7E9778, 0x7E9794, 0);
				if (CheckItem != 0)
				{
					ItemType = GetAttribute(pItemWeapon, 0);
					if (ItemType == 7)
					{
						Damage += SkillValue;
					}
				}
			}
		}
	}
	// CA_INC_CRITICAL_DMG_RATE
	StatValue = BioticBaseGetAbility(pPlayer, 0x6B);
	if (StatValue != 0)
	{
		CalValue = Damage * StatValue / 100;
		Damage += CalValue;
	}
	return Damage;
}
