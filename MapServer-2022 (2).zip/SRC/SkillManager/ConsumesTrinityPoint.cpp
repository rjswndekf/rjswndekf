#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 

int CONSUMES_RET = 0x004A7D56;
int CONSUMES_PLAYER;

/******* ASM Funs *******/
extern int SENDLIFIMANABROADCAST;

void ConsumesPoint()
{
	__asm mov eax,dword ptr ss:[ebp-0x4]
	__asm mov edx,dword ptr ds:[eax+0x58]
	__asm mov CONSUMES_PLAYER,edx

	__asm cmp dword ptr ds:[eax+0x70],0x1
	__asm jne SENDLIFEMANA

	ConsumesTrinityPoint(CONSUMES_PLAYER);

SENDLIFEMANA:
	__asm push 0x0
	__asm mov edx,dword ptr ss:[ebp-0x4]
	__asm mov ecx,dword ptr ds:[edx+0x58]
	__asm call SENDLIFIMANABROADCAST

	__asm jmp CONSUMES_RET
}

void ConsumesTrinityPoint(int PlayerPTR)
{
	int addrs = 0;
	int CalAffectPTR = 0;
	int pSkill = 0;
	int State = 0;
	int BuffCount = 0;
	int ParamPTR = 0;
	int Param5 = 0;
	int CurTP = 0;

	CalAffectPTR = (DWORD)PlayerPTR + 0x100;

	// Skill 8222 0x201E Thorns Whip
	State = CheckBuffSkillStatus(CalAffectPTR, 0x201E);
	if (State == 1)
	{
		ParamPTR = GetParamPTR(PlayerPTR, 0x201E);
		if (ParamPTR != 0)
		{
			Param5 = GetParams(ParamPTR, 5);

			addrs = (DWORD)PlayerPTR + 0x2050;
			CurTP = *(reinterpret_cast<int*>(addrs));
			if (CurTP < Param5)
			{
				EndBuffSkill(CalAffectPTR, 0x201E, 1);
			}
			else
			{
				DecTP(PlayerPTR, Param5);
				SendTPBroadcast(PlayerPTR);
			}
		}
	}

	// Skill 8201 0x2009 Dark Side Force
	State = CheckBuffSkillStatus(CalAffectPTR, 0x2009);
	if (State == 1)
	{
		ParamPTR = GetParamPTR(PlayerPTR, 0x2009);
		if (ParamPTR != 0)
		{
			Param5 = GetParams(ParamPTR, 5);

			addrs = (DWORD)PlayerPTR + 0x2050;
			CurTP = *(reinterpret_cast<int*>(addrs));
			if (CurTP < Param5)
			{
				EndBuffSkill(CalAffectPTR, 0x2009, 1);
			}
			else
			{
				DecTP(PlayerPTR, Param5);
				SendTPBroadcast(PlayerPTR);
			}
		}
	}

}
