#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 

int CALAF_AFPTR;
int CALAF_RET_ORIG = 0x004B9C99;
int CALAF_RET_ALLABILITY = 0x004C2882;
int CALAF_RET_END = 0x004C2899;
//int CALAF_RET_MANAINCI = 0x004C1B87;

/*** Aesir Skill Funs ***/
int SK_4082_RET = 0x004BA8C1;
int SK_4083_RET = 0x004BADAB;
int SK_4084_RET = 0x004BDA53;
int SK_4085_RET = 0x004BA861;
int SK_4089_RET = 0x004BAE71;
int SK_4090_RET = 0x004BC3E5;
int SK_4091_RET = 0x004BCCCB;
int SK_40B1_RET = 0x004C1BC0;
int SK_40A4_RET = 0x004BB51B;
int SK_40A5_RET = 0x004BB44F;
int SK_40A6_RET = 0x004BB581;

/******* ASM Funs *******/
extern int RTDYNAMICCAST;


// void CalAffect(IntPtr @this, uint CharId, ushort Kind, IntPtr ParamsPTR, int bActive);
void CalAffect(int CharID, int Kind, int pParams, int Active)
{
	// Original Code
	__asm mov dword ptr ss:[ebp-0x4D8],eax

	// Target / Player CalAffect Pointer
	__asm mov eax,dword ptr ss:[ebp-0x4D4]
	__asm mov CALAF_AFPTR, eax
	__asm cmp eax,0x0
	__asm je RET_END

	// Check Target / Player
	__asm mov edx,dword ptr ss:[eax+0x58]
	__asm cmp edx,0x0
	__asm je RET_END

	CalAffectSkill(CALAF_AFPTR, CharID, Kind, pParams, Active);

	__asm jmp eax

/************** END **************/
RET_END:
	__asm jmp CALAF_RET_END

}

int CalAffectSkill(int pCalAffect, int CharID, int Kind, int pParams, int Active)
{
	int RetAddrs = CALAF_RET_ORIG;

	switch(Kind)
	{
		/*************** Human ***************/
		// Skill 131 0x83 Bless Shield
		case 0x83:
		{
			BlessShield(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill 132 0x84 Invoke
		case 0x84:
		{
			Invoke(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 138 0x8A Stone Skin
		case 0x8A:
		{
			StoneSkin(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 179 0xB3 Empower
		case 0xB3:
		{
			Empower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 181 0xB5 Sword Mastery
		case 0xB5:
		{
			SwordMastery(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 182 0xB6 Aimed Blow
		case 0xB6:
		{
			AimedBlow(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 186 0xBA Order Swing
		case 0xBA:
		{
			OrderSwing(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 187 0xBB Crazy Swing
		case 0xBB:
		{
			CrazySwing(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 191 0xBF Critical Aura
		case 0xBF:
		{
			CriticalAura(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 215 0xD7 Stone Skin
		case 0xD7:
		{
			StoneSkin(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 164 0xA4 Blunt Mastery
		case 0xA4:
		{
			BluntMasteryA(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 166 0xA6 Shield Mastery
		case 0xA6:
		{
			ShieldMastery(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 172 0xAC Powered Heavy Armor
		case 0xAC:
		{
			PoweredHeavyArmor(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 199 0xC7 Over Crowd
		case 0xC7:
		{
			OverCrowd(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 214 0xD6 Ultimate Bastion
		case 0xD6:
		{
			UltimateBastion(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 196 0xC4 Heroic Power
		case 0xC4:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 211 0xD3 Heroic Power
		case 0xD3:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 200 0xC8 Aegis
		case 0xC8:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 216 0xD8 Aegis
		case 0xD8:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		/**************** Elf ****************/
		// Skill 260 0x104 Mental Barrier
		case 0x104:
		{
			MentalBarrier(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 339 0x153 Group All Mighty
		case 0x153:
		{
			GroupAllMighty(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 322 0x142 Marea's Grace
		case 0x142:
		{
			MareasGrace(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 292 0x124 Soul Meditation
		case 0x124:
		{
			SoulMeditation(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 318 0x13E Staff Mastery
		case 0x13E:
		{
			StaffMastery(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 303 0x12F Blunt Mastery
		case 0x12F:
		{
			BluntMasteryB(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 305 0x131 Reflection
		case 0x131:
		{
			Reflection(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 337 0x151 Heaven's Dawn
		case 0x151:
		{
			HeavensDawn(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 352 0x160 Last Divine
		case 0x160:
		{
			LastDivine(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 334 0x14E Heroic Power
		case 0x14E:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 349 0x15D Heroic Power
		case 0x15D:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 340 0x154 Aegis
		case 0x154:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 353 0x161 Aegis
		case 0x161:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		/************* Half Elf **************/
		// Skill 515 0x203 Fatal
		case 0x203:
		{
			Fatal(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 562 0x232 Crossbow Mastery
		case 0x232:
		{
			CrossbowMastery(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 567 0x237 Siege Shot
		case 0x237:
		{
			SiegeShot(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 569 0x239 Kaels Bolt
		case 0x239:
		{
			KaelsBolt(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 572 0x23C Rank Shot
		case 0x23C:
		{
			RankShotA(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 574 0x23E Premium Shot
		case 0x23E:
		{
			PremiumShotA(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 583 0x247 Death Chaser
		// Skill 547 0x223 Bow Mastery
		case 0x223:
		{
			BowMastery(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 550 0x226 Sharp Melee
		case 0x226:
		{
			SharpMelee(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 553 0x229 Kaels Arrow
		case 0x229:
		{
			KaelsArrow(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 557 0x22D Premium Shot
		case 0x22D:
		{
			PremiumShotB(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 559 0x22F Rank Shot
		case 0x22F:
		{
			RankShotB(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 598 0x256 Cataclysm
		case 0x256:
		{
			Cataclysm(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 580 0x244 Heroic Power
		case 0x244:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 595 0x253 Heroic Power
		case 0x253:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 584 0x248 Aegis
		case 0x248:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 600 0x258 Aegis
		case 0x258:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		/*************** Dhan ***************/
		// Skill 1027 0x403 Deadly Blow
		case 0x403:
		{
			DeadlyBlow(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 1040 0x410 Strength
		case 0x410:
		{
			Strength(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 1068 0x42C Katar Mastery
		case 0x42C:
		{
			KatarMasteryA(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 1085 0x43D Katar Mastery
		case 0x43D:
		{
			KatarMasteryB(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 1099 0x44B Royal Mask
		case 0x44B:
		{
			RoyalMask(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 1110 0x456 Crown's Laughter
		case 0x456:
		{
			CrownsLaughter(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 1125 0x465 Isolation Stealth
		case 0x465:
		{
			IsolationStealth(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 1107 0x453 Heroic Power
		case 0x453:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 1122 0x462 Heroic Power
		case 0x462:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 1111 0x457 Aegis
		case 0x457:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 1126 0x466 Aegis
		case 0x466:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		/*************** Giant ***************/
		// Skill 2052 0x804 Battle Chant
		case 0x804:
		{
			BattleChant(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 2054 0x806 Find Hole
		case 0x806:
		{
			FindHole(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 2064 0x810 Polearm Mastery
		case 0x810:
		{
			PolearmMastery(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 2065 0x811 Criminal Mind
		case 0x811:
		{
			CriminalMind(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 2082 0x822 Dual Sword Mastery
		case 0x822:
		{
			DualSwordMastery(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 2084 0x824 Rampage Force
		case 0x824:
		{
			RampageForce(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 2085 0x825 Ferocious
		case 0x825:
		{
			Ferocious(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 2087 0x827 Monster Mind
		case 0x827:
		{
			MonsterMind(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 2089 0x829 Brutality
		case 0x829:
		{
			Brutality(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 2103 0x837 Gigantic Storm
		case 0x837:
		{
			GiganticStorm(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 2118 0x846 Fury Tempest
		case 0x846:
		{
			FuryTempest(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 2100 0x834 Heroic Power
		case 0x834:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 2115 0x843 Heroic Power
		case 0x843:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 2104 0x838 Aegis
		case 0x838:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 2119 0x847 Aegis
		case 0x847:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		/************* Dark Elf **************/
		// Skill 32979 0x80D3 Ability Drain (Player)
		case 0x80D3:
		{
			AbilityDrainP(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 4121 0x1019 Ability Drain (Target)
		case 0x1019:
		{
			AbilityDrainT(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 4127 0x101F Area Toxic Potion
		// Skill 4099 0x1003 Dark Message
		case 0x1003:
		{
			DarkMessage(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 4116 0x1014 Staff Mastery
		case 0x1014:
		{
			StaffMasteryA(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 4117 0x1015 Add Intention
		case 0x1015:
		{
			AddIntention(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 4160 0x1040 Mana Incineration
		case 0x1040:
		{
			ManaIncineration(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 4135 0x1027 Staff Mastery
		case 0x1027:
		{
			StaffMasteryB(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 4136 0x1028 Add Temper
		case 0x1028:
		{
			AddTemper(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 4162 0x1042 Spell Liberation
		case 0x1042:
		{
			SpellLiberation(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 4177 0x1051 Spell Extension
		case 0x1051:
		{
			SpellExtension(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 4159 0x103F Heroic Power
		case 0x103F:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 4174 0x104E Heroic Power
		case 0x104E:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 4163 0x1043 Aegis
		case 0x1043:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 4178 0x1052 Aegis
		case 0x1052:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		/*************** Dekan ***************/
		// Skill 16401 0x4011 Zhen Mastery (Dragon Knight)
		case 0x4011:
		{
			ZhenMasteryA(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16402 0x4012 Blue Defense (Dragon Knight)
		case 0x4012:
		{
			BlueDefense(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16403 0x4013 Critical Immunity (Dragon Knight)
		case 0x4013:
		{
			CriticalImmunityA(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16408 0x4018 Forced Lock (Dragon Knight)
		case 0x4018:
		{
			ForcedLock(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16443 0x403B Elderblood Awaken (Dragon Knight)
		case 0x403B:
		{
			ElderbloodAwaken(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16419 0x4023 Zhen Mastery (Dragon Sage)
		case 0x4023:
		{
			ZhenMasteryB(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16420 0x4024 Blue Intelligence (Dragon Sage)
		case 0x4024:
		{
			BlueIntelligence(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16422 0x4026 Critical Immunity (Dragon Sage)
		case 0x4026:
		{
			CriticalImmunityB(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16427 0x402B Rapid Lock (Dragon Sage)
		case 0x402B:
		{
			RapidLock(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16435 0x4033 Impenetrable (Dragon Sage)
		case 0x4033:
		{
			Impenetrable(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16470 0x4056 Evolve Separation (Dragon Sage)
		case 0x4056:
		{
			EvolveSeparation(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16458 0x404A Reverse Scale (Dragon Sage)
		case 0x404A:
		{
			ReverseScale(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16440 0x4038 Heroic Power
		case 0x4038:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16455 0x4047 Heroic Power
		case 0x4047:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16444 0x403C Aegis
		case 0x403C:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16459 0x404B Aegis
		case 0x404B:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		/************** Trinity **************/
		// Skill 8195 0x2003 Tune of Life
		case 0x2003:
		{
			TuneOfLife(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8197 0x2005 Dormant Power
		case 0x2005:
		{
			DormantPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8198 0x2006 Arrendal Mastery
		case 0x2006:
		{
			ArrendalMasteryA(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8199 0x2007 Prism Sphere
		case 0x2007:
		{
			PrismSphere(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8200 0x2008 Trinity Force
		case 0x2008:
		{
			TrinityForceA(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		/***
		// Skill 8201 0x2009 Dark Side Force
		case 0x2009:
		***/

		// Skill 8202 0x200A Nature Unity
		case 0x200A:
		{
			NatureUnityCCalAffect(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8205 0x200D Sequoias Favor
		case 0x200D:
		{
			SequoiasFavor(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8206 0x200E Vine Protection
		case 0x200E:
		{
			VineProtection(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8207 0x200F Pulsating Light
		case 0x200F:
		{
			PulsatingLight(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8209 0x2011 Blessed Crown
		case 0x2011:
		{
			BlessedCrown(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8214 0x2016 Causal Loop/Dark Side Loop
		case 0x2016:
		{
			CausalLoop(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8216 0x2018 Growth Acceleration
		case 0x2018:
		{
			GrowthAcceleration(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8218 0x201A Revive Force
		case 0x201A:
		{
			ReviveForce(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8239 0x202F Eternal Aria
		case 0x202F:
		{
			EternalAria(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8219 0x201B Arrendal Mastery TN
		case 0x201B:
		{
			ArrendalMasteryB(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8221 0x201D Trinity Force TN
		case 0x201D:
		{
			TrinityForceB(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		/***
		// Skill 8223 0x201F Phantom Spirit
		case 0x201F:
		***/

		// Skill 8225 0x2021 Dark Assimilation
		case 0x2021:
		{
			DarkAssimilation(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8228 0x2024 Spirit Concentration
		case 0x2024:
		{
			SpiritConcentration(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8235 0x202B Dimensional Coat
		case 0x202B:
		{
			DimensionalCoat(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8252 0x203C Distortion Claw - Chaos
		case 0x203C:
		{
			DistortionClawChaosCalAffect(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8254 0x203E Silent Noise
		case 0x203E:
		{
			SilentNoise(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8236 0x202C Heroic Power
		case 0x202C:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8251 0x203B Heroic Power
		case 0x203B:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8240 0x2030 Aegis
		case 0x2030:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 8255 0x203F Aegis
		case 0x203F:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		/************** Aesir **************/
		// Skill 16514 0x4082 Rising Might
		case 0x4082:
		{
			RetAddrs = SK_4082_RET;
		}
		break;

		// Skill 16515 0x4083 Intelligence Blow
		case 0x4083:
		{
			RetAddrs = SK_4083_RET;
		}
		break;

		// Skill 16516 0x4084 Frozen Ice
		case 0x4084:
		{
			RetAddrs = SK_4084_RET;
		}
		break;

		// Skill 16517 0x4085 Protection
		case 0x4085:
		{
			RetAddrs = SK_4085_RET;
		}
		break;

		// Skill 16518 0x4086 Bless Shield
		case 0x4086:
		{
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16521 0x4089 Evade
		case 0x4089:
		{
			RetAddrs = SK_4089_RET;
		}
		break;

		// Skill 16528 0x4090 Experience Mambo
		case 0x4090:
		{
			RetAddrs = SK_4090_RET;
		}
		break;

		// Skill 16529 0x4091 Detect
		case 0x4091:
		{
			RetAddrs = SK_4091_RET;
		}
		break;

		// Skill 16561 0x40B1 Shield Strike
		case 0x40B1:
		{
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16546 0x40A2 Detect
		case 0x40A2:
		{
			RetAddrs = SK_40B1_RET;
		}
		break;

		// Skill 16548 0x40A4 Eternal Vitality
		case 0x40A4:
		{
			RetAddrs = SK_40A4_RET;
		}
		break;

		// Skill 16549 0x40A5 Shield Mastery
		case 0x40A5:
		{
			ShieldMastery(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16550 0x40A6 Crazy Strength
		case 0x40A6:
		{
			RetAddrs = SK_40A6_RET;
		}
		break;

		// Skill 16526 0x408E BluntMastery
		case 0x408E:
		{
			BluntMasteryC(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16527 0x408F Mentalty Amror
		case 0x408F:
		{
			MentaltyAmror(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16533 0x4095 MentalityTemper
		case 0x4095:
		{
			MentalityTemper(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16534 0x4096 CounterHunteress
		case 0x4096:
		{
			CounterHunteress(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16537 0x4099 GroupFatal
		case 0x4099:
		{
			GroupFatal(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16539 0x409B RegiShield
		case 0x409B:
		{
			RegiShieldCalAffect(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16540 0x409C MagicianAura
		case 0x409C:
		{
			MagicianAura(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16541 0x409D CaelsAura
		case 0x409D:
		{
			CaelsAura(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16542 0x409E RisingAura
		case 0x409E:
		{
			RisingAura(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16562 0x40B2 MagicBobySquare
		case 0x40B2:
		{
			MagicBobySquare(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16563 0x40B3 StealthReviver
		case 0x40B3:
		{
			StealthReviver(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16543 0x409F AxeMastery
		case 0x409F:
		{
			AxeMastery(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16547 0x40A3 DoubleAxeMastery
		case 0x40A3:
		{
			DoubleAxeMastery(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		
		// Skill 16551 0x40A7 WhisperMind
		case 0x40A7:
		{
			WhisperMind(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16552 0x40A8 RohasShiled
		case 0x40A8:
		{
			RohasShiledCalAffect(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16553 0x40A9 Excalibur
		case 0x40A9:
		{
			Excalibur(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16557 0x40AD AxeClock
		case 0x40AD:
		{
			AxeClock(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16558 0x40AE WhisperLimit
		case 0x40AE:
		{
			WhisperLimit(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16559 0x40AF MurderRemissionC
		case 0x40AF:
		{
			MurderRemissionC(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16576 0x40C0 AxeRange
		case 0x40C0:
		{
			AxeRange(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16560 0x40B0 Heroic Power
		case 0x40B0:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16575 0x40BF Heroic Power
		case 0x40BF:
		{
			HeroicPower(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16564 0x40B4 Aegis
		case 0x40B4:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		// Skill 16579 0x40C3 Aegis
		case 0x40C3:
		{
			Aegis(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;

		/************ Scroll Skill ***********/
		// Skill Add Move Speed Rate
		case 0xA085:
		{
			AddMoveSpeedRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Drop Cron Rate
		case 0xA09A:
		{
			DropCronRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Melee Attack Force Rate
		case 0xA0CF:
		{
			MeleeAttackForceRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Add Physical Defense Rate
		case 0xA0D0:
		{
			AddPhysicalDefenseRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Add Max Life Value
		case 0xA0D1:
		{
			AddMaxLifeValue(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Add Critical Damage Rate
		case 0xA0D2:
		{
			AddCriticalDamageRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Missile Attack Force Rate
		case 0xA0D3:
		{
			MissileAttackForceRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Magic Attack Force Rate
		case 0xA0D4:
		{
			MagicAttackForceRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Add Magic Defense Rate
		case 0xA0D5:
		{
			AddMagicDefenseRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Add All Stats Rate
		case 0xA0D6:
		{
			AddAllStatsRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Add All Stats Rate
		case 0xA0D9:
		{
			AddAllStatsRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Melee Attack Force Rate
		case 0xA0DA:
		{
			MeleeAttackForceRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Magic Attack Force Rate
		case 0xA0DB:
		{
			MagicAttackForceRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Missile Attack Force Rate
		case 0xA0DC:
		{
			MissileAttackForceRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Add Critical Damage Rate
		case 0xA0DD:
		{
			AddCriticalDamageRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Add Max Life Rate
		case 0xA0DE:
		{
			AddMaxLifeRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Add Physical Defense Rate
		case 0xA0DF:
		{
			AddPhysicalDefenseRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill Add Magic Defense Rate
		case 0xA0E0:
		{
			AddMagicDefenseRate(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill 41185 0xA0E1 Transcendence Scroll
		case 0xA0E1:
		{
			TranscendenceScroll(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
		// Skill 41186 0xA0E2 Conqueror Scroll
		case 0xA0E2:
		{
			ConquerorScroll(pCalAffect, pParams, Active);
			RetAddrs = CALAF_RET_ALLABILITY;
		}
		break;
	}
	
	return RetAddrs;
}

// Skill Heroic Power
void HeroicPower(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// CA_PVP_DEFENCE_RATE 0x6E
	QualitiesCalOption(CalAffectPTR, 0xF5, Param2, Active);
}

// Skill Aegis
void Aegis(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// CA_LIFE_DRAIN_BONUS 0x37
	QualitiesCalOption(CalAffectPTR, 0xFE, Param1, Active);	
}
