#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 


// Skill 32979 0x80D3 Ability Drain (Player)
void AbilityDrainP(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0xB7, Param2, Active);
}
// Skill 4121 0x1019 Ability Drain (Target)
void AbilityDrainT(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0xB6, Param1, Active);
}
// Skill 4127 0x101F Area Toxic Potion
//void AreaToxicPotion(int CalAffectPTR, int ParamsPTR, int Active){}
// Skill 4099 0x1003 Dark Message
void DarkMessage(int CalAffectPTR, int ParamsPTR, int Active)
{
	int addrs;
	int PlayerPTR;
	int IntVar;
	int PsyVar;
	int AddVar;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	IntVar = BioticBaseGetAbility(PlayerPTR, 0x2) * Param1 / 100;
	PsyVar = BioticBaseGetAbility(PlayerPTR, 0x4) * Param2 / 100;
	AddVar = IntVar + PsyVar;

	QualitiesCalOption(CalAffectPTR, 0xD6, AddVar, Active);
	QualitiesCalOption(CalAffectPTR, 0x96, AddVar, Active);	
}
// Skill 4116 0x1014 Staff Mastery
void StaffMasteryA(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0xB9, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x111, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0xEB, Param3, Active);
}
// Skill 4117 0x1015 Add Intention
void AddIntention(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x12, Param1, Active);
}
// Skill 4160 0x1040 Mana Incineration
void ManaIncineration(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0xE8, Param1, Active);
}

// Skill 4135 0x1027 Staff Mastery
void StaffMasteryB(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0xBA, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x112, Param2, Active);

}
// Skill 4136 0x1028 Add Temper
void AddTemper(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x10, Param1, Active);
}
// Skill 4162 0x1042 Spell Liberation
void SpellLiberation(int CalAffectPTR, int ParamsPTR, int Active)
{
	//int RemainderRate;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x62, Param2, Active);

	// CA_DAMAGE_RATE 0x2B
	//RemainderRate = 0 - Param1;
	QualitiesCalOption(CalAffectPTR, 0xF1, Param1, Active);
}
// Skill 4177 0x1051 Spell Extension
void SpellExtension(int CalAffectPTR, int ParamsPTR, int Active)
{

}
