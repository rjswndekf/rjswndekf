#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std;

/****************************************
 SAO+0x4C Kind
 BC+0x8=1 IgnoresTargetDefense
 BC+0x10=1 IgnoresTargetReductionDamage
 ***************************************/

int IGNORES_RETORG = 0x0052929C;
int IGNORES_RETEND = 0x00529314;

int IGNORES_THIS;
int IGNORES_BC;
int IGNORES_SAO;

void IgnoresTargetProc()
{
	// Kind
	__asm mov dword ptr ss:[ebp-0x88],ecx

	// pAttack
	__asm mov edx,dword ptr ss:[ebp-0x84]
	__asm mov IGNORES_THIS,edx
	// BC
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov IGNORES_BC,eax
	// SAO
	__asm mov eax,dword ptr ss:[ebp+0xC]
	__asm mov IGNORES_SAO,eax

	IgnoresTargetReductionDamage(IGNORES_THIS, IGNORES_BC, IGNORES_SAO);

	__asm test eax,eax
	__asm je RET_ORIG
	__asm jmp IGNORES_RETEND

RET_ORIG:
	__asm jmp IGNORES_RETORG

}

int IgnoresTargetReductionDamage(int pAttack, int BC, int SAO)
{
	int Result = 0;
	int addrs = 0;
	int PlayerPTR = 0;
	int CalAffectPTR = 0;
	int Kind = 0;
	int State = 0;
	int ParamPTR = 0;
	int Param1 = 0;
	int AttackChance = 0;
	int Chance = 0;

	addrs = (DWORD)pAttack + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	CalAffectPTR = (DWORD)PlayerPTR + 0x100;

	addrs = (DWORD)SAO + 0x4C;
	Kind = *(reinterpret_cast<unsigned short*>(addrs));

	// Skill 1110 0x456 Crown's Laughter
	/***
	State = CheckAffectStatus(CalAffectPTR, 0x456);
	if (State == 1)
	{
		ParamPTR = GetParamPTR(PlayerPTR, 0x456);
		if (ParamPTR != 0)
		{
			addrs = (DWORD)ParamPTR;
			Param1 = *(reinterpret_cast<int*>(addrs));
			AttackChance = Param1 * 10000;
			Chance = BioticBaseGetRandom(PlayerPTR, 1000000);
			if (AttackChance < Chance)
			{
				// IgnoresTargetReductionDamage
				addrs = (DWORD)BC + 0x10;
				*(reinterpret_cast<int*>(addrs)) = 1;
				Result = 1;
			}
		}
	}
	***/

	// Skill 309 0x135 Final Attempt
	if (Kind == 0x135)
	{
		// IgnoresTargetDefense
		addrs = (DWORD)BC + 0x8;
		*(reinterpret_cast<int*>(addrs)) = 1;
		Result = 1;
	}

	// Skill 311 0x137 Destruction
	if (Kind == 0x137)
	{
		// IgnoresTargetReductionDamage
		addrs = (DWORD)BC + 0x10;
		*(reinterpret_cast<int*>(addrs)) = 1;
		Result = 1;
	}

	// Skill 16392 0x4008 Breath
	if (Kind == 0x4008)
	{
		// IgnoresTargetDefense
		addrs = (DWORD)BC + 0x8;
		*(reinterpret_cast<int*>(addrs)) = 1;
		Result = 1;
	}

	// Skill 8224 0x2020 Penetrating Darkness
	if (Kind == 0x2020)
	{
		// IgnoresTargetDefense
		addrs = (DWORD)BC + 0x8;
		*(reinterpret_cast<int*>(addrs)) = 1;
		Result = 1;
	}
	// Skill 16536 0x4098 MagicStay
	if (Kind == 0x4098)
	{
		// IgnoresTargetDefense
		addrs = (DWORD)BC + 0x8;
		*(reinterpret_cast<int*>(addrs)) = 1;
		Result = 1;
	}

	return Result;
}