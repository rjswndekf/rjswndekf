#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 

int ADDSKILL_CALAFFECT;
int ADDSKILL_ASPTR;
int ADDSKILL_RETNUZ = 0x004AAD47;
int ADDSKILL_RETORG = 0x004AAD4E;
int ADDSKILL_RETEND = 0x004AAD75;

/******* ASM Funs *******/
extern int CHECKASENABLE;

void AddSkillCheck()
{
	__asm cmp dword ptr ss:[ebp-0x10],0x0
	__asm je CHECK_ADDSKILL
	__asm jmp ADDSKILL_RETNUZ

CHECK_ADDSKILL:
	__asm mov ecx,dword ptr ss:[ebp-0xD0]
	__asm mov ADDSKILL_CALAFFECT,ecx
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov ADDSKILL_ASPTR,eax

	SkillReflectCheck(ADDSKILL_CALAFFECT, ADDSKILL_ASPTR);

	__asm test eax,eax
	__asm je RET_ORIG
	__asm jmp ADDSKILL_RETEND

RET_ORIG:
	// Orig Code
	__asm jmp ADDSKILL_RETORG

}

int SkillReflectCheck(int CalAffectPTR, int pAffectedSkill)
{
	int Result = 0;
	//int addrs;
	int State;
	int pThis;

	// Skill 16458 0x404A Reverse Scale
	pThis = CalAffectPTR;
	State = CheckAffectStatus(pThis, 0x404A);
	//addrs = (DWORD)CalAffectPTR + 0x188;
	//State = *(reinterpret_cast<int*>(addrs));
	if (State == 1)
	{
		pThis = CalAffectPTR;
		Result = ReflectSkill(pThis, pAffectedSkill);
	}
	// Skill 8223 0x201F Phantom Spirit
	pThis = CalAffectPTR;
	State = CheckAffectStatus(pThis, 0x201F);
	if (State == 1)
	{
		pThis = CalAffectPTR;
		Result = ReflectSkill(pThis, pAffectedSkill);
	}
	// Skill 16578 0x40C2 Digjection
	pThis = CalAffectPTR;
	State = CheckAffectStatus(pThis, 0x40C2);
	if (State == 1)
	{
		pThis = CalAffectPTR;
		Result = ReflectSkill(pThis, pAffectedSkill);
	}

	return Result;
	
}
