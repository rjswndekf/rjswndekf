#include <SkillManager.h>
//#include <MapFunctions.h>

using namespace std; 

int LEARNSKILL_GENRET = 0x00505144;
int LEARNSKILL_DBRET = 0x005050E5;
int LEARNSKILL_DBADD1RET = 0x00506A8A;
int LEARNSKILL_DBADD2RET = 0x0050709B;
int LEARNSKILL_DBDEL1RET = 0x00511205;
int LEARNSKILL_DBDEL2RET = 0x005113FC;

/******* ASM Funs *******/
extern int SENDPACKET_FUN;
extern int SENDPACKETEX_FUN;

// RCM_SKILL_LEARNSKILL 0x1601
void LearnSkillGen()
{
	__asm push 0xA
	__asm lea edx,dword ptr ss:[ebp-0x40]
	__asm push edx
	__asm push 0x1601
	__asm mov ecx,dword ptr ss:[ebp-0xA4]
	__asm call SENDPACKET_FUN

	__asm lea edi,dword ptr ss:[ebp-0x40]
	__asm movzx eax,word ptr es:[edi+0x4]

	__asm cmp eax,0x200B
	__asm je ADDSKILL
	__asm cmp eax,0x200F
	__asm je ADDSKILL
	__asm cmp eax,0x2013
	__asm je ADDSKILL
	__asm cmp eax,0x2016
	__asm je ADDSKILL

	__asm jmp RET_TARGRT

ADDSKILL:
	__asm add eax,0x1
	__asm mov word ptr es:[edi+0x4],ax
	__asm push 0xA
	__asm push edi
	__asm push 0x1601
	__asm mov ecx,dword ptr ss:[ebp-0xA4]
	__asm call SENDPACKET_FUN

RET_TARGRT:
	__asm jmp LEARNSKILL_GENRET

}

// DBTASK_LEARNSKILL 0x4A12 (Client 0x1601)
void DBTaskLearnSkillGen()
{
	__asm mov dword ptr ss:[ebp-0x40],0x0

	__asm lea edi,dword ptr ss:[ebp-0x34]
	__asm movzx eax,word ptr es:[edi+0x4]

	__asm cmp eax,0x200B
	__asm je ADDSKILL
	__asm cmp eax,0x200F
	__asm je ADDSKILL
	__asm cmp eax,0x2013
	__asm je ADDSKILL
	__asm cmp eax,0x2016
	__asm je ADDSKILL

	__asm jmp RET_TARGRT

ADDSKILL:
	__asm add eax,0x1
	__asm mov word ptr es:[edi+0x4],ax
	__asm push 0xF
	__asm push edi
	__asm push 0x4A12
	__asm mov ecx,0x7F23A0
	__asm call SENDPACKETEX_FUN

RET_TARGRT:
	__asm jmp LEARNSKILL_DBRET

}


// DBTASK_LEARNSKILL 0x4A12 (Client 0x1606)
void DBTaskLearnSkillADD1()
{
	__asm lea edi,dword ptr ss:[ebp-0x68]
	__asm movzx eax,word ptr es:[edi+0x4]

	__asm cmp eax,0x200B
	__asm je ADDSKILL
	__asm cmp eax,0x200F
	__asm je ADDSKILL
	__asm cmp eax,0x2013
	__asm je ADDSKILL
	__asm cmp eax,0x2016
	__asm je ADDSKILL

	__asm jmp RET_TARGRT

ADDSKILL:
	__asm add eax,0x1
	__asm mov word ptr es:[edi+0x4],ax
	__asm push 0xF
	__asm push edi
	__asm push 0x4A12
	__asm mov ecx,0x7F23A0
	__asm call SENDPACKETEX_FUN

RET_TARGRT:
	__asm mov eax,dword ptr ss:[ebp-0xE8]
	__asm jmp LEARNSKILL_DBADD1RET
}

// DBTASK_LEARNSKILL 0x4A12 (Client 0x1613)
void DBTaskLearnSkillADD2()
{
	__asm lea edi,dword ptr ss:[ebp-0x78]
	__asm movzx eax,word ptr es:[edi+0x4]

	__asm cmp eax,0x200B
	__asm je ADDSKILL
	__asm cmp eax,0x200F
	__asm je ADDSKILL
	__asm cmp eax,0x2013
	__asm je ADDSKILL
	__asm cmp eax,0x2016
	__asm je ADDSKILL

	__asm jmp RET_TARGRT

ADDSKILL:
	__asm add eax,0x1
	__asm mov word ptr es:[edi+0x4],ax
	__asm push 0xF
	__asm push edi
	__asm push 0x4A12
	__asm mov ecx,0x7F23A0
	__asm call SENDPACKETEX_FUN

RET_TARGRT:
	__asm mov ecx,dword ptr ss:[ebp-0x108]
	__asm jmp LEARNSKILL_DBADD2RET
}


// DBTASK_LEARNSKILL 0x4A12 (Client 0x1616 DEL1)
void DBTaskLearnSkillDEL1()
{
	__asm lea edi,dword ptr ss:[ebp-0x3C]
	__asm movzx eax,word ptr es:[edi+0x4]

	__asm cmp eax,0x200B
	__asm je ADDSKILL
	__asm cmp eax,0x200F
	__asm je ADDSKILL
	__asm cmp eax,0x2013
	__asm je ADDSKILL
	__asm cmp eax,0x2016
	__asm je ADDSKILL

	__asm jmp RET_TARGRT

ADDSKILL:
	__asm add eax,0x1
	__asm mov word ptr es:[edi+0x4],ax
	__asm push 0xF
	__asm push edi
	__asm push 0x4A12
	__asm mov ecx,0x7F23A0
	__asm call SENDPACKETEX_FUN

RET_TARGRT:
	__asm mov eax,dword ptr ss:[ebp-0x18]
	__asm mov cx,word ptr ds:[eax+0x18]
	__asm jmp LEARNSKILL_DBDEL1RET

}

// DBTASK_LEARNSKILL 0x4A12 (Client 0x1616 DEL2)
void DBTaskLearnSkillDEL2()
{
	__asm lea edi,dword ptr ss:[ebp-0x70]
	__asm movzx eax,word ptr es:[edi+0x4]

	__asm cmp eax,0x200B
	__asm je ADDSKILL
	__asm cmp eax,0x200F
	__asm je ADDSKILL
	__asm cmp eax,0x2013
	__asm je ADDSKILL
	__asm cmp eax,0x2016
	__asm je ADDSKILL

	__asm jmp RET_TARGRT

ADDSKILL:
	__asm add eax,0x1
	__asm mov word ptr es:[edi+0x4],ax
	__asm push 0xF
	__asm push edi
	__asm push 0x4A12
	__asm mov ecx,0x7F23A0
	__asm call SENDPACKETEX_FUN

RET_TARGRT:
	__asm mov ecx,dword ptr ss:[ebp-0x18]
	__asm mov dx,word ptr ds:[ecx+0x18]
	__asm jmp LEARNSKILL_DBDEL2RET

}
