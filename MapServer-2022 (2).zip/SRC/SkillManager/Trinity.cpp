#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 

// Damage
// Skill 8193 0x2001 Pentagram of Light
void PentagramOfLightAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int AttackForce;

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 3;
	
	AttackForce = BioticBaseGetAbility(PlayerPTR, 0x22);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += AttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}
void PentagramOfLight(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int StrVar;
	int PsyVar;
	int Damage;
	int SkillDamage;
	int CheckPlayerPTR;
	int CalDamage;
	int Param1, Param2, Param3, Param4, Param5;

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	StrVar = (BioticBaseGetAbility(PlayerPTR, 0x0) * Param1) / 100;
	PsyVar = (BioticBaseGetAbility(PlayerPTR, 0x4) * Param2) / 100;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += StrVar;
	Damage += PsyVar;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;

	SkillDamage = Damage * Param3;

	CheckPlayerPTR = RTDynamicCast(PlayerPTR, 0x0, 0x7E9608, 0x7E9638, 0x0);

	if (CheckPlayerPTR != 0)
	{
		CalDamage = SkillDamageCalculation(PlayerPTR, SkillDamage, 0xA9) / Param3;
		addrs = (DWORD)DamagePTR;
		*(reinterpret_cast<int*>(addrs)) = CalDamage;
	}
}

// Skill 8194 0x2002 Darkness Calling
void DarknessCallingAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int AttackForce;

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 3;
	
	AttackForce = BioticBaseGetAbility(PlayerPTR, 0x22);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += AttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}
void DarknessCalling(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int StrVar;
	int PsyVar;
	int Damage;
	int Param1, Param2, Param3, Param4, Param5;

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	StrVar = (BioticBaseGetAbility(PlayerPTR, 0x0) * Param1) / 100;
	PsyVar = (BioticBaseGetAbility(PlayerPTR, 0x4) * Param2) / 100;
		
	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));
	
	Damage += StrVar;
	Damage += PsyVar;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 8204 0x200C Dark Side Trace
void DarkSideTraceAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int AttackForce;

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 3;
	
	AttackForce = BioticBaseGetAbility(PlayerPTR, 0x22);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += AttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}
void DarkSideTrace(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int PsyVar;
	int MagicAttack;
	int Damage;
	int Param1, Param2, Param3, Param4, Param5;

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	MagicAttack = (Damage * Param1) / 100;
	PsyVar = (BioticBaseGetAbility(PlayerPTR, 0x4) * Param2) / 100;
	Damage += MagicAttack;
	Damage += PsyVar;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 8212 0x2014 Dark Side Zone
void DarkSideZoneAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int AttackForce;

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 3;
	
	AttackForce = BioticBaseGetAbility(PlayerPTR, 0x22);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += AttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}
void DarkSideZone(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int MagicAttackRate;
	int Damage;
	int Param1, Param2, Param3, Param4, Param5;

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	MagicAttackRate = (Damage * Param1) / 100;
	Damage += MagicAttackRate;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 8210 0x2012 Mana Bombing
void ManaBombingAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int AttackForce;
	int CalAffectPTR;
	//int BaseDamage;
	int MaxMana;
	int Diff;
	int Param1, Param2, Param3, Param4, Param5;

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 3;
	
	CalAffectPTR = (DWORD)PlayerPTR + 0x100;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	AttackForce = BioticBaseGetAbility(PlayerPTR, 0x22);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += AttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;

	MaxMana = BioticBaseGetAbility(PlayerPTR, 0x0F);
	Diff = (MaxMana * Param1) / 100;
	ChangeMana(CalAffectPTR, Diff, 0);
	SendLifeManaBroadcast(PlayerPTR);

	DecTP(PlayerPTR, Param5);
	SendTPBroadcast(PlayerPTR);
}
void ManaBombing(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int MaxMana;
	int Diff;
	int Damage;
	int ManaDamage;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	MaxMana = BioticBaseGetAbility(PlayerPTR, 0x0F);
	Diff = (MaxMana * Param1) / 100;

	ManaDamage = Diff * Param2 / 100;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += ManaDamage;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 8217 0x2019 Lightning Swift
void LightningSwiftAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int AttackForce;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 3;
	
	AttackForce = BioticBaseGetAbility(PlayerPTR, 0x22);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += AttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;

	DecTP(PlayerPTR, Param5);
	SendTPBroadcast(PlayerPTR);

}
void LightningSwift(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int TargetPTR;
	int TargetMaxLife;
	int LifeDamage;
	int Damage;
	int Param1, Param2, Param3, Param4, Param5;

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)BC + 0x2C;
	TargetPTR = *(reinterpret_cast<int*>(addrs));

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	TargetMaxLife = BioticBaseGetAbility(TargetPTR, 0x0D);
	LifeDamage = (TargetMaxLife * Param1) / 100;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += LifeDamage;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 8238 0x202E Absolute Flash
void AbsoluteFlashAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int AttackForce;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 3;
	
	AttackForce = BioticBaseGetAbility(PlayerPTR, 0x22);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += AttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;

	DecTP(PlayerPTR, Param5);
	SendTPBroadcast(PlayerPTR);
}
void AbsoluteFlash(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int MaxLife;
	int LifeDamage;
	int Damage;

	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	
	MaxLife = BioticBaseGetAbility(PlayerPTR, 0x0D);
	
	LifeDamage = (MaxLife * Param1) / 100;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += LifeDamage;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 8220 0x201C Wound of Restriction
void WoundOfRestrictionAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int AttackForce;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 1;
	
	AttackForce = BioticBaseGetAbility(PlayerPTR, 0x20);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += AttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;

	IncTP(PlayerPTR, Param5);
	SendTPBroadcast(PlayerPTR);
}
void WoundOfRestriction(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int Damage;
	int DamageRate;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	DamageRate = (Damage * Param1) / 100;
	Damage += DamageRate;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 8224 0x2020 Penetrating Darkness
void PenetratingDarknessAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int AttackForce;

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 1;
	
	AttackForce = BioticBaseGetAbility(PlayerPTR, 0x20);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += AttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}
void PenetratingDarkness(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int Damage;
	int DamageRate;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	DamageRate = (Damage * Param1) / 100;
	//Damage += DamageRate;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = DamageRate;
}

// Skill 8227 0x2023 Windy Chain
void WindyChainAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int AttackForce;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 1;
	
	AttackForce = BioticBaseGetAbility(PlayerPTR, 0x20);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += AttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;

	IncTP(PlayerPTR, Param5);
	SendTPBroadcast(PlayerPTR);
}
void WindyChain(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int Damage;
	int DamageRate;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	DamageRate = (Damage * Param1 / 100);
	Damage += DamageRate;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 8230 0x2026 Thunderstroke
void ThunderstrokeAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int AttackForce;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 1;
	
	AttackForce = BioticBaseGetAbility(PlayerPTR, 0x20);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += AttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;

	IncTP(PlayerPTR, Param5);
	SendTPBroadcast(PlayerPTR);
}
void Thunderstroke(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int Damage;
	int DamageRate;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	DamageRate = (Damage * Param1) / 100;
	Damage += DamageRate;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 8233 0x2029 Airburst
void AirburstAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int AttackForce;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 1;
	
	AttackForce = BioticBaseGetAbility(PlayerPTR, 0x20);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += AttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;

	IncTP(PlayerPTR, Param5);
	SendTPBroadcast(PlayerPTR);
}
void Airburst(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int Damage;
	int DamageRate;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	DamageRate = (Damage * Param1) / 100;
	Damage += DamageRate;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 8252 0x203C Distortion Claw - Chaos
void DistortionClawChaosAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int AttackForce;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 1;
	
	AttackForce = BioticBaseGetAbility(PlayerPTR, 0x20);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += AttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;

	DecTP(PlayerPTR, Param5);
	SendTPBroadcast(PlayerPTR);
}
void DistortionClawChaos(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int Damage;
	int DamageRate;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	DamageRate = (Damage * Param1) / 100;
	Damage += DamageRate;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 8253 0x203D Dimensional Scar
void DimensionalScarAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int AttackForce;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 1;
	
	AttackForce = BioticBaseGetAbility(PlayerPTR, 0x20);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += AttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;

	IncTP(PlayerPTR, Param5);
	SendTPBroadcast(PlayerPTR);
}
void DimensionalScar(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int Damage;
	//int AttackForce;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	//AttackForce = BioticBaseGetAbility(PlayerPTR, 0x20);

	//Damage += AttackForce;

	//addrs = (DWORD)DamagePTR;
	//*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Affect
// Skill 8195 0x2003 Tune of Life
void TuneOfLife(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x2F, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x33, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x36, Param1, Active);
}
// Skill 8196 0x2004 Vine of Light
void VineOfLightAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active)
{
	int addrs;
	int Target;
	int Kind;
	int CheckResist;
	int Duration;
	
	addrs = (DWORD)SkillPTR;
	Kind = *(reinterpret_cast<unsigned short*>(addrs));
	
	addrs = (DWORD)CalAffectPTR + 0x58;
	Target = *(reinterpret_cast<int*>(addrs));

	if (Target != 0)
	{
		addrs = (DWORD)SkillPTR + 0x0C;
		Duration = *(reinterpret_cast<int*>(addrs));

		if (Active == 1)
		{
			CheckResist = CheckConditionResist(CalAffectPTR, Kind);
			if (CheckResist == 0)
			{
				ChangeConditionBySkill(Target, 0x40000008, Duration, Kind);
			}
		}
		else
		{
			ClearSkillCondition(Target, 0x40000008, Kind);
		}
	}

}

// Skill 8197 0x2005 Dormant Power
void DormantPower(int CalAffectPTR, int ParamsPTR, int Active)
{
	int addrs;
	int PlayerPTR;
	int SkillPoint;
	int LifeVar;
	int ManaVar;
	int Param1, Param2, Param3, Param4, Param5;

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	
	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	SkillPoint = BioticBaseGetAbility(PlayerPTR, 0x16);

	LifeVar = SkillPoint * Param1;
	ManaVar = SkillPoint * Param2;

	QualitiesCalOption(CalAffectPTR, 0xD6, LifeVar, Active);
	QualitiesCalOption(CalAffectPTR, 0x96, ManaVar, Active);
}

// Skill 8198 0x2006 Arrendal Mastery TR
void ArrendalMasteryA(int CalAffectPTR, int ParamsPTR, int Active)
{
	int addrs;
	int PlayerPTR;
	int Param1, Param2, Param3, Param4, Param5;
	int PsyVar;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	PsyVar = (BioticBaseGetAbility(PlayerPTR, 0x4) * Param2) / 100;

	QualitiesCalOption(CalAffectPTR, 0x22, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x112, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x81, PsyVar, Active);
	QualitiesCalOption(CalAffectPTR, 0x68, Param3, Active);
}
// Skill 8199 0x2007 Prism Sphere
void PrismSphere(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x51, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x88, Param3, Active);
	QualitiesCalOption(CalAffectPTR, 0x8A, Param4, Active);
}
// Skill 8200 0x2008 Trinity Force TR
void TrinityForceA(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0xFA, Param5, Active);
}

// Skill 8201 0x2009 Dark Side Force
//void DarkSideForce(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active){}

// Skill 8202 0x200A Nature Unity
void NatureUnityCCalAffect(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;
	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesSetOption(CalAffectPTR, 0xA7, Active);
}

// Skill 8203 0x200B Light Trace
void LightTraceAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active)
{
	int addrs;
	int BioticID;
	int CheckBioticID;
	int SelfCalAffectPTR;
	int Target;
	int CharID;
	unsigned int EntityID;
	int PsyVar;
	int Diff;

	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)SkillPTR + 0x10;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));
	EntityID = (int)CharID;

	addrs = (DWORD)CalAffectPTR + 0x58;
	Target = *(reinterpret_cast<int*>(addrs));

	if (Active == 1)
	{
		BioticID = FindBioticID(EntityID);
		if (BioticID != 0)
		{
			SelfCalAffectPTR = (DWORD)BioticID + 0x100;
			CheckBioticID = RTDynamicCast(Target, 0, 0x7E9608, 0x7E9638, 0);
			if (CheckBioticID != 0)
			{
				PsyVar = BioticBaseGetAbility(BioticID, 0x04);
				Diff = PsyVar * Param1 / 100;
				ChangeLife(SelfCalAffectPTR, Diff, 1);
				//AroundPlayers(BioticID, EntityID, Diff);
			}
			IncTP(BioticID, Param5);
			SendTPBroadcast(BioticID);
			CIOObjectRelease(BioticID);
		}
	}
}
// Skill 8207 0x200F Pulsating Light
void PulsatingLight(int CalAffectPTR, int ParamsPTR, int Active)
{
	int addrs;
	int PlayerPTR;
	int PsyVar;
	int RecoveryVar;
	
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	PsyVar = BioticBaseGetAbility(PlayerPTR, 0x04);
	RecoveryVar = PsyVar * Param1 / 100;

	QualitiesCalOption(CalAffectPTR, 0xD4, RecoveryVar, Active);
}

void PulsatingLightAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active)
{
	int addrs;
	int CharID;
	unsigned int EntityID;
	int BioticID;
	int SelfCalAffectPTR;
	int Param1, Param2, Param3, Param4, Param5;

	addrs = (DWORD)SkillPTR + 0x10;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));
	EntityID = (int)CharID;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	if (Active == 1)
	{
		BioticID = FindBioticID(EntityID);
		if (BioticID != 0)
		{
			SelfCalAffectPTR = (DWORD)BioticID + 0x100;
			IncTP(BioticID, Param5);
			SendTPBroadcast(BioticID);
			CIOObjectRelease(BioticID);
		}
	}
}

// Skill 8208 0x2010 Dark Side of Light
void DarkSideOfLightASEvent(int TargetPTR, int ParamsPTR, int pAffectSkill, int pDamage)
{
	int addrs = 0;
	int pPlayer = 0;
	int CharID = 0;
	int KindLevel = 0;
	int AttackForce = 0;
	int PsyVar = 0;
	int Param1 = 0;
	int Damage = 0;
	int HighDamage = 0;
	int LowDamage = 0;
	int HDamage = 0;
	int LDamage = 0;
	int AttachDamage = 0;

	addrs = (DWORD)pAffectSkill + 0x10;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));

	addrs = (DWORD)pAffectSkill + 0x2;
	KindLevel = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)ParamsPTR;
	Param1 = *(reinterpret_cast<int*>(addrs));

	pPlayer = EntityManagerGetPlayer(CharID);
	if (pPlayer != 0)
	{
		AttackForce = (BioticBaseGetAbility(pPlayer, 0x22) * Param1) / 100;
		PsyVar = (BioticBaseGetAbility(pPlayer, 0x4) * Param1) / 100;

		Damage = (AttackForce + PsyVar) / 5;

		HighDamage = (Damage * Param1) / 100;
		LowDamage = (HighDamage * 150) / 100;
		HDamage = HighDamage + LowDamage;
		LDamage = HighDamage - LowDamage;

		AttachDamage = CalAttachDamage(TargetPTR, LDamage, HDamage);

		addrs = (DWORD)pDamage;
		*(reinterpret_cast<int*>(addrs)) = AttachDamage;	

		CIOObjectRelease(pPlayer);
	}
}

// Skill 8211 0x2013 Sanctuary
void SanctuaryAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active)
{
	int addrs;
	int BioticID;
	int CheckBioticID;
	int Target;
	int SelfCalAffectPTR;
	int CharID;
	unsigned int EntityID;
	int MagicAttackVar;
	int Diff;

	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)SkillPTR + 0x10;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));
	EntityID = (int)CharID;

	addrs = (DWORD)CalAffectPTR + 0x58;
	Target = *(reinterpret_cast<int*>(addrs));

	if (Active == 1)
	{
		BioticID = FindBioticID(EntityID);
		if (BioticID != 0)
		{
			SelfCalAffectPTR = (DWORD)BioticID + 0x100;
			MagicAttackVar = BioticBaseGetAbility(BioticID, 0x08);
			Diff = MagicAttackVar * Param1 / 100;
			
			ChangeMana(SelfCalAffectPTR, Diff, 1);

			CheckBioticID = RTDynamicCast(Target, 0, 0x7E9608, 0x7E9638, 0);
			if (CheckBioticID != 0)
			{
				AroundPlayers(BioticID, EntityID, Diff);
			}
			IncTP(BioticID, Param5);
			SendTPBroadcast(BioticID);
			CIOObjectRelease(BioticID);
		}
	}
}

// Skill 8213 0x2015 Life Circulation
void LifeCirculationAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active)
{
	int addrs;
	int PlayerPTR;
	int MaxLife;
	int Diff;
	int Param1, Param2, Param3, Param4, Param5;

	if (Active == 1)
	{
		addrs = (DWORD)CalAffectPTR + 0x58;
		PlayerPTR = *(reinterpret_cast<int*>(addrs));

		Param1 = GetParams(ParamsPTR, 1);
		Param2 = GetParams(ParamsPTR, 2);
		Param3 = GetParams(ParamsPTR, 3);
		Param4 = GetParams(ParamsPTR, 4);
		Param5 = GetParams(ParamsPTR, 5);

		MaxLife = BioticBaseGetAbility(PlayerPTR, 0x0D);
		Diff = (MaxLife * Param1) / 100;
		ChangeLife(CalAffectPTR, Diff, 0);
		SendLifeManaBroadcast(PlayerPTR);

		IncTP(PlayerPTR, Param5);
		SendTPBroadcast(PlayerPTR);
	}
}

// Skill 8214 0x2016 Causal Loop/Dark Side Loop
void CausalLoop(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);
	
	QualitiesCalOption(CalAffectPTR, 0xFB, Param1, Active);
}

// Skill 8205 0x200D Sequoias Favor
void SequoiasFavor(int CalAffectPTR, int ParamsPTR, int Active)
{
	int addrs;
	int PlayerPTR;
	int PsyVar;
	int Param1, Param2, Param3, Param4, Param5;

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	PsyVar = (BioticBaseGetAbility(PlayerPTR, 0x4) * Param1) / 100;
	QualitiesCalOption(CalAffectPTR, 0x0C, PsyVar, Active);
	QualitiesCalOption(CalAffectPTR, 0x81, PsyVar, Active);

}
// Skill 8206 0x200E Vine Protection
void VineProtection(int CalAffectPTR, int ParamsPTR, int Active)
{
	//int RemainderRate;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x10, Param3, Active);
	// CA_DAMAGE_RATE 0x2B
	//RemainderRate = 0 - Param2;
	QualitiesCalOption(CalAffectPTR, 0xF1, Param2, Active);
}
// Skill 8209 0x2011 Blessed Crown
void BlessedCrown(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x09, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x0B, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x0D, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x12, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x14, Param1, Active);

}
void BlessedCrownAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active)
{
	int addrs;
	int BioticID;
	int CheckBioticID;
	int Target;
	int SelfCalAffectPTR;
	int CharID;
	unsigned int EntityID;
	
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)SkillPTR + 0x10;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));
	EntityID = (int)CharID;

	addrs = (DWORD)CalAffectPTR + 0x58;
	Target = *(reinterpret_cast<int*>(addrs));
	
	BioticID = FindBioticID(EntityID);

	if (Active == 1)
	{
		if (BioticID != 0)
		{
			SelfCalAffectPTR = (DWORD)BioticID + 0x100;
			CheckBioticID = RTDynamicCast(Target, 0, 0x7E9608, 0x7E9638, 0);
			if (CheckBioticID != 0)
			{
				AroundPlayers(BioticID, EntityID, 0);
			}
		}
	}
	if (BioticID != 0)
	{
		PlayerSendStatus(BioticID);
		CIOObjectRelease(BioticID);
	}
}

// Skill 8216 0x2018 Growth Acceleration
void GrowthAcceleration(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x2F, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x33, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x36, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x51, Param2, Active);
}
void GrowthAccelerationAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active)
{
	int addrs;
	int BioticID;
	int CheckBioticID;
	int Target;
	int SelfCalAffectPTR;
	int CharID;
	unsigned int EntityID;
	
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)SkillPTR + 0x10;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));
	EntityID = (int)CharID;

	addrs = (DWORD)CalAffectPTR + 0x58;
	Target = *(reinterpret_cast<int*>(addrs));

	BioticID = FindBioticID(EntityID);

	if (Active == 1)
	{
		if (BioticID != 0)
		{
			SelfCalAffectPTR = (DWORD)BioticID + 0x100;
			CheckBioticID = RTDynamicCast(Target, 0, 0x7E9608, 0x7E9638, 0);
			if (CheckBioticID != 0)
			{
				AroundPlayers(BioticID, EntityID, 0);
			}
			DecTP(BioticID, Param5);
			SendTPBroadcast(BioticID);
		}
	}
	if (BioticID != 0)
	{
		PlayerSendStatus(BioticID);
		CIOObjectRelease(BioticID);
	}
}

// Skill 8218 0x201A Revive Force
void ReviveForce(int CalAffectPTR, int ParamsPTR, int Active){}
void ReviveForceAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active)
{
	int addrs;
	int PlayerPTR;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	if (PlayerPTR != 0)
	{
		if (Active == 1)
		{
			DecTP(PlayerPTR, Param5);
			SendTPBroadcast(PlayerPTR);
		}
	}
}

// Skill 8236 0x202C Heroic Power TR
//void HeroicPowerA(int CalAffectPTR, int ParamsPTR, int Active){}

// Skill 8239 0x202F Eternal Aria
void EternalAria(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x10, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x51, Param2, Active);
}

// Skill 8219 0x201B Arrendal Mastery TN
void ArrendalMasteryB(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x22, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10B, Param2, Active);

}
// Skill 8221 0x201D Trinity Force TN
void TrinityForceB(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);
	
	QualitiesCalOption(CalAffectPTR, 0x86, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x88, Param3, Active);
	QualitiesCalOption(CalAffectPTR, 0x8A, Param4, Active);
	QualitiesCalOption(CalAffectPTR, 0xFA, Param5, Active);
}

// Skill 8222 0x201E Thorns Whip OnAffectSkillEvent
void ThornsWhipASEvent(int TargetPTR, int ParamsPTR, int pAffectSkill, int pDamage)
{
	int addrs = 0;
	int pPlayer = 0;
	int CharID = 0;
	int KindLevel = 0;
	int AttackForce = 0;
	int Param3 = 0;
	int Param4 = 0;
	int Damage = 0;
	int HighDamage = 0;
	int LowDamage = 0;
	int HDamage = 0;
	int LDamage = 0;
	int AttachDamage = 0;
	int Chance = 0;

	addrs = (DWORD)pAffectSkill + 0x10;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));


	addrs = (DWORD)pAffectSkill + 0x2;
	KindLevel = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)ParamsPTR + 0x8;
	Param3 = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)ParamsPTR + 0xC;
	Param4 = *(reinterpret_cast<int*>(addrs));

	pPlayer = EntityManagerGetPlayer(CharID);
	if (pPlayer != 0)
	{
		AttackForce = BioticBaseGetAbility(pPlayer, 0x20);
		Chance = BioticBaseGetRandom(pPlayer, 1000000);

		Damage = (AttackForce * Param3) / 100;
		HighDamage = (Damage * Param3) / 100;
		LowDamage = (HighDamage * 10) / 100;
		HDamage = HighDamage + LowDamage;
		LDamage = HighDamage - LowDamage;
		AttachDamage = CalAttachDamage(TargetPTR, LDamage, HDamage);

		if (Chance < Param4)
		{
			addrs = (DWORD)pDamage;
			*(reinterpret_cast<int*>(addrs)) = AttachDamage;
		}
		else
		{
			addrs = (DWORD)pDamage;
			*(reinterpret_cast<int*>(addrs)) = 0;
		}

		CIOObjectRelease(pPlayer);
	}
}

void ThornsWhipAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active)
{
	int addrs = 0;
	int TargetPTR = 0;
	int Kind = 0;
	int TResist = 0;
	int Duration = 0;

	addrs = (DWORD)SkillPTR;
	Kind = *(reinterpret_cast<unsigned short*>(addrs));

	addrs = (DWORD)SkillPTR + 0xC;
	Duration = *(reinterpret_cast<unsigned int*>(addrs));

	addrs = (DWORD)CalAffectPTR + 0x58;
	TargetPTR = *(reinterpret_cast<int*>(addrs));

	if (Active == 1)
	{
		TResist = CheckResistance(CalAffectPTR, Kind);
		if (TResist == 0)
		{
			ChangeConditionBySkill(TargetPTR, 0x00000040, Duration, Kind);
		}
	}
	else
	{
		ClearSkillCondition(TargetPTR, 0x00000040, Kind);
	}
}
// Skill 8223 0x201F Phantom Spirit
void PhantomSpiritAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active)
{
	int addrs;
	int PlayerPTR;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	if (PlayerPTR != 0)
	{
		if (Active == 1)
		{
			DecTP(PlayerPTR, Param5);
			SendTPBroadcast(PlayerPTR);
		}
	}

	//Reflects all effects
}

// Skill 8225 0x2021 Dark Assimilation
void DarkAssimilation(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);
	
	QualitiesCalOption(CalAffectPTR, 0x36, Param1, Active);
}
// Skill 8228 0x2024 Spirit Concentration
void SpiritConcentration(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);
	
	QualitiesCalOption(CalAffectPTR, 0x09, Param1, Active);
}
// Skill 8235 0x202B Dimensional Coat
void DimensionalCoat(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x78, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x76, 0x64, Active);
	QualitiesCalOption(CalAffectPTR, 0x77, 0x64, Active);

}
// Skill 8237 0x202D Spirit Assimilation
void SpiritAssimilationAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active)
{
	int addrs;
	int PlayerPTR;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	if (PlayerPTR != 0)
	{
		if (Active == 1)
		{
			DecTP(PlayerPTR, Param5);
			SendTPBroadcast(PlayerPTR);
		}
	}
}
// Skill 8251 0x203B Heroic Power TN
//void HeroicPowerB(int CalAffectPTR, int ParamsPTR, int Active){}

// Skill 8252 0x203C Distortion Claw - Chaos
void DistortionClawChaosCalAffect(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;
	int DecRate = 0;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);
	
	DecRate = 0 - Param3;
	
	QualitiesCalOption(CalAffectPTR, 0x2F, DecRate, Active);
	QualitiesCalOption(CalAffectPTR, 0x33, DecRate, Active);
	QualitiesCalOption(CalAffectPTR, 0x36, DecRate, Active);
}

// Skill 8253 0x203D Dimensional Scar
void DimensionalScarAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active)
{
	int addrs = 0;
	int TargetPTR = 0;
	int Kind = 0;
	int Param5 = 0;
	int TResist = 0;
	int Duration = 0;

	addrs = (DWORD)CalAffectPTR + 0x58;
	TargetPTR = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)SkillPTR;
	Kind = *(reinterpret_cast<unsigned short*>(addrs));
	
	addrs = (DWORD)SkillPTR + 0xC;
	Duration = *(reinterpret_cast<unsigned int*>(addrs));

	if (Active == 1)
	{
		TResist = CheckResistance(CalAffectPTR, Kind);
		if (TResist == 0)
		{
			ChangeConditionBySkill(TargetPTR, 0x00000040, Duration, Kind);
		}
	}
	else
	{
		ClearSkillCondition(TargetPTR, 0x00000040, Kind);
	}
}
// Skill 8253 0x203D Dimensional Scar OnAffectSkillEvent
void DimensionalScarASEvent(int TargetPTR, int ParamsPTR, int pAffectSkill, int pDamage)
{
	int addrs = 0;
	int pPlayer = 0;
	int CharID = 0;
	int KindLevel = 0;
	int AttackForce = 0;
	int Param1 = 0;
	int Damage = 0;
	int HighDamage = 0;
	int LowDamage = 0;
	int HDamage = 0;
	int LDamage = 0;
	int AttachDamage = 0;

	addrs = (DWORD)pAffectSkill + 0x10;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));

	addrs = (DWORD)pAffectSkill + 0x2;
	KindLevel = *(reinterpret_cast<char*>(addrs));

	addrs = (DWORD)ParamsPTR;
	Param1 = *(reinterpret_cast<int*>(addrs));

	pPlayer = EntityManagerGetPlayer(CharID);
	if (pPlayer != 0)
	{
		AttackForce = BioticBaseGetAbility(pPlayer, 0x20);

		Damage = (AttackForce * Param1) / 100;
		HighDamage = (Damage * Param1) / 100;
		LowDamage = (HighDamage * 20) / 100;
		HDamage = HighDamage + LowDamage;
		LDamage = HighDamage - LowDamage;

		AttachDamage = CalAttachDamage(TargetPTR, LDamage, HDamage);

		addrs = (DWORD)pDamage;
		*(reinterpret_cast<int*>(addrs)) = AttachDamage;

		CIOObjectRelease(pPlayer);
	}
}

// Skill 8254 0x203E Silent Noise
void SilentNoise(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x62, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x89, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x51, Param3, Active);
}
// Skill 32989 0x80DD Rear Blast
void RearBlastASEvent(int TargetPTR, int ParamsPTR, int pAffectSkill, int pDamage)
{
	int addrs = 0;
	int pPlayer = 0;
	int CharID = 0;
	int KindLevel = 0;
	int AttackForce = 0;
	int Param1 = 0;
	int Param2 = 0;
	int Damage = 0;
	int HighDamage = 0;
	int LowDamage = 0;
	int HDamage = 0;
	int LDamage = 0;
	int AttachDamage = 0;
	int Chance = 0;

	addrs = (DWORD)pAffectSkill + 0x10;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));

	addrs = (DWORD)ParamsPTR;
	Param1 = *(reinterpret_cast<int*>(addrs));

	addrs = (DWORD)ParamsPTR + 0x4;
	Param2 = *(reinterpret_cast<int*>(addrs));

	pPlayer = EntityManagerGetPlayer(CharID);
	if (pPlayer != 0)
	{
		AttackForce = BioticBaseGetAbility(pPlayer, 0x20);

		Damage = (AttackForce * Param2) / 100;
		HighDamage = (Damage * Param2) / 100;
		LowDamage = (HighDamage * 10) / 100;
		HDamage = HighDamage + LowDamage;
		LDamage = HighDamage - LowDamage;

		AttachDamage = CalAttachDamage(TargetPTR, LDamage, HDamage);
		AttachDamage += AttackForce;

		Chance = BioticBaseGetRandom(pPlayer, 1000000);

		if (Chance < Param1)
		{
			addrs = (DWORD)pDamage;
			*(reinterpret_cast<int*>(addrs)) = AttachDamage;
		}
		else
		{
			addrs = (DWORD)pDamage;
			*(reinterpret_cast<int*>(addrs)) = 0;
		}

		CIOObjectRelease(pPlayer);
	}

}
