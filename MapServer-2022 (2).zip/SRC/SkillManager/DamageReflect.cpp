#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 

int ATKEE_RETORIG = 0x004F7B64;
int ATKEE_SK4088 = 0x004F7B83;

int ATKER_RETORIG = 0x004F8443;
int ATKER_SK4088 = 0x004F849D;

/******* ASM Funs *******/
extern int ISAFFECTSKILL;
extern int ASINIT;


void AttackeeDamageReflect()
{
	// TargetCallAffect
	__asm mov dword ptr ss:[ebp-0x24C],edx
	
	// pInitAS
	__asm lea eax,dword ptr ss:[ebp-0x100]
	
	// Skill 16520 0x4088 Mirror Shield
	__asm push eax
	__asm push 0x4088
	__asm mov ecx,dword ptr ss:[ebp-0x24C]
	__asm call ISAFFECTSKILL
	__asm test eax,eax
	__asm je RET_ORIG

	__asm jmp ATKEE_SK4088

RET_ORIG:
	__asm jmp ATKEE_RETORIG

}

void AttackerDamageReflect()
{
	// pInitAS
	__asm lea ecx,dword ptr ss:[ebp-0x24]
	__asm call ASINIT

	// Skill 16520 0x4088 Mirror Shield
	__asm lea edx,dword ptr ss:[ebp-0x24]
	__asm push edx
	__asm push 0x4088
	__asm mov ecx,dword ptr ss:[ebp-0x60]
	__asm add ecx,0x100
	__asm call ISAFFECTSKILL
	__asm test eax,eax
	__asm je RET_ORIG

	__asm mov dword ptr ss:[ebp-0x4],0x1
	__asm jmp ATKER_SK4088

RET_ORIG:
	__asm jmp ATKER_RETORIG

}
