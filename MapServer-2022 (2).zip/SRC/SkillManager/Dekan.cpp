#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 


// Skill 16456 0x4048 Wide Forefoot Swing
void WideForefootSwing(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int MaxLife;
	int Diff;
	int LifeForce;
	int MagicAttackForce;
	int Damage;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	MaxLife = BioticBaseGetAbility(PlayerPTR, 0xD);

	Diff = (MaxLife * Param1) / 100;
	LifeForce = (Diff * Param2) / 100;

	MagicAttackForce = (BioticBaseGetAbility(PlayerPTR, 0x22) * Param5) / 100;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += LifeForce;
	Damage += MagicAttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 16401 0x4011 Zhen Mastery (Dragon Knight)
void ZhenMasteryA(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x27, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10C, Param3, Active);
}
// Skill 16402 0x4012 Blue Defense (Dragon Knight)
void BlueDefense(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x0D, Param1, Active);
}
// Skill 16403 0x4013 Critical Immunity (Dragon Knight)
void CriticalImmunityA(int CalAffectPTR, int ParamsPTR, int Active)
{
	int addrs;
	int PlayerPTR;
	int VitVar;

	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	VitVar = (BioticBaseGetAbility(PlayerPTR, 0x1) * Param1) / 100;
	// CA_CRITICAL_DAMAGE_REDUCTION 0x42
	QualitiesCalOption(CalAffectPTR, 0x82, VitVar, Active);
}
// Skill 16408 0x4018 Forced Lock
void ForcedLock(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x114, Param1, Active);
}
// Skill 16443 0x403B Elderblood Awaken (Dragon Knight)
void ElderbloodAwaken(int CalAffectPTR, int ParamsPTR, int Active)
{
	//int RemainderRate;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// CA_DAMAGE_RATE 0x2B
	//RemainderRate = 0 - Param1;
	QualitiesCalOption(CalAffectPTR, 0xF1, Param1, Active);
}
// Skill 16419 0x4023 Zhen Mastery (Dragon Sage)
void ZhenMasteryB(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x27, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10D, Param2, Active);
}
// Skill 16420 0x4024 Blue Intelligence (Dragon Sage)
void BlueIntelligence(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x12, Param1, Active);
}
// Skill 16422 0x4026 Critical Immunity (Dragon Sage)
void CriticalImmunityB(int CalAffectPTR, int ParamsPTR, int Active)
{
	int addrs;
	int PlayerPTR;
	int IntVar;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	IntVar = (BioticBaseGetAbility(PlayerPTR, 0x2) * Param1) / 100;
	// CA_CRITICAL_DAMAGE_REDUCTION 0x42
	QualitiesCalOption(CalAffectPTR, 0x82, IntVar, Active);
}
// Skill 16427 0x402B Rapid Lock (Dragon Sage)
void RapidLock(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x5F, Param1, Active);
}
// Skill 16435 0x4033 Impenetrable (Dragon Sage)
void Impenetrable(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// Skill 0x118 Physics Defence By Int Rate
	QualitiesCalOption(CalAffectPTR, 0x118, Param1, Active);
	// Skill 0x119 Magic Defence By Int Rate
	QualitiesCalOption(CalAffectPTR, 0x119, Param1, Active);
}
// Skill 16470 0x4056 Evolve Separation (Dragon Sage)
void EvolveSeparation(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x2F, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x54, Param2, Active);

}
// Skill 16458 0x404A Reverse Scale (Dragon Sage)
void ReverseScale(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x45, Param1, Active);

}
