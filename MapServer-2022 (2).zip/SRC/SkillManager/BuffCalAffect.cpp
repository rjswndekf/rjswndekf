#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std;

int BUFF_CALAFFECT;
int BUFF_RETORG = 0x004A9D10;
int BUFF_CALABI = 0x004AA5A4;

int BUFFAA_RETORG = 0x004A462D;
int BUFFAA_SENDSTATUS = 0x004A46CD;

void EventBuff(int Kind, int ParamPTR, int Active)
{
	// Orig Code
	__asm movzx eax,word ptr ss:[ebp+0x8]
	__asm mov dword ptr ss:[ebp-0x50],eax
	
	__asm mov ecx,dword ptr ss:[ebp-0x4C]
	__asm mov BUFF_CALAFFECT,ecx
	
	BuffCalAffect(BUFF_CALAFFECT, Kind, ParamPTR, Active);
	
	__asm test eax,eax
	__asm je RET_ORIG
	__asm jmp BUFF_CALABI

RET_ORIG:
	__asm jmp BUFF_RETORG
}

int BuffCalAffect(int CalAffectPTR, int Kind, int ParamPTR, int Active)
{
	int Result = 0;
	//Skill 556 0x22C Ghost Arrow
	if (Kind == 0x22C)
	{
		Result = 1;
		GhostArrow(CalAffectPTR, ParamPTR, Active);
	}

	return Result;
}

void BuffAffectActive()
{
	__asm movzx ecx,word ptr ss:[ebp-0x76]
	__asm mov dword ptr ss:[ebp-0x80],ecx

	// Skill 556 0x22C Ghost Arrow
	__asm cmp eax,0x22C
	__asm je SEND_STATUS

	// Ret Orig
	__asm jmp BUFFAA_RETORG

SEND_STATUS:
	__asm jmp BUFFAA_SENDSTATUS

}