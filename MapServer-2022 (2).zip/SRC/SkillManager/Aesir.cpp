#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 

// Skill 16526 0x408E BluntMastery
void BluntMasteryC(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x25, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10F, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x51, Param3, Active);
}

// Skill 16527 0x408F Mentalty Amror
void MentaltyAmror(int CalAffectPTR, int ParamsPTR, int Active)
{
	int addrs;
	int PlayerPTR;
	int PsyVar;
	
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	PsyVar = (BioticBaseGetAbility(PlayerPTR, 0x4) * Param1) / 100;

	QualitiesCalOption(CalAffectPTR, 0x46, PsyVar, Active);
}

// Skill 16532 0x4094 DispelMagic
void DispelMagicAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;
	
	if (Active == 1)
	{
		Param1 = GetParams(ParamsPTR, 1);
		Param2 = GetParams(ParamsPTR, 2);
		Param3 = GetParams(ParamsPTR, 3);
		Param4 = GetParams(ParamsPTR, 4);
		Param5 = GetParams(ParamsPTR, 5);

		EraseBuffSkill(CalAffectPTR, Param2);
	}
}

// Skill 16533 0x4095 MentalityTemper
void MentalityTemper(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x12, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10, Param2, Active);
}

// Skill 16534 0x4096 CounterHunteress
void CounterHunteress(int CalAffectPTR, int ParamsPTR, int Active)
{
	//int DecRate;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// CA_PVE_ATTACK_RATE 0x80
	QualitiesCalOption(CalAffectPTR, 0xF7, Param1, Active);
}

// Skill 16535 0x4097 ReserveWide
void ReserveWideASEvent(int TargetPTR, int ParamsPTR, int pAffectSkill, int pDamage)
{
	int addrs = 0;
	int pPlayer = 0;
	int CharID = 0;
	int AttackForce = 0;
	int PsyVar = 0;
	int Param1 = 0;
	int Damage = 0;
	int HighDamage = 0;
	int LowDamage = 0;
	int HDamage = 0;
	int LDamage = 0;
	int AttachDamage = 0;

	addrs = (DWORD)pAffectSkill + 0x10;
	CharID = *(reinterpret_cast<unsigned int*>(addrs));

	addrs = (DWORD)ParamsPTR;
	Param1 = *(reinterpret_cast<int*>(addrs));

	pPlayer = EntityManagerGetPlayer(CharID);
	if (pPlayer != 0)
	{
		AttackForce = (BioticBaseGetAbility(pPlayer, 0x22) * Param1) / 100;
		PsyVar = (BioticBaseGetAbility(pPlayer, 0x4) * Param1) / 100;

		Damage = (AttackForce + PsyVar) / 5;

		HighDamage = (Damage * Param1) / 100;
		LowDamage = (HighDamage * 80) / 100;
		HDamage = HighDamage + LowDamage;
		LDamage = HighDamage - LowDamage;

		AttachDamage = CalAttachDamage(TargetPTR, LDamage, HDamage);

		addrs = (DWORD)pDamage;
		*(reinterpret_cast<int*>(addrs)) = AttachDamage;

		CIOObjectRelease(pPlayer);
	} 
}

// Skill 16536 0x4098 MagicStay
void MagicStayAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int AttackDamage;
	int Param1;
	int Damage;

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 3;
	
	Param1 = GetParams(ParamsPTR, 1);

	AttackDamage = (BioticBaseGetAbility(PlayerPTR, 0x22) * Param1) / 100;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));
	
	Damage += AttackDamage;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 16537 0x4099 GroupFatal
void GroupFatal(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x73, Param1, Active);
}

// Skill 16538 0x409A MarshMaze
void MarshMazeAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int AttackDamage;
	int Param1;
	int Damage;

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 3;
	
	Param1 = GetParams(ParamsPTR, 1);

	AttackDamage = BioticBaseGetAbility(PlayerPTR, 0x22);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));
	
	Damage += AttackDamage;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}
void MarshMazeCalDamage(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int PsyVar;
	int Damage;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	PsyVar = (BioticBaseGetAbility(PlayerPTR, 0x4) * Param1) / 100;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += PsyVar;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 16539 0x409B RegiShield
void RegiShieldCalAffect(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;
	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesSetOption(CalAffectPTR, 0xA7, Active);
}
// Skill 16540 0x409C MagicianAura
void MagicianAura(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x2F, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x3F, Param2, Active);
}

// Skill 16541 0x409D CaelsAura
void CaelsAura(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x33, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x117, Param2, Active);
}

// Skill 16542 0x409E RisingAura
void RisingAura(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x36, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x62, Param2, Active);	
}

// Skill 16562 0x40B2 MagicBobySquare
void MagicBobySquare(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x88, Param3, Active);
	QualitiesCalOption(CalAffectPTR, 0x8A, Param4, Active);
}
// Skill 16563 0x40B3 StealthReviver
void StealthReviver(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x62, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x51, Param3, Active);
}

// Skill 16543 0x409F AxeMastery
void AxeMastery(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x22, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x10C, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x51, Param3, Active);
}
// Skill 16545 0x40A1 Whispel
void WhispelAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int AttackDamage;

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 1;

	AttackDamage = BioticBaseGetAbility(PlayerPTR, 0x20);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));
	
	Damage += AttackDamage;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}
void WhispelCalDamage(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int StrVar;
	int Damage;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	StrVar = (BioticBaseGetAbility(PlayerPTR, 0x4) * Param1) / 100;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += StrVar;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}
void WhispelAffectAcive(int CalAffectPTR, int ParamsPTR, int SkillPTR, int Active)
{
	int addrs = 0;
	int TargetPTR = 0;
	int Kind = 0;
	int TResist = 0;
	int Duration = 0;

	addrs = (DWORD)SkillPTR;
	Kind = *(reinterpret_cast<unsigned short*>(addrs));

	addrs = (DWORD)SkillPTR + 0xC;
	Duration = *(reinterpret_cast<unsigned int*>(addrs));

	addrs = (DWORD)CalAffectPTR + 0x58;
	TargetPTR = *(reinterpret_cast<int*>(addrs));

	if (Active == 1)
	{
		TResist = CheckResistance(CalAffectPTR, Kind);
		if (TResist == 0)
		{
			ChangeConditionBySkill(TargetPTR, 0xC0000001, Duration, Kind);
		}
	}
	else
	{
		ClearSkillCondition(TargetPTR, 0xC0000001, Kind);
	}
}

// Skill 16547 0x40A3 DoubleAxeMastery
void DoubleAxeMastery(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x6E, Param1, Active);
}

// Skill 16551 0x40A7 WhisperMind
void WhisperMind(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x117, Param2, Active);
}

// Skill 16552 0x40A8 RohasShiled
void RohasShiledCalAffect(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;
	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesSetOption(CalAffectPTR, 0xA7, Active);
}

// Skill 16553 0x40A9 Excalibur
void Excalibur(int CalAffectPTR, int ParamsPTR, int Active)
{
	int addrs;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x51, Param1, Active);

	// Clean Accumulation
	addrs = (DWORD)CalAffectPTR + 0xF0;
	*(reinterpret_cast<int*>(addrs)) = 0;
}
// Skill 16556 0x40AC LastWhisper
void LastWhisperAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int CalAffectPTR;
	int AttackDamage;
	int MaxLife;
	int CurLife;
	int Diff;
	int Param1;
	int Damage;

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 1;

	CalAffectPTR = (DWORD)PlayerPTR + 0x100;

	Param1 = GetParams(ParamsPTR, 1);

	AttackDamage = BioticBaseGetAbility(PlayerPTR, 0x20);

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));
	
	Damage += AttackDamage;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
	
	MaxLife = BioticBaseGetAbility(PlayerPTR, 0xD);
	addrs = (DWORD)PlayerPTR + 0xAC;
	CurLife = *(reinterpret_cast<int*>(addrs));
	Diff = (MaxLife * Param1) / 100;
	if (CurLife > Diff)
	{
		ChangeLife(CalAffectPTR, Diff, 0);
		SendLifeManaBroadcast(PlayerPTR);
	}
}
void LastWhisperCalDamage(int DynamicPTR, int BC, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int PlayerPTR;
	int MaxLife;
	int Diff;
	int AttackDamage;
	int Damage;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	addrs = (DWORD)DynamicPTR + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	MaxLife = BioticBaseGetAbility(PlayerPTR, 0xD);
	Diff = (MaxLife * Param1) / 100;

	AttackDamage = (BioticBaseGetAbility(PlayerPTR, 0x20) * Param2) / 100;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += Diff;
	Damage += AttackDamage;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}

// Skill 16557 0x40AD AxeClock
void AxeClock(int CalAffectPTR, int ParamsPTR, int Active)
{
	int DecRate;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);
	
	DecRate = 0 - Param1;

	QualitiesCalOption(CalAffectPTR, 0x3F, DecRate, Active);
}

// Skill 16558 0x40AE WhisperLimit
void WhisperLimit(int CalAffectPTR, int ParamsPTR, int Active)
{
	/***
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x78, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x7C, Param2, Active);
	***/
}

// Skill 16559 0x40AF MurderRemissionC
void MurderRemissionC(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x8, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0xA, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0xC, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0xF, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x11, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x13, Param1, Active);
}

// Skill 16576 0x40C0 AxeRange
void AxeRange(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x88, Param3, Active);
	QualitiesCalOption(CalAffectPTR, 0x8A, Param4, Active);
}

