#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 

int RANGE_CAFFECT;
int RANGE_SKILLPTR;
int RANGE_TARGET_ENTITYID;
int RANGE_MAXCOUNT;

int RANGE_RETORG = 0x004D8317;
int RANGE_RETEND = 0x004D88AF;
int RANGE_RETONE = 0x004D8401;

int AFFECT_RANGE_RETORG = 0x004D935B;
int AFFECT_RANGE_RETTAG = 0x004D9461;

extern int GETSKILLLEVELINFO;

void AttackRange()
{
	// Skill RangeType (pSkillInfo + 0x54)
	__asm mov dword ptr ss:[ebp-0xC4],ecx
	__asm cmp dword ptr ss:[ebp-0xC4],0x80000000
	__asm je RANGE_TYPE80
	__asm cmp dword ptr ss:[ebp-0xC4],0x80000003
	__asm je RANGE_TYPE83
	__asm jmp RANGE_RET_ORIG

RANGE_TYPE80:
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov cx,word ptr ds:[eax+0x18]
	__asm mov word ptr ss:[ebp-0x46],cx
	__asm movzx edx,word ptr ss:[ebp-0x46]
	__asm cmp edx,0x202E
	__asm je RANGE_TYPEONE
	__asm jmp RANGE_RET_ORIG

RANGE_TYPEONE:
	__asm jmp RANGE_RETONE

RANGE_TYPE83:
	// GetParams
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETSKILLLEVELINFO
	__asm mov edx,dword ptr ds:[eax+0x19]
	__asm mov dword ptr ss:[ebp-0x8],edx

	// MaxAttackCount (Param3)
	__asm lea eax,dword ptr ss:[ebp-0x8]
	__asm mov RANGE_MAXCOUNT,eax
	// pTargetEntityIDList
	__asm mov edx,dword ptr ss:[ebp+0xC]
	__asm mov RANGE_TARGET_ENTITYID, edx
	// pSkill
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm mov RANGE_SKILLPTR, ecx
	// CalAffect
	__asm mov ecx,dword ptr ss:[ebp-0xC0]
	__asm add ecx,0x100
	__asm mov RANGE_CAFFECT,ecx

	GetTargetCount(RANGE_CAFFECT, RANGE_SKILLPTR, RANGE_TARGET_ENTITYID, RANGE_MAXCOUNT);

	// AttackTargetCount
	__asm mov dword ptr ss:[ebp-0x4],eax

	__asm jmp RANGE_RETEND

RANGE_RET_ORIG:
	__asm jmp RANGE_RETORG

}

// Affect Range Target List Patch
void AffectRangeTargetList()
{
	__asm mov dword ptr ss:[ebp-0x1A0],ecx
	__asm cmp ecx, 0x2002
	__asm je AFFECT_RANGETYPE

	__asm jmp AFFECT_RANGE_RETORG

AFFECT_RANGETYPE:
	__asm jmp AFFECT_RANGE_RETTAG

}
