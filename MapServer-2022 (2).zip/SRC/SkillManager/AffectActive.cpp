#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 

int ONAFFECT_SENDSTATUS_RET = 0x004B1BB2;
int ONAFFECT_CONTINUED_DAMAGE_RET = 0x004B6D21;
int ONAFFECT_SEPARATING_ZEN_RET = 0x004B6186;
int ONAFFECT_RESIST_ALLSTATUS_RET = 0x004B144B;
int ONAFFECT_RESIST_STUN_RET = 0x004B6B8C;
int ONAFFECT_RESIST_ROOT_RET = 0x004B38F4;
int ONAFFECT_DOUBLEXP_RET = 0x004B8654;

int ONAFFECT_RET_ORIG = 0x004B0A77;
int ONAFFECT_RET_END = 0x004B8E7E;

int ONAF_CALAFFECTPTR;
int ONAF_PARAMPTR;

/*** Aesir Skill Funs ***/
int SK_4081_RET = 0x004B3F36;
int SK_408B_RET = 0x004B3659;
int SK_408C_RET = 0x004B6CE2;
int SK_4092_RET = 0x004B3243;
int SK_40A0_RET = 0x004B8A2F;


/******* ASM Funs *******/
//extern int RTDYNAMICCAST;

void OnAffect_Active(int pASkill, int Active)
{
	// pASkill +0x0 Kind +0x10 CharID

	// Kind
	__asm mov dword ptr ss:[ebp-0x1648],edx

	// CalAffect Pointer
	__asm mov ecx, dword ptr ss:[ebp-0x1644]
	__asm mov ONAF_CALAFFECTPTR, ecx
	__asm cmp ecx,0x0
	__asm je RET_END

	// Check Target / Player
	__asm mov edx, dword ptr ds:[ecx+0x58]
	__asm cmp edx,0x0
	__asm je RET_END

	// Params Pointer
	__asm mov eax,dword ptr ss:[ebp-0x8]
	__asm mov ONAF_PARAMPTR, eax

	OnAffectSkill(ONAF_CALAFFECTPTR, pASkill, ONAF_PARAMPTR, Active);

	__asm jmp eax

/************** END **************/
RET_END:
	__asm jmp ONAFFECT_RET_END

}

int OnAffectSkill(int pCalAffect, int pASkill, int pParams, int Active)
{
	int RetAddrs = ONAFFECT_RET_ORIG;
	int addrs = 0;
	int Kind = 0;
	int Params = 0;
	
	addrs = (DWORD)pASkill;
	Kind = *(reinterpret_cast<unsigned short*>(addrs));

	switch(Kind)
	{
		/*************** Human ***************/
		case 0x83: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x8A: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xAC: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xBA:
		{
			Params = GetParams(pParams, 3);
			DecLife(pCalAffect, Params, Active);
			RetAddrs = ONAFFECT_SENDSTATUS_RET;
		}
		break;
		case 0xBB:
		{
			Params = GetParams(pParams, 3);
			DecLife(pCalAffect, Params, Active);
			RetAddrs = ONAFFECT_SENDSTATUS_RET;
		}
		break;
		case 0xC4: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xC7: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xD3: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xD6: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xD7: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xC8: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;
		case 0xD8: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;

		/**************** Elf ****************/
		case 0x151: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x152:
		{
			ManaChargeAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_RET_END;
		}
		break;
		case 0x104: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x124: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x131: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x153: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x160: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x14E: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x15D: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x154: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;
		case 0x161: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;

		/************* Half Elf **************/
		case 0x229: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x22D: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x22F: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x239: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x23C: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x23E: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x255: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x256: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x244: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x253: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x248: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;
		case 0x258: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;

		/*************** Dhan ****************/
		case 0x40F: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x428: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x455: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x456: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x465: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x453: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x462: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x457: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;
		case 0x466: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;

		/*************** Giant ***************/
		case 0x804: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x811: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x822: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x827: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x837: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x846: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x834: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x843: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x838: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;
		case 0x847: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;

		/************* Dark Elf **************/
		case 0x1015: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x101F: RetAddrs = ONAFFECT_CONTINUED_DAMAGE_RET; break;
		case 0x1028: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x1040: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x1042: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x1051: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x103F: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x104E: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x1043: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;
		case 0x1052: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;

		/*************** Dekan ***************/
		case 0x4012: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x4013: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x4018: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x4024: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x4026: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x4003: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x403B: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x404A: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x4056: RetAddrs = ONAFFECT_SEPARATING_ZEN_RET; break;
		case 0x4038: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x4047: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x403C: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;
		case 0x404B: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;

		/************** Trinity **************/
		case 0x2003: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x2004:
		{
			VineOfLightAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_SENDSTATUS_RET;
		}
		break;
		case 0x2005: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x2006: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x2007: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x2008: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x200A: RetAddrs = ONAFFECT_RESIST_STUN_RET; break;
		case 0x200D: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x200E: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x2011:
		{
			BlessedCrownAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_SENDSTATUS_RET;
		}
		break;
		case 0x2018:
		{
			GrowthAccelerationAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_RET_END;
		}
		break;
		case 0x201A:
		{
			ReviveForceAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_SENDSTATUS_RET;
		}
		break;
		case 0x200B:
		{
			LightTraceAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_SENDSTATUS_RET;
		}
		break;
		case 0x200F:
		{
			PulsatingLightAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_SENDSTATUS_RET;
		}
		break;
		case 0x2013:
		{
			SanctuaryAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_SENDSTATUS_RET;
		}
		break;
		case 0x2015:
		{
			LifeCirculationAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_SENDSTATUS_RET;
		}
		break;
		case 0x2016: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x201B: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x201D: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x202C: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x202F: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x201E:
		{
			ThornsWhipAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_RET_END;
		}
		break;
		case 0x201F:
		{
			PhantomSpiritAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_SENDSTATUS_RET;
		}
		break;
		case 0x2021: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x2024: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x202B: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x202D:
		{
			SpiritAssimilationAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; 
		}
		break;
		case 0x203D:
		{
			DimensionalScarAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_SENDSTATUS_RET;
		}
		break;
		case 0x203B: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x203C: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x203E: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x2030: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;
		case 0x203F: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;

		/************** Aesir **************/
		case 0x4081: RetAddrs = SK_4081_RET; break;
		case 0x4082: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x4083: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x4084: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x4085: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x4086: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x4089: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x408A:
		{
			ManaChargeAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_RET_END;
		}
		break;
		case 0x408B: RetAddrs = SK_408B_RET; break;
		case 0x408C: RetAddrs = SK_408C_RET; break;
		case 0x4092: RetAddrs = SK_4092_RET; break;
		case 0x4094:
		{
			DispelMagicAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_RET_END;
		}
		break;
		case 0x40B1: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x40B2: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x40A4: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x40A5: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x40A6: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x408E: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x408F: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x4095: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x4096: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x4099: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x409B: RetAddrs = ONAFFECT_RESIST_STUN_RET; break;
		case 0x409C: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x409D: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x409E: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x40B3: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x409F: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x40A0: RetAddrs = SK_40A0_RET; break;
		case 0x40A1:
		{
			WhispelAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_SENDSTATUS_RET;
		}
		break;
		case 0x40A3: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x40A7: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x40A8: RetAddrs = ONAFFECT_RESIST_STUN_RET; break;
		case 0x40A9: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x40AB: RetAddrs = ONAFFECT_RESIST_ROOT_RET; break;
		case 0x40AD: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x40AE: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x40AF: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x40C0: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x40B0: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x40BF: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0x40B4: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;
		case 0x40C3: RetAddrs = ONAFFECT_RESIST_ALLSTATUS_RET; break;
		
		/************ Guild Skill ************/
		/***
		case 0x9021:
		{
			ChangeAttitudeAffectAcive(pCalAffect, pParams, pASkill, Active);
			RetAddrs = ONAFFECT_SENDSTATUS_RET;
		}
		***/

		/************ Scroll Skill ***********/
		case 0xA085: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA09A: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0CF: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0D0: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0D1: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0D2: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0D3: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0D4: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0D5: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0D6: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0D9: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0DA: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0DB: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0DC: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0DD: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0DE: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0DF: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0E0: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0E1: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0E2: RetAddrs = ONAFFECT_SENDSTATUS_RET; break;
		case 0xA0E3: RetAddrs = ONAFFECT_DOUBLEXP_RET; break;
	}

	return RetAddrs;
}

void DecLife(int CalAffectPTR, int Params, int Active)
{
	int addrs;
	int PlayerPTR;
	int CurLife;
	int Diff;

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));

	if (Active == 1)
	{
		CurLife = PlayerGetCurLife(PlayerPTR);
		Diff = CurLife * Params / 100;
		ChangeLife(CalAffectPTR, Diff, 0);
		SendLifeManaBroadcast(PlayerPTR);
	}
}
