#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std;

int ATTACKAEE_RET = 0x0052C8E2;

int ATTACKAEE_DAMAGE;
int ATTACKAEE_SAO;
int ATTACKAEE_THIS;

// Attackee Action
void AttackAction()
{
	// pDamage
	__asm lea edx,dword ptr ss:[ebp-0x3C]
	__asm mov ATTACKAEE_DAMAGE,edx
	// SAO
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm mov ATTACKAEE_SAO, ecx
	// pAttack
	__asm mov edx,dword ptr ss:[ebp-0x274]
	__asm mov ATTACKAEE_THIS, edx

	AttackAttackeeAction(ATTACKAEE_THIS, ATTACKAEE_SAO, ATTACKAEE_DAMAGE);

	__asm mov edx,dword ptr ss:[ebp-0x274]
	__asm mov eax,dword ptr ds:[edx+0x1CC]
	__asm mov dword ptr ss:[ebp-0x188],eax

	__asm jmp ATTACKAEE_RET
}

void AttackAttackeeAction(int pAttack, int SAO, int pDamage)
{
	int addrs = 0;
	int PlayerPTR = 0;
	int TargetPTR = 0;
	int pThis = 0;
	int SelfCalAffectPTR = 0;
	int TargetCalAffectPTR = 0;
	int TargetEntityID = 0;
	int State = 0;
	int pSkillInfo = 0;
	int Kind = 0;
	int KindType = 0;
	int KindLV = 0;
	int ParamPTR = 0;
	unsigned int CutTime = 0;
	unsigned int Damage = 0;
	unsigned int AddDamage = 0;
	unsigned int SubDamage = 0;
	int Param1 = 0;
	int Param2 = 0;
	int Param3 = 0;
	int Param4 = 0;
	int Param5 = 0;
	int ReduceDamageState = 0;
	int FullRate = 0;
	int RemainderRate = 0;
	int DecDamageRate = 0;
	int AttackChance = 0;
	int Chance = 0;
	int PassReduce = 0;
	int CurLife = 0;
	int MaxLife = 0;
	int RecoveryLife = 0;
	char AttackerType = 0;
	char AttackeeType = 0;

	unsigned char _tagAffectSkill[36];
	int ASADDRS = (DWORD)_tagAffectSkill;

	addrs = (DWORD)pAttack + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	SelfCalAffectPTR = (DWORD)PlayerPTR + 0x100;

	addrs = (DWORD)pAttack + 0x1D4;
	pThis = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pThis;
	TargetPTR = *(reinterpret_cast<int*>(addrs));
	TargetCalAffectPTR = (DWORD)TargetPTR + 0x100;

	addrs = (DWORD)SAO + 0x4C;
	Kind = *(reinterpret_cast<unsigned short*>(addrs));

	// Trinity Points Check
	TrinityPoints(PlayerPTR, Kind);

	// Skill 598 0x256 Cataclysm
	State = CheckAffectStatus(SelfCalAffectPTR, 0x256);
	if (State == 1)
	{
		if (Kind != 0)
		{
			ParamPTR = GetParamPTR(PlayerPTR, 0x256);
			if (ParamPTR != 0)
			{
				addrs = (DWORD)ParamPTR + 0x4;
				Param2 = *(reinterpret_cast<int*>(addrs));
				EraseBuffSkill(TargetCalAffectPTR, Param2);
			}
		}
	}

	// Add Target Death Chaser
	// Skill 583 0x247 Death Chaser
	State = CheckAffectStatus(SelfCalAffectPTR, 0x247);
	if (State == 1)
	{
		ParamPTR = GetParamPTR(PlayerPTR, 0x247);
		if (ParamPTR != 0)
		{
			// 32990 0x80DE Death Chaser
			State = CheckAffectStatus(TargetCalAffectPTR, 0x80DE);
			if (State == 0)
			{
				if (Kind != 0)
				{
					KindLV = GetTotalDynamicLevel(PlayerPTR, 0x247);
					// Init AffectSkill Pointer
					tagAffectSkillInit(ASADDRS);

					addrs = (DWORD)TargetPTR + 0x30;
					TargetEntityID = *(reinterpret_cast<int*>(addrs));

					// Add Target Affect Skill
					CutTime = GetCutTime();
					addrs = (DWORD)ASADDRS;
					*(reinterpret_cast<int*>(addrs)) = 0x80DE;
					addrs = (DWORD)ASADDRS + 0x2;
					*(reinterpret_cast<int*>(addrs)) = KindLV;
					addrs = (DWORD)ASADDRS + 0x3;
					*(reinterpret_cast<int*>(addrs)) = CutTime;
					addrs = (DWORD)ASADDRS + 0x7;
					*(reinterpret_cast<int*>(addrs)) = CutTime;
					addrs = (DWORD)ASADDRS + 0x10;
					*(reinterpret_cast<int*>(addrs)) = TargetEntityID;

					AddAffectSkill(TargetCalAffectPTR, ASADDRS);
				}
			}
		}
	}

	// Skill 8231 0x2027 Rear Blast
	State = CheckAffectStatus(SelfCalAffectPTR, 0x2027);
	if (State == 1)
	{
		ParamPTR = GetParamPTR(PlayerPTR, 0x2027);
		if (ParamPTR != 0)
		{
			// Skill 32989 0x80DD Rear Blast
			State = CheckAffectStatus(TargetCalAffectPTR, 0x80DD);
			if (State == 0)
			{
				KindLV = GetTotalDynamicLevel(PlayerPTR, 0x2027);

				// Init AffectSkill Pointer
				tagAffectSkillInit(ASADDRS);

				addrs = (DWORD)PlayerPTR + 0x30;
				TargetEntityID = *(reinterpret_cast<int*>(addrs));

				// Add Target Affect Skill
				CutTime = GetCutTime();
				addrs = (DWORD)ASADDRS;
				*(reinterpret_cast<int*>(addrs)) = 0x80DD;
				addrs = (DWORD)ASADDRS + 0x2;
				*(reinterpret_cast<int*>(addrs)) = KindLV;
				addrs = (DWORD)ASADDRS + 0x3;
				*(reinterpret_cast<int*>(addrs)) = CutTime;
				addrs = (DWORD)ASADDRS + 0x7;
				*(reinterpret_cast<int*>(addrs)) = CutTime;
				addrs = (DWORD)ASADDRS + 0x10;
				*(reinterpret_cast<int*>(addrs)) = TargetEntityID;

				AddAffectSkill(TargetCalAffectPTR, ASADDRS);
			}
		}
	}

	// Skill 1125 0x465 Isolation Stealth
	State = CheckAffectStatus(TargetCalAffectPTR, 0x465);
	if (State == 1)
	{
		if (Kind != 0)
		{
			pSkillInfo = GetSkillInfo(Kind);
			addrs = (DWORD)pSkillInfo + 0x57;
			KindType = *(reinterpret_cast<unsigned char*>(addrs));
			if (KindType == 0x80)
			{
				addrs = (DWORD)pDamage;
				*(reinterpret_cast<int*>(addrs)) = 0;
			}
		}
	}

	// Skill 2058 0x80A Life Force
	State = CheckAffectStatus(TargetCalAffectPTR, 0x80A);
	if (State == 1)
	{
		ParamPTR = GetParamPTR(TargetPTR, 0x80A);
		if (ParamPTR != 0)
		{
			addrs = (DWORD)ParamPTR + 0x4;
			RecoveryLife = *(reinterpret_cast<int*>(addrs));

			ChangeLife(TargetCalAffectPTR, RecoveryLife, 1);
			SendLifeManaBroadcast(TargetPTR);
		}
	}

	// Skill 8218 0x201A Revive Force
	State = CheckAffectStatus(TargetCalAffectPTR, 0x201A);
	if (State == 1)
	{
		ParamPTR = GetParamPTR(TargetPTR, 0x201A);
		addrs = (DWORD)ParamPTR;
		Param1 = *(reinterpret_cast<int*>(addrs));

		addrs = (DWORD)pDamage;
		Damage = *(reinterpret_cast<int*>(addrs));

		addrs = (DWORD)TargetPTR + 0xAC;
		CurLife = *(reinterpret_cast<int*>(addrs));

		MaxLife = BioticBaseGetAbility(TargetPTR, 0xD);

		RecoveryLife = (MaxLife * Param1) / 100;
		if (Damage > CurLife)
		{
			ChangeLife(TargetCalAffectPTR, RecoveryLife, 1);
			SendLifeManaBroadcast(TargetPTR);
		}
	}

	// Skill 8229 0x2025 Distortion Claw - Reverse
	State = CheckAffectStatus(TargetCalAffectPTR, 0x2025);
	if (State == 1)
	{
		ParamPTR = GetParamPTR(PlayerPTR, 0x2025);
		if (ParamPTR != 0)
		{
			addrs = (DWORD)ParamPTR + 0x4;
			Param2 = *(reinterpret_cast<int*>(addrs));

			addrs = (DWORD)pDamage;
			Damage = *(reinterpret_cast<int*>(addrs));
			AddDamage = (Damage * Param2) / 100;
			Damage += AddDamage;
			addrs = (DWORD)pDamage;
			*(reinterpret_cast<int*>(addrs)) = Damage;
		}
	}

	// Skill 572 0x23C Rank Shot
	State = CheckAffectStatus(SelfCalAffectPTR, 0x23C);
	if (State == 1)
	{
		addrs = (DWORD)PlayerPTR + 0x2E;
		AttackerType = *(reinterpret_cast<char*>(addrs));
		addrs = (DWORD)TargetPTR + 0x2E;
		AttackeeType = *(reinterpret_cast<char*>(addrs));
		if (AttackerType == 3)
		{
			if (AttackeeType == 3)
			{
				ParamPTR = GetParamPTR(PlayerPTR, 0x23C);
				addrs = (DWORD)ParamPTR;
				Param1 = *(reinterpret_cast<int*>(addrs));

				addrs = (DWORD)pDamage;
				Damage = *(reinterpret_cast<int*>(addrs));

				AddDamage = (Damage * Param1) / 100;
				Damage += AddDamage;

				addrs = (DWORD)pDamage;
				*(reinterpret_cast<int*>(addrs)) = Damage;
			}
		}
	}

	// Skill 2103 0x837 Gigantic Storm
	State = CheckAffectStatus(SelfCalAffectPTR, 0x837);
	if (State == 1)
	{
		addrs = (DWORD)PlayerPTR + 0x2E;
		AttackerType = *(reinterpret_cast<char*>(addrs));
		addrs = (DWORD)TargetPTR + 0x2E;
		AttackeeType = *(reinterpret_cast<char*>(addrs));
		if (AttackerType == 3)
		{
			if (AttackeeType == 3)
			{
				ParamPTR = GetParamPTR(PlayerPTR, 0x837);
				addrs = (DWORD)ParamPTR + 0x8;
				Param3 = *(reinterpret_cast<int*>(addrs));

				addrs = (DWORD)pDamage;
				Damage = *(reinterpret_cast<int*>(addrs));

				AddDamage = (Damage * Param3) / 100;
				Damage += AddDamage;

				addrs = (DWORD)pDamage;
				*(reinterpret_cast<int*>(addrs)) = Damage;
			}
		}
	}

	// Skill 16562 0x40B2 MagicBobySquare
	State = CheckAffectStatus(SelfCalAffectPTR, 0x40B2);
	if (State == 1)
	{
		if (Kind == 0)
		{
			ParamPTR = GetParamPTR(PlayerPTR, 0x40B2);
			addrs = (DWORD)ParamPTR;
			Param1 = *(reinterpret_cast<int*>(addrs));
			addrs = (DWORD)ParamPTR + 0x4;
			Param2 = *(reinterpret_cast<int*>(addrs));

			Chance = BioticBaseGetRandom(PlayerPTR, 1000000);
			if (Param1 > Chance)
			{
				addrs = (DWORD)pDamage;
				Damage = *(reinterpret_cast<int*>(addrs));
				
				AddDamage = (Damage * Param2) / 100;
				Damage += AddDamage;

				addrs = (DWORD)pDamage;
				*(reinterpret_cast<int*>(addrs)) = Damage;
			}
		}
	}

	// Skill Aegis
	SubDamage = BioticBaseGetAbility(TargetPTR, 0x37);
	if (SubDamage != 0)
	{
		addrs = (DWORD)pDamage;
		Damage = *(reinterpret_cast<int*>(addrs));
		
		if (Damage > SubDamage) Damage -= SubDamage;
		else Damage = 0;

		addrs = (DWORD)pDamage;
		*(reinterpret_cast<int*>(addrs)) = Damage;
	}
}
