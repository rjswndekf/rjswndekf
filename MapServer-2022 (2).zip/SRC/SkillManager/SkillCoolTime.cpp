#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 

int SCT_PLAYER;
int SCT_COOLTIME;
int SCT_RET = 0x004A3DAA;

void SkillCoolTimeProc()
{
	// CoolTime
	__asm mov ecx,dword ptr ss:[ebp-0x33C]
	__asm mov SCT_COOLTIME,ecx
	// pPlayer
	__asm mov edx,dword ptr ss:[ebp-0x3A8]
	__asm mov eax,dword ptr ds:[edx+0x58]
	__asm mov SCT_PLAYER,eax

	SkillCoolTime(SCT_PLAYER, SCT_COOLTIME);

	__asm mov ecx,eax
	__asm jmp SCT_RET
}

int SkillCoolTime(int pPlayer, int CoolTime)
{
	int CalCoolTime;
	int addrs;
	int Race;
	int pPet;
	int pItemPet;
	int PetType;
	int pThis;
	int Value;
	int CalValue;
	
	CalCoolTime = CoolTime;
	
	addrs = pPlayer + 0x2E;
	Race = *(reinterpret_cast<char*>(addrs));
	Race &= 0xFF;
	if (Race == 3)
	{
		// Check Pet Skill
		addrs = pPlayer + 0x19C8;
		pPet = *(reinterpret_cast<int*>(addrs));
		if (pPet != 0)
		{
			addrs = pPet + 0x8;
			pItemPet = *(reinterpret_cast<int*>(addrs));
			PetType = GetAttribute(pItemPet, 0);
			if (PetType == 260)
			{
				// Pet Skill CoolTime Dec Rate
				pThis = pPlayer + 0xD00;
				Value = EntityBaseStatusGetAbility(pThis, 0x26);
				if (Value != 0)
				{
					CalValue = (CoolTime * Value) / 100;
					CalCoolTime -= CalValue;
				}
			}
		}
		// Check CharacterAbility
		pThis = pPlayer;
		Value = BioticBaseGetAbility(pPlayer, 0x96);
		if (Value != 0)
		{
			CalValue = (CoolTime * Value) / 100;
			CalCoolTime -= CalValue;
		}
	}

	return CalCoolTime;
}