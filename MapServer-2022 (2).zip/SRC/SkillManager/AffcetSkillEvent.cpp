/*******************************************
 2018+ RCM_SKILL_AFFECTSKILLEVENT 0x1604 Packet Struct
 void AffectSkillEvent(byte Event, int AffectSkillPTR, byte Reason, uint Damage)
 06          +0 Event
 82 01 03 00 +1 CType
 BD AC 01 00 +5 EntityID (CharID)
   ---- tagAffectSkill Start
 81 00       +0 Kind +9
 00          +2 Level +B
 E7 05 E3 4F +3 AffectTime +C
 E7 05 E3 4F +7 EventTime  +10
 06          +B EventType  +14
 C0 7A 10 00 +C DurationTime +15
 BD AC 01 00 +10 TargetEntityID (BC+0x2C) +19
 00 00 00 00 +14 NewAdd +1D
 00 00 00 00 +18 EpochVector X +21
 00 00 00 00 +1C EpochVector Y +25
 00 00 00 00 +20 EpochVector Z +29
   ---- tagAffectSkill End
 00 00 00 00 +2D Damage
 00          +31 Reason (0 Enable 1 Disable)
 *******************************************/

#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 

unsigned char AFFECTSKILLEVENT_BUFFER[50] = {0};
int AFFECTSKILLEVENT_ADDRS = (DWORD)AFFECTSKILLEVENT_BUFFER;

unsigned char AFFECTSKILLEVENTEX_BUFFER[101] = {0};
int AFFECTSKILLEVENTEX_ADDRS = (DWORD)AFFECTSKILLEVENTEX_BUFFER;

unsigned char AFFECTSKILLSLOT_BUFFER[3600] = {0};
int AFFECTSKILLSLOT_ADDRS = (DWORD)AFFECTSKILLSLOT_BUFFER;

unsigned char DBTASK_SAVEAFFECTSKILL[36] = {0};
int DBTASK_SAVEAFFECTSKILL_ADDRS = (DWORD)DBTASK_SAVEAFFECTSKILL;

int ASRET = 0x004A14D1;
int ASEXRET = 0x004A1591;

/******* ASM Funs *******/
extern int ASINIT;
int ASSEND = 0x004D6400;
int TITLE_MESSAGE = 0x005B9260;

// RCM_SKILL_AFFECTSKILLEVENT 0x1604
void AffcetSkillEvent()
{
	// CalAffectPTR
	__asm mov dword ptr ss:[ebp-0x44],ecx
	
	// Init AffcetSkill
	__asm mov ecx, AFFECTSKILLEVENT_ADDRS
	__asm add ecx, 0x9
	__asm call ASINIT

	// Event
	__asm mov edi, AFFECTSKILLEVENT_ADDRS
	__asm mov al,byte ptr ss:[ebp+0x08]
	__asm mov byte ptr ss:[edi],al
	
	// PlayerPTR
	__asm mov ecx,dword ptr ss:[ebp-0x44]
	__asm mov esi,dword ptr ds:[ecx+0x58]

	// Ctype
	__asm mov ecx,dword ptr ds:[esi+0x2C]
	__asm mov dword ptr ds:[edi+0x01],ecx
	
	// EntityID
	__asm mov ecx,dword ptr ds:[esi+0x30]
	__asm mov dword ptr ds:[edi+0x05],ecx

	// ASPTR
	__asm mov esi,dword ptr ss:[ebp+0x0C]

	// Kind
	__asm movzx eax,word ptr ds:[esi]
	__asm mov word ptr ds:[edi+0x09],ax
	
	// Level
	__asm movzx eax,byte ptr ds:[esi+0x02]
	__asm mov byte ptr ds:[edi+0x0B],al
	
	// AffectTime
	__asm mov eax,dword ptr ds:[esi+0x03]
	__asm mov dword ptr ds:[edi+0x0C],eax
	
	// EventTime
	__asm mov eax,dword ptr ds:[esi+0x07]
	__asm mov dword ptr ds:[edi+0x10],eax
	
	// EventType
	__asm movzx eax,byte ptr ds:[esi+0x0B]
	__asm mov byte ptr ds:[edi+0x14],al
	
	// DurationTime
	__asm mov eax,dword ptr ds:[esi+0x0C]
	__asm mov dword ptr ds:[edi+0x15],eax
	
	// TargetEntityID
	__asm mov eax,dword ptr ds:[esi+0x10]
	__asm mov dword ptr ds:[edi+0x19],eax

	// Newadd
	__asm mov dword ptr ds:[edi+0x1D],0x0
	
	// EpochVector X
	__asm mov eax,dword ptr ds:[esi+0x14]
	__asm mov dword ptr ds:[edi+0x21],eax
	
	// EpochVector Y
	__asm mov eax,dword ptr ds:[esi+0x18]
	__asm mov dword ptr ds:[edi+0x25],eax

	// EpochVector Z
	__asm mov eax,dword ptr ds:[esi+0x1C]
	__asm mov dword ptr ds:[edi+0x29],eax

	// Damage
	__asm mov eax,dword ptr ss:[ebp+0x14]
	__asm mov dword ptr ds:[edi+0x2D],eax
	
	// Reason (0 Enable 1 Disable)
	__asm movzx eax,byte ptr ss:[ebp+0x10]
	__asm mov byte ptr ds:[edi+0x31],al

	//Send Packet
	__asm mov edi, AFFECTSKILLEVENT_ADDRS
	__asm push 0x2
	__asm push 0x1
	__asm push 0x32
	__asm push edi
	__asm push 0x1604
	__asm mov edx, dword ptr ss:[ebp-0x44]
	__asm mov ecx,dword ptr ds:[edx+0x58]
	__asm call ASSEND

	__asm jmp ASRET
}

// RCM_SKILL_AFFECTSKILLEVENT_EX 0x160D
void AffcetSkillEventEX()
{
	// CalAffectPTR
	__asm mov dword ptr ss:[ebp-0x7C],ecx
	
	// Init AffcetSkill
	__asm mov ecx, AFFECTSKILLEVENTEX_ADDRS
	__asm add ecx, 0x9
	__asm call ASINIT

	// Event
	__asm mov edi, AFFECTSKILLEVENTEX_ADDRS
	__asm mov al,byte ptr ss:[ebp+0x08]
	__asm mov byte ptr ss:[edi],al
	
	// PlayerPTR
	__asm mov ecx,dword ptr ss:[ebp-0x7C]
	__asm mov esi,dword ptr ds:[ecx+0x58]

	// Ctype
	__asm mov ecx,dword ptr ds:[esi+0x2C]
	__asm mov dword ptr ds:[edi+0x01],ecx
	
	// EntityID
	__asm mov ecx,dword ptr ds:[esi+0x30]
	__asm mov dword ptr ds:[edi+0x05],ecx

	// ASPTR
	__asm mov esi,dword ptr ss:[ebp+0x0C]

	// Kind
	__asm movzx eax,word ptr ds:[esi]
	__asm mov word ptr ds:[edi+0x09],ax
	
	// Level
	__asm movzx eax,byte ptr ds:[esi+0x02]
	__asm mov byte ptr ds:[edi+0x0B],al
	
	// AffectTime
	__asm mov eax,dword ptr ds:[esi+0x03]
	__asm mov dword ptr ds:[edi+0x0C],eax
	
	// EventTime
	__asm mov eax,dword ptr ds:[esi+0x07]
	__asm mov dword ptr ds:[edi+0x10],eax
	
	// EventType
	__asm movzx eax,byte ptr ds:[esi+0x0B]
	__asm mov byte ptr ds:[edi+0x14],al
	
	// DurationTime
	__asm mov eax,dword ptr ds:[esi+0x0C]
	__asm mov dword ptr ds:[edi+0x15],eax
	
	// TargetEntityID
	__asm mov eax,dword ptr ds:[esi+0x10]
	__asm mov dword ptr ds:[edi+0x19],eax

	// Newadd
	__asm mov dword ptr ds:[edi+0x1D],0x0
	
	// EpochVector X
	__asm mov eax,dword ptr ds:[esi+0x14]
	__asm mov dword ptr ds:[edi+0x21],eax
	
	// EpochVector Y
	__asm mov eax,dword ptr ds:[esi+0x18]
	__asm mov dword ptr ds:[edi+0x25],eax

	// EpochVector Z
	__asm mov eax,dword ptr ds:[esi+0x1C]
	__asm mov dword ptr ds:[edi+0x29],eax

	// Damage
	__asm mov eax,dword ptr ss:[ebp+0x14]
	__asm mov dword ptr ds:[edi+0x2D],eax
	
	// Reason (0 Enable 1 Disable)
	__asm movzx eax,byte ptr ss:[ebp+0x10]
	__asm mov byte ptr ds:[edi+0x31],al

	// Check Skill 0x903B
	__asm movzx ecx, word ptr ds:[edi+0x09]
	__asm cmp ecx,0x903B
	__asm jnz NOAS903B

	// Title Message
	__asm push 0x33
	__asm mov edi, AFFECTSKILLEVENTEX_ADDRS
	__asm lea edx,dword ptr ss:[edi+0x32]
	__asm push edx
	__asm mov eax,dword ptr ss:[edi+0x05]
	__asm push eax
	__asm mov ecx,0xB58A9C
	__asm call TITLE_MESSAGE
	__asm mov dword ptr ss:[edi+0x2D],0x1
	__asm jmp SEND_ASEX

NOAS903B:
	__asm mov dword ptr ss:[edi+0x2D],0x2

SEND_ASEX:
	//Send Packet
	__asm mov edi, AFFECTSKILLEVENTEX_ADDRS
	__asm push 0x2
	__asm push 0x1
	__asm push 0x65
	__asm push edi
	__asm push 0x160D
	__asm mov edx, dword ptr ss:[ebp-0x7C]
	__asm mov ecx,dword ptr ds:[edx+0x58]
	__asm call ASSEND

	__asm jmp ASEXRET
}

int SaveAffectSkill(int Active)
{
	int i;
	int addrs;
	int CalAffectPTR;
	unsigned int CutTime;
	int pThis;
	int PlayerPTR;
	unsigned int CharID;
	short RaceType;
	int pAffectSkill = 0;
	int SkillCount = 0;
	int SkillID = 0;
	int SKOffset = 0;

	short Kind = 0;
	char SkillLevel = 0;
	unsigned int AffectTime = 0;
	unsigned int EventTime = 0;
	char EventType = 0;
	unsigned int DurationTime = 0;
	unsigned int TargetEntityID = 0;
	unsigned int EpochVectorX = 0;
	unsigned int EpochVectorY = 0;
	unsigned int EpochVectorZ = 0;

	unsigned int DBAffectTime = 0;

	int pSkillInfo = 0;
	int pSkillLevelIfno = 0;
	unsigned int SkillAffectTime = 0;
	
	__asm mov CalAffectPTR,ecx

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	if (PlayerPTR == 0) return 1;

	addrs = (DWORD)PlayerPTR + 0x2E;
	RaceType = *(reinterpret_cast<short*>(addrs));
	if (RaceType != 3) return 1;

	if (RaceType == 3)
	{
		for(i = 0; i < 100; i++ )
		{
			pThis = (DWORD)AFFECTSKILLSLOT_ADDRS + (i * 0x24);
			tagAffectSkillInit(pThis);
		}
	}

	pThis = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x4;
	tagAffectSkillInit(pThis);
	
	CutTime = GetCutTime();

	pThis = (DWORD)CalAffectPTR;
	SkillCount = GetCharAffectSkill(pThis , AFFECTSKILLSLOT_ADDRS, 100);

	for(i = 0; i < SkillCount; i++ )
	{
		// AffectSkill
		pAffectSkill = (DWORD)AFFECTSKILLSLOT_ADDRS + (i * 36);
		Kind =  *(reinterpret_cast<short*>(pAffectSkill));

		addrs = (DWORD)pAffectSkill + 0x2;
		SkillLevel = *(reinterpret_cast<char*>(addrs));

		addrs = (DWORD)pAffectSkill + 0x3;
		AffectTime = *(reinterpret_cast<unsigned int*>(addrs));

		addrs = (DWORD)pAffectSkill + 0x7;
		EventTime = *(reinterpret_cast<unsigned int*>(addrs));

		addrs = (DWORD)pAffectSkill + 0xB;
		EventType = *(reinterpret_cast<char*>(addrs));

		addrs = (DWORD)pAffectSkill + 0xC;
		DurationTime = *(reinterpret_cast<unsigned int*>(addrs));

		addrs = (DWORD)pAffectSkill + 0x10;
		TargetEntityID = *(reinterpret_cast<unsigned int*>(addrs));

		addrs = (DWORD)pAffectSkill + 0x14;
		EpochVectorX = *(reinterpret_cast<unsigned int*>(addrs));

		addrs = (DWORD)pAffectSkill + 0x18;
		EpochVectorY = *(reinterpret_cast<unsigned int*>(addrs));

		addrs = (DWORD)pAffectSkill + 0x1C;
		EpochVectorZ = *(reinterpret_cast<unsigned int*>(addrs));

		SkillID = (int)Kind & 0xffff;
		pSkillInfo = GetSkillInfo(SkillID);
		if (pSkillInfo != 0)
		{
			SKOffset = SkillLevel * 0x1A5;
			pSkillLevelIfno = (DWORD)pSkillInfo + SKOffset + 0x58;
			addrs = (DWORD)pSkillLevelIfno + 0x9;
			SkillAffectTime = *(reinterpret_cast<unsigned int*>(addrs));

			if ((SkillID > 0x9000) && (SkillID < 0x904C) || (SkillID > 0xA000) && (SkillID < 0xA100))
			{
				if (Active == 1)
				{
					if ((SkillID == 0x9006) || (SkillID == 0x900B) || (SkillID == 0x900E) || (SkillID == 0x9016) || (SkillID == 0x901D) || 
						(SkillID == 0x901E) || (SkillID == 0x902A) || (SkillID == 0x9033) || (SkillID == 0x903C) || ((SkillID > 0x903D) && (SkillID < 0x904C)) || 
						(SkillID == 0xA087) || (SkillID == 0xA088) || (SkillID == 0xA089) || (SkillID == 0xA08A) || (SkillID == 0xA08B) || 
						(SkillID == 0xA08D) || (SkillID == 0xA09D) || (SkillID == 0xA0C3) || ((SkillID > 0x908E) && (SkillID < 0x9097)))
					{
						pThis = (DWORD)CalAffectPTR;
						DeleteCharAffectSkill(pThis, SkillID);
					}
					else
					{
						if (SkillLevel < 8)
						{
							if (pSkillLevelIfno != 0)
							{
								if (SkillAffectTime > 60000)
								{
									// DBTASK_SAVEAFFECTSKILL
									pThis = (DWORD)PlayerPTR;
									addrs = (DWORD)pThis + 0x30;
									CharID = *(reinterpret_cast<unsigned int*>(addrs));
									addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS;
									*(reinterpret_cast<unsigned int*>(addrs)) = CharID;
									
									if (AffectTime > DurationTime ) AffectTime = DurationTime;
									DBAffectTime = DurationTime - AffectTime;

									addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x4;
									*(reinterpret_cast<short*>(addrs)) = (short)SkillID;
									addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x6;
									*(reinterpret_cast<char*>(addrs)) = SkillLevel;
									addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x7;
									*(reinterpret_cast<unsigned int*>(addrs)) = DBAffectTime;
									addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0xB;
									*(reinterpret_cast<unsigned int*>(addrs)) = EventTime;
									addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0xF;
									*(reinterpret_cast<char*>(addrs)) = EventType;
									addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x10;
									*(reinterpret_cast<unsigned int*>(addrs)) = DurationTime;
									addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x14;
									*(reinterpret_cast<unsigned int*>(addrs)) = TargetEntityID;
									addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x18;
									*(reinterpret_cast<unsigned int*>(addrs)) = EpochVectorX;
									addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x1C;
									*(reinterpret_cast<unsigned int*>(addrs)) = EpochVectorY;
									addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x20;
									*(reinterpret_cast<unsigned int*>(addrs)) = EpochVectorZ;

									SendPacketEX(0x7F23A0, 0x4A13, DBTASK_SAVEAFFECTSKILL_ADDRS, 0x24);
								}
							}
						}
					}
				}
				// Active 0
				else
				{
					if (SkillLevel < 8)
					{
						if (pSkillLevelIfno != 0)
						{
							if (SkillAffectTime > 60000)
							{
								// DBTASK_SAVEAFFECTSKILL
								pThis = (DWORD)PlayerPTR;
								addrs = (DWORD)pThis + 0x30;
								CharID = *(reinterpret_cast<unsigned int*>(addrs));
								addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS;
								*(reinterpret_cast<unsigned int*>(addrs)) = CharID;

								if (AffectTime > DurationTime ) AffectTime = DurationTime;
								DBAffectTime = DurationTime - AffectTime;

								addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x4;
								*(reinterpret_cast<short*>(addrs)) = (short)SkillID;
								addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x6;
								*(reinterpret_cast<char*>(addrs)) = SkillLevel;
								addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x7;
								*(reinterpret_cast<unsigned int*>(addrs)) = DBAffectTime;
								addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0xB;
								*(reinterpret_cast<unsigned int*>(addrs)) = EventTime;
								addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0xF;
								*(reinterpret_cast<char*>(addrs)) = EventType;
								addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x10;
								*(reinterpret_cast<unsigned int*>(addrs)) = DurationTime;
								addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x14;
								*(reinterpret_cast<unsigned int*>(addrs)) = TargetEntityID;
								addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x18;
								*(reinterpret_cast<unsigned int*>(addrs)) = EpochVectorX;
								addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x1C;
								*(reinterpret_cast<unsigned int*>(addrs)) = EpochVectorY;
								addrs = (DWORD)DBTASK_SAVEAFFECTSKILL_ADDRS + 0x20;
								*(reinterpret_cast<unsigned int*>(addrs)) = EpochVectorZ;

								SendPacketEX(0x7F23A0, 0x4A13, DBTASK_SAVEAFFECTSKILL_ADDRS, 0x24);
							}
						}
					}
				}
				// Active 0 End
			}
		}
	}
	//End
	return 1;
}
