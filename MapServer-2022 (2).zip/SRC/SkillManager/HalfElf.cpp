#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std;


// Skill 544 0x220 Brandish Kick
void BrandishKickAttackForce(int PlayerPTR, int AttackTypePTR, int DamagePTR, int ParamsPTR)
{
	int addrs;
	int Damage;
	int KickAttackForce;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	KickAttackForce = BioticBaseGetAbility(PlayerPTR, 0x21) * Param1 / 100;

	// Settings SkillType
	addrs = (DWORD)AttackTypePTR;
	*(reinterpret_cast<int*>(addrs)) = 2;

	addrs = (DWORD)DamagePTR;
	Damage = *(reinterpret_cast<int*>(addrs));

	Damage += KickAttackForce;

	addrs = (DWORD)DamagePTR;
	*(reinterpret_cast<int*>(addrs)) = Damage;
}
// Affect
// Skill 515 0x203 Fatal
void Fatal(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x61, Param1, Active);
}

// Skill 562 0x232 Crossbow Mastery
void CrossbowMastery(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x2B, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x110, Param2, Active);
	QualitiesCalOption(CalAffectPTR, 0x51, Param3, Active);
}

// Skill 567 0x237 Siege Shot
void SiegeShot(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;
	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x33, Param1, Active);	
}

// Skill 569 0x239 Kaels Bolt
void KaelsBolt(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x38, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x86, Param3, Active);
}
// Skill 572 0x23C Rank Shot
void RankShotA(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// CA_PVP_ATTACK_RATE 0x6D
	QualitiesCalOption(CalAffectPTR, 0xF4, Param1, Active);
}
// Skill 574 0x23E Premium Shot
void PremiumShotA(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x73, Param1, Active);
}
// Skill 583 0x247 Death Chaser
/***
void DeathChaser(int CalAffectPTR, int ParamsPTR, int Active)
{
}
***/
// Skill 547 0x223 Bow Mastery
void BowMastery(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x2C, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x110, Param2, Active);
}
// Skill 550 0x226 Sharp Melee
void SharpMelee(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x36, Param1, Active);
	//QualitiesCalOption(CalAffectPTR, 0x89, Param2, Active);
}
// Skill 553 0x229 Kaels Arrow
void KaelsArrow(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x38, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x51, Param2, Active);
}
// Skill 556 0x22C Ghost Arrow
void GhostArrow(int CalAffectPTR, int ParamsPTR, int Active)
{
	//int RemainderRate;
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// CA_DAMAGE_RATE 0x2B
	//RemainderRate = 0 - Param1;
	QualitiesCalOption(CalAffectPTR, 0xF1, Param1, Active);
}
// Skill 557 0x22D Premium Shot
void PremiumShotB(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x8E, Param1, Active);
}
// Skill 559 0x22F Rank Shot
void RankShotB(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	// CA_PVP_DEFENCE_RATE 0x6E
	QualitiesCalOption(CalAffectPTR, 0xF5, Param1, Active);
}
// Skill 598 0x256 Cataclysm
void Cataclysm(int CalAffectPTR, int ParamsPTR, int Active)
{
	int Param1, Param2, Param3, Param4, Param5;

	Param1 = GetParams(ParamsPTR, 1);
	Param2 = GetParams(ParamsPTR, 2);
	Param3 = GetParams(ParamsPTR, 3);
	Param4 = GetParams(ParamsPTR, 4);
	Param5 = GetParams(ParamsPTR, 5);

	QualitiesCalOption(CalAffectPTR, 0x36, Param1, Active);
	QualitiesCalOption(CalAffectPTR, 0x33, Param1, Active);
}
