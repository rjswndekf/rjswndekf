#include <SkillManager.h>
//#include <MapFunctions.h>

using namespace std; 

int CALDMG_RET_ORIG = 0x00529BF8;
int CALDMG_RET_CLCATK = 0x0052B975;

int CALDMG_THIS;
int CALDMG_DMGPTR;
int CALDMG_PARAMPTR;

/*** Aesir Skill Funs ***/
int CAL_AESIR_BERM = 0x0052ACE2;

// int CalSkillDamage(IntPtr BC, IntPtr SAO, int Damage)
void CalSkillDamage(int BC, int SAO, int Damage)
{
	// Kind
	__asm mov dword ptr ss:[ebp-0x2FC],edx

	// pAttack (0x00B35568)
	__asm mov ecx, dword ptr ss:[ebp-0x2F4]
	__asm mov CALDMG_THIS, ecx

	// Damage Pointer
	__asm lea ecx,dword ptr ss:[ebp+0x10]
	__asm mov CALDMG_DMGPTR, ecx

	// Params Pointer
	__asm mov ecx,dword ptr ss:[ebp-0x10]
	__asm mov CALDMG_PARAMPTR, ecx

	CalSkillAttackDamage(CALDMG_THIS, BC, SAO, CALDMG_PARAMPTR, CALDMG_DMGPTR);

	__asm jmp eax
}

// pPlayerp = *(Attack +0x1CC) pTarget = *(*(Attack +0x1D4))
// pTarget = *(BC +0x2C)
// Kind = *(SAO +0x4C)
int CalSkillAttackDamage(int pAttack, int BC, int SAO, int pParams, int pDamage)
{
	int RetAddrs = CALDMG_RET_ORIG;
	int addrs = 0;
	int Kind = 0;

	addrs = (DWORD)SAO + 0x4C;
	Kind = *(reinterpret_cast<unsigned short*>(addrs));
	
	switch(Kind)
	{
		/*************** Human ***************/
		// Skill 135 0x87 Assault Crash
		case 0x87:
		{
			AssaultCrash(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		/**************** Elf ****************/
		//Skill 258 0x102 Holy Light
		case 0x102:
		{
			HolyLight(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		//Skill 289 0x121 Divine Beam
		case 0x121:
		{
			DivineBeam(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 310 0x136 Marea's Anger
		case 0x136:
		{
			MareasAnger(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		/*************** Dhan ****************/
		// Skill 1077 0x435 Suicide
		case 0x435:
		{
			Suicide(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		/*************** Dekan ***************/
		// Skill 16456 0x4048 Wide Forefoot Swing
		case 0x4048:
		{
			WideForefootSwing(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		/************** Trinity **************/
		// Skill 8193 0x2001 Pentagram of Light
		case 0x2001:
		{
			PentagramOfLight(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 8194 0x2002 Darkness Calling
		case 0x2002:
		{
			DarknessCalling(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 8204 0x200C Dark Side Trace
		case 0x200C:
		{
			DarkSideTrace(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 8212 0x2014 Dark Side Zone
		case 0x2014:
		{
			DarkSideZone(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 8210 0x2012 Mana Bombing
		case 0x2012:
		{
			ManaBombing(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 8217 0x2019 Lightning Swift
		case 0x2019:
		{
			LightningSwift(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 8238 0x202E Absolute Flash
		case 0x202E:
		{
			AbsoluteFlash(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 8220 0x201C Wound of Restriction
		case 0x201C:
		{
			WoundOfRestriction(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 8224 0x2020 Penetrating Darkness
		case 0x2020:
		{
			PenetratingDarkness(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 8227 0x2023 Windy Chain
		case 0x2023:
		{
			WindyChain(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 8230 0x2026 Thunderstroke
		case 0x2026:
		{
			Thunderstroke(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 8233 0x2029 Airburst
		case 0x2029:
		{
			Airburst(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 8252 0x203C Distortion Claw - Chaos
		case 0x203C:
		{
			DistortionClawChaos(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 8253 0x203D Dimensional Scar
		case 0x203D:
		{
			DimensionalScar(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		/*************** Aesir* **************/
		// Skill 16525 0x408D Intelligence Beam
		case 0x408D:
		{
			RetAddrs = CAL_AESIR_BERM;
		}
		break;
		// Skill 16538 0x409A MarshMaze
		case 0x409A:
		{
			MarshMazeCalDamage(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 16545 0x40A1 Whispel
		case 0x40A1:
		{
			WhispelCalDamage(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 16556 0x40AC LastWhisper
		case 0x40AC:
		{
			LastWhisperCalDamage(pAttack, BC, pDamage, pParams);
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
		// Skill 16561 0x40B1 Shield Strike
		case 0x40B1:
		{
			RetAddrs = CALDMG_RET_CLCATK;
		}
		break;
	}

	return RetAddrs;
}