#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std;

int AFDEPS_RET_ORIG = 0x004F9056;
int AFDEPS_RET_ENABLE = 0x004F9FDF;
int AFDEPS_RET_4093 = 0x004F995B;

int SEPARATIONDEP_RET = 0x004F9FE1;

int ATKINFO_FUN = 0x0052FF00;
int ATKINFO_RET = 0x0052BF6B;
int ATKINFO_INFOPTR;
int ATKINFO_THIS;

int ATKCOUNT_RET_ORIG = 0x004D864B;
int ATKCOUNT_RET_SK2001 = 0x004D8743;

int SKILLSET_RET_ORIG = 0x004A18D9;
int SKILLSET_RET_AFFECT = 0x004A19D7;
int SKILLSET_RET_ATTACK = 0x004A1D56;

int HEROIC_RETORIG = 0x0069800F;
int HEROIC_RETEND = 0x00698245;

int AFCLICK_KIND;
int AFCLICK_CALAFPTR;

int SETATKAF_RET_ORIG = 0x00530CAC;
int SETATKAF_RET_ENAF = 0x005322DD;

int SKILLDEF_RETORIG = 0x0052BA49;
int SKILLDEF_RETEXIT = 0x0052BAAF;

/******* ASM Funs *******/
extern int GETSKILLLEVELINFO;
extern int CHECKASENABLE;
extern int GETABILITY;

// Dekan Skill 0x4048 / 0x402F
void AffcetDepends()
{
	// EAX = Kind
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov dword ptr ss:[ebp-0x68],eax

	// Skill 16431 0x402F Heavy Wave
	__asm cmp eax, 0x402F
	__asm je SKILL_ENABLE
	// Skill 16456 0x4048 Wide Forefoot Swing
	__asm cmp eax, 0x4048
	__asm je SKILL_ENABLE

	// Skill 16412 0x401C Soul Divider (Original Need To Skill Depends)
	__asm cmp eax, 0x401C
	__asm je SKILL_ENABLE
	
	// Skill 16531 0x4093 Incarnation
	__asm cmp eax, 0x4093
	__asm je SKILL_4093

	__asm jmp AFDEPS_RET_ORIG

SKILL_ENABLE:
	__asm jmp AFDEPS_RET_ENABLE
	
SKILL_4093:
	__asm jmp AFDEPS_RET_4093

}
// Dekan Skill 0x400D Patch
void SeparationDependProcess()
{
	__asm push 0x4004
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm add ecx,0x100
	__asm call CHECKASENABLE
	__asm test eax,eax
	__asm jnz SKILL_ENABLE

	__asm push 0x4056
	__asm mov ecx,dword ptr ss:[ebp-0x64]
	__asm add ecx,0x100
	__asm call CHECKASENABLE
	__asm test eax,eax
	__asm je SKILL_DISABLE

SKILL_ENABLE:
	__asm xor eax,eax
	__asm jmp SEPARATIONDEP_RET

SKILL_DISABLE:
	__asm mov eax,-0x1B
	__asm jmp SEPARATIONDEP_RET

}

// Trinity Mer Base Damage Fix
void AttackInfoProc()
{
	// Original Code
	__asm push eax
	__asm mov ecx,dword ptr ss:[ebp-0x274]
	__asm call ATKINFO_FUN
	__asm mov edx,dword ptr ss:[ebp-0x274]
	__asm mov byte ptr ds:[edx+0x14],al

	//Check Ctype
	__asm mov eax,dword ptr ss:[ebp-0x274]
	__asm mov ecx,dword ptr ds:[eax+0x1CC]
	__asm mov edx,dword ptr ds:[ecx+0x2C]
	__asm cmp edx,0x34035
	__asm jne RET_TARGET
	
	// AttackInfoPTR
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov ATKINFO_INFOPTR,eax
	// DynamicPTR
	__asm mov ecx,dword ptr ss:[ebp-0x274]
	__asm mov ATKINFO_THIS,ecx
	
	AttackBaseDamage(ATKINFO_THIS, ATKINFO_INFOPTR);
	
RET_TARGET:
	__asm jmp ATKINFO_RET
}

void AttackBaseDamage(int DynamicPTR, int AttackInfoPTR)
{
	int addrs;
	int PlayerPTR;
	int CType;
	int BaseDamage;
	unsigned short Kindex;
	unsigned int MerAttackBaseDamage;
	
	if (DynamicPTR != 0)
	{
		addrs = (DWORD)DynamicPTR + 0x1CC;
		PlayerPTR = *(reinterpret_cast<int*>(addrs));
		if (PlayerPTR != 0)
		{
			addrs = (DWORD)DynamicPTR + 0x4;
			CType = *(reinterpret_cast<int*>(addrs));
	
			addrs = (DWORD)AttackInfoPTR + 0x4C;
			Kindex = *(reinterpret_cast<unsigned short*>(addrs));
	
			BaseDamage = (DWORD)AttackInfoPTR + 0x48;

			// Trinity Mer
			if (CType == 0x34035)
			{
				// Normal Attack
				if (Kindex == 0x0)
				{
					// Base Damage = STR + INT + (LV * 3)
					MerAttackBaseDamage = BioticBaseGetAbility(PlayerPTR, 0x20) + BioticBaseGetAbility(PlayerPTR, 0x22) + (BioticBaseGetAbility(PlayerPTR, 0x15) *3);
					*(reinterpret_cast<unsigned int*>(BaseDamage)) = MerAttackBaseDamage;
				}
			}
		}
	}
	
}

// Trinity Skill Pentagram of Light Attack Count
void PentagramOfLightAttackCount()
{
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov ax,word ptr ds:[edx+0x18]
	__asm mov word ptr ss:[ebp-0x7A],ax
	__asm movzx ecx,word ptr ss:[ebp-0x7A]
	__asm cmp ecx,0x2001
	__asm je SK_2001

	__asm jmp ATKCOUNT_RET_ORIG

SK_2001:
	__asm mov edx,dword ptr ss:[ebp+0x8]
	__asm mov eax,dword ptr ds:[edx+0x34]
	__asm mov dword ptr ss:[ebp-0x34],eax
	__asm mov dword ptr ss:[ebp-0x30],0x0
	__asm mov ecx,dword ptr ss:[ebp+0x8]
	__asm call GETSKILLLEVELINFO
	__asm mov ecx,dword ptr ds:[eax+0x19]

	__asm jmp ATKCOUNT_RET_SK2001
}

// Skill Setting Type
void SkillSetType()
{
	//Kind
	__asm movzx ecx,word ptr ss:[ebp-0x2E2]

	//__asm mov eax,dword ptr ss:[ebp-0x3F4]
	//__asm mov CalAffectPTR,eax

	// Skill 8232 Distortion Claw - Oblivion
	__asm cmp ecx, 0x2028
	__asm je AFFECT_TYPE

	// Skill 8252 Distortion Claw - Chaos
	__asm cmp ecx, 0x203C
	__asm je ATTACK_TYPE

	// Return Original
	__asm jmp SKILLSET_RET_ORIG

AFFECT_TYPE:
	__asm jmp SKILLSET_RET_AFFECT

ATTACK_TYPE:
	__asm jmp SKILLSET_RET_ATTACK

}

// Trinity Dormant Power Enable Fix
void AffectSkillON(int PlayerPTR)
{
	int addrs;
	int CalAffectPTR;
	int CType;
	int State;
	
	if (PlayerPTR != 0)
	{
		CalAffectPTR = (DWORD)PlayerPTR + 0x100;
	
		addrs = (DWORD)PlayerPTR + 0x2C;
		CType = *(reinterpret_cast<int*>(addrs));
	
		// Trinity
		if ((CType == 213045) || (CType == 213046) || (CType == 213047))
		{
			// Skill 8197 Dormant Power
			State = CheckAffectStatus(CalAffectPTR, 0x2005);
			if (State == 0)
			{
				EnableAffectSkill(CalAffectPTR, 0x2005);
			}
		}
	}
}

// AffectSkill Disable Fix
void AffectSkillOFF(int PlayerPTR)
{
	int addrs;
	int CalAffectPTR;
	int CType;
	int State;
	
	if (PlayerPTR != 0)
	{
		CalAffectPTR = (DWORD)PlayerPTR + 0x100;
	
		addrs = (DWORD)PlayerPTR + 0x2C;
		CType = *(reinterpret_cast<int*>(addrs));

		// Trinity
		if ((CType == 213045) || (CType == 213046) || (CType == 213047))
		{
			// Skill 8197 Dormant Power
			State = CheckAffectStatus(CalAffectPTR, 0x2005);
			if (State == 1)
			{
				EndAffectSkill(CalAffectPTR, 0x2005, 0x1, 0x0, 0x0);
			}
		}
	}

}


void AffcetClickProc()
{
	// Kind
	__asm movzx eax,word ptr ss:[ebp+0x8]
	__asm mov AFCLICK_KIND,eax
	// CalAffectPTR
	__asm mov ecx,dword ptr ss:[ebp-0x1C]
	__asm mov AFCLICK_CALAFPTR,ecx
	
	AffcetClickCheck(AFCLICK_CALAFPTR, AFCLICK_KIND);

	// Original Code
	__asm mov esp,ebp
	__asm pop ebp
	__asm retn 0x4
}

void AffcetClickCheck(int CalAffectPTR, int Kind)
{
	int addrs;
	int PlayerPTR;
	int CType;
	int State;

	addrs = (DWORD)CalAffectPTR + 0x58;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	
	if (PlayerPTR != 0)
	{
		addrs = (DWORD)PlayerPTR + 0x2C;
		CType = *(reinterpret_cast<int*>(addrs));

		// Trinity
		if ((CType == 213045) || (CType == 213046) || (CType == 213047))
		{
			// Skill 8197 Dormant Power
			if (Kind == 0x2005)
			{
				State = CheckAffectStatus(CalAffectPTR, 0x2005);
				if (State == 0)
				{
					EnableAffectSkill(CalAffectPTR, 0x2005);
				}
			}
		}
	}
}

void StartHeroicPower()
{
	__asm mov eax,dword ptr ss:[ebp+0x8]
	__asm mov dword ptr ss:[ebp-0x8],eax

	__asm cmp eax,0x390C2
	__asm je AESIR_EMBLA
	__asm cmp eax,0x39046
	__asm je AESIR_EMBLA

	__asm cmp eax,0x390C3
	__asm je AESIR_WHISPER
	__asm cmp eax,0x39047
	__asm je AESIR_WHISPER

	__asm jmp HEROIC_RETORIG

AESIR_EMBLA:
	__asm mov ax,0x40B0
	__asm jmp HEROIC_RETEND

AESIR_WHISPER:
	__asm mov ax,0x40BF
	__asm jmp HEROIC_RETEND

}

void TrinityPoints(int PlayerPTR, int Kind)
{
	int CalAffectPTR;
	int State = 0;
	int GenTP;
	
	if (PlayerPTR != 0)
	{
		CalAffectPTR = (DWORD)PlayerPTR + 0x100;

		// Skill 8200 0x2008 Trinity Force (Trinity Rumir)
		State = CheckAffectStatus(CalAffectPTR, 0x2008);
		if (State == 1)
		{
			if ((Kind == 0) || (Kind == 0x2009))
			{
				// Generate TP Value On Normal Attack
				GenTP = GetAffectOptionValue(CalAffectPTR, 0xFA);
				if (GenTP < 0) GenTP = 0;
				IncTP(PlayerPTR, GenTP);
				SendTPBroadcast(PlayerPTR);
			}
		}

		// Skill 8221 0x201D Trinity Force (Trinity Noir)
		State = CheckAffectStatus(CalAffectPTR, 0x201D);
		if (State == 1)
		{
			if ((Kind == 0) || (Kind == 0x201E))
			{
				// Generate TP Value On Normal Attack
				GenTP = GetAffectOptionValue(CalAffectPTR, 0xFA);
				if (GenTP < 0) GenTP = 0;
				IncTP(PlayerPTR, GenTP);
				SendTPBroadcast(PlayerPTR);
			}
		}
	}
}

// Set Attack Skill Add Affect
void SetAttackAffect()
{
	// Original Code
	__asm mov dword ptr ss:[ebp-0x4],0x0
	
	// Kind
	__asm movzx eax,word ptr ss:[ebp+0xC]

	// Skill 8220 Wound of Restriction
	__asm cmp eax, 0x201C
	__asm je EnableAffect
	// Skill 8222 0x201E Thorns Whip
	__asm cmp eax, 0x201E
	__asm je EnableAffect	
	// Skill 8227 Windy Chain
	__asm cmp eax, 0x2023
	__asm je EnableAffect
	// Skill 8230 Thunderstroke
	__asm cmp eax, 0x2026
	__asm je EnableAffect
	// Skill 8252 Distortion Claw - Chaos
	__asm cmp eax, 0x203C
	__asm je EnableAffect
	// Skill 8253 Dimensional Scar
	__asm cmp eax, 0x203D
	__asm je EnableAffect
	// Skill 16545 0x40A1 Whispel
	__asm cmp eax, 0x40A1
	__asm je EnableAffect

	// Return Original
	__asm jmp SETATKAF_RET_ORIG

EnableAffect:
	__asm mov dword ptr ss:[ebp-0x4],0x1
	__asm mov eax, 0x1

	__asm jmp SETATKAF_RET_ENAF

}

// Check Target Skill Defense
void SkillDefenseCheck()
{
	// Kind
	__asm mov ecx,dword ptr ss:[ebp+0xC]
	__asm movzx edx,word ptr ds:[ecx+0x4C]

	// Blazing
	__asm cmp edx, 0x4A81
	__asm je RET_EXIT
	// Frozen
	__asm cmp edx, 0x4A82
	__asm je RET_EXIT
	// Darkness
	__asm cmp edx, 0x4A83
	__asm je RET_EXIT
	// Divine
	__asm cmp edx, 0x4A84
	__asm je RET_EXIT
	// Blazing
	__asm cmp edx, 0x8001
	__asm je RET_EXIT
	// Frozen
	__asm cmp edx, 0x8008
	__asm je RET_EXIT
	// Darkness
	__asm cmp edx, 0x8005
	__asm je RET_EXIT
	// Divine
	__asm cmp edx, 0x8006
	__asm je RET_EXIT

	// Get Target Skill Defense
	__asm push 0x62
	__asm mov ecx,dword ptr ss:[ebp-0x4]
	__asm call GETABILITY
	__asm jmp SKILLDEF_RETORIG

RET_EXIT:
	__asm jmp SKILLDEF_RETEXIT
}
