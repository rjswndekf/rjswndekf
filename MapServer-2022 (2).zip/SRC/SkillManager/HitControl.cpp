#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 

int HIT_ATTACK;
int HIT_RET = 0x0052965C;

void HitChance(int BC, int SAO)
{
	__asm mov dword ptr ss:[ebp-0x6C],ecx
	__asm mov HIT_ATTACK,ecx
	
	HitControl(HIT_ATTACK, BC, SAO);

	// Orig Code
	__asm mov eax,dword ptr ss:[ebp+0xC]
	__asm jmp HIT_RET
}

/*** SAO + 0x40 Hit Rate ***/
void HitControl(int pAttack, int BC, int SAO)
{
	int addrs = 0;
	int PlayerPTR = 0;
	int TargetPTR = 0;
	int pThis = 0;
	int SelfCalAffectPTR = 0;
	int TargetCalAffectPTR = 0;
	int Kind = 0;
	int State = 0;
	
	addrs = (DWORD)pAttack + 0x1CC;
	PlayerPTR = *(reinterpret_cast<int*>(addrs));
	SelfCalAffectPTR = (DWORD)PlayerPTR + 0x100;

	addrs = (DWORD)pAttack + 0x1D4;
	pThis = *(reinterpret_cast<int*>(addrs));
	addrs = (DWORD)pThis;
	TargetPTR = *(reinterpret_cast<int*>(addrs));
	TargetCalAffectPTR = (DWORD)TargetPTR + 0x100;

	addrs = (DWORD)SAO + 0x4C;
	Kind = *(reinterpret_cast<unsigned short*>(addrs));

	// Skill 4177 0x1051 Spell Extension
	State = CheckAffectStatus(SelfCalAffectPTR, 0x1051);
	if (State == 1)
	{
		if (Kind != 0)
		{
			// Max Hit Rate
			addrs = (DWORD)SAO + 0x40;
			*(reinterpret_cast<unsigned short*>(addrs)) = 0x7FFF;
		}
	}
}
