#include <SkillManager.h>
#include <MapFunctions.h>

using namespace std; 

int REVIVE_CHECK_RETORG = 0x004FCFF0;
int REVIVE_CHECK_SK4087 = 0x004FD052;
int REVIVE_CHECK_SK4093 = 0x004FD14B;

int RELEASE_TARGET_RETORG = 0x004D90CA;
int RELEASE_TARGET_SK4087 = 0x004D9116;
int RELEASE_TARGET_SK4093 = 0x004D9116;

int CALREVIVE_RETORG = 0x00435C9B;
int CALREVIVE_SK4087 = 0x00435D73;
int CALREVIVE_SK4093 = 0x00435DBD;

int CHECKREVIVE_SKITEM_RETORIG = 0x0049EF6A;
int CHECKREVIVE_SKITEM_SK4093 = 0x0049EFAA;

int USE_REVIVESKITEM_RETORIG = 0x004AB4FB;
int USE_REVIVESKITEM_SK4093 = 0x004AB5CB;

void ReviveCheckTarget()
{
	// Original Code
	__asm mov dword ptr ss:[ebp-0x2A0],eax

	// Skill 16519 0x4087 Revive
	__asm cmp dword ptr ss:[ebp-0x2A0],0x4087
	__asm je SK_4087

	// Skill 16531 0x4093 Incarnation
	__asm cmp dword ptr ss:[ebp-0x2A0],0x4093
	__asm je SK_4093

	__asm jmp REVIVE_CHECK_RETORG

SK_4087:
	__asm jmp REVIVE_CHECK_SK4087

SK_4093:
	__asm jmp REVIVE_CHECK_SK4093

}

void ReleaseTargetStateOfDeath()
{
	// Original Code
	__asm mov dword ptr ss:[ebp-0x198],edx

	// Skill 16519 0x4087 Revive
	__asm cmp dword ptr ss:[ebp-0x198],0x4087
	__asm je SK_4087

	// Skill 16531 0x4093 Incarnation
	__asm cmp dword ptr ss:[ebp-0x198],0x4093
	__asm je SK_4093

	__asm jmp RELEASE_TARGET_RETORG

SK_4087:
	__asm jmp RELEASE_TARGET_SK4087

SK_4093:
	__asm jmp RELEASE_TARGET_SK4093
}

void CalReviveLifeMana()
{
	// Original Code
	__asm mov dword ptr ss:[ebp-0x300],eax

	// Skill 16519 0x4087 Revive
	__asm cmp dword ptr ss:[ebp-0x300],0x4087
	__asm je SK_4087

	// Skill 16531 0x4093 Incarnation
	__asm cmp dword ptr ss:[ebp-0x300],0x4093
	__asm je SK_4093

	__asm jmp CALREVIVE_RETORG

SK_4087:
	__asm jmp CALREVIVE_SK4087

SK_4093:
	__asm jmp CALREVIVE_SK4093
}

void CheckReviveSkillItem()
{
	// Original Code
	__asm mov dword ptr ss:[ebp-0x218],eax

	// Skill 16531 0x4093 Incarnation
	__asm cmp dword ptr ss:[ebp-0x218],0x4093
	__asm je SK_4093

	__asm jmp CHECKREVIVE_SKITEM_RETORIG

SK_4093:
	__asm jmp CHECKREVIVE_SKITEM_SK4093
}

void UseItemSkillReviveScroll()
{
	// Original Code
	__asm movzx ecx,word ptr ss:[ebp-0x1E]
	__asm mov dword ptr ss:[ebp-0x34],ecx

	// Skill 16531 0x4093 Incarnation
	__asm cmp dword ptr ss:[ebp-0x34],0x4093
	__asm je SK_4093

	__asm jmp USE_REVIVESKITEM_RETORIG

SK_4093:
	__asm jmp USE_REVIVESKITEM_SK4093
}