#include <Scenegraph.h>
#include <MapFunctions.h>

using namespace std;

int TAGASP1_RET = 0x004A9859;
int TAGASP2_RET = 0x004A9872;
int TAGASP3_RET = 0x004A9896;
int TAGASP4_RET = 0x005249D3;

int LVINFO_PLAYER;
int LVINFO_RET = 0x00524D57;

/******* ASM Funs *******/
extern int GETABILITY;

// 2021 RCM_MAP_NEWENTITY_PLAYER 0x1209 Patch
void TagAffectSkillP1()
{
	__asm mov eax,0x24
	__asm mul edi
	__asm mov edi,dword ptr ss:[ebp+0x8]
	__asm add edi, eax

	__asm jmp TAGASP1_RET
	
}

void TagAffectSkillP2()
{
	__asm mov eax,0x24
	__asm mul edx
	__asm mov edx,dword ptr ss:[ebp+0x8]

	__asm jmp TAGASP2_RET
}

void TagAffectSkillP3()
{
	__asm mov eax,0x24
	__asm mul edx
	__asm mov edx,dword ptr ss:[ebp+0x8]

	__asm jmp TAGASP3_RET
}

void TagAffectSkillSize()
{
	__asm movzx edx,byte ptr ds:[edx+0xD4] //Affect Skill Count
	__asm mov eax,0x24
	__asm mul edx

	__asm jmp TAGASP4_RET

}

void GetCharLevelInfo()
{
	__asm mov ecx,dword ptr ss:[ebp-0xF4]
	__asm mov LVINFO_PLAYER, ecx

	// Char Level +0x30
	GetCharAllLevel(LVINFO_PLAYER);

	__asm mov ecx,dword ptr ss:[ebp-0x108]
	__asm mov word ptr ds:[ecx+0x30],ax

	// Char Trans State +0xE7 (2021)
	BioticBaseGetAbility(LVINFO_PLAYER, 0x76);
	__asm mov ecx,dword ptr ss:[ebp-0x108]
	__asm mov byte ptr ds:[ecx+0xE7],al

	// VIP Level +0xE8 = 4 (2021)
	BioticBaseGetAbility(LVINFO_PLAYER, 0x90);
	__asm mov ecx,dword ptr ss:[ebp-0x108]
	__asm mov byte ptr ds:[ecx+0xE8],al

	// Original Code
	// Packet Size
	__asm mov eax,dword ptr ss:[ebp-0xFC]
	__asm jmp LVINFO_RET
}
